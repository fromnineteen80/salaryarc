# RELATE Variable Inventory

**Purpose:** Complete list of all measured outputs from the scoring system  
**Total Variables:** 256+ discrete data points per user

---

## MODULE 1: What You Want (scoreModule1)

### Top-Level Outputs
| Variable | Type | Range | Description |
|----------|------|-------|-------------|
| gender | string | 'M' or 'W' | User gender |
| code | string | 4 letters | Persona code (e.g., ACFH) |
| keyDriver.dimension | string | physical/social/lifestyle | Strongest non-values dimension |
| keyDriver.strength | number | 0-100 | How strong the key driver is |
| keyDriver.confidence | string | high/moderate/low | Confidence in driver identification |
| keyDriver.coDriver | string/null | dimension name | Second driver if close |
| flags | array | strings | Consistency/balance flags |

### Per-Dimension Outputs (×4 dimensions = 28 variables)
| Variable | Type | Range | Description |
|----------|------|-------|-------------|
| dimensions.{dim}.poleAScore | number | raw | Sum of pole A responses |
| dimensions.{dim}.poleBScore | number | raw | Sum of pole B responses |
| dimensions.{dim}.direction | string | 'A' or 'B' | Which pole won |
| dimensions.{dim}.strength | number | 0-100 | How strongly |
| dimensions.{dim}.flexibility | string | high/moderate/low | How flexible |
| dimensions.{dim}.assignedPole | string | pole name | e.g., "Beauty", "Thrill" |
| dimensions.{dim}.consistency.poleA | object | variance + rating | Response consistency |

**M1 Total: ~35 discrete variables**

---

## MODULE 2: Who You Are (scoreModule2)

### Top-Level Outputs
| Variable | Type | Range | Description |
|----------|------|-------|-------------|
| gender | string | 'M' or 'W' | User gender |
| code | string | 4 letters | Persona code |
| keyDriver.dimension | string | dimension name | Strongest dimension |
| keyDriver.pole | string | pole name | The pole (e.g., "Presence") |
| keyDriver.strength | number | 0-100 | Strength |
| overallSelfPerceptionGap.average | number | 0-3+ | Average gap across dimensions |
| overallSelfPerceptionGap.interpretation | string | aligned/moderate/significant | Overall gap reading |
| overallSelfPerceptionGap.mismatchedDimensions | array | dimension names | Which dimensions have gaps |
| flags | array | objects | Self-perception and identity flags |

### Per-Dimension Outputs (×4 dimensions = 32+ variables)
| Variable | Type | Range | Description |
|----------|------|-------|-------------|
| dimensions.{dim}.poleAScore | number | raw | Pole A sum |
| dimensions.{dim}.poleBScore | number | raw | Pole B sum |
| dimensions.{dim}.assignedPole | string | 'A' or 'B' | Direction |
| dimensions.{dim}.poleName | string | name | e.g., "Maturity" |
| dimensions.{dim}.strength | number | 0-100 | Strength |
| dimensions.{dim}.selfPerceptionGap.value | number | 0-3+ | Gap magnitude |
| dimensions.{dim}.selfPerceptionGap.directSays | string | interpretation | What direct Qs say |
| dimensions.{dim}.selfPerceptionGap.behavioralSays | string | interpretation | What behavioral Qs say |
| dimensions.{dim}.selfPerceptionGap.perceptionMismatch | boolean | true/false | Is there a mismatch? |
| dimensions.{dim}.selfPerceptionGap.interpretation | string | aligned/moderate/significant | Per-dimension read |

**M2 Total: ~45 discrete variables**

---

## MODULE 3: How You Connect (scoreModule3)

### Top-Level Outputs
| Variable | Type | Range | Description |
|----------|------|-------|-------------|
| rawScores.want | number | raw | Sum of want responses |
| rawScores.offer | number | raw | Sum of offer responses |
| wantScore | number | 0-100 | Normalized want |
| offerScore | number | 0-100 | Normalized offer |
| contextSwitchingType | number | 1-4 | Type assignment |
| typeName | string | name | e.g., "Unified" |
| typeDescription | string | text | Full description |
| wantOfferGap | number | 0-100 | Gap between want and offer |
| wantStrength | number | 0-50 | Distance from threshold |
| offerStrength | number | 0-50 | Distance from threshold |
| typeDetails.strengths | array | strings | Type strengths |
| typeDetails.challenges | array | strings | Type challenges |
| typeDetails.compatibleWith | array | numbers | Compatible types |
| typeDetails.tensionWith | array | numbers | Tension types |

**M3 Total: ~15 discrete variables**

---

## MODULE 4: When Things Get Hard (scoreModule4)

### Conflict Approach
| Variable | Type | Range | Description |
|----------|------|-------|-------------|
| conflictApproach.score | number | 0-100 | 100=pure pursue |
| conflictApproach.approach | string | pursue/withdraw | Direction |
| conflictApproach.intensity | number | 0-50 | How strong |
| conflictApproach.pursueRaw | number | raw | Pursue sum |
| conflictApproach.withdrawRaw | number | raw | Withdraw sum |

### Emotional Drivers
| Variable | Type | Range | Description |
|----------|------|-------|-------------|
| emotionalDrivers.scores.abandonment | number | 0-100 | Abandonment score |
| emotionalDrivers.scores.engulfment | number | 0-100 | Engulfment score |
| emotionalDrivers.scores.inadequacy | number | 0-100 | Inadequacy score |
| emotionalDrivers.scores.injustice | number | 0-100 | Injustice score |
| emotionalDrivers.rawScores.{driver} | number | 4-20 | Raw scores |
| emotionalDrivers.primary | string | driver name | Highest driver |
| emotionalDrivers.primaryScore | number | 0-100 | Primary score |
| emotionalDrivers.secondary | string | driver name | Second highest |
| emotionalDrivers.secondaryScore | number | 0-100 | Secondary score |

### Repair/Recovery
| Variable | Type | Range | Description |
|----------|------|-------|-------------|
| repairRecovery.speed.score | number | 0-100 | Speed score |
| repairRecovery.speed.style | string | quick/slow | Speed style |
| repairRecovery.speed.intensity | number | 0-50 | How strong |
| repairRecovery.mode.score | number | 0-100 | Mode score |
| repairRecovery.mode.style | string | verbal/physical | Mode style |
| repairRecovery.mode.intensity | number | 0-50 | How strong |
| repairRecovery.rawScores.{pole} | number | raw | Raw scores |

### Emotional Capacity
| Variable | Type | Range | Description |
|----------|------|-------|-------------|
| emotionalCapacity.score | number | 0-100 | Capacity score |
| emotionalCapacity.level | string | high/medium/low | Level |
| emotionalCapacity.rawHigh | number | raw | High-cap sum |
| emotionalCapacity.rawLow | number | raw | Low-cap sum |

### Gottman Screener
| Variable | Type | Range | Description |
|----------|------|-------|-------------|
| gottmanScreener.horsemen.criticism | number | 4-20 | Criticism score |
| gottmanScreener.horsemen.contempt | number | 4-20 | Contempt score |
| gottmanScreener.horsemen.defensiveness | number | 4-20 | Defensiveness score |
| gottmanScreener.horsemen.stonewalling | number | 4-20 | Stonewalling score |
| gottmanScreener.primary | string | horseman name | Highest horseman |
| gottmanScreener.primaryScore | number | 4-20 | Primary score |
| gottmanScreener.overallRisk | string | low/medium/high | Risk level |
| gottmanScreener.coachingPriority | string | maintenance/recommended/immediate | Priority |

### M4 Summary
| Variable | Type | Range | Description |
|----------|------|-------|-------------|
| summary.approach | string | pursue/withdraw | Quick ref |
| summary.primaryDriver | string | driver name | Quick ref |
| summary.repairSpeed | string | quick/slow | Quick ref |
| summary.repairMode | string | verbal/physical | Quick ref |
| summary.capacity | string | high/medium/low | Quick ref |
| summary.gottmanRisk | string | low/medium/high | Quick ref |

**M4 Total: ~45 discrete variables**

---

## DEMOGRAPHICS ENGINE

### Relate Score Components
| Variable | Type | Range | Description |
|----------|------|-------|-------------|
| relateScore | number | 1-10 | Overall market score |
| ageScore | number | 0-100 | Age component |
| incomePercentile | number | 0-100 | Income percentile |
| educationPercentile | number | 0-100 | Education percentile |
| heightPercentile | number | 0-100 | Height percentile |
| ethnicityScore | number | varies | Ethnicity component |
| childrenScore | number | varies | Children component |

### Match Pool
| Variable | Type | Range | Description |
|----------|------|-------|-------------|
| matchPool.idealPool | number | % | Ideal match percentage |
| matchPool.acceptablePool | number | % | Acceptable match percentage |
| matchPool.tierBreakdown | object | per-tier | Pool by tier |
| matchProbability | number | % | Success probability |

**Demographics Total: ~20 discrete variables**

---

## FRAMEWORKS (Computed from above)

### Tension Stack 1: Erotic Dimension
| Variable | Type | Description |
|----------|------|-------------|
| eroticType | string | Categorization |
| polarityScore | number | Polarity level |
| desirePattern | string | How desire works |
| eroticRisk | string | Risk identification |
| eroticOpportunity | string | Opportunity identification |

### Tension Stack 2: Vulnerability Profile
| Variable | Type | Description |
|----------|------|-------------|
| armorType | string | Primary armor |
| shameResilience | string | Resilience level |
| vulnerabilityPattern | string | How they protect |
| openingPath | string | How to reach them |

### Tension Stack 3: Attraction-Attachment
| Variable | Type | Description |
|----------|------|-------------|
| attractionAttachmentMatch | string | Aligned/Misaligned |
| attractionPattern | string | What attracts them |
| attachmentNeed | string | What they need |
| paradoxPresent | boolean | Is there a paradox? |

### Tension Stack 4: Intimacy-Conflict Bridge
| Variable | Type | Description |
|----------|------|-------------|
| connectionConflictBalance | string | Balance assessment |
| intimacyStyle | string | How they connect |
| conflictImpact | string | How conflict affects intimacy |

### Tension Stack 5: Internal Coherence
| Variable | Type | Description |
|----------|------|-------------|
| coherenceLevel | string | high/moderate/low |
| contradictions | array | Identified contradictions |
| developmentEdge | string | Growth area |

### Tension Stack 6: Market Reality
| Variable | Type | Description |
|----------|------|-------------|
| marketPosition | string | Position assessment |
| powerDynamic | string | Power in pairings |
| accessProbability | object | Per-persona access |

**Frameworks Total: ~30 computed variables**

---

## MODIFIER SYSTEM

### Skill Modifiers
| Variable | Type | Description |
|----------|------|-------------|
| attachment | string | Attachment style |
| communication | string | Communication skill level |
| empathy | string | Empathy level |
| conflictResolution | string | Conflict skill level |
| stressManagement | string | Stress management level |
| selfAwareness | string | Self-awareness level |
| growthOrientation | string | Growth vs fixed mindset |

### Demographic Modifiers
| Variable | Type | Description |
|----------|------|-------------|
| age | number | Age |
| income | number | Income |
| height | string | Height |
| education | string | Education level |
| fitness | string | Fitness level |
| location | string | Metro area |
| children | string | Children status |

**Modifiers Total: ~15 variables**

---

## DERIVED CROSS-MODULE VARIABLES

### M1 × M2 Analysis
| Variable | Type | Description |
|----------|------|-------------|
| m1m2CodeMatch | boolean | Same code? |
| m1m2GapByDimension | object | Per-dimension gaps |
| attractionCoherenceLevel | string | How coherent |
| type2MismatchFlags | array | Structural mismatches |

### M3 × M4 Analysis
| Variable | Type | Description |
|----------|------|-------------|
| connectionConflictPattern | string | How they interact |
| repairAccessibility | string | Can partner reach them in repair? |

### Full Profile Synthesis
| Variable | Type | Description |
|----------|------|-------------|
| relationshipReadiness | string | green/yellow/red |
| primaryGrowthEdge | string | Top priority |
| coachingUrgency | string | Priority level |

**Derived Total: ~15 variables**

---

## GRAND TOTAL

| Category | Count |
|----------|-------|
| M1 (What You Want) | ~35 |
| M2 (Who You Are) | ~45 |
| M3 (How You Connect) | ~15 |
| M4 (When Things Get Hard) | ~45 |
| Demographics | ~20 |
| Frameworks (computed) | ~30 |
| Modifiers | ~15 |
| Derived Cross-Module | ~15 |
| **TOTAL** | **~220 discrete variables** |

Plus validation flags, confidence scores, and narrative generators.

---

## WHERE THESE FEED IN THE REPORT

(Per draft_report_outline.md)

| Report Layer | Primary Variables |
|--------------|-------------------|
| Layer 1: Categories | M2 code, tier assignment |
| Layer 2: Basic Elements | M1 dimensions, M2 dimensions, gap analysis |
| Layer 3: Specification | M3 scores, M4 all subscores |
| Layer 4: Modifiers | Demographics, skill modifiers |
| Layer 5: Frameworks | All 6 tension stacks |
| Layer 6: Chemistry | Computed from 1-5 |
| Layer 7: Arcs | Computed from 1-5 + time model |
| Layer 8: Coaching | Computed from all + prioritization |

---

*This inventory maps to existing JS outputs. The report generator reads these variables and interprets their combinations.*
