# Relate Platform - Claude Code Handoff

## What You're Building

A React web app with two integrated engines:

1. **Markets Engine** - Economic position in the dating market (from SalaryArc)
2. **Assessment Engine** - Relational patterns and compatibility (from RELATE files)

---

## Files To Include

### GROUP A: SalaryArc (Markets Engine)

| File | Description |
|------|-------------|
| `Salaryarc.jsx` | 13,500-line monolith to extract (DO NOT REWRITE) |
| `SalaryArc-Calculation-Reference.txt` | All formulas, CBSA keys, scoring logic |

### GROUP B: RELATE Assessment (Assessment Engine)

| File | Description | Status |
|------|-------------|--------|
| `relate_questions.js` | 367 questions + 4 scoring functions + checkpoint system | COMPLETE - USE AS-IS |
| `relate_frameworks.js` | 6 tension stacks + parallels + strengths calculations | COMPLETE - USE AS-IS |
| `relate_persona_definitions.js` | 32 personas + 256 compatibility pairings pre-mapped | COMPLETE - USE AS-IS |
| `relate_demographics_engine.js` | Relate Score + Match Pool (overlaps with SalaryArc) | COMPLETE - USE AS-IS |
| `relate_modifier_system.js` | Skill/demographic modifiers and effects | COMPLETE - USE AS-IS |

### GROUP C: RELATE Documentation (Reference Specs)

| File | Description |
|------|-------------|
| `relate_taxonomy.md` | Complete report structure with section definitions |
| `draft_report_outline.md` | Example report for Builder × Influencer (THE TEMPLATE) |
| `RELATE_ASSESSMENT_UX.md` | User flow and screen specs |
| `CHECKPOINT_NOTES.md` | Save/resume implementation details |
| `RELATE_VARIABLE_INVENTORY.md` | All 220+ variables the system measures |

---

## Site Hierarchy

```
/                           Landing page
│
├── /markets                Financial analysis section (FROM SALARYARC)
│   ├── /calculator         Income history, demographics, career context
│   ├── /report             AI-generated narrative with charts
│   └── /visualize          Life in Weeks, dating matches, metro comparisons
│
├── /assessment             Personality assessment (FROM RELATE FILES)
│   ├── /session-1          M1: What You Want (134 questions)
│   ├── /session-2          M2: Who You Are (137 questions)
│   ├── /session-3          M3+M4: Connection + Conflict (96 questions)
│   └── /report             6-section relationship report
│
├── /coaching               Engagement after assessment complete
│                           Content driven by assessment results
│
└── /about
    ├── /data               Reference data tables
    └── /glossary           Term definitions
```

---

## PART 1: SALARYARC EXTRACTION

### Data Sources (Do Not Change)

**CBSA Dataset:** `https://raw.githubusercontent.com/fromnineteen80/salaryarc/main/cbsa-data.js`
- ~917 metros with demographics, income brackets, lifestyle metrics

**ZIP Centroids:** `https://raw.githubusercontent.com/fromnineteen80/salaryarc/main/zip-centroids.js`
- Maps ZIP to lat/lng for CBSA lookup

### Key Locations in JSX

| Content | Lines | Extract To |
|---------|-------|------------|
| Weights (WEIGHTS_MALE, WEIGHTS_FEMALE) | 970-971 | `constants/market-constants.js` |
| Age curves, children scores | 974-1001 | `constants/market-constants.js` |
| Felon/drug rates | 1040-1100 | `constants/market-constants.js` |
| Shared calculation module | 1100-1420 | `utils/market-calculations.js` |
| CBSA and ZIP data fetching | 5851-5900 | `hooks/useMarketData.js` |
| Calculator page | 6200-9000 | `pages/markets/Calculator.jsx` |
| Report page | 9000-10000 | `pages/markets/Report.jsx` |
| Visualize page | 10000-12000 | `pages/markets/Visualize.jsx` |

### Critical: What to Preserve

- Exact color values and styling
- Complex calculation chains with exact field names
- Chart configurations with custom tooltips
- Form validation and conditional field display
- AI prompt templates for narrative generation

**Do not simplify, modernize, or improve. Extract exactly.**

---

## PART 2: RELATE ASSESSMENT - WHAT'S COMPLETE

### The Rule

**The JS files are the source of truth. Do not rewrite scoring logic, question content, persona definitions, or compatibility tables. They are complete. Import and use them.**

### What EXISTS and WORKS

| Component | Location | What It Returns |
|-----------|----------|-----------------|
| 367 questions | relate_questions.js | Question objects with IDs, text, scoring poles |
| scoreModule1() | relate_questions.js | M1 preference scores (what user wants) |
| scoreModule2() | relate_questions.js | Persona code (e.g., 'BDFH') + 4 dimension scores + gaps |
| scoreModule3() | relate_questions.js | Context-switching type + want/offer scores |
| scoreModule4() | relate_questions.js | Conflict approach, 4 drivers, repair style, capacity, Gottman |
| scoreAttentiveness() | relate_questions.js | Empathy level (0-100) with coaching link |
| computeAllTensionStacks() | relate_frameworks.js | 6 framework analyses with types and risks |
| 32 persona definitions | relate_persona_definitions.js | Full profiles with metadata, behaviors, strengths |
| 256 tier assignments | relate_persona_definitions.js | Pre-mapped: which personas are Ideal/Kismet/Effort/etc. |
| Checkpoint encode/decode | relate_questions.js | Save/resume functionality |

### Key Exports You'll Use

```javascript
// From relate_questions.js
import {
  MEN_M1_QUESTIONS, WOMEN_M1_QUESTIONS,
  MEN_M2_QUESTIONS, WOMEN_M2_QUESTIONS,
  MEN_M3_QUESTIONS, WOMEN_M3_QUESTIONS,
  MEN_M4_QUESTIONS, WOMEN_M4_QUESTIONS,
  scoreModule1,
  scoreModule2,
  scoreModule3,
  scoreModule4,
  scoreAttentiveness,
  CHECKPOINT_CONFIG,
  encodeCheckpointString,
  decodeCheckpointString
} from './relate_questions.js';

// From relate_frameworks.js
import {
  computeAllTensionStacks,
  calculateParallels,
  calculateStrengths
} from './relate_frameworks.js';

// From relate_persona_definitions.js
import {
  M2_PERSONA_METADATA,
  W2_PERSONA_METADATA,
  M2_COMPATIBILITY_TABLE,
  W2_COMPATIBILITY_TABLE,
  getPersonaName,
  getFullProfile
} from './relate_persona_definitions.js';

// From relate_modifier_system.js
import {
  SKILL_MODIFIERS,
  DEMOGRAPHIC_MODIFIERS,
  applyModifiersToRelateScore,
  generateModifierProfile,
  generateCoachingRecommendations
} from './relate_modifier_system.js';
```

---

## PART 3: WHAT'S NOT BUILT - THE ORCHESTRATION LAYER

**This is what Claude Code needs to build.**

The scoring functions return raw numbers. The persona tables return tier labels. But nothing yet:

1. **Calculates a compatibility score** for each of the 16 matches
2. **Ranks matches within tiers** (which of the 3 Kismet matches is best?)
3. **Generates the report narrative** from the numbers

### Missing Component 1: Persona Ranker Function

**Purpose:** Take user's complete assessment results → Compare against all 16 opposite-gender personas → Return ranked list with scores.

**Build this function:**

```javascript
/**
 * Ranks all 16 opposite-gender personas by compatibility with user
 * 
 * @param {Object} userResults - Complete assessment results
 * @param {string} userResults.gender - 'M' or 'W'
 * @param {string} userResults.personaCode - User's 4-letter code (e.g., 'BDFH')
 * @param {Object} userResults.m1 - Module 1 scores
 * @param {Object} userResults.m2 - Module 2 scores
 * @param {Object} userResults.m3 - Module 3 scores
 * @param {Object} userResults.m4 - Module 4 scores
 * @param {Object} userResults.tensionStacks - 6 framework results
 * @returns {Array} Ranked personas with scores and tier assignments
 */
function rankCompatiblePersonas(userResults) {
  const { gender, personaCode, m1, m2, m3, m4, tensionStacks } = userResults;
  
  // Get the compatibility table for this user's persona
  const compatTable = gender === 'M' ? M2_COMPATIBILITY_TABLE : W2_COMPATIBILITY_TABLE;
  const tierAssignments = compatTable[personaCode];
  
  // Get opposite-gender persona metadata
  const targetPersonas = gender === 'M' ? W2_PERSONA_METADATA : M2_PERSONA_METADATA;
  
  const rankedList = [];
  
  // For each of the 16 potential matches
  for (const [matchCode, matchProfile] of Object.entries(targetPersonas)) {
    
    // 1. Determine tier (pre-assigned in compatibility table)
    let tier = 'incompatible';
    let tierScore = 0;
    if (tierAssignments.ideal.includes(matchCode)) { tier = 'ideal'; tierScore = 80; }
    else if (tierAssignments.kismet.includes(matchCode)) { tier = 'kismet'; tierScore = 65; }
    else if (tierAssignments.effort.includes(matchCode)) { tier = 'effort'; tierScore = 45; }
    else if (tierAssignments.longShot.includes(matchCode)) { tier = 'longShot'; tierScore = 25; }
    else if (tierAssignments.atRisk.includes(matchCode)) { tier = 'atRisk'; tierScore = 10; }
    else { tier = 'incompatible'; tierScore = 2; }
    
    // 2. Calculate dimension alignment score (for ranking within tier)
    //    Compare user's M2 dimensions with match's typical dimensions
    const dimensionScore = calculateDimensionAlignment(m2, matchProfile);
    
    // 3. Calculate M3 compatibility (want/offer alignment)
    const m3Score = calculateM3Compatibility(m3, matchProfile.typicalM3);
    
    // 4. Calculate M4 compatibility (conflict style alignment)
    const m4Score = calculateM4Compatibility(m4, matchProfile.typicalM4);
    
    // 5. Combine into final compatibility score
    //    Tier provides base, other factors adjust within tier range
    const compatibilityScore = Math.round(
      tierScore * 0.5 +           // Tier is 50% of score
      dimensionScore * 0.2 +      // Dimension alignment is 20%
      m3Score * 0.15 +            // M3 compatibility is 15%
      m4Score * 0.15              // M4 compatibility is 15%
    );
    
    rankedList.push({
      code: matchCode,
      name: matchProfile.name,
      tier,
      tierScore,
      compatibilityScore,
      profile: matchProfile,
      // Include component scores for report detail
      components: {
        dimension: dimensionScore,
        m3: m3Score,
        m4: m4Score
      }
    });
  }
  
  // Sort by compatibility score (highest first)
  rankedList.sort((a, b) => b.compatibilityScore - a.compatibilityScore);
  
  // Add rank numbers
  rankedList.forEach((match, index) => {
    match.rank = index + 1;
  });
  
  return rankedList;
}
```

**Helper functions to build:**

```javascript
// Calculate how well user's 4 dimensions align with match's 4 dimensions
function calculateDimensionAlignment(userM2, matchProfile) {
  // Each dimension: same pole = 25 points, opposite = 0
  // Max score = 100 (all 4 dimensions match)
  let score = 0;
  
  // Compare Physical dimension (A vs B)
  if (userM2.physical.direction === matchProfile.dimensions.physical) score += 25;
  
  // Compare Social dimension (C vs D)  
  if (userM2.social.direction === matchProfile.dimensions.social) score += 25;
  
  // Compare Lifestyle dimension (E vs F)
  if (userM2.lifestyle.direction === matchProfile.dimensions.lifestyle) score += 25;
  
  // Compare Values dimension (G vs H)
  if (userM2.values.direction === matchProfile.dimensions.values) score += 25;
  
  return score;
}

// Calculate M3 compatibility (context-switching alignment)
function calculateM3Compatibility(userM3, matchTypicalM3) {
  // High want + High offer from match = good
  // Compare want/offer gaps
  const wantAlignment = 100 - Math.abs(userM3.wantScore - matchTypicalM3.offerScore);
  const offerAlignment = 100 - Math.abs(userM3.offerScore - matchTypicalM3.wantScore);
  return (wantAlignment + offerAlignment) / 2;
}

// Calculate M4 compatibility (conflict style alignment)
function calculateM4Compatibility(userM4, matchTypicalM4) {
  // Pursue-pursue = conflict risk
  // Withdraw-withdraw = stalemate risk
  // Pursue-withdraw = common but manageable
  // Check repair style compatibility
  // Check driver compatibility
  
  let score = 50; // Base
  
  // Conflict approach compatibility
  if (userM4.approach === 'pursue' && matchTypicalM4.approach === 'withdraw') score += 10;
  if (userM4.approach === 'withdraw' && matchTypicalM4.approach === 'pursue') score += 10;
  if (userM4.approach === matchTypicalM4.approach) score -= 10; // Same approach = friction
  
  // Repair style compatibility
  if (userM4.repairSpeed === matchTypicalM4.repairSpeed) score += 15;
  if (userM4.repairMode === matchTypicalM4.repairMode) score += 15;
  
  // Driver risk (certain combinations are volatile)
  // Abandonment + Engulfment = pursue-withdraw spiral
  if (userM4.primaryDriver === 'abandonment' && matchTypicalM4.primaryDriver === 'engulfment') score -= 20;
  if (userM4.primaryDriver === 'engulfment' && matchTypicalM4.primaryDriver === 'abandonment') score -= 20;
  
  return Math.max(0, Math.min(100, score));
}
```

### Missing Component 2: Typical M3/M4 Profiles for Personas

**Purpose:** Each persona needs "typical" M3 and M4 scores so we can compare user's actual scores against expected patterns.

**Build this data structure:**

```javascript
// Add to relate_persona_definitions.js OR create new file
const PERSONA_TYPICAL_PROFILES = {
  // Male personas
  'ACEG': { // Gladiator
    typicalM3: {
      wantScore: 75,      // Wants high context-switching (mystery, access)
      offerScore: 40,     // Offers less (guarded)
      type: 2             // High want, low offer
    },
    typicalM4: {
      approach: 'pursue',
      intensity: 72,
      primaryDriver: 'inadequacy',
      repairSpeed: 'slow',
      repairMode: 'physical',
      capacity: 'medium'
    }
  },
  'BDFH': { // Builder
    typicalM3: {
      wantScore: 65,
      offerScore: 70,
      type: 3             // Balanced, slight offer lead
    },
    typicalM4: {
      approach: 'withdraw',
      intensity: 55,
      primaryDriver: 'inadequacy',
      repairSpeed: 'slow',
      repairMode: 'verbal',
      capacity: 'high'
    }
  },
  // ... define for all 32 personas
};
```

**How to derive these:** Look at each persona's behavioral descriptions in M2_PERSONA_METADATA and W2_PERSONA_METADATA. Their dating behavior, relationship patterns, and struggles tell you what their M3/M4 profiles should be.

Example derivation for Builder (BDFH):
- "Evaluates partners by their self-awareness" → High M3 Want (wants depth)
- "Creates space for his emotions" → High M3 Offer (gives access)
- "Comfortable with depth and difficulty" → High M4 capacity
- "Peace through understanding rather than avoidance" → Verbal repair mode
- Confidence + Peace dimensions → Withdraw approach (doesn't chase)

### Missing Component 3: Report Generator

**Purpose:** Take all scores and rankings → Generate the 6-section report narrative.

**Build this function:**

```javascript
/**
 * Generates the complete assessment report
 * 
 * @param {Object} userResults - All assessment data
 * @param {Array} rankedMatches - Output from rankCompatiblePersonas()
 * @returns {Object} Report sections with content
 */
function generateReport(userResults, rankedMatches) {
  const { gender, personaCode, m1, m2, m3, m4, tensionStacks, attentiveness, demographics } = userResults;
  
  // Get user's persona profile
  const personaMetadata = gender === 'M' ? M2_PERSONA_METADATA : W2_PERSONA_METADATA;
  const userProfile = personaMetadata[personaCode];
  
  return {
    // SECTION 1: Market Position
    marketPosition: generateMarketSection(demographics, userResults.relateScore, userResults.matchPool),
    
    // SECTION 2: Who You Are
    whoYouAre: {
      persona: {
        code: personaCode,
        name: userProfile.name,
        tagline: userProfile.tagline,
        traits: userProfile.traits
      },
      dimensions: formatDimensions(m2),
      tensionStacks: formatTensionStacks(tensionStacks),
      attentiveness: formatAttentiveness(attentiveness),
      growthEdges: identifyGrowthEdges(m2, m4, attentiveness)
    },
    
    // SECTION 3: What You Want
    whatYouWant: {
      preferenceCode: m1.preferenceCode,
      description: describePreferences(m1),
      gapAnalysis: analyzeM1M2Gap(m1, m2)
    },
    
    // SECTION 4: Your 16 Matches (the ranked list)
    matches: rankedMatches.map(match => ({
      rank: match.rank,
      code: match.code,
      name: match.name,
      tier: match.tier,
      compatibilityScore: match.compatibilityScore,
      summary: generateMatchSummary(userResults, match),
      // Expandable detail
      detail: generateMatchDetail(userResults, match)
    })),
    
    // SECTION 5: You In Relationships
    inRelationships: {
      patterns: describeRelationalPatterns(m3, m4),
      regressionTriggers: identifyRegressionTriggers(m4),
      growthCapacity: assessGrowthCapacity(m2, m4, attentiveness)
    },
    
    // SECTION 6: Coaching
    coaching: generateCoachingPlan(userResults, rankedMatches)
  };
}
```

**The interpretation logic lives in draft_report_outline.md.** Read that file carefully. It shows exactly how to interpret specific score combinations. For example:

- His Abandonment (78) × Her Engulfment (65) = pursue-withdraw spiral
- His Physical dimension (52%) = moderate, not extreme
- Builder × Influencer = Kismet tier with specific chemistry patterns

**Copy that interpretation pattern for all pairings.**

### Missing Component 4: Match Detail Generator

**Purpose:** For each of the 16 matches, generate the expandable detail section.

```javascript
function generateMatchDetail(userResults, match) {
  // Use draft_report_outline.md as the template
  // Each match detail includes:
  
  return {
    // Their profile
    theirPersona: {
      name: match.profile.name,
      traits: match.profile.traits,
      datingBehavior: match.profile.datingBehavior,
      inRelationships: match.profile.inRelationships
    },
    
    // The foundation (dimension comparison)
    foundation: compareDimensions(userResults.m2, match.profile),
    
    // The chemistry (what emerges from combination)
    chemistry: analyzeChemistry(userResults, match),
    
    // The dynamics (how you'll operate together)
    dynamics: predictDynamics(userResults.m3, userResults.m4, match.profile),
    
    // Tension stacks for this specific pairing
    pairingTensionStacks: computePairingTensionStacks(userResults, match),
    
    // Conflict prediction
    conflictPattern: predictConflictPattern(userResults.m4, match.profile.typicalM4),
    
    // Recovery prognosis
    recoveryPrognosis: assessRecoveryPrognosis(userResults.m4, match.profile.typicalM4),
    
    // Daily life preview
    dailyLife: describeDailyLife(userResults, match),
    
    // The invitation (why consider this pairing)
    invitation: generateInvitation(userResults, match)
  };
}
```

---

## PART 4: ASSESSMENT DATA FLOW

```
User completes /markets/calculator
         ↓
    Demographics stored: gender, location, income, age, ethnicity
         ↓
    SalaryArc's calculateRelateScore() → Market position (1-10)
         ↓
User clicks "personality assessment" → /assessment
         ↓
    Demographics PRE-FILLED (do not re-ask gender, age, location)
         ↓
    Session 1: M1 questions (134) → scoreModule1() → What they want
         ↓
    [Checkpoint save]
         ↓
    Session 2: M2 questions (137) → scoreModule2() → Who they are + persona code
         ↓
    [Checkpoint save]
         ↓
    Session 3: M3+M4 questions (96) → scoreModule3(), scoreModule4()
         ↓
    scoreAttentiveness() → Empathy level
         ↓
    computeAllTensionStacks() → 6 framework analyses
         ↓
    rankCompatiblePersonas() → Ordered list of 16 matches [BUILD THIS]
         ↓
    generateReport() → 6-section report [BUILD THIS]
         ↓
    Display /assessment/report
```

### Question Counts

| Session | Module | Questions | Time |
|---------|--------|-----------|------|
| 1 | M1: What You Want | 134 | ~38 min |
| 2 | M2: Who You Are | 137 | ~39 min |
| 3 | M3: How You Connect | 28 | ~8 min |
| 3 | M4: When Things Get Hard | 68 | ~19 min |
| **Total** | | **367** | **~104 min** |

### Checkpoint System

Users can save and resume. The system is built into relate_questions.js:

```javascript
// Save progress
const checkpoint = encodeCheckpointString(gender, session, responses);
await window.storage.set('relate_checkpoint', checkpoint);

// Resume
const saved = await window.storage.get('relate_checkpoint');
const { gender, session, responses } = decodeCheckpointString(saved.value);
```

---

## PART 5: INTEGRATION POINTS

### Shared Demographics

Markets collects these. Assessment should NOT re-ask:
- Gender
- Age (from birth year in income history)
- Location (CBSA from ZIP)
- Ethnicity
- Income (current)

### Two Relate Scores

There are two different calculations:

| Score | Source | Purpose |
|-------|--------|---------|
| Market Relate Score | SalaryArc JSX lines 1100-1300 | Economic dating market value |
| Assessment Relate Score | relate_demographics_engine.js | Includes modifier adjustments |

**Keep them separate.** Markets page uses SalaryArc's version. Assessment report can reference both.

### Coaching Integration

/coaching page content is driven by assessment results:
- Growth edges from relate_frameworks.js
- Skill priorities from relate_modifier_system.js
- Pairing-specific recommendations from generateCoachingPlan()

---

## Build Order

1. Set up Vite project with route structure
2. Extract SalaryArc constants → constants/market-constants.js
3. Extract SalaryArc calculation module → utils/market-calculations.js
4. Extract /markets/calculator → verify form submits correctly
5. Extract /markets/report → verify AI narrative generates
6. Extract /markets/visualize → verify charts render
7. Import relate_*.js files as ES modules
8. **Build PERSONA_TYPICAL_PROFILES data structure** (derive from persona metadata)
9. **Build rankCompatiblePersonas() function**
10. **Build generateReport() and helper functions**
11. Build /assessment/session-1 with question flow + checkpoint save
12. Build /assessment/session-2 with question flow + checkpoint save
13. Build /assessment/session-3 with question flow
14. Build /assessment/report using generateReport() output
15. Wire /coaching to assessment results
16. Connect landing page links

**Do not proceed to the next step until the current step works.**

---

## Do Not

- Rewrite SalaryArc calculations
- Rewrite RELATE scoring functions (scoreModule1-4, computeAllTensionStacks)
- Change CBSA field names
- Change color values or styling
- Simplify existing UI details
- Merge the two Relate Score implementations
- Add questions or change persona definitions
- Invent new tier logic (the 256 pairings are pre-assigned)

---

## Design Language

Match existing:
- Cream/off-white background (#FAF8F5 or similar)
- Coral/terracotta accent (#C85A3B or similar)
- Serif headings (editorial feel)
- Clean card-based layouts
- Minimal, considered typography

---

## Reference Files

When building the orchestration layer:
1. **draft_report_outline.md** - THE TEMPLATE. Shows exactly how to interpret scores for Builder × Influencer. Copy this pattern.
2. **relate_taxonomy.md** - Report structure. Each section defined with what to include.
3. **RELATE_VARIABLE_INVENTORY.md** - All 220+ variables. Know what data you have access to.
4. **relate_persona_definitions.js** - Persona behaviors and descriptions. Use these to derive typical M3/M4 profiles.
