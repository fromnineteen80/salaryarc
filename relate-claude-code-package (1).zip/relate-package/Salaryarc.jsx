import React, { useState, useEffect, useRef } from 'react';
import { ComposedChart, Line, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Customized, ReferenceLine } from 'recharts';

/*
 * ============================================================================
 * SALARYARC WRITING RULES - FOR ALL GENERATED NARRATIVE CONTENT
 * ============================================================================
 * 
 * These rules apply to Context By Year, analysis sections, and any dynamic
 * narrative content generated for users. Violations make the product feel
 * like generic AI slop. Follow these without exception.
 *
 * 1. ONE IDEA PER SENTENCE
 *    If you need a dash or colon to bolt on a second thought, make it its
 *    own sentence or cut it entirely.
 *
 * 2. LEAD WITH THE CONCRETE
 *    Numbers, places, dollar amounts first. Not abstractions about 
 *    "understanding" or "realizing" or "beginning to see."
 *
 * 3. STRONG VERBS, NO PADDING
 *    Cut "actually," "really," "just," "basically," "began to understand,"
 *    "started to realize." Say what happened.
 *
 * 4. NO "NOT X, BUT Y" CONSTRUCTIONS
 *    These are filler. Say what it IS, not what it isn't followed by what
 *    it is. "Not a goal number, but stability" becomes "Stability mattered
 *    more than hitting a number."
 *
 * 5. NO COLON-EXPLANATIONS
 *    A colon followed by a clarifying phrase is an em dash in disguise.
 *    "He needed one thing: stability" should be "He needed stability."
 *
 * 6. NO EM DASHES OR DOUBLE DASHES
 *    Never use — or -- to connect thoughts. If two ideas need connecting,
 *    they either belong in separate sentences or need a proper conjunction.
 *
 * 7. VARY SENTENCE LENGTH
 *    Short sentences punch. Longer ones build momentum and carry the reader
 *    through complexity. Monotonous rhythm kills engagement.
 *
 * 8. SPECIFICITY BEATS GENERALITY
 *    "$800 flights every few weeks" is good. "The emotional weight of a
 *    family split down the middle" is vague and saccharine. Cut it.
 *
 * 9. NO THROAT-CLEARING
 *    Cut opening phrases like "This year marked," "This was the year when,"
 *    "It was during this time that," "What became clear was." Start with
 *    the actual content.
 *
 * 10. THE INSIGHT LANDS AT THE END
 *     Build toward the point. Do not explain it to death afterward. The
 *     last sentence should hit, not summarize.
 *
 * 11. READ IT ALOUD
 *     If it sounds like a LinkedIn post, a self-help book, or a TED talk
 *     transcript, rewrite it. Real insight does not announce itself.
 *
 * 12. NO EMOTIONAL EDITORIALIZING
 *     "The weight of," "the burden of," "the freedom of" are lazy shortcuts.
 *     Show the situation. Let the reader feel it. Do not tell them how to
 *     feel about it.
 *
 * EXAMPLES OF VIOLATIONS:
 * BAD:  "This year marked the beginning of understanding what you needed: 
 *        not a goal, but stability."
 * GOOD: "Two households. Two time zones. The same $110k stretched across
 *        both. The goal stopped mattering. Making it work did."
 *
 * BAD:  "The salary felt different now—less like achievement and more like
 *        survival."
 * GOOD: "On paper, $110k. In practice, $55k per household after the split."
 *
 * ============================================================================
 */

// =============================================================================
// PERSONA DETECTION SYSTEM
// =============================================================================

/**
 * Detect trajectory persona from income data patterns
 * Returns one of: CLIMBER, LATE_BLOOMER, EARLY_ACHIEVER, FALLEN, RETURNED, STRUGGLER, STEADY, GENERAL
 */
const detectTrajectoryPersona = (data, firstYear, lastYear) => {
  const startIncome = firstYear.income;
  const endIncome = lastYear.income;
  const startPercentile = firstYear.percentile;
  const endPercentile = lastYear.percentile;
  const multiple = endIncome / startIncome;
  const yearsBelowFunctional = data.filter(d => d.income < d.greenLine).length;
  const totalYears = data.length;
  
  // Find if there was a major drop (30%+ decline year over year)
  const hadMajorDrop = data.some((d, i) => {
    if (i === 0) return false;
    return d.income < data[i-1].income * 0.7;
  });
  
  // Find if there was late acceleration (40%+ jump in back half)
  const midpoint = Math.floor(data.length / 2);
  const hadLateAcceleration = data.slice(midpoint).some((d, i) => {
    const prevIncome = i === 0 ? data[midpoint - 1]?.income : data[midpoint + i - 1].income;
    return prevIncome && d.income > prevIncome * 1.4;
  });
  
  // The Climber: Started bottom half, now top 20%
  if (startPercentile < 50 && endPercentile >= 80) {
    return 'CLIMBER';
  }
  
  // The Late Bloomer: Flat for 5+ years then accelerated significantly
  if (hadLateAcceleration && multiple > 3) {
    return 'LATE_BLOOMER';
  }
  
  // The Early Achiever: Top 20% by age 30, maintained
  const earlyData = data.find(d => d.age <= 30);
  if (earlyData && earlyData.percentile >= 80 && endPercentile >= 75) {
    return 'EARLY_ACHIEVER';
  }
  
  // The Fallen: Was top 30%, dropped below median
  const peakPercentile = Math.max(...data.map(d => d.percentile));
  if (peakPercentile >= 70 && endPercentile < 50) {
    return 'FALLEN';
  }
  
  // The Returned: Had it, lost 30%+, rebuilt to within 20% of peak
  const peakIncome = Math.max(...data.map(d => d.income));
  if (hadMajorDrop && endIncome >= peakIncome * 0.8) {
    return 'RETURNED';
  }
  
  // The Struggler: Never crossed functional threshold
  if (yearsBelowFunctional === totalYears) {
    return 'STRUGGLER';
  }
  
  // The Steady: Stayed within 30-70 percentile range throughout
  const allMiddle = data.every(d => d.percentile >= 30 && d.percentile <= 70);
  if (allMiddle) {
    return 'STEADY';
  }
  
  return 'GENERAL';
};

/**
 * Detect complexity overlays (user can have multiple)
 */
const detectComplexityOverlays = (data, formData) => {
  const overlays = [];
  
  const wasMarried = data.some(d => d.married === 'yes' || d.married === 'Yes');
  const isNowSingle = data[data.length - 1].married === 'no' || data[data.length - 1].married === 'No';
  const hasKids = data.some(d => d.children === 'yes' || d.children === 'Yes');
  const locationChanges = new Set(data.map(d => d.location)).size;
  
  if (wasMarried && isNowSingle && hasKids) {
    overlays.push('DIVORCED_PARENT');
  } else if (wasMarried && isNowSingle) {
    overlays.push('DIVORCED_NO_KIDS');
  }
  
  if (locationChanges >= 3) {
    overlays.push('GEOGRAPHIC_MIGRANT');
  }
  
  if (formData.firstSector && formData.currentSector && 
      formData.firstSector !== formData.currentSector) {
    overlays.push('CAREER_REINVENTOR');
  }
  
  const firstYear = data[0];
  const lastYear = data[data.length - 1];
  if (firstYear.percentile < 40 && lastYear.income > lastYear.goal * 1.5) {
    overlays.push('SCARCITY_MINDSET');
  }
  
  const marriedYears = data.filter(d => d.married === 'yes' || d.married === 'Yes').length;
  if (marriedYears >= 10 && (data[data.length - 1].married === 'yes' || data[data.length - 1].married === 'Yes')) {
    overlays.push('LONG_MARRIAGE');
  }
  
  if (hasKids && !wasMarried) {
    overlays.push('SINGLE_PARENT');
  }
  
  return overlays;
};

/**
 * Detect market position for relationship scoring
 */
const detectMarketPosition = (gender, lastYear) => {
  const isHighEarner = lastYear.percentile >= 80;
  const isLowEarner = lastYear.percentile < 40;
  
  if (gender === 'woman' && isHighEarner) return 'HIGH_EARNING_WOMAN';
  if (gender === 'woman' && isLowEarner) return 'LOW_EARNING_WOMAN';
  if (gender === 'man' && isHighEarner) return 'HIGH_EARNING_MAN';
  if (gender === 'man' && isLowEarner) return 'LOW_EARNING_MAN';
  return 'MARKET_MIDDLE';
};

/**
 * Detect full persona profile
 */
const detectFullPersona = (reportData, formData) => {
  if (!reportData || reportData.length < 2) {
    return {
      trajectory: 'GENERAL',
      overlays: [],
      marketPosition: 'MARKET_MIDDLE',
      mindsetCard: 'scarcityMindset',
      futureCard: 'whatYoureBuilding'
    };
  }
  
  const firstYear = reportData[0];
  const lastYear = reportData[reportData.length - 1];
  
  const trajectory = detectTrajectoryPersona(reportData, firstYear, lastYear);
  const overlays = detectComplexityOverlays(reportData, formData);
  const marketPosition = detectMarketPosition(formData.gender, lastYear);
  
  // Determine mindset card
  let mindsetCard = 'scarcityMindset';
  if (trajectory === 'EARLY_ACHIEVER') mindsetCard = 'abundanceMindset';
  else if (trajectory === 'STEADY') mindsetCard = 'stabilityMindset';
  else if (trajectory === 'FALLEN') mindsetCard = 'lossMindset';
  
  // Determine future card
  const hasKids = reportData.some(d => d.children === 'yes' || d.children === 'Yes');
  const futureCard = hasKids ? 'whatYoureCreating' : 'whatYoureBuilding';
  
  return {
    trajectory,
    overlays,
    marketPosition,
    mindsetCard,
    futureCard,
    firstYear,
    lastYear
  };
};

/**
 * Build system prompt for Claude API
 */
const buildSystemPrompt = (persona, formData) => {
  const toneByPersona = {
    CLIMBER: 'Validating without fawning. The climb was real. Do not diminish it or oversell it.',
    LATE_BLOOMER: 'Curious about the inflection. The patience matters. Do not frame early years as wasted.',
    EARLY_ACHIEVER: 'Respectful without assuming ease. Sustained performance is real. Explore what drives it.',
    FALLEN: 'Direct without pity. The fall is real. Do not rush to silver linings.',
    RETURNED: 'Respect for the full arc. Both chapters matter. The second climb is different.',
    STRUGGLER: 'Honest without condescension. The constraints are real. Do not lecture about choices.',
    STEADY: 'Respect for consistency. Stability is undervalued. Do not imply lack of ambition.',
    GENERAL: 'Direct, observational, grounded in data but human.'
  };
  
  return `You are analyzing income data for ${formData.firstName || 'this person'}.

TRAJECTORY PERSONA: ${persona.trajectory}
COMPLEXITY OVERLAYS: ${persona.overlays?.join(', ') || 'None'}
MARKET POSITION: ${persona.marketPosition || 'Not specified'}

TONE: ${toneByPersona[persona.trajectory] || toneByPersona.GENERAL}

MANDATORY WRITING RULES - VIOLATIONS WILL BE REJECTED:

1. ONE IDEA PER SENTENCE
   If you need a dash or colon to bolt on a second thought, make it its own sentence or cut it entirely.

2. LEAD WITH THE CONCRETE
   Numbers, places, dollar amounts first. Not abstractions about "understanding" or "realizing" or "beginning to see."

3. STRONG VERBS, NO PADDING
   Cut "actually," "really," "just," "basically," "began to understand," "started to realize." Say what happened.

4. NO "NOT X, BUT Y" CONSTRUCTIONS
   These are filler. Say what it IS, not what it isn't followed by what it is.
   BAD: "Not a goal number, but stability"
   GOOD: "Stability mattered more than hitting a number."

5. NO COLON-EXPLANATIONS
   A colon followed by a clarifying phrase is an em dash in disguise.
   BAD: "He needed one thing: stability"
   GOOD: "He needed stability."

6. NO EM DASHES OR DOUBLE DASHES EVER
   Never use — or -- to connect thoughts. If two ideas need connecting, they either belong in separate sentences or need a proper conjunction.
   EXCEPTION: Logical compound modifiers like "30 year retirement" are fine. But "cost-of-living" should be "cost of living" and "late-career" should be "late career."

7. VARY SENTENCE LENGTH
   Short sentences punch. Longer ones build momentum and carry the reader through complexity. Monotonous rhythm kills engagement.

8. SPECIFICITY BEATS GENERALITY
   "$800 flights every few weeks" is good. "The emotional weight of a family split down the middle" is vague and saccharine. Cut it.

9. NO THROAT-CLEARING
   Cut opening phrases like "This year marked," "This was the year when," "It was during this time that," "What became clear was." Start with the actual content.

10. THE INSIGHT LANDS AT THE END
    Build toward the point. Do not explain it to death afterward. The last sentence should hit, not summarize.

11. READ IT ALOUD
    If it sounds like a LinkedIn post, a self-help book, or a TED talk transcript, rewrite it. Real insight does not announce itself.

12. NO EMOTIONAL EDITORIALIZING
    "The weight of," "the burden of," "the freedom of" are lazy shortcuts. Show the situation. Let the reader feel it. Do not tell them how to feel about it.

EXAMPLES OF BAD vs GOOD:

BAD: "This year marked the beginning of understanding what you needed: not a goal, but stability."
GOOD: "Two households. Two time zones. The same $110k stretched across both. The goal stopped mattering. Making it work did."

BAD: "The salary felt different now—less like achievement and more like survival."
GOOD: "On paper, $110k. In practice, $55k per household after the split."

BAD: "What became clear was that the early-career struggles had shaped a risk-averse approach to financial decision-making."
GOOD: "Seven years below the functional line left marks. You still check prices twice."

OUTPUT FORMATTING:
- Start each finding with **Bold Header Text.** followed by your analysis
- Write 3-5 flowing sentences per finding, not choppy bullet points
- Use consistent paragraph structure throughout
- Do NOT use numbered lists with sub-headers (like "1. **Header**" then "The Strategic Retreat")
- Express ALL Relate Scores as X.X/10 (like 8.2/10), NEVER as percentages or /100
- Keep paragraph spacing consistent - one blank line between findings

Write like a professional analyst, not a motivational speaker.`;
};

/**
 * Format report data for Claude context
 */
const formatDataContext = (reportData, formData, persona) => {
  const { firstYear, lastYear } = persona;
  
  const incomeHistory = reportData.map(d => {
    const married = d.married === 'yes' || d.married === 'Married';
    const relateInfo = d.relateScore ? ` | Relate: ${d.relateScore.toFixed(1)}/10` : '';
    const matchInfo = !married && d.realisticPool ? ` | Match: ${d.realisticPool.toLocaleString()} pool` : (married ? ' | Married' : '');
    return `${d.year} | ${d.location} | Age ${d.age} | $${d.income.toLocaleString()} | ${d.percentile}th pct | ${d.income >= d.greenLine ? 'Above' : 'BELOW'} functional${relateInfo}${matchInfo}`;
  }).join('\n');
  
  const multiple = (lastYear.income / firstYear.income).toFixed(1);
  const percentileGain = lastYear.percentile - firstYear.percentile;
  const yearsBelowFunctional = reportData.filter(d => d.income < d.greenLine).length;
  const locations = [...new Set(reportData.map(d => d.location))];
  
  let keyStats = `Start: $${firstYear.income.toLocaleString()} at ${firstYear.percentile}th percentile (${firstYear.location}, age ${firstYear.age})
Current: $${lastYear.income.toLocaleString()} at ${lastYear.percentile}th percentile (${lastYear.location}, age ${lastYear.age})
Multiple: ${multiple}x
Percentile gain: ${percentileGain > 0 ? '+' : ''}${percentileGain} points
Years below functional survival: ${yearsBelowFunctional} of ${reportData.length}
Locations: ${locations.join(' → ')}`;

  // Career context
  let careerContext = '\n\nCAREER CONTEXT:';
  if (formData.firstJobYear) {
    careerContext += `\nFirst job year: ${formData.firstJobYear}`;
    careerContext += `\nYears BEFORE ${formData.firstJobYear} represent family/household income (not the user's career)`;
    careerContext += `\nYears ${formData.firstJobYear} and after represent the user's personal career income`;
  }
  if (formData.firstJobTitle) careerContext += `\nFirst job title: ${formData.firstJobTitle}`;
  if (formData.firstSector) careerContext += `\nFirst sector: ${formData.firstSector}`;
  if (formData.currentJobTitle) careerContext += `\nCurrent job title: ${formData.currentJobTitle}`;
  if (formData.currentSector) careerContext += `\nCurrent sector: ${formData.currentSector}`;

  // Interview responses
  const probeResponses = formData.probeResponses || {};
  let interviewSection = '\n\nINTERVIEW RESPONSES:';
  for (const [probeId, response] of Object.entries(probeResponses)) {
    if (response) {
      const truncated = response.length > 500 ? response.substring(0, 500) + '...' : response;
      interviewSection += `\n\n[${probeId}]: "${truncated}"`;
    }
  }
  
  if (Object.keys(probeResponses).length === 0) {
    interviewSection += '\n(No interview responses provided)';
  }
  
  return `INCOME HISTORY:
${incomeHistory}

KEY STATS:
${keyStats}
${careerContext}
${interviewSection}`;
};

/**
 * Get card-specific prompt
 */
const getCardPrompt = (cardName, reportData, formData, persona) => {
  const { firstYear, lastYear } = persona;
  const locations = [...new Set(reportData.map(d => d.location))];
  const yearsBelowFunctional = reportData.filter(d => d.income < d.greenLine).length;
  
  const firstJobYear = parseInt(formData.firstJobYear) || null;
  
  const prompts = {
    contextByYear: `Generate a brief 2-3 sentence context for EACH year in the data. Return as a JSON array: [{"year": 1998, "context": "..."}, ...]

IMPORTANT: ${firstJobYear ? `Years BEFORE ${firstJobYear} are family/household income (use "Your father earned..." or "The household income was..."). Years ${firstJobYear} and after are the user's personal career (use "You earned..." or "Your salary was..."). First job was: ${formData.firstJobTitle || 'not specified'} in ${formData.firstSector || 'unspecified sector'}.` : 'Treat all years as the user\'s personal income.'}

Each context should:
1. Ground that year in the financial reality (income, percentile, above/below thresholds)
2. Reference location, life events (marriage, divorce, kids, moves)
3. For single years, include Relate score context and match pool size
4. Use job titles when relevant (first job: ${formData.firstJobTitle || 'N/A'}, current: ${formData.currentJobTitle || 'N/A'})`,

    keyFindings: `Generate 5-7 substantial key findings about this income trajectory. This is the centerpiece analysis.

DATA SUMMARY:
- Start: $${firstYear.income?.toLocaleString()} at ${firstYear.percentile}th percentile (${firstYear.location}, age ${firstYear.age})
- Current: $${lastYear.income?.toLocaleString()} at ${lastYear.percentile}th percentile (${lastYear.location}, age ${lastYear.age})
- Multiple: ${(lastYear.income / firstYear.income).toFixed(1)}x nominal increase
- Years below functional survival line: ${yearsBelowFunctional} of ${reportData.length}
- Locations traversed: ${locations.join(' → ')}

Each finding should:
1. Start with a **bolded claim** that could stand alone as a headline
2. Follow with 3-5 sentences of analysis with SPECIFIC numbers, percentages, dollar amounts
3. Reveal something non-obvious - the hidden story in the data
4. Connect financial facts to lived experience and meaning

Cover these dimensions:
- Origin story and starting constraints
- The arc of progress (was it linear? stepwise? explosive?)
- Geographic decisions and their purchasing power impact
- Key inflection points (marriage, divorce, career moves, sector changes)
- Current position in historical and statistical context
- What the trajectory reveals about discipline, timing, or circumstance`,

    percentileThresholds: `Analyze where this person started and where they ended up in the income distribution.

TRAJECTORY:
- Started: ${firstYear.percentile}th percentile ($${firstYear.income?.toLocaleString()}) at age ${firstYear.age} in ${firstYear.location}
- Current: ${lastYear.percentile}th percentile ($${lastYear.income?.toLocaleString()}) at age ${lastYear.age} in ${lastYear.location}
- Percentile gain: ${lastYear.percentile - firstYear.percentile} points over ${lastYear.year - firstYear.year} years

THRESHOLDS (2025):
- Median (50th): $83,592
- Top 10% (90th): $251,036
- Top 5% (95th): $335,575
- Top 1% (99th): $659,060

Generate 3-4 paragraphs analyzing:
1. The starting position - what did that percentile mean for daily life, options, stress?
2. The journey through thresholds - which ones were crossed and when?
3. The current position - what does this percentile actually mean in practice?
4. The statistical rarity - what percentage of people make this kind of percentile jump?

Be specific about how many American households are at each level. The top 1% is about 1.3 million households out of 134 million total.`,

    rarityAnalysis: `Analyze how statistically rare this trajectory is.

TRAJECTORY:
- Start: ${firstYear.percentile}th percentile → Current: ${lastYear.percentile}th percentile
- Percentile gain: ${lastYear.percentile - firstYear.percentile} points
- Income multiple: ${(lastYear.income / firstYear.income).toFixed(1)}x
- Time span: ${lastYear.year - firstYear.year} years
- Years below functional: ${yearsBelowFunctional}

Generate 4-5 substantial findings covering:
1. Intergenerational mobility statistics - what % of people starting at ${firstYear.percentile}th percentile reach the ${lastYear.percentile}th?
2. Recovery from any setbacks visible in the data
3. The inflation-adjusted difficulty (achieving this during 2021-2024 inflation)
4. Whether this came from employment income vs equity/inheritance (most top 1% is NOT salary)
5. Any compounding factors that made this harder (divorce, co-parenting, geographic constraints)

Use specific percentages and cite what research shows about income mobility.`,

    scarcityMindset: `Analyze the gap between objective financial position and likely felt sense of security.

Starting: ${firstYear.percentile}th percentile ($${firstYear.income?.toLocaleString()})
Current: ${lastYear.percentile}th percentile ($${lastYear.income?.toLocaleString()})
Years below functional survival line: ${yearsBelowFunctional} of ${reportData.length}

Generate 4-5 substantial findings exploring:
1. How many years were spent in constraint vs abundance? The nervous system calibrates to the longer period.
2. What was the "felt rich" ceiling based on aspiration? How far beyond it are they now?
3. Poverty proximity memory - how close to the poverty line were they, and does the body remember?
4. The median multiple shift - from Xx median to Yx median, but does it feel real?
5. What work remains? The money problem may be solved; the internal update takes longer.

Ground each point in specific numbers from their data.`,

    abundanceMindset: `Analyze what it means to have started from or achieved abundance early.
Current: ${lastYear.percentile}th percentile ($${lastYear.income?.toLocaleString()})
What blindspots might exist? What assumptions about "normal" are invisible?

Generate 4-5 findings about the psychology of sustained high income or early achievement.`,

    stabilityMindset: `Analyze the psychology of steady progress.
Range: ${Math.min(...reportData.map(d => d.percentile))}th to ${Math.max(...reportData.map(d => d.percentile))}th percentile
What does consistency mean financially and emotionally?

Generate 4-5 findings about the value and psychology of stable trajectory.`,

    lossMindset: `Analyze the psychology of having had and lost.
Peak: ${Math.max(...reportData.map(d => d.percentile))}th percentile
Current: ${lastYear.percentile}th percentile
What remains? What adaptation is required?

Generate 4-5 findings about recovery and recalibration.`,

    whatYoureCreating: `This person has children. Analyze what they're creating generationally.

Started: ${firstYear.percentile}th percentile
Current: ${lastYear.percentile}th percentile ($${lastYear.income?.toLocaleString()})

Generate 4-5 substantial findings covering:
1. What percentile are their children starting at vs where they started?
2. The generational inflection point - are they the hinge in family economic history?
3. Optionality created - savings rate potential, when does work become optional?
4. Educational and opportunity access now available
5. The asymmetry in lived experience - they know both sides, children will only know abundance`,

    whatYoureBuilding: `This person does not have children. Analyze what they're building.
Current: ${lastYear.percentile}th percentile at age ${lastYear.age}
What optionality has been created? What freedom does this provide?

Generate 4-5 findings about wealth accumulation and freedom without generational transfer.`,

    inflationImpact: `Analyze how inflation and Regional Price Parity affected purchasing power over this person's career.

WRITE IN FLOWING ANALYTICAL PROSE. Each finding should be 3-5 sentences that EXPLAIN and ANALYZE, not just state facts. Connect ideas. Show cause and effect. Make the reader understand WHY things happened, not just WHAT happened.

Locations: ${locations.join(' → ')}
Time span: ${firstYear.year} to ${lastYear.year}
First location: ${firstYear.location}
Current location: ${lastYear.location}

Generate 4-5 substantial findings. Each finding should:
- Start with a bold header using **Header Text.**
- Follow with 3-5 sentences of flowing analysis
- Explain the WHY, not just the WHAT
- Connect to the person's overall trajectory

Topics to cover:
1. How geographic moves affected purchasing power - did moves to expensive cities erase gains? Did moves to cheaper areas amplify income growth?
2. The timing of geography changes - when did geography work against them vs for them?
3. The 2021-2024 inflation shock (25%+ in 3 years, worst since 1981) - how did it interact with their income trajectory?
4. The "hidden story" of the $700k equivalent line - what does its shape reveal about the interplay of income, inflation, and geography?
5. The net effect over the full period - how much purchasing power did they actually gain after accounting for inflation and geography?

DO NOT write in short, choppy sentences. DO NOT just list facts. Write like a thoughtful analyst explaining a complex picture.`,

    relateScoreAnalysis: `Analyze this person's Relate Score - what it measures and what goes into it.

RELATE SCORE COMPONENTS (weighted sum):
The Relate Score is a 0-100 scale measuring dating market position, ALWAYS displayed as X/10.

ACTUAL COMPUTED VALUES FOR THIS USER:
- Final Relate Score: ${(lastYear.relateScore / 10).toFixed(1) || 'N/A'}/10
${lastYear.relateComponents ? `
Component Breakdown (all scores are /100 internally, but reference as /10 for users):
- Income (national percentile): ${(lastYear.relateComponents.incomeNational / 10)?.toFixed(1) || 'N/A'}/10
- Income (local-adjusted): ${(lastYear.relateComponents.incomeLocal / 10)?.toFixed(1) || 'N/A'}/10
- Education (national): ${(lastYear.relateComponents.eduNational / 10)?.toFixed(1) || 'N/A'}/10
- Education (local-adjusted): ${(lastYear.relateComponents.eduLocal / 10)?.toFixed(1) || 'N/A'}/10
- Age Score: ${(lastYear.relateComponents.ageScore / 10)?.toFixed(1) || 'N/A'}/10
- Ethnicity Score: ${(lastYear.relateComponents.ethnicityScore / 10)?.toFixed(1) || 'N/A'}/10
- Children Score: ${(lastYear.relateComponents.childrenScore / 10)?.toFixed(1) || 'N/A'}/10
- Base Score (before marriage premium): ${(lastYear.relateComponents.baseScore / 10)?.toFixed(1) || 'N/A'}/10
- Marriage Premium multiplier: ${lastYear.relateComponents.marriagePremium?.toFixed(2) || '1.00'}x
` : '(Component breakdown not available)'}

WEIGHT FORMULA (${formData.gender === 'man' || formData.gender === 'male' ? 'men' : 'women'}):
${formData.gender === 'man' || formData.gender === 'male' ? 
`Income (45%) + Education (20%) + Age (15%) + Ethnicity (10%) + Children (10%)` :
`Income (25%) + Education (25%) + Age (30%) + Ethnicity (10%) + Children (10%)`}

User profile:
- Gender: ${formData.gender || 'not specified'}
- Age: ${lastYear.age}
- Income: $${lastYear.income?.toLocaleString()} at ${lastYear.percentile}th percentile
- Education: ${lastYear.education || formData.education || 'not specified'}
- Ethnicity: ${formData.ethnicity || 'not specified'}
- Has children: ${lastYear.hasKids === 'yes' || lastYear.children === 'yes' ? 'Yes' : 'No'}
- Relationship: ${lastYear.relationship || 'Single'}

${formData.probeResponses?.partnerPreferences ? `
PARTNER PREFERENCES (user's own words):
"${formData.probeResponses.partnerPreferences}"
` : ''}

${formData.probeResponses?.relocationOpenness ? `
RELOCATION OPENNESS (user's own words):
"${formData.probeResponses.relocationOpenness}"
` : ''}

Generate 4-5 substantial findings covering:
1. WHAT THE SCORE MEANS: A ${(lastYear.relateScore / 10).toFixed(1) || 'N/A'}/10 means what tier of the dating market? How does this compare to average (5/10)?
2. WHICH COMPONENTS HELP: Looking at the component breakdown above, which factors score HIGHEST and pull the total UP?
3. WHICH COMPONENTS HURT: Which factors score LOWEST and drag the total DOWN? ${lastYear.relateComponents?.ageScore < 70 ? `Age scores ${(lastYear.relateComponents.ageScore / 10)?.toFixed(1)}/10 - explain why.` : ''}
4. LOCAL VS NATIONAL: The income shows ${(lastYear.relateComponents?.incomeNational / 10)?.toFixed(1) || 'N/A'}/10 national vs ${(lastYear.relateComponents?.incomeLocal / 10)?.toFixed(1) || 'N/A'}/10 local - explain the adjustment.
5. ACTIONABLE INSIGHT: What could realistically improve? What can't change?${formData.probeResponses?.partnerPreferences ? ' Consider their stated partner preferences.' : ''}${formData.probeResponses?.relocationOpenness ? ' Consider their relocation openness and how geography affects their score.' : ''}

CRITICAL: ALWAYS express Relate Score as #/10, NEVER as a percentage or /100. Say "8.0/10" not "80/100" or "80%".`,

    matchScoreAnalysis: `Analyze this person's Match Score and LOCAL dating pool - the realistic number of potential partners.

DO NOT start with a markdown header like "## Match Score Analysis". Instead, start with this EXACT format as the first line:
*Your Match Score: ${lastYear.matchPool?.toLocaleString() || 'N/A'} realistic matches in ${lastYear.location}${formData.ethnicity ? ` and approximately ${Math.round((lastYear.matchPool || 0) * 0.15).toLocaleString()} ${formData.ethnicity} ${formData.gender === 'man' ? 'women' : 'men'} match your education` : ''}*

Then add a blank line, then begin the analysis.

MATCH SCORE MECHANICS:
Match Score = Sigmoid function of Relate Score, representing match probability per encounter

ACTUAL COMPUTED VALUES:
- Relate Score: ${(lastYear.relateScore / 10).toFixed(1) || 'N/A'}/10
- Match Probability: ${lastYear.matchScore?.toFixed(1) || 'N/A'}%
- LOCAL Single Pool: ${lastYear.localSinglePool?.toLocaleString() || 'N/A'} single ${formData.gender === 'man' ? 'women' : 'men'} in ${lastYear.location}
- Realistic Match Pool: ${lastYear.matchPool?.toLocaleString() || 'N/A'} (funnel: 18-64, non-felon, single, × match probability)
- Metro Population: ${lastYear.population?.toLocaleString() || 'N/A'}

THE FUNNEL (actual math):
1. Metro population: ${lastYear.population?.toLocaleString() || 'N/A'}
2. − 65+ and homeless (27.5%) → Adults 18-64
3. → Target gender (${formData.gender === 'man' ? 'women ~51%' : 'men ~49%'} × local weight)
4. − Felons (stratified by demographics: ~0.5-14%)
5. → Single (35% × local weight)
6. = Local single pool: ${lastYear.localSinglePool?.toLocaleString() || 'N/A'}
7. × Match probability ${lastYear.matchScore?.toFixed(1) || 'N/A'}%
8. = Realistic matches: ${lastYear.matchPool?.toLocaleString() || 'N/A'}

FURTHER FILTERING (conceptual):
- Same ethnicity (${formData.ethnicity || 'not specified'}): Would narrow pool by ~60-80%
- Education-matched (${lastYear.education || 'college+'} or higher): Would narrow pool by ~50-70%
- Combined filters: Might leave ${Math.round((lastYear.matchPool || 0) * 0.15).toLocaleString()} highly compatible matches

${formData.probeResponses?.partnerPreferences ? `
PARTNER PREFERENCES (user's own words):
"${formData.probeResponses.partnerPreferences}"

Incorporate their stated preferences into the analysis - how do their preferences affect their realistic pool?
` : ''}

${formData.probeResponses?.relocationOpenness ? `
RELOCATION OPENNESS (user's own words):
"${formData.probeResponses.relocationOpenness}"

Incorporate their relocation openness - if they mentioned specific metros, discuss how those markets compare.
` : ''}

Generate 4-5 substantial findings covering:
1. POOL SIZE IN CONTEXT: ${lastYear.matchPool?.toLocaleString() || 'N/A'} in ${lastYear.location} - is this large or small? Compare to NYC (~500k), Chicago (~300k), small metros (~20k).
2. THE MATH: Walk through the funnel above - why does ${lastYear.population?.toLocaleString() || 'N/A'} become ${lastYear.matchPool?.toLocaleString() || 'N/A'}?
3. WHAT ${lastYear.matchScore?.toFixed(1) || 50}% PROBABILITY MEANS: On apps, if you swipe on 100 profiles, expect ~${Math.round(lastYear.matchScore || 50)} mutual matches.
4. ETHNICITY/EDUCATION FILTERS: With ethnicity AND education filtering, the ${lastYear.matchPool?.toLocaleString() || 'N/A'} might become ~${Math.round((lastYear.matchPool || 0) * 0.15).toLocaleString()}. What does that mean practically?
5. GEOGRAPHIC STRATEGY: ${formData.probeResponses?.relocationOpenness ? 'Based on their stated relocation preferences, ' : ''}In a 10M+ metro like NYC or LA, the pool would be ~5-10x larger. Worth relocating? Trade-offs?

IMPORTANT: Use the ACTUAL numbers shown above. The pool is LOCAL to ${lastYear.location}, not national.
CRITICAL: ALWAYS express Relate Score as #/10, NEVER as a percentage or /100.`
  };
  
  return prompts[cardName] || `Generate analysis for ${cardName}.`;
};

/**
 * Generate narrative content for a specific card via Claude API
 * Sequential processing - no parallel calls to avoid rate limits
 */
const generateNarrativeCard = async (cardName, reportData, formData, persona) => {
  const systemPrompt = buildSystemPrompt(persona, formData);
  const dataContext = formatDataContext(reportData, formData, persona);
  const cardPrompt = getCardPrompt(cardName, reportData, formData, persona);
  
  const userMessage = `${dataContext}

---

CARD TO GENERATE: ${cardName}

${cardPrompt}`;

  const response = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: "claude-sonnet-4-20250514",
      max_tokens: 4000,
      system: systemPrompt,
      messages: [{ role: "user", content: userMessage }]
    })
  });
  
  if (!response.ok) {
    // Wait and retry once on any error
    await new Promise(resolve => setTimeout(resolve, 3000));
    const retryResponse = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "claude-sonnet-4-20250514",
        max_tokens: 4000,
        system: systemPrompt,
        messages: [{ role: "user", content: userMessage }]
      })
    });
    
    if (!retryResponse.ok) {
      throw new Error(`API error ${retryResponse.status}`);
    }
    
    const retryData = await retryResponse.json();
    return retryData.content?.[0]?.text || '';
  }
  
  const data = await response.json();
  return data.content?.[0]?.text || '';
};

/**
 * Generate all narrative content for Report
 * SEQUENTIAL processing - one card at a time to guarantee no rate limits
 */
const generateAllNarratives = async (reportData, formData, onProgress) => {
  const persona = detectFullPersona(reportData, formData);
  const results = { persona };
  
  // Human-readable card names for progress display
  const cardDisplayNames = {
    contextByYear: 'Context by Year',
    keyFindings: 'Key Findings',
    rarityAnalysis: 'Rarity Analysis',
    scarcityMindset: 'Scarcity Mindset',
    abundanceMindset: 'Abundance Mindset',
    stabilityMindset: 'Stability Mindset',
    lossMindset: 'Loss & Recovery',
    whatYoureCreating: 'What You\'re Creating',
    whatYoureBuilding: 'What You\'re Building',
    inflationImpact: 'Inflation Impact',
    relateScoreAnalysis: 'Relate Score',
    matchScoreAnalysis: 'Match Score',
    percentileThresholds: 'Percentile Analysis'
  };
  
  // Persona display names (without saying "persona")
  const trajectoryNames = {
    CLIMBER: 'Upward Trajectory',
    LATE_BLOOMER: 'Late Bloomer',
    EARLY_ACHIEVER: 'Early Achiever',
    FALLEN: 'Recovery Path',
    RETURNED: 'Second Act',
    STRUGGLER: 'Persistent Climber',
    STEADY: 'Steady Builder',
    GENERAL: 'Your Journey'
  };
  
  const trajectoryName = trajectoryNames[persona.trajectory] || 'Your Journey';
  
  // All cards to generate - SEQUENTIAL order
  const allCards = [
    'contextByYear',
    'keyFindings',
    'percentileThresholds',
    'rarityAnalysis',
    persona.mindsetCard,
    persona.futureCard,
    'inflationImpact',
    'relateScoreAnalysis',
    'matchScoreAnalysis'
  ];
  
  // Process ONE AT A TIME - no parallel, no rate limits
  for (let i = 0; i < allCards.length; i++) {
    const cardName = allCards[i];
    const displayName = cardDisplayNames[cardName] || cardName;
    
    if (onProgress) onProgress({ 
      current: i + 1, 
      total: allCards.length + 1, // +1 for finalizing step
      cardName: displayName,
      trajectoryName 
    });
    
    const content = await generateNarrativeCard(cardName, reportData, formData, persona);
    
    // Special handling for contextByYear - parse JSON
    if (cardName === 'contextByYear') {
      try {
        const jsonMatch = content.match(/\[[\s\S]*\]/);
        if (jsonMatch) {
          const contexts = JSON.parse(jsonMatch[0]);
          const contextMap = {};
          contexts.forEach(c => { contextMap[c.year] = c.context; });
          results.contextByYear = contextMap;
        } else {
          results.contextByYear = {};
        }
      } catch (e) {
        console.error('Error parsing contextByYear JSON:', e);
        results.contextByYear = {};
      }
    } else {
      results[cardName] = content;
    }
    
    // Small delay between calls to be safe
    if (i < allCards.length - 1) {
      await new Promise(resolve => setTimeout(resolve, 500));
    }
  }
  
  // Final "Finalizing" step
  if (onProgress) onProgress({ 
    current: allCards.length + 1, 
    total: allCards.length + 1,
    cardName: 'Finalizing your report',
    trajectoryName 
  });
  
  // Brief pause for finalization display
  await new Promise(resolve => setTimeout(resolve, 1000));
  
  return results;
};

// =============================================================================
// CHART HELPER FUNCTIONS
// =============================================================================

// Convert percentile to inverted value (99th percentile becomes 1, 38th becomes 62)
// So the line goes DOWN toward 1% as you improve
const percentileToTop = (percentile) => 100 - percentile;

// Transform for chart positioning - spreads out the lower values
const transformForAxis = (value) => {
  if (value <= 100) return value * 0.85;
  return 85 + ((value - 100) / 300) * 15;
};

/**
 * Process narrative text for consistent HTML rendering
 * Ensures uniform paragraph spacing and formatting across all sections
 */
const formatNarrativeText = (text) => {
  if (!text) return '';
  
  // Clean up any existing HTML tags first (in case of fallback content)
  let cleaned = text
    .replace(/<p[^>]*>/gi, '')
    .replace(/<\/p>/gi, '\n\n')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<strong>/gi, '**')
    .replace(/<\/strong>/gi, '**')
    .trim();
  
  // Handle italic header line (*text* at start)
  let headerHtml = '';
  const italicMatch = cleaned.match(/^\*([^*]+)\*\n\n/);
  if (italicMatch) {
    headerHtml = `<p style="font-style: italic; margin-bottom: 16px;">${italicMatch[1]}</p>`;
    cleaned = cleaned.replace(/^\*([^*]+)\*\n\n/, '');
  }
  
  // Convert **bold** to <strong>
  cleaned = cleaned.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
  
  // Split into paragraphs (double newline)
  const paragraphs = cleaned.split(/\n\n+/).filter(p => p.trim());
  
  // Wrap each paragraph with consistent styling
  const bodyHtml = paragraphs.map(p => {
    // Replace single newlines with <br/> within paragraphs
    const content = p.trim().replace(/\n/g, '<br/>');
    return `<p style="margin-bottom: 11px;">${content}</p>`;
  }).join('');
  
  return headerHtml + bodyHtml;
};

// Normal percent ticks (used by % to $700k, % of Goal)
const percentTicks = [0, 25, 50, 75, 100, 400];
const transformedTicks = percentTicks.map(transformForAxis);

const formatPercentTick = (transformedValue) => {
  // Reverse the transform to get original percent value
  let originalValue;
  if (transformedValue <= 85) {
    originalValue = transformedValue / 0.85;
  } else {
    originalValue = 100 + ((transformedValue - 85) / 15) * 300;
  }
  return `${Math.round(originalValue)}%`;
};

// Generate dollar axis ticks based on income range
const generateDollarTicks = (incomeData, visibleLines) => {
  // Collect max values from all visible dollar lines
  const maxValues = [];
  if (visibleLines?.income) maxValues.push(Math.max(...incomeData.map(d => d.income)));
  if (visibleLines?.purchasePower) maxValues.push(Math.max(...incomeData.map(d => d.purchasePower)));
  if (visibleLines?.equiv700k) maxValues.push(Math.max(...incomeData.map(d => d.equiv700k)));
  if (visibleLines?.goal) maxValues.push(Math.max(...incomeData.map(d => d.goal)));
  if (visibleLines?.safe) maxValues.push(Math.max(...incomeData.map(d => d.safe)));
  if (visibleLines?.greenLine) maxValues.push(Math.max(...incomeData.map(d => d.greenLine)));
  if (visibleLines?.medianHH) maxValues.push(Math.max(...incomeData.map(d => d.medianHH)));
  if (visibleLines?.povertyLine) maxValues.push(Math.max(...incomeData.map(d => d.povertyLine)));
  
  const maxDollar = maxValues.length > 0 ? Math.max(...maxValues) : 700000;
  const minIncome = Math.min(...incomeData.map(d => d.income));
  
  const ticks = []; // Don't include $0 - first year label will be at origin
  
  // Include $100k only if income range spans that region meaningfully
  if (maxDollar > 100000 && minIncome < 200000) {
    ticks.push(100000);
  }
  
  if (maxDollar > 150000) ticks.push(200000);
  if (maxDollar > 300000) ticks.push(400000);
  if (maxDollar > 500000) ticks.push(600000);
  
  // Add the actual max value as the top tick (rounded to nearest 50k)
  const roundedMax = Math.ceil(maxDollar / 50000) * 50000;
  if (!ticks.includes(roundedMax)) {
    ticks.push(roundedMax);
  }
  
  return ticks.sort((a, b) => a - b);
};

const generatePercentTicks = (incomeData, visibleLines) => {
  // Collect max percent values from visible percent lines (use untransformed values)
  const maxValues = [];
  if (visibleLines?.percentile) maxValues.push(Math.max(...incomeData.map(d => d.percentile)));
  if (visibleLines?.achieve) maxValues.push(Math.max(...incomeData.map(d => d.pctToGoal)));
  if (visibleLines?.relateScore) maxValues.push(Math.max(...incomeData.map(d => d.relateScore)));
  if (visibleLines?.matchScore) maxValues.push(Math.max(...incomeData.filter(d => d.matchScore !== null).map(d => d.matchScore)));
  
  const maxPercent = maxValues.length > 0 ? Math.max(...maxValues) : 100;
  
  // Build tick array based on max
  const ticks = [0];
  if (maxPercent > 20) ticks.push(25);
  if (maxPercent > 45) ticks.push(50);
  if (maxPercent > 70) ticks.push(75);
  if (maxPercent <= 100) ticks.push(100);
  if (maxPercent > 100) {
    ticks.push(100);
    if (maxPercent > 200) ticks.push(200);
    if (maxPercent > 300) ticks.push(300);
    // Add actual max rounded up to nearest 50
    const roundedMax = Math.ceil(maxPercent / 50) * 50;
    if (!ticks.includes(roundedMax)) ticks.push(roundedMax);
  }
  
  return ticks.map(transformForAxis);
};

// ═══════════════════════════════════════════════════════════════════════════════
// SHARED CALCULATION MODULE - THE ONE SOURCE OF TRUTH
// Implements exactly what report-calculations.md defines
// Demo, Report, and Map ALL call these functions - no duplicates, no variations
// ═══════════════════════════════════════════════════════════════════════════════

// --- CONSTANTS (from Section 8.1-8.5 of project instructions) ---

const WEIGHTS_MALE = { income: 0.45, education: 0.15, age: 0.20, ethnicity: 0.10, children: 0.10 };
const WEIGHTS_FEMALE = { income: 0.25, education: 0.20, age: 0.25, ethnicity: 0.15, children: 0.15 };

// Age desirability curves (Section 8.3)
const AGE_CURVE_MALE = [
  { minAge: 0,  maxAge: 17,  startScore: 30, endScore: 30 },
  { minAge: 18, maxAge: 24,  startScore: 40, endScore: 60 },
  { minAge: 25, maxAge: 29,  startScore: 60, endScore: 75 },
  { minAge: 30, maxAge: 34,  startScore: 75, endScore: 85 },
  { minAge: 35, maxAge: 44,  startScore: 85, endScore: 85 },
  { minAge: 45, maxAge: 49,  startScore: 85, endScore: 75 },
  { minAge: 50, maxAge: 54,  startScore: 75, endScore: 65 },
  { minAge: 55, maxAge: 59,  startScore: 65, endScore: 55 },
  { minAge: 60, maxAge: 120, startScore: 55, endScore: 55 },
];

const AGE_CURVE_FEMALE = [
  { minAge: 0,  maxAge: 17,  startScore: 40, endScore: 40 },
  { minAge: 18, maxAge: 21,  startScore: 60, endScore: 80 },
  { minAge: 22, maxAge: 29,  startScore: 85, endScore: 85 },
  { minAge: 30, maxAge: 34,  startScore: 85, endScore: 75 },
  { minAge: 35, maxAge: 39,  startScore: 75, endScore: 65 },
  { minAge: 40, maxAge: 44,  startScore: 65, endScore: 55 },
  { minAge: 45, maxAge: 49,  startScore: 55, endScore: 50 },
  { minAge: 50, maxAge: 120, startScore: 50, endScore: 50 },
];

// Children scores (Section 8.4)
const CHILDREN_SCORES = {
  man: { has_kids_over_35: 60, has_kids_under_35: 45, no_kids_over_35: 50, no_kids_under_35: 70 },
  woman: { has_kids_over_30: 55, has_kids_under_30: 40, no_kids_over_35: 45, no_kids_under_35: 65 }
};

// Marriage premium config (Section 8.5)
const MARRIAGE_PREMIUM_CONFIG = {
  provision_thresholds: [
    { min: 0.0,  max: 0.8,      factor: -0.05 },
    { min: 0.8,  max: 1.0,      factor: 0.00 },
    { min: 1.0,  max: 1.25,     factor: 0.03 },
    { min: 1.25, max: 1.5,      factor: 0.06 },
    { min: 1.5,  max: 2.0,      factor: 0.10 },
    { min: 2.0,  max: Infinity, factor: 0.15 },
  ],
  hypergamy_factor: 0.10,
  premium_floor: 0.90,
  premium_ceiling: 1.20
};

// Income brackets for CBSA lookup (Section 8.7)
const INCOME_BRACKETS = [
  { col: 'income_under_35k_cbsa',  min: 0,      max: 35000 },
  { col: 'income_35k_50k_cbsa',    min: 35000,  max: 50000 },
  { col: 'income_50k_75k_cbsa',    min: 50000,  max: 75000 },
  { col: 'income_75k_100k_cbsa',   min: 75000,  max: 100000 },
  { col: 'income_100k_150k_cbsa',  min: 100000, max: 150000 },
  { col: 'income_150k_200k_cbsa',  min: 150000, max: 200000 },
  { col: 'income_200k_300k_cbsa',  min: 200000, max: 300000 },
  { col: 'income_300k_500k_cbsa',  min: 300000, max: 500000 },
  { col: 'income_500k_750k_cbsa',  min: 500000, max: 750000 },
  { col: 'income_750k_plus_cbsa',  min: 750000, max: Infinity }
];

// Education order for percentile calc (Section 8.8)
const EDUCATION_ORDER = ['less_hs', 'hs_grad', 'trade', 'associate', 'some_college', 'bachelors', 'graduate'];
const EDUCATION_COLUMNS = [
  'education_less_hs_cbsa', 'education_hs_grad_cbsa', 'education_trade_cbsa',
  'education_associate_cbsa', 'education_some_college_cbsa', 
  'education_bachelors_cbsa', 'education_graduate_cbsa'
];

// Felony rates by gender and ethnicity (based on Bureau of Justice Statistics data)
// Simplified to white vs people of color (poc) for matching user demographics
const FELON_RATES = {
  men: {
    overall: 0.13,
    white: 0.08,
    poc: 0.22       // Weighted average for non-white men
  },
  women: {
    overall: 0.03,
    white: 0.02,
    poc: 0.05       // Weighted average for non-white women
  }
};

// Education dramatically reduces felony rates (multipliers applied to ethnicity rate)
// College completion is one of strongest predictors of no criminal record
const EDUCATION_FELON_MULTIPLIERS = {
  'high school': 1.3,      // Slightly above base
  'some college': 0.65,    // Below base
  'bachelors': 0.20,       // Much lower
  'graduate': 0.10         // Very low
};

// Drug use rates by gender and ethnicity (based on CDC data, marriage-weighted)
// Men use drugs at higher rates than women; slight variation by ethnicity
const DRUG_USE_RATES = {
  men: {
    overall: 0.16,
    white: 0.16,      // Men + white
    poc: 0.14         // Men + POC slightly lower
  },
  women: {
    overall: 0.12,
    white: 0.13,      // Women + white
    poc: 0.11         // Women + POC
  }
};

// Education affects drug use rates (multipliers applied to base rate)
// Higher education correlates with lower drug use
const EDUCATION_DRUG_MULTIPLIERS = {
  'high school': 1.25,     // 18% base → higher
  'some college': 1.10,    // 16% base
  'bachelors': 0.80,       // 12% base → lower
  'graduate': 0.60         // 9% base → lowest
};

// === UNAVAILABLE POPULATION FILTERS ===

// STAGE 1: Universal exclusions (applied to total population first)
// These affect everyone equally regardless of demographics
const OVER_65_RATE = 0.23;      // 23% of adults 18+ are 65+ (Census 2024: 61.2M of ~267M adults)
const HOMELESS_RATE = 0.005;    // 0.5% of adults are homeless
const UNIVERSAL_EXCLUSION_RATE = OVER_65_RATE + HOMELESS_RATE;  // 23.5%

// STAGE 2: Stratified felon rates (applied after gender filter)
// Vary by target demographic (gender, ethnicity, education)
// See FELON_RATES and EDUCATION_FELON_MULTIPLIERS above

// STAGE 3: Stratified drug use rates (applied after felon filter)
// Vary by target demographic (gender, ethnicity, education)
// See DRUG_USE_RATES and EDUCATION_DRUG_MULTIPLIERS above

// === CBSA DATA KEYS REFERENCE ===
// All keys from cbsa-data.js organized by how they're used in calculations
// 
// COMPLETE REFERENCE TABLE:
// | Attribute    | Local Weight (÷50)   | National Percentages (÷100)                                                                                     |
// |--------------|----------------------|-----------------------------------------------------------------------------------------------------------------|
// | Income       | income_cbsa          | income_under_35k_cbsa, income_35k_50k_cbsa, income_50k_75k_cbsa, income_75k_100k_cbsa, income_100k_150k_cbsa,   |
// |              |                      | income_150k_200k_cbsa, income_200k_300k_cbsa, income_300k_500k_cbsa, income_500k_750k_cbsa, income_750k_plus    |
// | Education    | bachelors_cbsa       | education_less_hs_cbsa, education_hs_grad_cbsa, education_trade_cbsa, education_associate_cbsa,                |
// |              |                      | education_some_college_cbsa, education_bachelors_cbsa, education_graduate_cbsa                                 |
// | Fitness      | activity_cbsa        | fitness_never_cbsa, fitness_1_day_cbsa, fitness_2_3_days_cbsa, fitness_4_6_days_cbsa, fitness_daily_cbsa       |
// | BMI          | obesity_cbsa         | bmi_elite_cbsa, bmi_normal_cbsa, bmi_overweight_cbsa, bmi_obesity_cbsa                                         |
// | Smoking      | smoking_cbsa         | smoking_no_cbsa, smoking_yes_cbsa                                                                              |
// | Age          | age_25_45_cbsa       | age_18_19_cbsa, age_20_24_cbsa, age_25_29_cbsa, age_30_34_cbsa, age_35_39_cbsa, age_40_44_cbsa,                |
// |              |                      | age_45_49_cbsa, age_50_54_cbsa, age_55_59_cbsa, age_60_64_cbsa, age_65_69_cbsa, age_70_74_cbsa,                |
// |              |                      | age_75_79_cbsa, age_80_84_cbsa, age_85_120_cbsa                                                                |
// | Relationship | single_18_65_cbsa    | relationship_married_cbsa, relationship_dating_cbsa, relationship_separated_cbsa, relationship_single_cbsa    |
// | Male         | male_cbsa            | gender_man_cbsa                                                                                                |
// | Female       | female_cbsa          | gender_woman_cbsa                                                                                              |
// | Ethnicity    | pct_white_cbsa       | ethnicity_white_cbsa, ethnicity_hispanic_cbsa, ethnicity_black_cbsa, ethnicity_asian_cbsa,                     |
// |              |                      | ethnicity_native_cbsa, ethnicity_pacific_cbsa, ethnicity_other_cbsa                                            |
// | Height       | (none)               | height_under_60_cbsa, height_60_62_cbsa, height_63_65_cbsa, height_66_68_cbsa, height_69_71_cbsa,              |
// |              |                      | height_72plus_cbsa                                                                                             |
// | Political    | (none)               | political_conservative_cbsa, political_moderate_cbsa, political_liberal_cbsa, political_apolitical_cbsa        |
// | Have Kids    | (none)               | have_kids_yes_cbsa, have_kids_no_cbsa                                                                          |
// | Drugs        | (none)               | drugs_no_cbsa, drugs_yes_cbsa                                                                                  |
// | Orientation  | (none)               | orientation_straight_cbsa, orientation_bisexual_cbsa, orientation_gay_lesbian_cbsa, orientation_other_cbsa     |

// === IDEAL POOLS CALCULATION FORMULAS ===
// MAP THRESHOLD: 500+ to display on map
// 
// IMPORTANT: single_18_65_cbsa is INVERTED in the data, use (100 - single_18_65_cbsa) / 50
//
// EXCLUSION RATES (for bachelor's+ population):
//   FELON_RATES:  Men overall=0.026, white=0.016, poc=0.044 | Women overall=0.006, white=0.004, poc=0.010
//   DRUG_RATES:   Men overall=0.128, white=0.128, poc=0.112 | Women overall=0.096, white=0.104, poc=0.088
//
// PRIME DATING AGE (25-54):
//   primeAgePct = (age_25_29_cbsa + age_30_34_cbsa + age_35_39_cbsa + age_40_44_cbsa + age_45_49_cbsa + age_50_54_cbsa) / 100
//
// DENOMINATORS (just singles, no exclusions) - NOTE: uses FLIPPED singles weight
//   LOCAL_SINGLE_MEN = cbsa_population × (male_cbsa/100) × (gender_man_cbsa/50) × (relationship_single_cbsa/100) × ((100-single_18_65_cbsa)/50)
//   LOCAL_SINGLE_WOMEN = cbsa_population × (female_cbsa/100) × (gender_woman_cbsa/50) × (relationship_single_cbsa/100) × ((100-single_18_65_cbsa)/50)
//   NATIONAL_SINGLE_MEN = national_population × (male_national/100) × (relationship_single_national/100)
//   NATIONAL_SINGLE_WOMEN = national_population × (female_national/100) × (relationship_single_national/100)
//
// STATE 1: IDEAL MEN (no ethnicity) - FELON=0.026, DRUG=0.128
//   = cbsa_population × 0.765
//     × (male_cbsa/100) × (gender_man_cbsa/50)
//     × (1-0.026) × (1-0.128)
//     × (relationship_single_cbsa/100) × ((100-single_18_65_cbsa)/50)  ← FLIPPED
//     × (orientation_straight_cbsa/100) × primeAgePct                  ← AGE 25-54
//     × ((education_bachelors_cbsa+education_graduate_cbsa)/100) × (bachelors_cbsa/50)
//     × ((income_200k_300k_cbsa+income_300k_500k_cbsa+income_500k_750k_cbsa+income_750k_plus_cbsa)/100) × (income_cbsa/50)
//     × (height_72plus_cbsa/100)
//     × min(((bmi_elite_cbsa+bmi_normal_cbsa+bmi_overweight_cbsa)/100) × (50/obesity_cbsa), 1)
//     × min((smoking_no_cbsa/100) × (smoking_cbsa/50), 1)
//   PCT = IDEAL_MEN / LOCAL_SINGLE_MEN × 100
//   PER_100K = IDEAL_MEN / LOCAL_SINGLE_MEN × 100000
//
// STATE 1: IDEAL WOMEN (no ethnicity) - FELON=0.006, DRUG=0.096
//   = cbsa_population × 0.765
//     × (female_cbsa/100) × (gender_woman_cbsa/50)
//     × (1-0.006) × (1-0.096)
//     × (relationship_single_cbsa/100) × ((100-single_18_65_cbsa)/50)  ← FLIPPED
//     × (orientation_straight_cbsa/100) × primeAgePct                  ← AGE 25-54
//     × ((education_bachelors_cbsa+education_graduate_cbsa)/100) × (bachelors_cbsa/50)
//     × min((bmi_elite_cbsa/100) × (50/obesity_cbsa), 1)              ← ELITE ONLY
//     × min(((fitness_4_6_days_cbsa+fitness_daily_cbsa)/100) × (activity_cbsa/50), 1)  ← FITNESS 4-6+
//     × min((smoking_no_cbsa/100) × (smoking_cbsa/50), 1)
//     × (have_kids_no_cbsa/100)
//   PCT = IDEAL_WOMEN / LOCAL_SINGLE_WOMEN × 100
//   PER_100K = IDEAL_WOMEN / LOCAL_SINGLE_WOMEN × 100000
//
// STATE 2/3 (WHITE): Add × (ethnicity_white_cbsa/100) × (pct_white_cbsa/50), use white felon/drug rates
// STATE 2/3 (POC): Add × ((100-ethnicity_white_cbsa)/100) × ((100-pct_white_cbsa)/50), use poc felon/drug rates
//
// NATIONAL TOTALS:
//   NATIONAL_[TYPE] = SUM([TYPE] for all CBSAs)
//   NATIONAL_[TYPE]_PCT = NATIONAL_[TYPE] / NATIONAL_SINGLE_[GENDER] × 100
//   NATIONAL_[TYPE]_PER_100K = NATIONAL_[TYPE] / NATIONAL_SINGLE_[GENDER] × 100000

// LOCAL WEIGHT KEYS (divide by 50, where 50 = national average)
const CBSA_LOCAL_WEIGHT_KEYS = {
  income: 'income_cbsa',
  education: 'bachelors_cbsa',
  fitness: 'activity_cbsa',
  bmi: 'obesity_cbsa',
  smoking: 'smoking_cbsa',
  age: 'age_25_45_cbsa',
  relationship: 'single_18_65_cbsa',
  male: 'male_cbsa',
  female: 'female_cbsa',
  ethnicity: 'pct_white_cbsa',
};

// NATIONAL PERCENTAGE KEYS (divide by 100, these are actual percentages)
const CBSA_NATIONAL_PCT_KEYS = {
  income: ['income_under_35k_cbsa', 'income_35k_50k_cbsa', 'income_50k_75k_cbsa', 'income_75k_100k_cbsa', 'income_100k_150k_cbsa', 'income_150k_200k_cbsa', 'income_200k_300k_cbsa', 'income_300k_500k_cbsa', 'income_500k_750k_cbsa', 'income_750k_plus_cbsa'],
  education: ['education_less_hs_cbsa', 'education_hs_grad_cbsa', 'education_trade_cbsa', 'education_associate_cbsa', 'education_some_college_cbsa', 'education_bachelors_cbsa', 'education_graduate_cbsa'],
  fitness: ['fitness_never_cbsa', 'fitness_1_day_cbsa', 'fitness_2_3_days_cbsa', 'fitness_4_6_days_cbsa', 'fitness_daily_cbsa'],
  bmi: ['bmi_elite_cbsa', 'bmi_normal_cbsa', 'bmi_overweight_cbsa', 'bmi_obesity_cbsa'],
  smoking: ['smoking_no_cbsa', 'smoking_yes_cbsa'],
  age: ['age_18_19_cbsa', 'age_20_24_cbsa', 'age_25_29_cbsa', 'age_30_34_cbsa', 'age_35_39_cbsa', 'age_40_44_cbsa', 'age_45_49_cbsa', 'age_50_54_cbsa', 'age_55_59_cbsa', 'age_60_64_cbsa', 'age_65_69_cbsa', 'age_70_74_cbsa', 'age_75_79_cbsa', 'age_80_84_cbsa', 'age_85_120_cbsa'],
  relationship: ['relationship_married_cbsa', 'relationship_dating_cbsa', 'relationship_separated_cbsa', 'relationship_single_cbsa'],
  gender: ['gender_man_cbsa', 'gender_woman_cbsa', 'gender_other_cbsa'],
  ethnicity: ['ethnicity_white_cbsa', 'ethnicity_hispanic_cbsa', 'ethnicity_black_cbsa', 'ethnicity_asian_cbsa', 'ethnicity_native_cbsa', 'ethnicity_pacific_cbsa', 'ethnicity_other_cbsa'],
  height: ['height_under_60_cbsa', 'height_60_62_cbsa', 'height_63_65_cbsa', 'height_66_68_cbsa', 'height_69_71_cbsa', 'height_72plus_cbsa'],
  political: ['political_conservative_cbsa', 'political_moderate_cbsa', 'political_liberal_cbsa', 'political_apolitical_cbsa'],
  have_kids: ['have_kids_yes_cbsa', 'have_kids_no_cbsa'],
  want_kids: ['want_kids_yes_cbsa', 'want_kids_no_cbsa', 'want_kids_maybe_cbsa'],
  drugs: ['drugs_no_cbsa', 'drugs_yes_cbsa'],
  orientation: ['orientation_straight_cbsa', 'orientation_bisexual_cbsa', 'orientation_gay_lesbian_cbsa', 'orientation_other_cbsa'],
};

// ABSOLUTE VALUES (not percentages, used directly)
const CBSA_ABSOLUTE_KEYS = [
  'cbsa_population',       // Total metro population
  'rpp',                   // Regional Price Parity (100 = national average cost of living)
  'lat', 'lng',            // Coordinates
  'cbsa',                  // CBSA code
];

// === HELPER FUNCTIONS: Map user inputs to CBSA keys ===

const getHeightBracketKey = (heightStr) => {
  const match = heightStr.match(/(\d+)'(\d+)"/);
  if (!match) return null;
  const inches = parseInt(match[1]) * 12 + parseInt(match[2]);
  
  if (inches < 60) return 'height_under_60_cbsa';
  if (inches <= 62) return 'height_60_62_cbsa';
  if (inches <= 65) return 'height_63_65_cbsa';
  if (inches <= 68) return 'height_66_68_cbsa';
  if (inches <= 71) return 'height_69_71_cbsa';
  return 'height_72plus_cbsa';
};

const getHeightInches = (heightStr) => {
  const match = heightStr.match(/(\d+)'(\d+)"/);
  if (!match) return null;
  return parseInt(match[1]) * 12 + parseInt(match[2]);
};

const getAgeBracketKey = (age) => {
  if (age <= 19) return 'age_18_19_cbsa';
  if (age <= 24) return 'age_20_24_cbsa';
  if (age <= 29) return 'age_25_29_cbsa';
  if (age <= 34) return 'age_30_34_cbsa';
  if (age <= 39) return 'age_35_39_cbsa';
  if (age <= 44) return 'age_40_44_cbsa';
  if (age <= 49) return 'age_45_49_cbsa';
  if (age <= 54) return 'age_50_54_cbsa';
  if (age <= 59) return 'age_55_59_cbsa';
  if (age <= 64) return 'age_60_64_cbsa';
  if (age <= 69) return 'age_65_69_cbsa';
  if (age <= 74) return 'age_70_74_cbsa';
  if (age <= 79) return 'age_75_79_cbsa';
  if (age <= 84) return 'age_80_84_cbsa';
  return 'age_85_120_cbsa';
};

const getIncomeBracketKey = (income) => {
  if (income < 35000) return 'income_under_35k_cbsa';
  if (income < 50000) return 'income_35k_50k_cbsa';
  if (income < 75000) return 'income_50k_75k_cbsa';
  if (income < 100000) return 'income_75k_100k_cbsa';
  if (income < 150000) return 'income_100k_150k_cbsa';
  if (income < 200000) return 'income_150k_200k_cbsa';
  if (income < 300000) return 'income_200k_300k_cbsa';
  if (income < 500000) return 'income_300k_500k_cbsa';
  if (income < 750000) return 'income_500k_750k_cbsa';
  return 'income_750k_plus_cbsa';
};

const getBMIKey = (bodyType) => {
  const map = {
    'lean_fit': 'bmi_elite_cbsa',
    'average': 'bmi_normal_cbsa',
    'overweight': 'bmi_overweight_cbsa',
    'obese': 'bmi_obesity_cbsa'
  };
  return map[bodyType] || null;
};

const getFitnessKey = (workoutFrequency) => {
  const map = {
    'never': 'fitness_never_cbsa',
    '1_day': 'fitness_1_day_cbsa',
    '2_3_days': 'fitness_2_3_days_cbsa',
    '4_6_days': 'fitness_4_6_days_cbsa',
    'daily': 'fitness_daily_cbsa'
  };
  return map[workoutFrequency] || null;
};

const getPoliticalKey = (politicalViews) => {
  const map = {
    'conservative': 'political_conservative_cbsa',
    'moderate': 'political_moderate_cbsa',
    'liberal': 'political_liberal_cbsa',
    'apolitical': 'political_apolitical_cbsa'
  };
  return map[politicalViews] || null;
};

const getSmokingKey = (smoking) => {
  const map = {
    'yes': 'smoking_yes_cbsa',
    'no': 'smoking_no_cbsa'
  };
  return map[smoking] || null;
};

const getEducationKey = (education) => {
  const map = {
    'less than hs': 'education_less_hs_cbsa',
    'hs_grad': 'education_hs_grad_cbsa',
    'hs grad': 'education_hs_grad_cbsa',
    'high school': 'education_hs_grad_cbsa',
    'trade': 'education_trade_cbsa',
    'associate': 'education_associate_cbsa',
    'some college': 'education_some_college_cbsa',
    'some_college': 'education_some_college_cbsa',
    'bachelors': 'education_bachelors_cbsa',
    "bachelor's": 'education_bachelors_cbsa',
    'graduate': 'education_graduate_cbsa'
  };
  return map[(education || '').toLowerCase()] || null;
};

const getEthnicityKey = (ethnicity) => {
  const map = {
    'white': 'ethnicity_white_cbsa',
    'hispanic': 'ethnicity_hispanic_cbsa',
    'black': 'ethnicity_black_cbsa',
    'asian': 'ethnicity_asian_cbsa',
    'native': 'ethnicity_native_cbsa',
    'pacific': 'ethnicity_pacific_cbsa',
    'other': 'ethnicity_other_cbsa'
  };
  return map[(ethnicity || '').toLowerCase()] || null;
};

const getKidsKey = (hasKids) => {
  if (hasKids === 'yes' || hasKids === 'Yes' || hasKids === true) return 'have_kids_yes_cbsa';
  if (hasKids === 'no' || hasKids === 'No' || hasKids === false) return 'have_kids_no_cbsa';
  return null;
};

const getOrientationKey = (orientation) => {
  const map = {
    'straight': 'orientation_straight_cbsa',
    'bisexual': 'orientation_bisexual_cbsa',
    'gay': 'orientation_gay_lesbian_cbsa',
    'lesbian': 'orientation_gay_lesbian_cbsa',
    'other': 'orientation_other_cbsa'
  };
  return map[(orientation || '').toLowerCase()] || null;
};

const getRelationshipKey = (relationshipStatus) => {
  const status = (relationshipStatus || '').toLowerCase();
  if (status === 'married' || status === 'yes') return 'relationship_married_cbsa';
  if (status === 'dating') return 'relationship_dating_cbsa';
  if (status === 'separated' || status === 'divorced') return 'relationship_separated_cbsa';
  if (status === 'single' || status === 'no') return 'relationship_single_cbsa';
  return null;
};

// === AGE PREFERENCE TABLES ===
// These tables define what each gender finds acceptable/premium at each life stage
// Used to calculate age alignment score: Premium = 1.00, Acceptable = 0.70, One bracket outside = 0.40, Two+ brackets outside = 0.15

// What Women Want (by life stage)
// Why: Women's preferences shift from attraction to stability to companionship as they age
const AGE_PREFS_WHAT_WOMEN_WANT = {
  '18-19': { 
    acceptable: ['18-19', '20-24', '25-29'], 
    premium: ['20-24'],
    why: 'Young, exploring, attracted to slightly older but not too old'
  },
  '20-24': { 
    acceptable: ['20-24', '25-29', '30-34'], 
    premium: ['30-34', '25-29'],
    why: 'Want maturity and early stability, still value attraction'
  },
  '25-29': { 
    acceptable: ['25-29', '30-34', '35-39'], 
    premium: ['30-34', '35-39'],
    why: 'Marriage-minded years, want established men with commitment potential'
  },
  '30-34': { 
    acceptable: ['30-34', '35-39', '40-44'], 
    premium: ['30-34', '35-39'],
    why: 'Urgency around family, need commitment-ready and financially stable'
  },
  '35-39': { 
    acceptable: ['35-39', '40-44', '45-49'], 
    premium: ['40-44', '45-49'],
    why: 'More flexible, value shared life stage and lifestyle compatibility'
  },
  '40-44': { 
    acceptable: ['35-39', '40-44', '45-49', '50-54'], 
    premium: ['40-44', '45-49'],
    why: 'Companionship focus, want age-appropriate partner, less about family'
  },
  '45-49': { 
    acceptable: ['35-39', '40-44', '45-49', '50-54', '55-59'], 
    premium: ['40-44', '45-49', '50-54'],
    why: 'Shared experience matters, health and lifestyle alignment'
  },
  '50-54': { 
    acceptable: ['45-49', '50-54', '55-59', '60-64'], 
    premium: ['50-54', '55-59'],
    why: 'Age-appropriate, value stability and companionship'
  },
  '55-59': { 
    acceptable: ['55-59', '60-64'], 
    premium: ['55-59', '60-64'],
    why: 'Narrowing pool, prioritize health and shared retirement vision'
  },
  '60-64': { 
    acceptable: ['60-64'], 
    premium: ['60-64'],
    why: 'Age-appropriate, companionship and shared life stage'
  }
};

// What Men Want (by life stage)
// Why: Men consistently prefer younger, with acceptable range widening at peak value (40-44)
const AGE_PREFS_WHAT_MEN_WANT = {
  '18-19': { 
    acceptable: ['18-19', '20-24'], 
    premium: ['18-19'],
    why: 'Peers, physical attraction, shared life stage'
  },
  '20-24': { 
    acceptable: ['18-19', '20-24', '25-29'], 
    premium: ['20-24'],
    why: 'Youth and attraction, slight flexibility younger'
  },
  '25-29': { 
    acceptable: ['20-24', '25-29', '30-34'], 
    premium: ['20-24', '25-29'],
    why: 'Starting to value youth + compatibility, career building'
  },
  '30-34': { 
    acceptable: ['20-24', '25-29', '30-34'], 
    premium: ['25-29'],
    why: 'Family potential, prefer younger for fertility and attraction'
  },
  '35-39': { 
    acceptable: ['20-24', '25-29', '30-34', '35-39'], 
    premium: ['25-29', '30-34'],
    why: 'Peak earning, can attract younger, family timeline matters'
  },
  '40-44': { 
    acceptable: ['20-24', '25-29', '30-34', '35-39', '40-44'], 
    premium: ['25-29', '30-34', '35-39'],
    why: 'Peak male value, widest acceptable range, prefer younger'
  },
  '45-49': { 
    acceptable: ['25-29', '30-34', '35-39', '40-44', '45-49'], 
    premium: ['25-29', '35-39'],
    why: 'Still prefer younger but narrowing, lifestyle match matters'
  },
  '50-54': { 
    acceptable: ['30-34', '35-39', '40-44', '45-49', '50-54'], 
    premium: ['35-39', '40-44', '45-49'],
    why: 'Realistic adjustment, health and energy alignment'
  },
  '55-59': { 
    acceptable: ['35-39', '40-44', '45-49', '50-54', '55-59'], 
    premium: ['40-44', '45-49', '50-54'],
    why: 'Companionship focus, shared retirement timeline'
  },
  '60-64': { 
    acceptable: ['45-49', '50-54', '55-59', '60-64'], 
    premium: ['50-54', '55-59'],
    why: 'Age-appropriate, health and lifestyle compatibility'
  }
};

// Age alignment scoring constants
const AGE_SCORE_PREMIUM = 1.00;
const AGE_SCORE_ACCEPTABLE = 0.70;
const AGE_SCORE_ONE_OUTSIDE = 0.40;
const AGE_SCORE_TWO_PLUS_OUTSIDE = 0.15;

// === BODY TYPE + FITNESS CONDITIONAL LOGIC ===
// Fitness matters differently based on body type - it can reward, penalize, or be neutral
// The logic differs by gender: men get more leeway for being overweight if active

/**
 * Get body type and fitness weight adjustments based on conditional logic
 * @param {string} gender - 'men' or 'women'
 * @param {string} bodyType - 'lean_fit', 'average', 'overweight', 'obese'
 * @param {string} fitnessLevel - 'never', '1_day', '2_3_days', '4_6_days', 'daily'
 * @returns {object} { bodyTypeWeight, fitnessWeight, totalWeight, isReward, isPenalty, logic }
 */
const getBodyFitnessWeights = (gender, bodyType, fitnessLevel) => {
  // Base weights by gender
  // Men: Body Type 12%, Fitness 2% | Women: Body Type 35%, Fitness 3%
  const baseBodyType = gender === 'women' ? 0.35 : 0.12;
  const baseFitness = gender === 'women' ? 0.03 : 0.02;
  
  // Determine if fitness is "active" (2-3 days or more for women's average, daily/4-6 for overweight)
  const isHighlyActive = fitnessLevel === 'daily' || fitnessLevel === '4_6_days';
  const isModeratelyActive = fitnessLevel === '2_3_days';
  const isMinimallyActive = fitnessLevel === '1_day';
  const isInactive = fitnessLevel === 'never';
  
  if (gender === 'women') {
    // Women: Base Body Type 35%, Base Fitness 3%
    if (bodyType === 'lean_fit') {
      // Elite body, fitness confirms → high score on both, rewarded
      return { bodyTypeWeight: 0.35, fitnessWeight: 0.03, totalWeight: 0.38, isReward: true, isPenalty: false, logic: 'Elite body, fitness confirms → rewarded' };
    }
    if (bodyType === 'average') {
      if (isHighlyActive || isModeratelyActive) {
        // Active lifestyle offsets average body
        return { bodyTypeWeight: 0.25, fitnessWeight: 0.03, totalWeight: 0.28, isReward: true, isPenalty: false, logic: 'Active lifestyle offsets average body' };
      }
      // Not active enough, body type tells story
      return { bodyTypeWeight: 0.35, fitnessWeight: 0, totalWeight: 0.35, isReward: false, isPenalty: false, logic: 'Not active enough, body type tells story' };
    }
    if (bodyType === 'overweight') {
      if (isHighlyActive) {
        // Effort matters, some credit
        return { bodyTypeWeight: 0.30, fitnessWeight: 0.03, totalWeight: 0.33, isReward: true, isPenalty: false, logic: 'Effort matters, some credit' };
      }
      if (isModeratelyActive) {
        // Not enough effort to offset
        return { bodyTypeWeight: 0.35, fitnessWeight: 0, totalWeight: 0.35, isReward: false, isPenalty: false, logic: 'Not enough effort to offset' };
      }
      // Not trying, penalized
      return { bodyTypeWeight: 0.35, fitnessWeight: 0.03, totalWeight: 0.38, isReward: false, isPenalty: true, logic: 'Not trying, penalized' };
    }
    if (bodyType === 'obese') {
      // Fitness doesn't save this, penalized regardless
      return { bodyTypeWeight: 0.35, fitnessWeight: 0.03, totalWeight: 0.38, isReward: false, isPenalty: true, logic: 'Fitness doesn\'t save this, penalized regardless' };
    }
  }
  
  if (gender === 'men') {
    // Men: Base Body Type 12%, Base Fitness 2%
    if (bodyType === 'lean_fit') {
      // Elite body, fitness confirms → premium, rewarded
      return { bodyTypeWeight: 0.12, fitnessWeight: 0.02, totalWeight: 0.14, isReward: true, isPenalty: false, logic: 'Elite body, fitness confirms → premium, rewarded' };
    }
    if (bodyType === 'average') {
      if (isHighlyActive || isModeratelyActive) {
        // Active offsets average
        return { bodyTypeWeight: 0.10, fitnessWeight: 0.02, totalWeight: 0.12, isReward: true, isPenalty: false, logic: 'Active offsets average' };
      }
      // Body type tells story
      return { bodyTypeWeight: 0.12, fitnessWeight: 0, totalWeight: 0.12, isReward: false, isPenalty: false, logic: 'Body type tells story' };
    }
    if (bodyType === 'overweight') {
      if (isHighlyActive) {
        // Men get a pass if active
        return { bodyTypeWeight: 0.10, fitnessWeight: 0.02, totalWeight: 0.12, isReward: true, isPenalty: false, logic: 'Men get a pass if active' };
      }
      if (isModeratelyActive || isMinimallyActive) {
        // Neutral, men get more leeway
        return { bodyTypeWeight: 0.12, fitnessWeight: 0, totalWeight: 0.12, isReward: false, isPenalty: false, logic: 'Neutral, men get more leeway' };
      }
      // Not trying at all, slight penalty
      return { bodyTypeWeight: 0.12, fitnessWeight: 0.02, totalWeight: 0.14, isReward: false, isPenalty: true, logic: 'Not trying at all, slight penalty' };
    }
    if (bodyType === 'obese') {
      // No pass for obese, penalized
      return { bodyTypeWeight: 0.12, fitnessWeight: 0.02, totalWeight: 0.14, isReward: false, isPenalty: true, logic: 'No pass for obese, penalized' };
    }
  }
  
  // Default fallback
  return { bodyTypeWeight: baseBodyType, fitnessWeight: 0, totalWeight: baseBodyType, isReward: false, isPenalty: false, logic: 'Default' };
};

// === RELATE SCORE AND SIGMOID WEIGHT CONSTANTS ===

// A. Cumulative Relate Score #/10 Weights (what user sees as their overall desirability)
// These weights determine how much each attribute matters in the user's total score
const RELATE_SCORE_WEIGHTS = {
  men: {
    income: 0.25,      // Women heavily value financial stability/provider potential
    height: 0.15,      // Extremely important for male attractiveness
    age: 0.08,         // Men's value peaks later (35-44)
    bodyType: 0.12,    // Physical attractiveness matters, but less than for women
    education: 0.11,   // Signals compatibility, conversation, earning potential; important for men's status
    kids: 0.05,        // Slight penalty for men
    ethnicity: 0.10,   // Local representation affects dating pool access
    smoking: 0.04,     // Dealbreaker for many
    political: 0.08,   // Compatibility filter, slightly more important to men
    fitness: 0.02      // Conditional - only scores if body type is average/overweight
  },
  women: {
    income: 0,         // Men don't evaluate women on earnings
    height: 0,         // Doesn't apply to women
    age: 0.17,         // Women's value peaks early (20-29), youth highly valued by men
    bodyType: 0.35,    // Men weight physical attractiveness heavily when evaluating women
    education: 0.08,   // Signals compatibility, conversation, earning potential
    kids: 0.17,        // Significant penalty for women (men more hesitant to raise another's kids)
    ethnicity: 0.10,   // Local representation affects dating pool access
    smoking: 0.04,     // Dealbreaker for many
    political: 0.06,   // Compatibility filter
    fitness: 0.03      // Conditional - only scores if body type is average/overweight
  }
};

// B. Tier-Specific Sigmoid Weights
// These weights determine competitiveness at each tier of the match funnel

// Realistic Sigmoid (Age + Income) - core "can you compete" attributes
const REALISTIC_SIGMOID_WEIGHTS = {
  men: {
    income: 0.75,      // Women heavily filter on income
    age: 0.25          // Women consider age but less critical
  },
  women: {
    income: 0.10,      // Men barely consider income
    age: 0.90          // Men heavily filter on age
  }
};

// Preferred Sigmoid (Ethnicity + Education + Political + Kids + Smoking) - compatibility and lifestyle filters
const PREFERRED_SIGMOID_WEIGHTS = {
  men: {
    ethnicity: 0.35,   // Local representation matters equally for pool access
    education: 0.30,   // Signals status/compatibility; men's education valued more
    political: 0.20,   // Compatibility filter; slightly more important to men
    kids: 0.10,        // Slight concern for men
    smoking: 0.05      // Dealbreaker for both
  },
  women: {
    ethnicity: 0.35,   // Local representation matters equally for pool access
    education: 0.20,   // Signals status/compatibility
    political: 0.15,   // Compatibility filter
    kids: 0.25,        // Major filter for women being evaluated
    smoking: 0.05      // Dealbreaker for both
  }
};

// Ideal Sigmoid (Height + Body Type + Fitness) - physical/appearance attributes
const IDEAL_SIGMOID_WEIGHTS = {
  men: {
    height: 0.55,      // Critical for men
    bodyType: 0.25,    // Important for men
    fitness: 0.20      // Conditional; steals from Body Type when active
  },
  women: {
    height: 0,         // Doesn't apply to women
    bodyType: 0.70,    // Primary physical metric for women
    fitness: 0.30      // Conditional; steals from Body Type when active
  }
};

// === COMPONENT SCORING FUNCTIONS ===
// Each function scores the user's competitiveness on a specific attribute (0-100)

// Ordered list of age brackets for calculating distance
const AGE_BRACKET_ORDER = ['18-19', '20-24', '25-29', '30-34', '35-39', '40-44', '45-49', '50-54', '55-59', '60-64'];

/**
 * Convert age to bracket string
 */
const getAgeBracket = (age) => {
  if (age <= 19) return '18-19';
  if (age <= 24) return '20-24';
  if (age <= 29) return '25-29';
  if (age <= 34) return '30-34';
  if (age <= 39) return '35-39';
  if (age <= 44) return '40-44';
  if (age <= 49) return '45-49';
  if (age <= 54) return '50-54';
  if (age <= 59) return '55-59';
  return '60-64';
};

/**
 * Calculate age alignment score based on what the target pool wants
 * Uses the age preference tables to determine if user is in premium/acceptable/outside range
 * 
 * @param {number} userAge - User's age
 * @param {string} userGender - 'man' or 'woman'
 * @param {number} targetAgeMin - Minimum age user is seeking
 * @param {number} targetAgeMax - Maximum age user is seeking
 * @returns {object} { score: 0-100, bracket: string, targetBracket: string, alignment: string }
 */
const calculateAgeAlignmentScore = (userAge, userGender, targetAgeMin, targetAgeMax) => {
  const userBracket = getAgeBracket(userAge);
  
  // Calculate midpoint of target age range to determine which bracket they're primarily seeking
  const targetMidAge = (targetAgeMin + targetAgeMax) / 2;
  const targetBracket = getAgeBracket(targetMidAge);
  
  // Get what the target pool wants (flip the gender)
  const prefsTable = userGender === 'man' ? AGE_PREFS_WHAT_WOMEN_WANT : AGE_PREFS_WHAT_MEN_WANT;
  const targetPrefs = prefsTable[targetBracket];
  
  if (!targetPrefs) {
    return { score: 50, bracket: userBracket, targetBracket, alignment: 'unknown' };
  }
  
  // Check if user is in premium range
  if (targetPrefs.premium.includes(userBracket)) {
    return { score: AGE_SCORE_PREMIUM * 100, bracket: userBracket, targetBracket, alignment: 'premium', why: targetPrefs.why };
  }
  
  // Check if user is in acceptable range
  if (targetPrefs.acceptable.includes(userBracket)) {
    return { score: AGE_SCORE_ACCEPTABLE * 100, bracket: userBracket, targetBracket, alignment: 'acceptable', why: targetPrefs.why };
  }
  
  // Calculate how far outside acceptable range
  const userBracketIndex = AGE_BRACKET_ORDER.indexOf(userBracket);
  const acceptableIndices = targetPrefs.acceptable.map(b => AGE_BRACKET_ORDER.indexOf(b));
  const minAcceptable = Math.min(...acceptableIndices);
  const maxAcceptable = Math.max(...acceptableIndices);
  
  let bracketsOutside = 0;
  if (userBracketIndex < minAcceptable) {
    bracketsOutside = minAcceptable - userBracketIndex;
  } else if (userBracketIndex > maxAcceptable) {
    bracketsOutside = userBracketIndex - maxAcceptable;
  }
  
  if (bracketsOutside === 1) {
    return { score: AGE_SCORE_ONE_OUTSIDE * 100, bracket: userBracket, targetBracket, alignment: 'one_outside', why: targetPrefs.why };
  }
  
  return { score: AGE_SCORE_TWO_PLUS_OUTSIDE * 100, bracket: userBracket, targetBracket, alignment: 'two_plus_outside', why: targetPrefs.why };
};

/**
 * Calculate income percentile score
 * Higher income = higher score, adjusted by local weight
 * 
 * @param {number} userIncome - User's annual income
 * @param {object} cbsaData - CBSA data for the metro area
 * @returns {object} { score: 0-100, percentile: number, bracket: string }
 */
const calculateIncomeScore = (userIncome, cbsaData) => {
  const bracket = getIncomeBracketKey(userIncome);
  const incomeWeight = (cbsaData?.income_cbsa || 50) / 50;
  
  // Calculate cumulative percentile (what % of people earn less than user)
  const brackets = CBSA_NATIONAL_PCT_KEYS.income;
  const bracketIndex = brackets.indexOf(bracket);
  
  let cumulativePercentile = 0;
  for (let i = 0; i < bracketIndex; i++) {
    cumulativePercentile += (cbsaData?.[brackets[i]] || 0);
  }
  // Add half of current bracket (assume user is in middle of their bracket)
  cumulativePercentile += (cbsaData?.[bracket] || 0) / 2;
  
  // Apply local weight adjustment
  const adjustedScore = Math.min(100, cumulativePercentile * incomeWeight);
  
  return { score: adjustedScore, percentile: cumulativePercentile, bracket };
};

/**
 * Calculate height percentile score (men only)
 * Taller = higher score
 * 
 * @param {string} heightStr - Height string like "5'10""
 * @param {object} cbsaData - CBSA data for the metro area
 * @returns {object} { score: 0-100, percentile: number, bracket: string, inches: number }
 */
const calculateHeightScore = (heightStr, cbsaData) => {
  const bracket = getHeightBracketKey(heightStr);
  const inches = getHeightInches(heightStr);
  
  if (!bracket || !inches) {
    return { score: 50, percentile: 50, bracket: null, inches: null };
  }
  
  // Calculate cumulative percentile (what % of people are shorter than user)
  const brackets = CBSA_NATIONAL_PCT_KEYS.height;
  const bracketIndex = brackets.indexOf(bracket);
  
  let cumulativePercentile = 0;
  for (let i = 0; i < bracketIndex; i++) {
    cumulativePercentile += (cbsaData?.[brackets[i]] || 0);
  }
  // Add half of current bracket
  cumulativePercentile += (cbsaData?.[bracket] || 0) / 2;
  
  return { score: cumulativePercentile, percentile: cumulativePercentile, bracket, inches };
};

/**
 * Calculate education percentile score
 * Higher education = higher score, adjusted by local weight
 * 
 * @param {string} education - Education level
 * @param {object} cbsaData - CBSA data for the metro area
 * @returns {object} { score: 0-100, percentile: number, bracket: string }
 */
const calculateEducationScore = (education, cbsaData) => {
  const bracket = getEducationKey(education);
  const educationWeight = (cbsaData?.bachelors_cbsa || 50) / 50;
  
  if (!bracket) {
    return { score: 50, percentile: 50, bracket: null };
  }
  
  // Calculate cumulative percentile (what % of people have less education)
  const brackets = CBSA_NATIONAL_PCT_KEYS.education;
  const bracketIndex = brackets.indexOf(bracket);
  
  let cumulativePercentile = 0;
  for (let i = 0; i < bracketIndex; i++) {
    cumulativePercentile += (cbsaData?.[brackets[i]] || 0);
  }
  // Add half of current bracket
  cumulativePercentile += (cbsaData?.[bracket] || 0) / 2;
  
  // Apply local weight adjustment
  const adjustedScore = Math.min(100, cumulativePercentile * educationWeight);
  
  return { score: adjustedScore, percentile: cumulativePercentile, bracket };
};

/**
 * Calculate ethnicity alignment score
 * Higher local representation = higher score (majority match bonus)
 * Uses pct_white_cbsa weight for stratification
 * 
 * @param {string} ethnicity - User's ethnicity
 * @param {object} cbsaData - CBSA data for the metro area
 * @returns {object} { score: 0-100, localPct: number, alignment: string }
 */
const calculateEthnicityScore = (ethnicity, cbsaData) => {
  const bracket = getEthnicityKey(ethnicity);
  
  if (!bracket) {
    return { score: 50, localPct: 0, alignment: 'unknown' };
  }
  
  // Get local representation percentage
  const localPct = cbsaData?.[bracket] || 0;
  
  // Get white weight for stratification context
  const whiteWeight = (cbsaData?.pct_white_cbsa || 50) / 50;
  
  // Score based on local representation
  // >50% = majority match (bonus)
  // 20-50% = significant presence (neutral)
  // <20% = minority mismatch (penalty)
  let score, alignment;
  if (localPct >= 50) {
    score = 80 + (localPct - 50) * 0.4; // 80-100
    alignment = 'majority_match';
  } else if (localPct >= 20) {
    score = 50 + (localPct - 20) * 1; // 50-80
    alignment = 'significant_presence';
  } else {
    score = 20 + localPct * 1.5; // 20-50
    alignment = 'minority_mismatch';
  }
  
  return { score: Math.min(100, score), localPct, alignment, whiteWeight };
};

/**
 * Calculate kids penalty score
 * No kids = full score, has kids = penalty (heavier for women)
 * 
 * @param {string|boolean} hasKids - Whether user has kids
 * @param {string} gender - 'men' or 'women'
 * @returns {object} { score: 0-100, hasKids: boolean }
 */
const calculateKidsScore = (hasKids, gender) => {
  const kids = hasKids === 'yes' || hasKids === 'Yes' || hasKids === true;
  
  if (!kids) {
    return { score: 100, hasKids: false };
  }
  
  // Penalty is heavier for women (men more hesitant to raise another's kids)
  // Men with kids: 90% score (10% penalty)
  // Women with kids: 60% score (40% penalty)
  const score = gender === 'women' ? 60 : 90;
  
  return { score, hasKids: true };
};

/**
 * Calculate political alignment score
 * Higher local representation of user's political view = higher score
 * 
 * @param {string} politicalViews - User's political views
 * @param {object} cbsaData - CBSA data for the metro area
 * @returns {object} { score: 0-100, localPct: number }
 */
const calculatePoliticalScore = (politicalViews, cbsaData) => {
  const bracket = getPoliticalKey(politicalViews);
  
  if (!bracket) {
    return { score: 50, localPct: 0 };
  }
  
  // Get local representation percentage
  const localPct = cbsaData?.[bracket] || 25; // Default 25% if missing
  
  // Score based on local representation (more alignment = easier to find matches)
  // Scale: 0% representation = 20, 50% representation = 100
  const score = 20 + (localPct * 1.6);
  
  return { score: Math.min(100, score), localPct };
};

/**
 * Calculate smoking score
 * Non-smoker = high score, smoker = low score, adjusted by local weight
 * 
 * @param {string} smoking - 'yes' or 'no'
 * @param {object} cbsaData - CBSA data for the metro area
 * @returns {object} { score: 0-100, isSmoker: boolean }
 */
const calculateSmokingScore = (smoking, cbsaData) => {
  const isSmoker = smoking === 'yes' || smoking === 'Yes';
  const smokingWeight = (cbsaData?.smoking_cbsa || 50) / 50;
  
  // Non-smokers are preferred universally
  // But in high-smoking areas (weight > 1), penalty for smoking is slightly reduced
  if (!isSmoker) {
    return { score: 100, isSmoker: false };
  }
  
  // Smoker base score: 40, adjusted by local weight
  // Higher smoking weight means smoking is more common locally (less penalty)
  const score = Math.min(60, 40 * smokingWeight);
  
  return { score, isSmoker: true };
};

/**
 * Calculate body type score
 * lean_fit = high, average = medium, overweight = low, obese = very low
 * Adjusted by local obesity weight
 * 
 * @param {string} bodyType - 'lean_fit', 'average', 'overweight', 'obese'
 * @param {object} cbsaData - CBSA data for the metro area
 * @returns {object} { score: 0-100, bodyType: string }
 */
const calculateBodyTypeScore = (bodyType, cbsaData) => {
  const obesityWeight = (cbsaData?.obesity_cbsa || 50) / 50;
  
  // Base scores by body type
  const baseScores = {
    'lean_fit': 95,
    'average': 70,
    'overweight': 45,
    'obese': 20
  };
  
  const baseScore = baseScores[bodyType] || 50;
  
  // In high-obesity areas (weight > 1), being fit is MORE valuable
  // In low-obesity areas (weight < 1), competition is stiffer
  let adjustedScore = baseScore;
  if (bodyType === 'lean_fit') {
    // Premium increases in high-obesity areas
    adjustedScore = Math.min(100, baseScore + (obesityWeight - 1) * 10);
  } else if (bodyType === 'obese') {
    // Penalty decreases slightly in high-obesity areas
    adjustedScore = Math.min(40, baseScore * obesityWeight);
  }
  
  return { score: adjustedScore, bodyType, obesityWeight };
};

/**
 * Calculate fitness score (conditional on body type)
 * Only meaningful for average/overweight body types
 * 
 * @param {string} fitnessLevel - 'never', '1_day', '2_3_days', '4_6_days', 'daily'
 * @param {string} bodyType - User's body type
 * @param {object} cbsaData - CBSA data for the metro area
 * @returns {object} { score: 0-100, isActive: boolean, fitnessLevel: string }
 */
const calculateFitnessScore = (fitnessLevel, bodyType, cbsaData) => {
  const activityWeight = (cbsaData?.activity_cbsa || 50) / 50;
  
  // Base scores by fitness level
  const baseScores = {
    'daily': 95,
    '4_6_days': 85,
    '2_3_days': 65,
    '1_day': 40,
    'never': 20
  };
  
  const baseScore = baseScores[fitnessLevel] || 50;
  const isActive = fitnessLevel === 'daily' || fitnessLevel === '4_6_days' || fitnessLevel === '2_3_days';
  
  // In high-activity areas (weight > 1), being active is more expected
  // Adjust score based on local activity levels
  const adjustedScore = Math.min(100, baseScore * (2 - activityWeight) + (activityWeight - 1) * 20);
  
  return { score: Math.max(0, Math.min(100, adjustedScore)), isActive, fitnessLevel, activityWeight };
};

// === MAIN RELATE SCORE CALCULATION ===

/**
 * Calculate the user's overall Relate Score (competitiveness rating)
 * This is the composite score displayed to the user as #/10
 * 
 * @param {object} user - User profile data
 * @param {string} user.gender - 'man' or 'woman'
 * @param {number} user.age - User's age
 * @param {number} user.income - User's annual income
 * @param {string} user.education - User's education level
 * @param {string} user.ethnicity - User's ethnicity
 * @param {string|boolean} user.hasKids - Whether user has kids
 * @param {string} user.height - Height string (men only)
 * @param {string} user.bodyType - Body type
 * @param {string} user.fitnessLevel - Workout frequency
 * @param {string} user.politicalViews - Political views
 * @param {string} user.smoking - Smoking status
 * @param {number} user.targetAgeMin - Minimum age user is seeking
 * @param {number} user.targetAgeMax - Maximum age user is seeking
 * @param {object} cbsaData - CBSA data for the metro area
 * @returns {object} { score: 0-100, scoreOutOf10: string, components: {...}, weights: {...} }
 */
const calculateUserRelateScore = (user, cbsaData) => {
  const gender = user.gender === 'man' ? 'men' : 'women';
  const weights = RELATE_SCORE_WEIGHTS[gender];
  
  // Calculate each component score
  const components = {};
  
  // Age (uses alignment scoring based on what target pool wants)
  const ageResult = calculateAgeAlignmentScore(
    user.age,
    user.gender,
    user.targetAgeMin || user.age - 5,
    user.targetAgeMax || user.age + 5
  );
  components.age = ageResult;
  
  // Income
  const incomeResult = calculateIncomeScore(user.income, cbsaData);
  components.income = incomeResult;
  
  // Height (men only)
  if (gender === 'men' && user.height) {
    const heightResult = calculateHeightScore(user.height, cbsaData);
    components.height = heightResult;
  } else {
    components.height = { score: 0, percentile: 0, bracket: null, inches: null };
  }
  
  // Education
  const educationResult = calculateEducationScore(user.education, cbsaData);
  components.education = educationResult;
  
  // Ethnicity
  const ethnicityResult = calculateEthnicityScore(user.ethnicity, cbsaData);
  components.ethnicity = ethnicityResult;
  
  // Kids
  const kidsResult = calculateKidsScore(user.hasKids, gender);
  components.kids = kidsResult;
  
  // Political
  const politicalResult = calculatePoliticalScore(user.politicalViews, cbsaData);
  components.political = politicalResult;
  
  // Smoking
  const smokingResult = calculateSmokingScore(user.smoking, cbsaData);
  components.smoking = smokingResult;
  
  // Body Type
  const bodyTypeResult = calculateBodyTypeScore(user.bodyType, cbsaData);
  components.bodyType = bodyTypeResult;
  
  // Fitness
  const fitnessResult = calculateFitnessScore(user.fitnessLevel, user.bodyType, cbsaData);
  components.fitness = fitnessResult;
  
  // Get conditional body type + fitness weights
  const bodyFitnessWeights = getBodyFitnessWeights(gender, user.bodyType, user.fitnessLevel);
  components.bodyFitnessLogic = bodyFitnessWeights;
  
  // Calculate weighted score
  // Note: Body Type and Fitness weights are conditional, so we handle them specially
  let totalScore = 0;
  
  // Standard components (not body type or fitness)
  totalScore += components.income.score * weights.income;
  totalScore += components.height.score * weights.height;
  totalScore += components.age.score * weights.age;
  totalScore += components.education.score * weights.education;
  totalScore += components.ethnicity.score * weights.ethnicity;
  totalScore += components.kids.score * weights.kids;
  totalScore += components.political.score * weights.political;
  totalScore += components.smoking.score * weights.smoking;
  
  // Body Type + Fitness (using conditional weights)
  // If reward: fitness adds to score
  // If penalty: fitness subtracts from score (lower component score)
  // If neutral: only body type counts
  if (bodyFitnessWeights.isReward) {
    // Both count positively
    totalScore += components.bodyType.score * bodyFitnessWeights.bodyTypeWeight;
    totalScore += components.fitness.score * bodyFitnessWeights.fitnessWeight;
  } else if (bodyFitnessWeights.isPenalty) {
    // Body type counts, fitness amplifies the penalty
    totalScore += components.bodyType.score * bodyFitnessWeights.bodyTypeWeight;
    // Fitness weight adds to total but with low body/fitness scores, this increases the "weight" of the low score
    totalScore += components.fitness.score * bodyFitnessWeights.fitnessWeight;
  } else {
    // Neutral - only body type counts
    totalScore += components.bodyType.score * bodyFitnessWeights.bodyTypeWeight;
  }
  
  // Ensure score is in valid range
  const finalScore = Math.max(0, Math.min(100, totalScore));
  const scoreOutOf10 = (finalScore / 10).toFixed(1);
  
  return {
    score: finalScore,
    scoreOutOf10,
    components,
    weights,
    bodyFitnessWeights
  };
};

/**
 * Calculate tier-specific sigmoid score for Realistic tier
 * Based on Age + Income only
 */
const calculateRealisticSigmoidScore = (user, cbsaData) => {
  const gender = user.gender === 'man' ? 'men' : 'women';
  const weights = REALISTIC_SIGMOID_WEIGHTS[gender];
  
  const ageResult = calculateAgeAlignmentScore(
    user.age,
    user.gender,
    user.targetAgeMin || user.age - 5,
    user.targetAgeMax || user.age + 5
  );
  
  const incomeResult = calculateIncomeScore(user.income, cbsaData);
  
  const score = (ageResult.score * weights.age) + (incomeResult.score * weights.income);
  
  return {
    score: Math.max(0, Math.min(100, score)),
    components: { age: ageResult, income: incomeResult },
    weights
  };
};

/**
 * Calculate tier-specific sigmoid score for Preferred tier
 * Based on Ethnicity + Education + Political + Kids + Smoking
 */
const calculatePreferredSigmoidScore = (user, cbsaData) => {
  const gender = user.gender === 'man' ? 'men' : 'women';
  const weights = PREFERRED_SIGMOID_WEIGHTS[gender];
  
  const ethnicityResult = calculateEthnicityScore(user.ethnicity, cbsaData);
  const educationResult = calculateEducationScore(user.education, cbsaData);
  const politicalResult = calculatePoliticalScore(user.politicalViews, cbsaData);
  const kidsResult = calculateKidsScore(user.hasKids, gender);
  const smokingResult = calculateSmokingScore(user.smoking, cbsaData);
  
  const score = 
    (ethnicityResult.score * weights.ethnicity) +
    (educationResult.score * weights.education) +
    (politicalResult.score * weights.political) +
    (kidsResult.score * weights.kids) +
    (smokingResult.score * weights.smoking);
  
  return {
    score: Math.max(0, Math.min(100, score)),
    components: {
      ethnicity: ethnicityResult,
      education: educationResult,
      political: politicalResult,
      kids: kidsResult,
      smoking: smokingResult
    },
    weights
  };
};

/**
 * Calculate tier-specific sigmoid score for Ideal tier
 * Based on Height + Body Type + Fitness
 */
const calculateIdealSigmoidScore = (user, cbsaData) => {
  const gender = user.gender === 'man' ? 'men' : 'women';
  const weights = IDEAL_SIGMOID_WEIGHTS[gender];
  
  // Height (men only)
  let heightResult;
  if (gender === 'men' && user.height) {
    heightResult = calculateHeightScore(user.height, cbsaData);
  } else {
    heightResult = { score: 0, percentile: 0, bracket: null, inches: null };
  }
  
  const bodyTypeResult = calculateBodyTypeScore(user.bodyType, cbsaData);
  const fitnessResult = calculateFitnessScore(user.fitnessLevel, user.bodyType, cbsaData);
  
  // Get conditional weights
  const bodyFitnessWeights = getBodyFitnessWeights(gender, user.bodyType, user.fitnessLevel);
  
  // For Ideal sigmoid, we use the IDEAL_SIGMOID_WEIGHTS but apply conditional logic
  let score = heightResult.score * weights.height;
  
  // Apply conditional body type + fitness logic
  if (bodyFitnessWeights.isReward || bodyFitnessWeights.isPenalty) {
    // Scale the body type and fitness weights to match IDEAL_SIGMOID_WEIGHTS total
    const idealBodyFitnessTotal = weights.bodyType + weights.fitness;
    const conditionalTotal = bodyFitnessWeights.totalWeight;
    const scaleFactor = idealBodyFitnessTotal / conditionalTotal;
    
    score += bodyTypeResult.score * bodyFitnessWeights.bodyTypeWeight * scaleFactor;
    score += fitnessResult.score * bodyFitnessWeights.fitnessWeight * scaleFactor;
  } else {
    // Neutral - use standard weights
    score += bodyTypeResult.score * weights.bodyType;
  }
  
  return {
    score: Math.max(0, Math.min(100, score)),
    components: {
      height: heightResult,
      bodyType: bodyTypeResult,
      fitness: fitnessResult
    },
    weights,
    bodyFitnessWeights
  };
};

/**
 * Get stratified felon rate based on target demographics
 * Applied AFTER gender filter, BEFORE single filter
 */
const getStratifiedFelonRate = (targetGender, targetEthnicity = null, targetEducation = null) => {
  // Get base felon rate for gender
  let felonRate = FELON_RATES[targetGender]?.overall || 0.08;
  
  // Adjust for ethnicity if filtering for same-ethnicity matches
  if (targetEthnicity) {
    const ethLower = targetEthnicity.toLowerCase();
    // Map to white or poc
    const ethKey = ethLower === 'white' ? 'white' : 'poc';
    if (FELON_RATES[targetGender]?.[ethKey]) {
      felonRate = FELON_RATES[targetGender][ethKey];
    }
  }
  
  // Adjust for education level (educated people have much lower felony rates)
  if (targetEducation) {
    const eduLower = targetEducation.toLowerCase();
    // Normalize education keys to match EDUCATION_FELON_MULTIPLIERS
    let eduKey = eduLower;
    if (eduLower === 'hs_grad' || eduLower === 'hs grad' || eduLower === 'highschool') eduKey = 'high school';
    else if (eduLower === 'some_college' || eduLower === 'somecollege' || eduLower === 'associates') eduKey = 'some college';
    else if (eduLower === 'bachelor' || eduLower === "bachelor's") eduKey = 'bachelors';
    else if (eduLower === 'masters' || eduLower === 'phd' || eduLower === 'doctorate' || eduLower === 'grad') eduKey = 'graduate';
    
    if (EDUCATION_FELON_MULTIPLIERS[eduKey]) {
      felonRate *= EDUCATION_FELON_MULTIPLIERS[eduKey];
    }
  }
  
  // Cap at reasonable bounds (minimum 0.5%, maximum 45%)
  return Math.max(0.005, Math.min(0.45, felonRate));
};

/**
 * Get stratified drug use rate based on target demographics
 * Applied AFTER felon filter, BEFORE single filter
 * Based on CDC data, marriage-weighted
 */
const getStratifiedDrugRate = (targetGender, targetEthnicity = null, targetEducation = null) => {
  // Get base drug rate for gender
  let drugRate = DRUG_USE_RATES[targetGender]?.overall || 0.14;
  
  // Adjust for ethnicity if filtering for same-ethnicity matches
  if (targetEthnicity) {
    const ethLower = targetEthnicity.toLowerCase();
    // Map to white or poc
    const ethKey = ethLower === 'white' ? 'white' : 'poc';
    if (DRUG_USE_RATES[targetGender]?.[ethKey]) {
      drugRate = DRUG_USE_RATES[targetGender][ethKey];
    }
  }
  
  // Adjust for education level (educated people have lower drug use)
  if (targetEducation) {
    const eduLower = targetEducation.toLowerCase();
    // Normalize education keys to match EDUCATION_DRUG_MULTIPLIERS
    let eduKey = eduLower;
    if (eduLower === 'hs_grad' || eduLower === 'hs grad' || eduLower === 'highschool' || eduLower === 'less than hs') eduKey = 'high school';
    else if (eduLower === 'some_college' || eduLower === 'somecollege' || eduLower === 'associates' || eduLower === 'associate' || eduLower === 'trade') eduKey = 'some college';
    else if (eduLower === 'bachelor' || eduLower === "bachelor's") eduKey = 'bachelors';
    else if (eduLower === 'masters' || eduLower === 'phd' || eduLower === 'doctorate' || eduLower === 'grad') eduKey = 'graduate';
    
    if (EDUCATION_DRUG_MULTIPLIERS[eduKey]) {
      drugRate *= EDUCATION_DRUG_MULTIPLIERS[eduKey];
    }
  }
  
  // Cap at reasonable bounds (minimum 5%, maximum 25%)
  return Math.max(0.05, Math.min(0.25, drugRate));
};

// --- HELPER FUNCTIONS (Sections 8.6-8.11) ---

// Section 8.6: Sigmoid for match probability
/**
 * Section 8.11: Match Probability Model (Hinge-style)
 * 
 * Based on dating app research:
 * - Average men (score ~50): 1-3% of women swipe right
 * - Above average (score ~70): 5-10% swipe right
 * - Top 10% (score ~85): 15-20% swipe right
 * - Top 1% (score ~95+): 25-30% swipe right
 * 
 * Uses logistic function with realistic floor/ceiling:
 * P(match) = floor + (ceiling - floor) / (1 + e^(-k*(score - midpoint)))
 * 
 * Parameters tuned to match real dating app data:
 * - floor: 0.5% (even lowest-rated profiles get some matches)
 * - ceiling: 30% (even perfect profiles don't match with everyone)
 * - midpoint: 65 (inflection point - above average gets better returns)
 * - k: 0.08 (steepness - gradual increase, not binary)
 */
const MATCH_PROBABILITY_CONFIG = {
  floor: 0.005,      // 0.5% minimum
  ceiling: 0.30,     // 30% maximum
  midpoint: 65,      // Score where probability = ~15%
  steepness: 0.08    // How sharply probability changes
};

const getBaseMatchProbability = (score) => {
  const { floor, ceiling, midpoint, steepness } = MATCH_PROBABILITY_CONFIG;
  const sigmoid = 1 / (1 + Math.exp(-steepness * (score - midpoint)));
  return floor + (ceiling - floor) * sigmoid;
};

// Reference values for this model:
// Score 30: ~1.2% match rate
// Score 50: ~3.5% match rate
// Score 65: ~15% match rate (midpoint)
// Score 80: ~23% match rate
// Score 95: ~28% match rate
// Score 100: ~29% match rate

// Get weights by gender
const getWeights = (gender) => {
  const g = (gender || '').toLowerCase();
  return (g === 'man' || g === 'male') ? WEIGHTS_MALE : WEIGHTS_FEMALE;
};

// Section 8.3: Age score from curves
const getAgeScore = (age, gender) => {
  const g = (gender || '').toLowerCase();
  const curve = (g === 'man' || g === 'male') ? AGE_CURVE_MALE : AGE_CURVE_FEMALE;
  
  for (const bracket of curve) {
    if (age >= bracket.minAge && age <= bracket.maxAge) {
      if (bracket.startScore === bracket.endScore) return bracket.startScore;
      const proportion = (age - bracket.minAge) / (bracket.maxAge - bracket.minAge);
      return bracket.startScore + proportion * (bracket.endScore - bracket.startScore);
    }
  }
  return 50;
};

// Section 8.4: Children score
const getChildrenScore = (hasKids, age, gender) => {
  const g = (gender || '').toLowerCase();
  const isMale = g === 'man' || g === 'male';
  const scores = isMale ? CHILDREN_SCORES.man : CHILDREN_SCORES.woman;
  
  if (isMale) {
    if (hasKids) return age >= 35 ? scores.has_kids_over_35 : scores.has_kids_under_35;
    return age >= 35 ? scores.no_kids_over_35 : scores.no_kids_under_35;
  } else {
    if (hasKids) return age >= 30 ? scores.has_kids_over_30 : scores.has_kids_under_30;
    return age >= 35 ? scores.no_kids_over_35 : scores.no_kids_under_35;
  }
};

// Section 8.10: Ethnicity score
const getEthnicityScore = (userEthnicity, cbsaData) => {
  const ethnicityToColumn = {
    'white': 'ethnicity_white_cbsa', 'hispanic': 'ethnicity_hispanic_cbsa',
    'black': 'ethnicity_black_cbsa', 'asian': 'ethnicity_asian_cbsa',
    'native': 'ethnicity_native_cbsa', 'pacific': 'ethnicity_pacific_cbsa',
    'other': 'ethnicity_other_cbsa'
  };
  
  const column = ethnicityToColumn[(userEthnicity || '').toLowerCase()];
  if (column && cbsaData[column] !== undefined) {
    return cbsaData[column];
  }
  
  // Fallback: Use pct_white_cbsa (local weight) as proxy - NO SILENT FALLBACKS
  if ((userEthnicity || '').toLowerCase() === 'white') {
    if (cbsaData.pct_white_cbsa === undefined) {
      console.warn('[getEthnicityScore] Missing pct_white_cbsa for white user');
    }
    return cbsaData.pct_white_cbsa;
  }
  if (cbsaData.pct_white_cbsa === undefined) {
    console.warn('[getEthnicityScore] Missing pct_white_cbsa for non-white user');
  }
  return 100 - cbsaData.pct_white_cbsa;
};

// Section 8.9: Local adjustment formula
const applyLocalAdjustment = (nationalPercentile, cbsaIndex) => {
  const idx = cbsaIndex <= 0 ? 1 : cbsaIndex;
  const localScore = 50 + (nationalPercentile - 50) * (50 / idx);
  return Math.max(0, Math.min(100, localScore));
};

// Section 8.7: Income percentile using CBSA distribution
const getIncomePercentileLocal = (income, cbsaData) => {
  let cumulative = 0;
  for (const bracket of INCOME_BRACKETS) {
    const pct = cbsaData[bracket.col] || 0;
    if (income < bracket.max) {
      const range = bracket.max - bracket.min;
      const bracketProgress = range > 0 ? (income - bracket.min) / range : 0;
      return cumulative + (pct * bracketProgress);
    }
    cumulative += pct;
  }
  return 99;
};

// Section 8.8: Education percentile
const getEducationPercentile = (userEducation, cbsaData) => {
  const eduMap = {
    'less than hs': 'less_hs', 'hs grad': 'hs_grad', 'trade': 'trade',
    'associate': 'associate', 'some college': 'some_college',
    'bachelors': 'bachelors', "bachelor's": 'bachelors',
    'graduate': 'graduate'
  };
  
  const normalized = eduMap[(userEducation || '').toLowerCase()] || 'hs_grad';
  const userIdx = EDUCATION_ORDER.indexOf(normalized);
  if (userIdx === -1) return 50;
  
  const eduPcts = EDUCATION_COLUMNS.map(col => cbsaData[col] || 0);
  const cumulativeBelow = eduPcts.slice(0, userIdx).reduce((a, b) => a + b, 0);
  const userLevelPct = eduPcts[userIdx] || 0;
  
  return cumulativeBelow + (userLevelPct / 2);
};

// Section 8.5: Marriage premium
const calculateMarriagePremium = (income, localIncomeScore, relationshipStatus, colFamily4) => {
  const status = (relationshipStatus || '').toLowerCase();
  if (status !== 'married' && status !== 'yes') return 1.0;
  
  const provisionRatio = colFamily4 > 0 ? income / colFamily4 : 1.0;
  const localRank = localIncomeScore / 100;
  
  let provisionFactor = 0.0;
  for (const t of MARRIAGE_PREMIUM_CONFIG.provision_thresholds) {
    if (provisionRatio >= t.min && provisionRatio < t.max) {
      provisionFactor = t.factor;
      break;
    }
  }
  
  const hypergamyFactor = (localRank - 0.5) * MARRIAGE_PREMIUM_CONFIG.hypergamy_factor;
  let premium = 1.0 + provisionFactor + hypergamyFactor;
  premium = Math.max(MARRIAGE_PREMIUM_CONFIG.premium_floor, premium);
  premium = Math.min(MARRIAGE_PREMIUM_CONFIG.premium_ceiling, premium);
  
  return premium;
};

// --- MAIN CALCULATION FUNCTIONS (Sections 8.12-8.13) ---

/**
 * Section 8.12: Calculate Relate Score
 * @param {Object} user - { age, income, education, gender, ethnicity, hasKids, relationshipStatus }
 * @param {Object} cbsaData - CBSA demographics from cbsa-data.js
 * @param {number} colFamily4 - Cost of living for family of 4
 * @returns {Object} { relateScore, incomeLocal, components }
 */
const calculateRelateScore = (user, cbsaData, colFamily4) => {
  // VALIDATE: Required CBSA fields for Relate Score
  const requiredFields = ['income_cbsa', 'bachelors_cbsa'];
  const missingFields = requiredFields.filter(f => cbsaData[f] === undefined || cbsaData[f] === null);
  if (missingFields.length > 0) {
    console.warn('[calculateRelateScore] Missing CBSA fields:', missingFields, 'CBSA:', cbsaData?.name);
  }
  
  const weights = getWeights(user.gender);
  
  // Step 1: Income (local adjusted) - NO FALLBACKS
  const incomeNational = getIncomePercentileLocal(user.income || 0, cbsaData);
  const incomeLocal = applyLocalAdjustment(incomeNational, cbsaData.income_cbsa);
  
  // Step 2: Education (local adjusted) - NO FALLBACKS
  const eduNational = getEducationPercentile(user.education, cbsaData);
  const eduLocal = applyLocalAdjustment(eduNational, cbsaData.bachelors_cbsa);
  
  // Step 3: Age (no local adjustment)
  const ageScore = getAgeScore(user.age || 30, user.gender);
  
  // Step 4: Ethnicity
  const ethnicityScore = getEthnicityScore(user.ethnicity, cbsaData);
  
  // Step 5: Children
  const childrenScore = getChildrenScore(user.hasKids, user.age || 30, user.gender);
  
  // Step 6: Weighted sum
  const baseScore = 
    incomeLocal * weights.income +
    eduLocal * weights.education +
    ageScore * weights.age +
    ethnicityScore * weights.ethnicity +
    childrenScore * weights.children;
  
  // Step 7: Marriage premium
  const marriagePremium = calculateMarriagePremium(
    user.income || 0, incomeLocal, user.relationshipStatus, colFamily4
  );
  
  // Step 8: Final score (capped at 100)
  const finalScore = Math.min(100, baseScore * marriagePremium);
  
  return {
    relateScore: Math.round(finalScore * 10) / 10,
    incomeLocal,
    components: { incomeNational, incomeLocal, eduNational, eduLocal, ageScore, ethnicityScore, childrenScore, baseScore, marriagePremium }
  };
};

/**
 * Section 8.13: Calculate Match Score
 * @param {Object} user - { gender, ethnicity, relationshipStatus }
 * @param {Object} cbsaData - CBSA demographics from cbsa-data.js
 * @param {number} relateScore - From calculateRelateScore
 * @returns {Object} { matchScore, matchPool, localSinglePool, targetGenderLabel }
 */
const calculateMatchScore = (user, cbsaData, relateScore) => {
  const status = (user.relationshipStatus || '').toLowerCase();
  if (status === 'married' || status === 'yes') {
    return { matchScore: null, matchPool: null, localSinglePool: null, targetGenderLabel: null };
  }
  
  // VALIDATE: Required CBSA fields must exist (no silent fallbacks)
  const requiredFields = ['cbsa_population', 'gender_woman_cbsa', 'gender_man_cbsa', 'female_cbsa', 'male_cbsa', 'relationship_single_cbsa', 'single_18_65_cbsa'];
  const missingFields = requiredFields.filter(f => cbsaData[f] === undefined || cbsaData[f] === null);
  if (missingFields.length > 0) {
    console.warn('[calculateMatchScore] Missing CBSA fields:', missingFields, 'CBSA:', cbsaData?.name);
  }
  
  // Get base probability from sigmoid
  const baseProbability = getBaseMatchProbability(relateScore);
  
  // Target gender setup
  const g = (user.gender || '').toLowerCase();
  const isMale = g === 'man' || g === 'male';
  const targetGenderLabel = isMale ? 'women' : 'men';
  
  // National percentages (divide by 100) - NO FALLBACKS, use actual data
  const targetGenderNationalPct = cbsaData[isMale ? 'gender_woman_cbsa' : 'gender_man_cbsa'];
  const singleNationalPct = cbsaData.relationship_single_cbsa;
  
  // Local weights (divide by 50, where 50 = average) - NO FALLBACKS
  const targetGenderLocalWeight = cbsaData[isMale ? 'female_cbsa' : 'male_cbsa'];
  const singleLocalWeight = cbsaData.single_18_65_cbsa;
  
  // Get stratified felon rate for target demographics
  // Graduate degree holders look at bachelor's+ pool
  const targetEducation = user.education?.toLowerCase() === 'graduate' ? 'bachelors' : user.education;
  const felonRate = getStratifiedFelonRate(targetGenderLabel, user.ethnicity, targetEducation);
  
  // Get stratified drug use rate for target demographics
  const drugRate = getStratifiedDrugRate(targetGenderLabel, user.ethnicity, targetEducation);
  
  // === THE FUNNEL (correct order) ===
  const population = cbsaData.cbsa_population;
  
  // Step 1: Remove 65+ and homeless from total population
  const adults18_64 = population * (1 - UNIVERSAL_EXCLUSION_RATE);
  
  // Step 2: Filter to target gender
  const targetGender18_64 = adults18_64 
    * (targetGenderNationalPct / 100) 
    * (targetGenderLocalWeight / 50);
  
  // Step 3: Remove felons (stratified by demographics)
  const nonFelonTargetGender = targetGender18_64 * (1 - felonRate);
  
  // Step 4: Remove drug users (stratified by demographics)
  const nonDrugUserPool = nonFelonTargetGender * (1 - drugRate);
  
  // Step 5: Filter to singles
  const localSinglePool = Math.round(
    nonDrugUserPool 
    * (singleNationalPct / 100) 
    * (singleLocalWeight / 50)
  );
  
  // Step 6: Apply match probability
  const matchPool = Math.round(localSinglePool * baseProbability);
  
  // Match score is just the probability as percentage
  const matchScore = Math.round(baseProbability * 100);
  
  return { matchScore, matchPool, localSinglePool, targetGenderLabel };
};

// === THREE-TIER MATCH CALCULATION SYSTEM ===
// Realistic → Preferred → Ideal, each with its own pool filters and sigmoid

/**
 * Get percentage of population within user's preferred age range
 * Sums age bracket percentages that fall within ageMin-ageMax
 * 
 * @param {number} ageMin - Minimum age preference
 * @param {number} ageMax - Maximum age preference
 * @param {object} cbsaData - CBSA data
 * @returns {number} Percentage (0-100) of population in range
 */
const getAgeRangePercentage = (ageMin, ageMax, cbsaData) => {
  if (!ageMin || !ageMax || !cbsaData) return 100; // No filter = 100%
  
  // Map age ranges to brackets
  const brackets = [
    { key: 'age_18_19_cbsa', min: 18, max: 19 },
    { key: 'age_20_24_cbsa', min: 20, max: 24 },
    { key: 'age_25_29_cbsa', min: 25, max: 29 },
    { key: 'age_30_34_cbsa', min: 30, max: 34 },
    { key: 'age_35_39_cbsa', min: 35, max: 39 },
    { key: 'age_40_44_cbsa', min: 40, max: 44 },
    { key: 'age_45_49_cbsa', min: 45, max: 49 },
    { key: 'age_50_54_cbsa', min: 50, max: 54 },
    { key: 'age_55_59_cbsa', min: 55, max: 59 },
    { key: 'age_60_64_cbsa', min: 60, max: 64 }
  ];
  
  let totalPct = 0;
  for (const bracket of brackets) {
    // Include bracket if it overlaps with user's range
    if (bracket.max >= ageMin && bracket.min <= ageMax) {
      totalPct += (cbsaData[bracket.key] || 0);
    }
  }
  
  return totalPct;
};

/**
 * Get percentage of population at or above user's minimum income preference
 * 
 * @param {number} minIncome - Minimum income preference
 * @param {object} cbsaData - CBSA data
 * @returns {number} Percentage (0-100) of population at or above threshold
 */
const getIncomeAbovePercentage = (minIncome, cbsaData) => {
  if (minIncome === 0 || minIncome === undefined || !cbsaData) return 100; // $0 = no filter
  
  const brackets = [
    { key: 'income_under_35k_cbsa', threshold: 0 },
    { key: 'income_35k_50k_cbsa', threshold: 35000 },
    { key: 'income_50k_75k_cbsa', threshold: 50000 },
    { key: 'income_75k_100k_cbsa', threshold: 75000 },
    { key: 'income_100k_150k_cbsa', threshold: 100000 },
    { key: 'income_150k_200k_cbsa', threshold: 150000 },
    { key: 'income_200k_300k_cbsa', threshold: 200000 },
    { key: 'income_300k_500k_cbsa', threshold: 300000 },
    { key: 'income_500k_750k_cbsa', threshold: 500000 },
    { key: 'income_750k_plus_cbsa', threshold: 750000 }
  ];
  
  let totalPct = 0;
  for (const bracket of brackets) {
    // Include if bracket threshold >= minIncome
    if (bracket.threshold >= minIncome || (bracket.threshold === 0 && minIncome <= 35000)) {
      // Special handling: income_under_35k only counts if minIncome < 35k
      if (bracket.key === 'income_under_35k_cbsa' && minIncome > 0) {
        continue; // Skip the under 35k bracket if they want income > $0
      }
      totalPct += (cbsaData[bracket.key] || 0);
    }
  }
  
  return totalPct;
};

/**
 * Get percentage of population at or above user's minimum height preference
 * Used for women seeking men
 * 
 * @param {string} minHeight - Minimum height preference (e.g., "5'10"") or 'no_preference'
 * @param {object} cbsaData - CBSA data
 * @returns {number} Percentage (0-100) of population at or above threshold
 */
const getHeightAbovePercentage = (minHeight, cbsaData) => {
  if (!minHeight || minHeight === 'no_preference' || minHeight === '' || !cbsaData) return 100;
  
  const minInches = getHeightInches(minHeight);
  if (!minInches) return 100;
  
  const brackets = [
    { key: 'height_under_60_cbsa', maxInches: 59 },
    { key: 'height_60_62_cbsa', maxInches: 62 },
    { key: 'height_63_65_cbsa', maxInches: 65 },
    { key: 'height_66_68_cbsa', maxInches: 68 },
    { key: 'height_69_71_cbsa', maxInches: 71 },
    { key: 'height_72plus_cbsa', maxInches: 999 }
  ];
  
  let totalPct = 0;
  for (const bracket of brackets) {
    // Include if bracket's max inches >= minInches - 1 (meaning the bracket contains heights >= minHeight)
    // Actually, we want brackets where people could be at or above minHeight
    // height_69_71 means 69-71 inches, so if minHeight is 70", include this bracket
    if (bracket.maxInches >= minInches) {
      totalPct += (cbsaData[bracket.key] || 0);
    }
  }
  
  return totalPct;
};

/**
 * Get percentage of population matching multi-select preferences
 * Sums percentages for all selected options
 * 
 * @param {array} selections - Array of selected values (e.g., ['liberal', 'moderate'])
 * @param {string} fieldType - Type of field ('political', 'bmi', 'fitness')
 * @param {object} cbsaData - CBSA data
 * @returns {number} Percentage (0-100) of population matching
 */
const getMultiSelectPercentage = (selections, fieldType, cbsaData) => {
  if (!selections || selections.length === 0 || selections.includes('no_preference') || !cbsaData) {
    return 100; // No preference = include everyone
  }
  
  const fieldMaps = {
    political: {
      'conservative': 'political_conservative_cbsa',
      'moderate': 'political_moderate_cbsa',
      'liberal': 'political_liberal_cbsa',
      'apolitical': 'political_apolitical_cbsa'
    },
    bmi: {
      'lean_fit': 'bmi_elite_cbsa',
      'average': 'bmi_normal_cbsa',
      'overweight': 'bmi_overweight_cbsa',
      'obese': 'bmi_obesity_cbsa'
    },
    fitness: {
      'never': 'fitness_never_cbsa',
      '1_day': 'fitness_1_day_cbsa',
      '2_3_days': 'fitness_2_3_days_cbsa',
      '4_6_days': 'fitness_4_6_days_cbsa',
      'daily': 'fitness_daily_cbsa'
    },
    ethnicity: {
      'white': 'ethnicity_white_cbsa',
      'hispanic': 'ethnicity_hispanic_cbsa',
      'black': 'ethnicity_black_cbsa',
      'asian': 'ethnicity_asian_cbsa',
      'native': 'ethnicity_native_cbsa',
      'pacific': 'ethnicity_pacific_cbsa',
      'other': 'ethnicity_other_cbsa'
    },
    education: {
      'less than hs': 'education_less_hs_cbsa',
      'hs_grad': 'education_hs_grad_cbsa',
      'high school': 'education_hs_grad_cbsa',
      'trade': 'education_trade_cbsa',
      'associate': 'education_associate_cbsa',
      'some college': 'education_some_college_cbsa',
      'some_college': 'education_some_college_cbsa',
      'bachelors': 'education_bachelors_cbsa',
      "bachelor's": 'education_bachelors_cbsa',
      'graduate': 'education_graduate_cbsa'
    }
  };
  
  const map = fieldMaps[fieldType];
  if (!map) return 100;
  
  let totalPct = 0;
  for (const selection of selections) {
    const key = map[selection.toLowerCase()];
    if (key) {
      totalPct += (cbsaData[key] || 0);
    }
  }
  
  return totalPct;
};

/**
 * Get percentage for single-select filter (kids, smoking)
 * 
 * @param {string} preference - User's preference ('no_preference', 'yes', 'no')
 * @param {string} fieldType - Type of field ('kids', 'smoking')
 * @param {object} cbsaData - CBSA data
 * @returns {number} Percentage (0-100) of population matching
 */
const getSingleSelectPercentage = (preference, fieldType, cbsaData) => {
  if (!preference || preference === 'no_preference' || !cbsaData) return 100;
  
  const fieldMaps = {
    kids: {
      'yes': 'have_kids_yes_cbsa',
      'no': 'have_kids_no_cbsa'
    },
    smoking: {
      'yes': 'smoking_yes_cbsa',
      'no': 'smoking_no_cbsa'
    }
  };
  
  const map = fieldMaps[fieldType];
  if (!map) return 100;
  
  const key = map[preference.toLowerCase()];
  return key ? (cbsaData[key] || 100) : 100;
};

/**
 * Get education filter percentage - cumulative for minimum education
 * If user wants bachelor's+, sum bachelor's and graduate
 * 
 * @param {string} minEducation - Minimum education preference
 * @param {object} cbsaData - CBSA data
 * @returns {number} Percentage (0-100) of population at or above education level
 */
const getEducationAbovePercentage = (minEducation, cbsaData) => {
  if (!minEducation || minEducation === 'no_preference' || !cbsaData) return 100;
  
  const educationOrder = [
    'education_less_hs_cbsa',
    'education_hs_grad_cbsa',
    'education_trade_cbsa',
    'education_associate_cbsa',
    'education_some_college_cbsa',
    'education_bachelors_cbsa',
    'education_graduate_cbsa'
  ];
  
  const minKey = getEducationKey(minEducation);
  if (!minKey) return 100;
  
  const minIndex = educationOrder.indexOf(minKey);
  if (minIndex === -1) return 100;
  
  let totalPct = 0;
  for (let i = minIndex; i < educationOrder.length; i++) {
    totalPct += (cbsaData[educationOrder[i]] || 0);
  }
  
  return totalPct;
};

/**
 * Main three-tier match calculation
 * Calculates Realistic → Preferred → Ideal matches with tier-specific sigmoids
 * 
 * @param {object} user - User profile
 * @param {object} cbsaData - CBSA data for the metro area
 * @param {object} partnerPrefs - User's partner preferences from formData.partnerPrefs
 * @param {object} userProfile - User's own profile from formData.userProfile (for sigmoid)
 * @returns {object} Complete three-tier calculation results
 */
const calculateThreeTierMatches = (user, cbsaData, partnerPrefs = {}, userProfile = {}) => {
  const status = (user.relationshipStatus || '').toLowerCase();
  if (status === 'married' || status === 'yes') {
    return {
      realisticPool: null, realisticMatches: null, realisticMatchRate: null,
      preferredPool: null, preferredMatches: null, preferredMatchRate: null,
      idealPool: null, idealMatches: null, idealMatchRate: null,
      relateScore: null, relateScoreOutOf10: null,
      targetGenderLabel: null, components: null
    };
  }
  
  // Validate CBSA data
  const requiredFields = ['cbsa_population', 'gender_woman_cbsa', 'gender_man_cbsa', 'female_cbsa', 'male_cbsa', 'relationship_single_cbsa', 'single_18_65_cbsa'];
  const missingFields = requiredFields.filter(f => cbsaData[f] === undefined || cbsaData[f] === null);
  if (missingFields.length > 0) {
    console.warn('[calculateThreeTierMatches] Missing CBSA fields:', missingFields);
  }
  
  // Target gender setup
  const g = (user.gender || '').toLowerCase();
  const isMale = g === 'man' || g === 'male';
  const targetGenderLabel = isMale ? 'women' : 'men';
  const gender = isMale ? 'men' : 'women';
  
  // Build complete user object for sigmoid calculations
  const userForSigmoid = {
    gender: user.gender,
    age: user.age,
    income: user.income,
    education: user.education,
    ethnicity: user.ethnicity,
    hasKids: user.hasKids,
    height: userProfile.height || null,
    bodyType: userProfile.bodyType || 'average',
    fitnessLevel: userProfile.workoutFrequency || 'never',
    politicalViews: userProfile.politicalViews || 'moderate',
    smoking: userProfile.smoking || 'no',
    targetAgeMin: partnerPrefs.ageMin || (user.age - 10),
    targetAgeMax: partnerPrefs.ageMax || (user.age + 10)
  };
  
  // === TIER 1: REALISTIC ===
  // Population → Universal exclusion → Gender → Orientation → Felons → Drugs → Singles → Age → Income
  
  const population = cbsaData.cbsa_population || 0;
  
  // Step 1: Remove 65+ and homeless
  const adults18_64 = population * (1 - UNIVERSAL_EXCLUSION_RATE);
  
  // Step 2: Filter to target gender
  const targetGenderNationalPct = cbsaData[isMale ? 'gender_woman_cbsa' : 'gender_man_cbsa'] || 50;
  const targetGenderLocalWeight = cbsaData[isMale ? 'female_cbsa' : 'male_cbsa'] || 50;
  const targetGender18_64 = adults18_64 * (targetGenderNationalPct / 100) * (targetGenderLocalWeight / 50);
  
  // Step 3: Filter by orientation
  const userOrientation = (user.orientation || 'straight').toLowerCase();
  let orientationPct = 100;
  if (userOrientation === 'straight') {
    // Straight user: target pool is straight people of opposite gender
    orientationPct = cbsaData.orientation_straight_cbsa || 91;
  } else if (userOrientation === 'gay' || userOrientation === 'lesbian') {
    // Gay/lesbian user: target pool is gay/lesbian people of same gender
    orientationPct = cbsaData.orientation_gay_lesbian_cbsa || 4;
  } else if (userOrientation === 'bisexual') {
    // Bisexual user: target pool is straight + bisexual
    orientationPct = (cbsaData.orientation_straight_cbsa || 91) + (cbsaData.orientation_bisexual_cbsa || 4);
  }
  const afterOrientation = targetGender18_64 * (orientationPct / 100);
  
  // Step 4: Remove felons (stratified)
  const targetEducation = user.education?.toLowerCase() === 'graduate' ? 'bachelors' : user.education;
  const felonRate = getStratifiedFelonRate(targetGenderLabel, user.ethnicity, targetEducation);
  const afterFelons = afterOrientation * (1 - felonRate);
  
  // Step 5: Remove drug users (stratified)
  const drugRate = getStratifiedDrugRate(targetGenderLabel, user.ethnicity, targetEducation);
  const afterDrugs = afterFelons * (1 - drugRate);
  
  // Step 6: Filter to singles
  const singleNationalPct = cbsaData.relationship_single_cbsa || 30;
  const singleLocalWeight = cbsaData.single_18_65_cbsa || 50;
  const singlesPool = afterDrugs * (singleNationalPct / 100) * (singleLocalWeight / 50);
  
  // Step 7: Filter by age range preference
  const ageRangePct = getAgeRangePercentage(partnerPrefs.ageMin, partnerPrefs.ageMax, cbsaData);
  const afterAge = singlesPool * (ageRangePct / 100);
  
  // Step 8: Filter by income preference
  const incomeAbovePct = getIncomeAbovePercentage(partnerPrefs.minIncome, cbsaData);
  const realisticPool = Math.round(afterAge * (incomeAbovePct / 100));
  
  // Realistic Sigmoid
  const realisticSigmoid = calculateRealisticSigmoidScore(userForSigmoid, cbsaData);
  const realisticMatchRate = getBaseMatchProbability(realisticSigmoid.score);
  const realisticMatches = Math.round(realisticPool * realisticMatchRate);
  
  // === TIER 2: PREFERRED ===
  // Realistic → Ethnicity → Education → Political → Kids → Smoking
  
  // Ethnicity filter (if user has preference)
  const ethnicityPct = partnerPrefs.ethnicity && partnerPrefs.ethnicity !== 'no_preference'
    ? (cbsaData[getEthnicityKey(partnerPrefs.ethnicity)] || 100)
    : 100;
  const afterEthnicity = realisticMatches * (ethnicityPct / 100);
  
  // Education filter (cumulative - at or above minimum)
  const educationPct = getEducationAbovePercentage(partnerPrefs.minEducation, cbsaData);
  const afterEducation = afterEthnicity * (educationPct / 100);
  
  // Political filter (multi-select)
  const politicalPct = getMultiSelectPercentage(partnerPrefs.politicalViews, 'political', cbsaData);
  const afterPolitical = afterEducation * (politicalPct / 100);
  
  // Kids filter
  const kidsPct = getSingleSelectPercentage(partnerPrefs.hasKids, 'kids', cbsaData);
  const afterKids = afterPolitical * (kidsPct / 100);
  
  // Smoking filter
  const smokingPct = getSingleSelectPercentage(partnerPrefs.smoking, 'smoking', cbsaData);
  const preferredPool = Math.round(afterKids * (smokingPct / 100));
  
  // Preferred Sigmoid
  const preferredSigmoid = calculatePreferredSigmoidScore(userForSigmoid, cbsaData);
  const preferredMatchRate = getBaseMatchProbability(preferredSigmoid.score);
  const preferredMatches = Math.round(preferredPool * preferredMatchRate);
  
  // === TIER 3: IDEAL ===
  // Preferred → Height (women seeking men) → Body Type → Fitness (conditional)
  
  // Height filter (women seeking men only)
  let heightPct = 100;
  if (!isMale && partnerPrefs.minHeight && partnerPrefs.minHeight !== 'no_preference') {
    heightPct = getHeightAbovePercentage(partnerPrefs.minHeight, cbsaData);
  }
  const afterHeight = preferredMatches * (heightPct / 100);
  
  // Body type filter (multi-select)
  const bodyTypePct = getMultiSelectPercentage(partnerPrefs.bodyType, 'bmi', cbsaData);
  const afterBodyType = afterHeight * (bodyTypePct / 100);
  
  // Fitness filter (conditional)
  // Only apply if user's bodyType preference is ONLY average and/or overweight
  let fitnessPct = 100;
  const bodyTypePrefs = partnerPrefs.bodyType || [];
  const onlyAverageOrOverweight = bodyTypePrefs.length > 0 
    && !bodyTypePrefs.includes('no_preference')
    && !bodyTypePrefs.includes('lean_fit')
    && !bodyTypePrefs.includes('obese')
    && (bodyTypePrefs.includes('average') || bodyTypePrefs.includes('overweight'));
  
  if (onlyAverageOrOverweight) {
    fitnessPct = getMultiSelectPercentage(partnerPrefs.workoutFrequency, 'fitness', cbsaData);
  }
  const idealPool = Math.round(afterBodyType * (fitnessPct / 100));
  
  // Ideal Sigmoid
  const idealSigmoid = calculateIdealSigmoidScore(userForSigmoid, cbsaData);
  const idealMatchRate = getBaseMatchProbability(idealSigmoid.score);
  const idealMatches = Math.round(idealPool * idealMatchRate);
  
  // === USER'S OVERALL RELATE SCORE ===
  const relateScoreResult = calculateUserRelateScore(userForSigmoid, cbsaData);
  
  return {
    // Tier 1: Realistic
    realisticPool,
    realisticMatches,
    realisticMatchRate: Math.round(realisticMatchRate * 100),
    realisticSigmoidScore: realisticSigmoid.score,
    
    // Tier 2: Preferred
    preferredPool,
    preferredMatches,
    preferredMatchRate: Math.round(preferredMatchRate * 100),
    preferredSigmoidScore: preferredSigmoid.score,
    
    // Tier 3: Ideal
    idealPool,
    idealMatches,
    idealMatchRate: Math.round(idealMatchRate * 100),
    idealSigmoidScore: idealSigmoid.score,
    
    // User's overall score (displayed to user)
    relateScore: relateScoreResult.score,
    relateScoreOutOf10: relateScoreResult.scoreOutOf10,
    
    // Legacy compatibility (maps to Realistic tier)
    matchScore: Math.round(realisticMatchRate * 100),
    matchPool: realisticMatches,
    localSinglePool: realisticPool,
    
    // Meta
    targetGenderLabel,
    components: {
      realistic: realisticSigmoid.components,
      preferred: preferredSigmoid.components,
      ideal: idealSigmoid.components,
      relateScore: relateScoreResult.components
    },
    
    // Filter percentages (for debugging/display)
    filterPcts: {
      orientation: orientationPct,
      felon: Math.round(felonRate * 100),
      drug: Math.round(drugRate * 100),
      single: singleNationalPct,
      ageRange: ageRangePct,
      incomeAbove: incomeAbovePct,
      ethnicity: ethnicityPct,
      education: educationPct,
      political: politicalPct,
      kids: kidsPct,
      smoking: smokingPct,
      height: heightPct,
      bodyType: bodyTypePct,
      fitness: fitnessPct
    }
  };
};

/**
 * Combined calculation for a single data point
 * Use this when you have user profile + CBSA data and need both scores
 * Now supports three-tier calculation when partnerPrefs is provided
 */
const calculateDatingMetrics = (user, cbsaData, colFamily4, partnerPrefs = {}, userProfile = {}) => {
  const { relateScore, incomeLocal, components } = calculateRelateScore(user, cbsaData, colFamily4);
  
  // Use three-tier calculation
  const threeTier = calculateThreeTierMatches(user, cbsaData, partnerPrefs, userProfile);
  
  return {
    // Legacy fields (for backward compatibility)
    relateScore,
    matchScore: threeTier.matchScore,
    matchPool: threeTier.matchPool,
    localSinglePool: threeTier.localSinglePool,
    targetGenderLabel: threeTier.targetGenderLabel,
    incomeLocal,
    components,
    
    // New three-tier fields
    realisticPool: threeTier.realisticPool,
    realisticMatches: threeTier.realisticMatches,
    realisticMatchRate: threeTier.realisticMatchRate,
    preferredPool: threeTier.preferredPool,
    preferredMatches: threeTier.preferredMatches,
    preferredMatchRate: threeTier.preferredMatchRate,
    idealPool: threeTier.idealPool,
    idealMatches: threeTier.idealMatches,
    idealMatchRate: threeTier.idealMatchRate,
    relateScoreOutOf10: threeTier.relateScoreOutOf10,
    filterPcts: threeTier.filterPcts
  };
};

// ═══════════════════════════════════════════════════════════════════════════════
// END SHARED CALCULATION MODULE
// ═══════════════════════════════════════════════════════════════════════════════

// Demo user input data (static - calculations use cbsaDataLoaded from GitHub)
// DEMO_FORM_DATA represents the user profile for generating narratives
const DEMO_FORM_DATA = {
  firstName: 'Demo',
  gender: 'man',
  ethnicity: 'white',
  orientation: 'straight',
  firstJobTitle: 'Communications Associate',
  firstJobYear: '2004',
  currentJobTitle: 'Executive Vice President of Corporate Affairs',
  firstSector: 'government',
  currentSector: 'energy',
  sectorTransitionYear: '2017',
  sectorTransitionReason: 'career opportunity',
  probeResponses: {}
};

const demoBase = [
  { year: 1998, location: 'Boise, ID', zipCode: '83642', age: 18, income: 29000, goal: 75000, education: 'hs_grad', relationship: 'single', children: false, label: "Father's income", context: "Your father earned $29k in 1998 Boise. The 38th percentile. A family of four needed $48k to cover basics in that market, so the household ran $19k short every year. Boise's rock-bottom cost of living was the only reason it worked at all. The same income in Sacramento or DC would have meant eviction notices and maxed credit cards. You watched money get counted, watched purchases get weighed, watched the math never quite add up. The 4.2/10 Relate score captures the reality of limited resources, limited options, limited room for error." },
  { year: 2004, location: 'Los Angeles, CA', zipCode: '90401', age: 24, income: 40000, goal: 100000, education: 'bachelors', relationship: 'single', children: false, label: "First real job", context: "Los Angeles after college. $40k salary, 45th percentile nationally. The city required $78k for a family of four to cover basic expenses. Nearly double your income. Adjusted for LA's prices, your purchasing power equaled roughly $32k back in Boise. The move to an expensive market erased most of your nominal progress. Your 5/10 Relate score reflected the squeeze of being young, educated, and stretched thin in a city where money determines access to everything." },
  { year: 2005, location: 'Washington, DC', zipCode: '20001', age: 25, income: 46000, goal: 100000, education: 'bachelors', relationship: 'single', children: false, label: "Washington move", context: "Washington brought a $6k raise that vanished into higher rent. The Regional Price Parity exceeded even Los Angeles. You paid more to live despite the bigger number on your paycheck. Running faster to stay in place. DC at 25 meant competing against ambitious young professionals with family money, law degrees, and six-figure consulting salaries." },
  { year: 2008, location: 'Sacramento, CA', zipCode: '95816', age: 28, income: 70000, goal: 150000, education: 'graduate', relationship: 'single', children: false, label: "Sacramento I", context: "Sacramento 2008. A $24k jump in three years, a 52% raise, your first time above the median. You cleared the threshold a family of four needed in that market. The Great Recession hit that same year. You moved up while the broader economy contracted around you." },
  { year: 2011, location: 'Los Angeles, CA', zipCode: '90401', age: 31, income: 90000, goal: 150000, education: 'graduate', relationship: 'married', children: false, label: "Back to Los Angeles", context: "Marriage brought you back to Los Angeles. Your $90k looked strong on paper but Los Angeles consumed roughly $20k of it in price premium compared to cheaper markets. Married, earning well above median, stable. But the financial math remained tight." },
  { year: 2013, location: 'Sacramento, CA', zipCode: '95816', age: 33, income: 100000, goal: 150000, education: 'graduate', relationship: 'married', children: false, label: "Sacramento II", context: "Six figures. A psychological milestone. Sacramento's lower cost of living let you keep more of it. The marriage was showing cracks. No income level fixes fundamental incompatibility." },
  { year: 2015, location: 'Sacramento, CA', zipCode: '95816', age: 35, income: 110000, goal: 175000, education: 'graduate', relationship: 'married', children: true, label: "Divorce, kids", context: "Divorce finalized. A child now in the picture. Your income cleared cost of living with room to breathe, but divorce splits everything. Single parenting, career demands, the logistics of shared custody." },
  { year: 2017, location: 'Edwardsville, IL', zipCode: '62025', age: 37, income: 140000, goal: 175000, education: 'graduate', relationship: 'single', children: true, label: "Midwest move", context: "Geographic arbitrage. $140k in Edwardsville bought more than $170k would in Sacramento. Re-entering the dating market at 37 post-divorce required recalibration. In a smaller metro where your income dominated instead of merely competed." },
  { year: 2018, location: 'Detroit, MI', zipCode: '48243', age: 38, income: 150000, goal: 200000, education: 'graduate', relationship: 'single', children: true, label: "Detroit stint", context: "A Detroit assignment. The goal expanded to $200k. Detroit's Regional Price Parity preserved purchasing power. The trajectory had moved beyond survival into wealth accumulation." },
  { year: 2020, location: 'Austin, TX', zipCode: '78703', age: 40, income: 225000, goal: 200000, education: 'graduate', relationship: 'single', children: true, label: "COVID-19 pandemic", context: "COVID-19. The first time exceeding your target at 112% of goal. Austin's tech boom was pushing costs up, but you broke through anyway. You accelerated during a year when most Americans lost ground." },
  { year: 2022, location: 'Washington, DC', zipCode: '20001', age: 42, income: 200000, goal: 225000, education: 'graduate', relationship: 'single', children: true, label: "Washington return", context: "Back to Washington during peak inflation. The Consumer Price Index hit 8% that year, the worst since 1981. At $200k you cleared the family threshold comfortably." },
  { year: 2024, location: 'Edwardsville, IL', zipCode: '62025', age: 44, income: 300000, goal: 225000, education: 'graduate', relationship: 'single', children: true, label: "The surge", context: "$300k and a return to Edwardsville. You exceeded your target at 133% of what you once thought you would need. The 94th percentile. Nearly 3x the local cost of living threshold." },
  { year: 2025, location: 'Edwardsville, IL', zipCode: '62025', age: 45, income: 700000, goal: 250000, education: 'graduate', relationship: 'single', children: true, label: "Current", context: "Executive Vice President of Corporate Affairs at an energy company. Top 1% of 134 million American households. 2.8x your latest goal. Geographic arbitrage in Edwardsville adds $60k to $80k in effective purchasing power annually." }
];

// Lookup tables for demo
const CPI_DATA = { 1998: 51.2, 2004: 59.7, 2005: 62.3, 2008: 68.6, 2011: 72.3, 2013: 74.9, 2015: 75.8, 2017: 78.4, 2018: 80.4, 2020: 82.4, 2022: 93.1, 2024: 99.0, 2025: 100.0 };
const MEDIAN_DATA = { 1998: 38885, 2004: 44334, 2005: 46326, 2008: 50303, 2011: 50054, 2013: 51939, 2015: 56516, 2017: 61372, 2018: 63179, 2020: 67521, 2022: 74580, 2024: 79350, 2025: 80610 };
const POVERTY_DATA = { 1998: 16530, 2004: 19307, 2005: 19971, 2008: 21834, 2011: 22811, 2013: 23624, 2015: 24257, 2017: 24600, 2018: 25100, 2020: 26200, 2022: 27750, 2024: 31200, 2025: 32150 };

// Default CBSA for fallback when ZIP lookup fails
const DEFAULT_CBSA = {
  name: 'National Average', rpp: 100, cbsa_population: 330000000, latitude: 39.8283, longitude: -98.5795,
  // Normalized scores (50 = national avg)
  income_cbsa: 50, bachelors_cbsa: 50, pct_white_cbsa: 50, age_25_45_cbsa: 50, single_18_65_cbsa: 50, male_cbsa: 50, female_cbsa: 50,
  // Actual percentages - age ranges
  age_18_19_cbsa: 3, age_20_24_cbsa: 7, age_25_29_cbsa: 7, age_30_34_cbsa: 7, age_35_39_cbsa: 7, age_40_44_cbsa: 6, age_45_49_cbsa: 6, age_50_54_cbsa: 6, age_55_59_cbsa: 7, age_60_64_cbsa: 7, age_65_69_cbsa: 6, age_70_74_cbsa: 5, age_75_79_cbsa: 4, age_80_84_cbsa: 3, age_85_120_cbsa: 2,
  // Actual percentages - other
  have_kids_yes_cbsa: 40, have_kids_no_cbsa: 60,
  orientation_straight_cbsa: 91, orientation_gay_lesbian_cbsa: 4, orientation_bisexual_cbsa: 4, orientation_other_cbsa: 1,
  gender_man_cbsa: 49, gender_woman_cbsa: 51, gender_other_cbsa: 0,
  relationship_single_cbsa: 35, relationship_married_cbsa: 48, relationship_dating_cbsa: 12, relationship_separated_cbsa: 5,
  ethnicity_white_cbsa: 60, ethnicity_hispanic_cbsa: 19, ethnicity_black_cbsa: 13, ethnicity_asian_cbsa: 6, ethnicity_native_cbsa: 1, ethnicity_pacific_cbsa: 0.2, ethnicity_other_cbsa: 0.8,
  education_less_hs_cbsa: 10, education_hs_grad_cbsa: 27, education_trade_cbsa: 5, education_associate_cbsa: 8, education_some_college_cbsa: 19, education_bachelors_cbsa: 21, education_graduate_cbsa: 10,
  income_under_35k_cbsa: 25, income_35k_50k_cbsa: 12, income_50k_75k_cbsa: 16, income_75k_100k_cbsa: 12, income_100k_150k_cbsa: 15, income_150k_200k_cbsa: 8, income_200k_300k_cbsa: 7, income_300k_500k_cbsa: 3, income_500k_750k_cbsa: 1, income_750k_plus_cbsa: 1,
};

const formatCurrency = (value) => {
  if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
  if (value >= 1000) return `$${(value / 1000).toFixed(0)}k`;
  return `$${value}`;
};

// Calculate functional context for each year
const getFunctionalContext = (yearData, index, allData) => {
  const { income, greenLine } = yearData;
  const greenLineRatio = income / greenLine;
  const aboveGreenLine = income >= greenLine;
  const isCurrentYear = index === allData.length - 1;
  
  // Check if this is the first year crossing above greenLine
  const previousYears = allData.slice(0, index);
  const wasEverAbove = previousYears.some(d => d.income >= d.greenLine);
  const isFirstCrossing = aboveGreenLine && !wasEverAbove;
  
  // Check if fell back below after being above
  const wasAboveLastYear = index > 0 && allData[index - 1].income >= allData[index - 1].greenLine;
  const fellBelow = !aboveGreenLine && wasAboveLastYear;
  
  // Calculate gap
  const gap = income - greenLine;
  const gapFormatted = formatCurrency(Math.abs(gap));
  
  // Generate contextual addendum
  let addendum = '';
  
  if (isFirstCrossing) {
    addendum = isCurrentYear
      ? ` This marks the first time crossing above the functional threshold, the point where income provides genuine stability rather than just covering costs. At ${Math.round(greenLineRatio * 100)}% of that threshold, financial shocks are manageable rather than catastrophic.`
      : ` This year marked the first time crossing above the functional threshold, the point where income provides genuine stability rather than just covering costs. At ${Math.round(greenLineRatio * 100)}% of that threshold, financial shocks became manageable rather than catastrophic.`;
  } else if (fellBelow) {
    addendum = isCurrentYear
      ? ` Despite nominal income, this drops below the functional threshold due to the higher cost metro. The ${gapFormatted} gap below that line means returning to financial fragility.`
      : ` Despite nominal income, this year dropped below the functional threshold due to the higher cost metro. The ${gapFormatted} gap below that line meant returning to financial fragility.`;
  } else if (aboveGreenLine && greenLineRatio >= 2.0) {
    addendum = isCurrentYear
      ? ` At ${greenLineRatio.toFixed(1)}x the functional threshold, income now provides substantial cushion against disruption.`
      : ` At ${greenLineRatio.toFixed(1)}x the functional threshold, income now provided substantial cushion against disruption.`;
  } else if (aboveGreenLine && greenLineRatio >= 1.5) {
    addendum = isCurrentYear
      ? ` Sitting ${Math.round((greenLineRatio - 1) * 100)}% above the functional threshold provides meaningful breathing room.`
      : ` Sitting ${Math.round((greenLineRatio - 1) * 100)}% above the functional threshold provided meaningful breathing room.`;
  } else if (!aboveGreenLine && greenLineRatio >= 0.85) {
    addendum = isCurrentYear
      ? ` At ${Math.round(greenLineRatio * 100)}% of the functional threshold, genuine stability remains just out of reach, close enough to see but not yet achieved.`
      : ` At ${Math.round(greenLineRatio * 100)}% of the functional threshold, genuine stability remained just out of reach, close enough to see but not yet achieved.`;
  } else if (!aboveGreenLine && greenLineRatio < 0.5) {
    addendum = isCurrentYear
      ? ` At less than half the functional threshold, this income leaves no margin for error. Every dollar is spoken for before it arrives.`
      : ` At less than half the functional threshold, this income left no margin for error. Every dollar was spoken for before it arrived.`;
  }
  
  return addendum;
};

// Generate Relate/Match context for Context by Year section
const getRelateMatchContext = (yearData) => {
  const { relateScore, matchScore, matchPool, localSinglePool, relationship, age, percentile, population } = yearData;
  
  // Skip if married (off market)
  if (relationship === 'Married' || matchScore === null) return '';
  
  const relateTier = Math.round(relateScore / 10);
  const formatPool = (n) => n >= 1000000 ? `${(n/1000000).toFixed(1)}M` : n >= 1000 ? `${Math.round(n/1000)}k` : n;
  const formatPop = (n) => n >= 1000000 ? `${(n/1000000).toFixed(1)}M` : `${(n/1000).toFixed(0)}k`;
  
  // Build contextual Relate explanation
  let relateExplanation = '';
  if (relateTier >= 9 && percentile >= 95) {
    relateExplanation = `The ${relateTier}/10 Relate score reflects top-tier positioning—income, education, and timing all aligned.`;
  } else if (relateTier >= 8 && percentile >= 85) {
    relateExplanation = `A ${relateTier}/10 Relate score means strong leverage in the local market, with income doing the heavy lifting.`;
  } else if (relateTier >= 7 && percentile >= 75) {
    relateExplanation = `At ${relateTier}/10, the Relate score captures solid positioning—income above most, options widening.`;
  } else if (relateTier >= 6 && age < 35) {
    relateExplanation = `The ${relateTier}/10 Relate score reflects youth offsetting income limitations—time remains an asset.`;
  } else if (relateTier >= 6) {
    relateExplanation = `A ${relateTier}/10 Relate score means competitive but not dominant—income helping, age starting to factor.`;
  } else if (relateTier >= 5 && percentile >= 50) {
    relateExplanation = `At ${relateTier}/10, the Relate score reflects the squeeze—income above median but other factors limiting options.`;
  } else if (relateTier >= 4) {
    relateExplanation = `The ${relateTier}/10 Relate score captures constrained options—finances or circumstances narrowing the field.`;
  } else {
    relateExplanation = `A ${relateTier}/10 Relate score reflects real headwinds—income and circumstances working against you in this market.`;
  }
  
  // Build Match context
  let matchExplanation = '';
  const matchRate = localSinglePool > 0 ? (matchPool / localSinglePool * 100) : 0;
  if (matchPool >= 50000) {
    matchExplanation = ` In a ${formatPop(population)} metro, that translates to ${formatPool(matchPool)} realistic matches from ${formatPool(localSinglePool)} local singles.`;
  } else if (matchPool >= 10000) {
    matchExplanation = ` The ${formatPop(population)} metro yields ${formatPool(matchPool)} realistic matches—enough volume to be selective.`;
  } else if (matchPool >= 1000) {
    matchExplanation = ` In this ${formatPop(population)} market, ${formatPool(matchPool)} realistic matches means options exist but require effort.`;
  } else {
    matchExplanation = ` The smaller ${formatPop(population)} metro limits the pool to ${formatPool(matchPool)} realistic matches—geography constraining opportunity.`;
  }
  
  return ' ' + relateExplanation + matchExplanation;
};

const lineConfig = {
  income: { color: '#5C5A4D', label: 'Income', type: 'dollar' },
  purchasePower: { color: '#5C5A4D', label: 'Purchase Power', type: 'dollar' },
  equiv700k: { color: '#1B6CB5', hoverColor: '#2E8AD8', label: '$700k Equivalent', type: 'dollar' },
  goal: { color: '#2E8AD8', label: 'Initial Goal', type: 'dollar' },
  achieve: { color: '#9A9891', label: 'Achieved', type: 'percent' },
  percentile: { color: '#C5C2BA', label: 'Percentile', type: 'percent' },
  safe: { color: '#347613', label: 'Safe Family Of Four', type: 'dollar' },
  greenLine: { color: '#eab308', label: 'Functional Survival', type: 'dollar' },
  medianHH: { color: '#C86A45', label: 'Median Household', type: 'dollar' },
  povertyLine: { color: '#B53232', label: 'Poverty Line', type: 'dollar' },
  relateScore: { color: '#8A74C9', label: 'Relate', type: 'percent' },
  matchScore: { color: '#C4B5F0', label: 'Match', type: 'percent' },
};

// Helper to find crossover point between two data points
const findCrossover = (d1, d2, getTop, getBot) => {
  const diff1 = getTop(d1) - getBot(d1);
  const diff2 = getTop(d2) - getBot(d2);
  if ((diff1 > 0) === (diff2 > 0)) return null; // No crossover
  const t = diff1 / (diff1 - diff2);
  return {
    year: d1.year + t * (d2.year - d1.year),
    value: getTop(d1) + t * (getTop(d2) - getTop(d1))
  };
};

// Custom component to render shading between income and greenLine (when income > greenLine)
// Functional Band - yellow shaded area between income and greenLine (when income > greenLine)
// Shows you've escaped financial fragility
const FunctionalBand = ({ xAxisMap, yAxisMap, data }) => {
  if (!xAxisMap || !yAxisMap || !data) return null;
  
  const xAxis = Object.values(xAxisMap)[0];
  const yAxis = Object.values(yAxisMap).find(a => a.yAxisId === 'dollar');
  
  if (!xAxis || !yAxis || !xAxis.scale || !yAxis.scale) return null;
  
  const xScale = xAxis.scale;
  const yScale = yAxis.scale;
  
  const getTop = d => d.income;
  const getBot = d => d.greenLine;
  
  // Build points with crossovers
  const topPts = [];
  const botPts = [];
  
  for (let i = 0; i < data.length; i++) {
    const d = data[i];
    if (d.income >= d.greenLine) {
      topPts.push(`${xScale(d.year)},${yScale(d.income)}`);
      botPts.push(`${xScale(d.year)},${yScale(d.greenLine)}`);
    } else {
      // Collapsed point
      topPts.push(`${xScale(d.year)},${yScale(d.income)}`);
      botPts.push(`${xScale(d.year)},${yScale(d.income)}`);
    }
    
    if (i < data.length - 1) {
      const cross = findCrossover(data[i], data[i+1], getTop, getBot);
      if (cross) {
        topPts.push(`${xScale(cross.year)},${yScale(cross.value)}`);
        botPts.push(`${xScale(cross.year)},${yScale(cross.value)}`);
      }
    }
  }
  
  const points = topPts.join(' ') + ' ' + botPts.reverse().join(' ');
  return <polygon points={points} fill="#eab308" fillOpacity={0.08} stroke="none" />;
};

// Aspiration Band - green shaded area between Safe (family of 4) and Goal
// Shows the "level up" zone: once you're surviving, this is what you're working towards
const AspirationBand = ({ xAxisMap, yAxisMap, data }) => {
  if (!xAxisMap || !yAxisMap || !data) return null;
  
  const xAxis = Object.values(xAxisMap)[0];
  const yAxis = Object.values(yAxisMap).find(a => a.yAxisId === 'dollar');
  
  if (!xAxis || !yAxis || !xAxis.scale || !yAxis.scale) return null;
  
  const xScale = xAxis.scale;
  const yScale = yAxis.scale;
  
  // Top is goal, bottom is safe - shows aspiration zone
  const topPts = [];
  const botPts = [];
  
  for (let i = 0; i < data.length; i++) {
    const d = data[i];
    // Only shade where goal > safe (which should always be true)
    if (d.goal > d.safe) {
      topPts.push(`${xScale(d.year)},${yScale(d.goal)}`);
      botPts.push(`${xScale(d.year)},${yScale(d.safe)}`);
    } else {
      // Collapsed if somehow goal <= safe
      topPts.push(`${xScale(d.year)},${yScale(d.safe)}`);
      botPts.push(`${xScale(d.year)},${yScale(d.safe)}`);
    }
  }
  
  const points = topPts.join(' ') + ' ' + botPts.reverse().join(' ');
  return <polygon points={points} fill="#86efac" fillOpacity={0.25} stroke="none" />
};

// Custom component to render shading between goal and income (only when income > goal)
const GoalBand = ({ xAxisMap, yAxisMap, data }) => {
  if (!xAxisMap || !yAxisMap || !data) return null;
  
  const xAxis = Object.values(xAxisMap)[0];
  const yAxis = Object.values(yAxisMap).find(a => a.yAxisId === 'dollar');
  
  if (!xAxis || !yAxis || !xAxis.scale || !yAxis.scale) return null;
  
  const xScale = xAxis.scale;
  const yScale = yAxis.scale;
  
  const getTop = d => d.income;
  const getBot = d => d.goal;
  
  // Build points with crossovers
  const topPts = [];
  const botPts = [];
  
  for (let i = 0; i < data.length; i++) {
    const d = data[i];
    if (d.income >= d.goal) {
      topPts.push(`${xScale(d.year)},${yScale(d.income)}`);
      botPts.push(`${xScale(d.year)},${yScale(d.goal)}`);
    } else {
      // Collapsed point
      topPts.push(`${xScale(d.year)},${yScale(d.income)}`);
      botPts.push(`${xScale(d.year)},${yScale(d.income)}`);
    }
    
    if (i < data.length - 1) {
      const cross = findCrossover(data[i], data[i+1], getTop, getBot);
      if (cross) {
        topPts.push(`${xScale(cross.year)},${yScale(cross.value)}`);
        botPts.push(`${xScale(cross.year)},${yScale(cross.value)}`);
      }
    }
  }
  
  const points = topPts.join(' ') + ' ' + botPts.reverse().join(' ');
  return <polygon points={points} fill="#E3EED5" fillOpacity={0.075} stroke="none" />;
};

// Overlap band - where Goal band and Functional band intersect
const OverlapBand = ({ xAxisMap, yAxisMap, data }) => {
  if (!xAxisMap || !yAxisMap || !data) return null;
  
  const xAxis = Object.values(xAxisMap)[0];
  const yAxis = Object.values(yAxisMap).find(a => a.yAxisId === 'dollar');
  
  if (!xAxis || !yAxis || !xAxis.scale || !yAxis.scale) return null;
  
  const xScale = xAxis.scale;
  const yScale = yAxis.scale;
  
  const getTop = d => d.income;
  const getBot = d => Math.max(d.goal, d.greenLine);
  
  // Build points with crossovers
  const topPts = [];
  const botPts = [];
  
  for (let i = 0; i < data.length; i++) {
    const d = data[i];
    const thresh = Math.max(d.goal, d.greenLine);
    if (d.income >= thresh) {
      topPts.push(`${xScale(d.year)},${yScale(d.income)}`);
      botPts.push(`${xScale(d.year)},${yScale(thresh)}`);
    } else {
      topPts.push(`${xScale(d.year)},${yScale(d.income)}`);
      botPts.push(`${xScale(d.year)},${yScale(d.income)}`);
    }
    
    if (i < data.length - 1) {
      const cross = findCrossover(data[i], data[i+1], getTop, getBot);
      if (cross) {
        topPts.push(`${xScale(cross.year)},${yScale(cross.value)}`);
        botPts.push(`${xScale(cross.year)},${yScale(cross.value)}`);
      }
    }
  }
  
  const points = topPts.join(' ') + ' ' + botPts.reverse().join(' ');
  return <polygon points={points} fill="#64748b" fillOpacity={0.06} stroke="none" />;
};

const CustomTooltip = ({ active, payload, label, visibleLines, chartData }) => {
  if (active && payload && payload.length) {
    const d = chartData?.find(d => d.year === label);
    if (!d) return null;
    const showRelateMatch = visibleLines.relateScore || visibleLines.matchScore;
    const relateTier = Math.round(d.relateScore / 10);
    const formatPool = (n) => n >= 1000000 ? `${(n/1000000).toFixed(1)}M` : n >= 1000 ? `${Math.round(n/1000)}k` : n;
    const formatPop = (n) => n >= 1000000 ? `${(n/1000000).toFixed(1)}M` : `${(n/1000).toFixed(0)}k`;
    return (
      <div style={{ backgroundColor: '#1f2937', padding: '12px', borderRadius: '4px', fontSize: '11px', color: '#ffffff', minWidth: '220px' }}>
        <div style={{ fontWeight: '600', marginBottom: '8px', paddingBottom: '6px', borderBottom: '1px solid #73726C' }}>
          {label} · {d?.location}
        </div>
        {visibleLines.income && <Row label="Income" value={formatCurrency(d.income)} color="#ffffff" />}
        {visibleLines.purchasePower && <Row label="Purchase Power" value={formatCurrency(d.purchasePower)} color={lineConfig.purchasePower.color} />}
        {visibleLines.equiv700k && <Row label="$700k Equiv" value={formatCurrency(d.equiv700k)} color={lineConfig.equiv700k.hoverColor} />}
        {visibleLines.goal && <Row label="Initial Goal" value={formatCurrency(d.goal)} color={lineConfig.goal.color} />}
        {visibleLines.achieve && <Row label="Achieved" value={`${d.pctToGoal}%`} color={lineConfig.achieve.color} />}
        {visibleLines.safe && <Row label="Safe Family Of Four" value={formatCurrency(d.safe)} color={lineConfig.safe.color} />}
        {visibleLines.greenLine && <Row label="Functional Survival" value={formatCurrency(d.greenLine)} color={lineConfig.greenLine.color} />}
        {visibleLines.medianHH && <Row label="Median Household" value={formatCurrency(d.medianHH)} color={lineConfig.medianHH.color} />}
        {visibleLines.povertyLine && <Row label="Poverty Line" value={formatCurrency(d.povertyLine)} color={lineConfig.povertyLine.color} />}
        {visibleLines.percentile && <Row label="Percentile" value={d.percentile === 99 ? 'Top 1%' : `${d.percentile}th`} color={lineConfig.percentile.color} />}
        {showRelateMatch && (
          <>
            <div style={{ borderTop: '1px solid #73726C', marginTop: '6px', paddingTop: '6px', fontSize: '10px', lineHeight: '1.5' }}>
              {visibleLines.relateScore && (() => {
                const relateTier = Math.round(d.relateScore / 10);
                const gap = d.greenLine - d.income;
                const surplus = d.income - d.greenLine;
                const c = d.relateComponents || {};
                
                // Dynamic explanation based on data point characteristics (THE GOOD PROSE)
                let relateContext;
                const isMarried = d.matchScore === null;
                const nearPoverty = d.income < d.povertyLine * 1.5;
                const belowFunctional = d.income < d.greenLine;
                const aboveSafe = d.income > d.safe;
                const aboveGoal = d.income > d.goal;
                
                // Use year + percentile + financial situation for unique context per point
                if (nearPoverty && d.percentile < 30) {
                  relateContext = 'financial pressure limiting options';
                } else if (nearPoverty && d.percentile < 45) {
                  relateContext = 'stretched thin in expensive market';
                } else if (belowFunctional && d.year < 2005) {
                  relateContext = 'early career in high-cost area';
                } else if (belowFunctional && d.percentile >= 50) {
                  relateContext = 'income decent but costs eating it';
                } else if (belowFunctional) {
                  relateContext = 'local expenses outpacing earnings';
                } else if (isMarried && aboveGoal) {
                  relateContext = 'peak earning years, settled down';
                } else if (isMarried && d.percentile >= 75) {
                  relateContext = 'strong provider, off market';
                } else if (isMarried) {
                  relateContext = 'married during building years';
                } else if (aboveGoal && d.percentile >= 90) {
                  relateContext = 'income dominating this market';
                } else if (aboveSafe && d.percentile >= 85) {
                  relateContext = 'earnings giving you real leverage';
                } else if (aboveSafe && surplus > 50000) {
                  relateContext = 'comfortable surplus above survival';
                } else if (d.percentile >= 75 && surplus > 20000) {
                  relateContext = 'solid position with breathing room';
                } else if (d.age >= 40 && relateTier >= 7) {
                  relateContext = 'experience and earnings aligned';
                } else if (d.age < 30 && relateTier >= 6) {
                  relateContext = 'ahead of curve for your age';
                } else if (d.age < 30 && d.percentile >= 50) {
                  relateContext = 'building momentum early';
                } else if (relateTier >= 7) {
                  relateContext = 'well positioned locally';
                } else if (relateTier >= 5) {
                  relateContext = 'competitive but room to grow';
                } else {
                  relateContext = 'facing headwinds in this market';
                }
                
                // NEW: Build "what's holding back 10" explanation
                let holdingBack = null;
                if (relateTier >= 7 && relateTier < 10) {
                  const drags = [];
                  if (c.ageScore < 90) drags.push('age');
                  if (c.childrenScore < 65) drags.push('kids');
                  if (c.incomeLocal < 90) drags.push('income');
                  if (c.eduLocal < 65) drags.push('education');
                  if (c.ethnicityScore < 55) drags.push('demographics');
                  
                  if (drags.length > 0) {
                    holdingBack = drags.slice(0, 2).join(' and ') + ' keeping you from a 10';
                  }
                }
                
                // Warning states
                let warningColor = null;
                if (d.income < d.povertyLine) warningColor = '#B53232';
                else if (gap > 0) warningColor = '#eab308';
                
                return (
                  <div style={{ marginBottom: visibleLines.matchScore ? '6px' : '0' }}>
                    <div style={{ marginBottom: '3px' }}>
                      <span style={{ color: lineConfig.relateScore.color, fontWeight: '600' }}>{relateTier}/10</span>
                      <span style={{ color: '#d1d5db' }}> in local dating economy</span>
                    </div>
                    <div style={{ color: warningColor || '#9ca3af' }}>
                      {relateContext.charAt(0).toUpperCase() + relateContext.slice(1)}
                    </div>
                    {holdingBack && (
                      <div style={{ color: '#9ca3af', marginTop: '2px' }}>
                        {holdingBack.charAt(0).toUpperCase() + holdingBack.slice(1)}
                      </div>
                    )}
                  </div>
                );
              })()}
              {visibleLines.matchScore && (
                <div>
                  {d.matchScore === null ? (
                    <span style={{ color: '#9ca3af' }}>Off market during marriage</span>
                  ) : (
                    <>
                      <div style={{ marginBottom: '2px' }}>
                        <span style={{ color: lineConfig.matchScore.color, fontWeight: '600' }}>{formatPool(d.realisticMatches || d.matchPool)}</span>
                        <span style={{ color: '#d1d5db' }}> realistic matches</span>
                      </div>
                      <div style={{ marginBottom: '2px' }}>
                        <span style={{ color: '#A193D8', fontWeight: '600' }}>{formatPool(d.preferredMatches || Math.round((d.matchPool || 0) * 0.6))}</span>
                        <span style={{ color: '#d1d5db' }}> preferred matches</span>
                      </div>
                      <div style={{ marginBottom: '2px' }}>
                        <span style={{ color: '#C4B5F0', fontWeight: '600' }}>{formatPool(d.idealMatches || Math.round((d.matchPool || 0) * 0.25))}</span>
                        <span style={{ color: '#d1d5db' }}> ideal matches</span>
                      </div>
                      <div style={{ color: '#9ca3af', fontSize: '10px', marginTop: '4px' }}>
                        from {formatPool(d.realisticPool || d.localSinglePool)} local single {d.targetGenderLabel || 'people'}
                      </div>
                    </>
                  )}
                </div>
              )}
            </div>
          </>
        )}
      </div>
    );
  }
  return null;
};

const Row = ({ label, value, color }) => (
  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
    <span style={{ color: '#d1d5db' }}>{label}</span>
    <span style={{ color, fontWeight: '500', filter: 'brightness(1.3)' }}>{value}</span>
  </div>
);

const Toggle = ({ active, color, label, onClick }) => {
  const [hovered, setHovered] = useState(false);
  return (
    <button
      onClick={onClick}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        padding: '3px 8px',
        fontSize: '10px',
        fontWeight: '500',
        borderRadius: '3px',
        border: 'none',
        backgroundColor: active ? color : (hovered ? '#E5E2DA' : '#F5F3ED'),
        color: active ? 'white' : '#5C5A4D',
        cursor: 'pointer',
        transition: 'all 0.1s',
        letterSpacing: '0.02em'
      }}
    >
      {label}
    </button>
  );
};

const Section = ({ title, children, isOpen, onToggle }) => {
  return (
    <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb' }}>
      <button
        onClick={onToggle}
        style={{
          width: '100%',
          padding: '10px 12px',
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          border: 'none',
          backgroundColor: 'transparent',
          cursor: 'pointer',
          fontSize: '11px',
          fontWeight: '600',
          color: '#374151',
          textTransform: 'uppercase',
          letterSpacing: '0.05em'
        }}
      >
        {title}
        <span style={{ color: '#9A9891', fontSize: '10px' }}>{isOpen ? '▼' : '▶'}</span>
      </button>
      {isOpen && <div style={{ padding: '0 12px 12px', fontSize: '13px', lineHeight: '1.6', color: '#3D3D3A' }}>{children}</div>}
    </div>
  );
};

const Stat = ({ label, value, sub, highlight }) => (
  <div style={{ textAlign: 'center', padding: '8px' }}>
    <div style={{ fontSize: '18px', fontWeight: '700', color: '#141413', fontFamily: 'monospace', textDecoration: highlight ? 'underline' : 'none', textDecorationColor: '#d1d5db', textUnderlineOffset: '3px' }}>{value}</div>
    <div style={{ fontSize: '11px', color: '#3D3D3A', textTransform: 'uppercase', letterSpacing: '0.03em' }}>{label}</div>
    {sub && <div style={{ fontSize: '9px', color: '#9A9891', marginTop: '2px' }}>{sub}</div>}
  </div>
);

const StatCard = ({ label, value, sub, highlight, onClick, isActive }) => {
  const [isHovered, setIsHovered] = useState(false);
  
  return (
    <div 
      style={{ 
        backgroundColor: isHovered ? '#fafafa' : 'white', 
        borderRadius: '4px', 
        border: isActive ? '1px solid #9A9891' : '1px solid #e5e7eb', 
        padding: '8px',
        cursor: 'pointer',
        transition: 'all 0.15s ease',
        transform: isHovered ? 'translateY(-1px)' : 'none',
        boxShadow: isHovered ? '0 2px 4px rgba(0,0,0,0.04)' : 'none'
      }}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onClick={onClick}
    >
      <Stat label={label} value={value} sub={sub} highlight={highlight} />
    </div>
  );
};

const PageHeader = ({ currentPage, setCurrentPage, scaledFont, windowWidth, containerWidth, setContainerWidth }) => {
  const [menuOpen, setMenuOpen] = React.useState(false);
  
  const navButtonStyle = (isActive) => ({
    height: '28px',
    padding: '0 12px',
    border: 'none',
    borderRadius: '4px',
    backgroundColor: isActive ? '#E5E2DA' : 'transparent',
    cursor: 'pointer',
    fontSize: '12px',
    fontWeight: '500',
    color: '#3D3929',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-start',
    width: '100%',
  });
  
  return (
    <div style={{ marginBottom: '16px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <div style={{ display: 'flex', alignItems: 'baseline' }}>
        <div 
          onClick={() => setCurrentPage('home')}
          style={{ 
            fontFamily: 'Georgia, serif',
            fontSize: windowWidth < 640 ? '20px' : '24px',
            fontWeight: '400',
            color: '#C96442',
            letterSpacing: '0.01em',
            cursor: 'pointer',
          }}
        >
          Relate
        </div>
        <span style={{
          fontFamily: 'Georgia, serif',
          fontSize: windowWidth < 640 ? '20px' : '24px',
          fontWeight: '400',
          color: '#141413',
          marginLeft: '4px',
        }}>
          / Markets
        </span>
      </div>
      
      {/* Desktop: Horizontal navigation */}
      {windowWidth > 800 ? (
        <div style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
          <button onClick={() => setCurrentPage('calculator')} style={{ ...navButtonStyle(currentPage === 'calculator'), width: 'auto' }}>Calculator</button>
          <button onClick={() => setCurrentPage('report')} style={{ ...navButtonStyle(currentPage === 'report'), width: 'auto' }}>Report</button>
          <button onClick={() => setCurrentPage('visualize')} style={{ ...navButtonStyle(currentPage === 'visualize'), width: 'auto' }}>Visualize</button>
          <button onClick={() => setCurrentPage('data')} style={{ ...navButtonStyle(currentPage === 'data'), width: 'auto' }}>Data</button>
          <button onClick={() => setCurrentPage('glossary')} style={{ ...navButtonStyle(currentPage === 'glossary'), width: 'auto' }}>Glossary</button>
          <button onClick={() => setCurrentPage('demo')} style={{ ...navButtonStyle(currentPage === 'demo'), width: 'auto' }}>Demo</button>
          {windowWidth >= 1250 && (
            <div style={{ display: 'flex', gap: '4px', marginLeft: '8px' }}>
              <button
                onClick={() => setContainerWidth(Math.max(900, containerWidth - 100))}
                style={{
                  width: '28px',
                  height: '28px',
                  border: '1px solid #E5E2DA',
                  borderRadius: '4px',
                  backgroundColor: containerWidth < 1100 ? '#E5E2DA' : 'white',
                  cursor: containerWidth <= 900 ? 'not-allowed' : 'pointer',
                  fontSize: '14px',
                  fontWeight: '500',
                  color: containerWidth <= 900 ? '#9C9A91' : '#3D3929',
                }}
              >
                −
              </button>
              <button
                onClick={() => setContainerWidth(Math.min(1400, containerWidth + 100))}
                style={{
                  width: '28px',
                  height: '28px',
                  border: '1px solid #E5E2DA',
                  borderRadius: '4px',
                  backgroundColor: containerWidth > 1100 ? '#E5E2DA' : 'white',
                  cursor: containerWidth >= 1400 ? 'not-allowed' : 'pointer',
                  fontSize: '14px',
                  fontWeight: '500',
                  color: containerWidth >= 1400 ? '#9C9A91' : '#3D3929',
                }}
              >
                +
              </button>
            </div>
          )}
        </div>
      ) : (
        /* Mobile/Tablet: Hamburger menu */
        <div style={{ position: 'relative' }}>
          <button
            onClick={() => setMenuOpen(!menuOpen)}
            style={{
              width: '36px',
              height: '36px',
              border: '1px solid #E5E2DA',
              borderRadius: '4px',
              backgroundColor: menuOpen ? '#E5E2DA' : 'white',
              cursor: 'pointer',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              justifyContent: 'center',
              gap: '4px',
              padding: '8px',
            }}
          >
            <div style={{ width: '16px', height: '2px', backgroundColor: '#3D3929', borderRadius: '1px' }} />
            <div style={{ width: '16px', height: '2px', backgroundColor: '#3D3929', borderRadius: '1px' }} />
            <div style={{ width: '16px', height: '2px', backgroundColor: '#3D3929', borderRadius: '1px' }} />
          </button>
          
          {menuOpen && (
            <div style={{
              position: 'absolute',
              top: '42px',
              right: '0',
              backgroundColor: 'white',
              border: '1px solid #E5E2DA',
              borderRadius: '4px',
              padding: '8px',
              minWidth: '140px',
              boxShadow: '0 4px 12px rgba(0,0,0,0.1)',
              zIndex: 1000,
            }}>
              <button onClick={() => { setCurrentPage('calculator'); setMenuOpen(false); }} style={navButtonStyle(currentPage === 'calculator')}>Calculator</button>
              <button onClick={() => { setCurrentPage('report'); setMenuOpen(false); }} style={navButtonStyle(currentPage === 'report')}>Report</button>
              <button onClick={() => { setCurrentPage('visualize'); setMenuOpen(false); }} style={navButtonStyle(currentPage === 'visualize')}>Visualize</button>
              <button onClick={() => { setCurrentPage('data'); setMenuOpen(false); }} style={navButtonStyle(currentPage === 'data')}>Data</button>
              <button onClick={() => { setCurrentPage('glossary'); setMenuOpen(false); }} style={navButtonStyle(currentPage === 'glossary')}>Glossary</button>
              <button onClick={() => { setCurrentPage('demo'); setMenuOpen(false); }} style={navButtonStyle(currentPage === 'demo')}>Demo</button>
            </div>
          )}
        </div>
      )}
    </div>
  );
};

// Dating Market Map Component - uses same calculation engine as Report tooltip
const DatingMarketMap = ({ 
  currentLocation, 
  currentMatchPool, 
  scaledFont, 
  cbsaData,           // Full CBSA dataset from GitHub
  userProfile,        // { gender, orientation, age, education, ethnicity, hasKids, income, relateScore }
  partnerPrefs,       // { ageMin, ageMax, ethnicityPref, openToKids, educationMin, incomeMin }
  hasUserData = false, // Whether user has filled out calculator
  relocationMetros = null // Array of metro names user is open to relocating to, or null for top 15
}) => {
  const [hoveredMetro, setHoveredMetro] = React.useState(null);
  const [mousePos, setMousePos] = React.useState({ x: 0, y: 0 });
  const [idealPoolsMode, setIdealPoolsMode] = React.useState(null); // null | 'men' | 'women'
  const svgRef = React.useRef(null);
  
  // Format pool with smart display: 36.8k for tens of thousands, 391k for hundreds, never .0
  const formatPool = (n) => {
    if (n >= 1000000) {
      const m = n / 1000000;
      return m % 1 === 0 ? `${Math.round(m)}M` : `${m.toFixed(1).replace(/\.0$/, '')}M`;
    }
    if (n >= 100000) return `${Math.round(n/1000)}k`;
    if (n >= 10000) {
      const k = n / 1000;
      return k % 1 === 0 ? `${Math.round(k)}k` : `${k.toFixed(1).replace(/\.0$/, '')}k`;
    }
    if (n >= 1000) return `${(n/1000).toFixed(1).replace(/\.0$/, '')}k`;
    return String(Math.round(n));
  };
  const formatCurrency = (n) => `$${(n/1000).toFixed(0)}k`;
  
  // All available metros with coordinates and CBSA keys
  // Includes top 30 US metros to support up to 15 relocation targets
  const allMetrosBase = [
    // Top 15 metros (purple) - manually calibrated and confirmed
    { rank: 1, name: 'New York', state: 'NY', x: 835, y: 205, cbsaKey: 'New York-Newark-Jersey City, NY-NJ' },
    { rank: 2, name: 'Los Angeles', state: 'CA', x: 85, y: 345, cbsaKey: 'Los Angeles-Long Beach-Anaheim, CA' },
    { rank: 3, name: 'Chicago', state: 'IL', x: 605, y: 195, cbsaKey: 'Chicago-Naperville-Elgin, IL-IN' },
    { rank: 4, name: 'Dallas', state: 'TX', x: 450, y: 420, cbsaKey: 'Dallas-Fort Worth-Arlington, TX' },
    { rank: 5, name: 'Houston', state: 'TX', x: 510, y: 490, cbsaKey: 'Houston-Pasadena-The Woodlands, TX' },
    { rank: 6, name: 'Washington', state: 'DC', x: 785, y: 245, cbsaKey: 'Washington-Arlington-Alexandria, DC-VA-MD-WV' },
    { rank: 7, name: 'Miami', state: 'FL', x: 805, y: 545, cbsaKey: 'Miami-Fort Lauderdale-West Palm Beach, FL' },
    { rank: 8, name: 'Philadelphia', state: 'PA', x: 820, y: 205, cbsaKey: 'Philadelphia-Camden-Wilmington, PA-NJ-DE-MD' },
    { rank: 9, name: 'Atlanta', state: 'GA', x: 680, y: 365, cbsaKey: 'Atlanta-Sandy Springs-Roswell, GA' },
    { rank: 10, name: 'Phoenix', state: 'AZ', x: 195, y: 375, cbsaKey: 'Phoenix-Mesa-Chandler, AZ' },
    { rank: 11, name: 'Boston', state: 'MA', x: 860, y: 188, cbsaKey: 'Boston-Cambridge-Newton, MA-NH' },
    { rank: 12, name: 'San Francisco', state: 'CA', x: 50, y: 255, cbsaKey: 'San Francisco-Oakland-Fremont, CA' },
    { rank: 13, name: 'Seattle', state: 'WA', x: 95, y: 35, cbsaKey: 'Seattle-Tacoma-Bellevue, WA' },
    { rank: 14, name: 'Denver', state: 'CO', x: 350, y: 260, cbsaKey: 'Denver-Aurora-Centennial, CO' },
    { rank: 15, name: 'Austin', state: 'TX', x: 430, y: 465, cbsaKey: 'Austin-Round Rock-San Marcos, TX' },
  ];
  
  // Calculate full dating market metrics for a metro - same as Report tooltip
  // Calculate metrics for a metro using SHARED CALCULATION MODULE
  const calculateMetroMetrics = (metroCbsa, user) => {
    if (!metroCbsa) return null;
    
    const population = metroCbsa.cbsa_population || 100000;
    const rpp = metroCbsa.rpp || 100;
    
    // If no user data, just return total singles (both genders)
    if (!user || !hasUserData) {
      const singlePct = (metroCbsa.relationship_single_cbsa || 35) / 100;
      const adultPct = 0.78;
      const totalSingles = Math.round(population * adultPct * singlePct);
      return { totalSingles, hasUserData: false };
    }
    
    // Use SHARED CALCULATION MODULE
    const income = user.income || 100000;
    const purchasePower = Math.round(income * (100 / rpp));
    const colFamily4 = 108000 * (rpp / 100); // Base COL adjusted for location
    
    // Calculate using shared functions
    const { relateScore, incomeLocal } = calculateRelateScore(user, metroCbsa, colFamily4);
    const { matchScore, matchPool, localSinglePool, targetGenderLabel } = calculateMatchScore(user, metroCbsa, relateScore);
    
    // Relate context for tooltip
    const relateTier = Math.round(relateScore / 10);
    let relateContext;
    if (incomeLocal >= 85 && relateTier >= 7) relateContext = 'income dominating this market';
    else if (incomeLocal >= 75 && relateTier >= 6) relateContext = 'earnings giving you real leverage';
    else if (relateTier >= 7) relateContext = 'well positioned locally';
    else if (relateTier >= 5) relateContext = 'competitive but room to grow';
    else relateContext = 'facing headwinds in this market';
    
    // Education-filtered pool for detailed tooltip
    const isWhite = (user.ethnicity || '').toLowerCase() === 'white';
    const eduFilterPct = ((metroCbsa.education_bachelors_cbsa || 23) + (metroCbsa.education_graduate_cbsa || 12)) / 100;
    const ethFilterPct = isWhite ? (metroCbsa.ethnicity_white_cbsa || 58) / 100 : (100 - (metroCbsa.ethnicity_white_cbsa || 58)) / 100;
    const educationMatchPool = Math.round((matchPool || 0) * eduFilterPct * ethFilterPct);
    
    return {
      hasUserData: true,
      income,
      purchasePower,
      rpp,
      localSinglePool,
      realisticMatches: matchPool,
      educationMatchPool,
      targetGender: targetGenderLabel,
      relateTier,
      relateContext,
      relateScore,
      matchScore,
      isWhite
    };
  };
  
  // Calculate ideal pools for a CBSA
  // Threshold: 500+ to display on map
  const calculateIdealPools = (c) => {
    if (!c || !c.cbsa_population) return { idealMen: 0, idealWomen: 0 };
    
    const pop = c.cbsa_population;
    const available = pop * 0.765; // Universal exclusion
    
    // FLIPPED singles weight (data is inverted)
    const flippedSingles = 100 - (c.single_18_65_cbsa || 50);
    
    // Felon and drug rates for bachelor's+
    const FELON_MEN = 0.026, DRUG_MEN = 0.128;
    const FELON_WOMEN = 0.006, DRUG_WOMEN = 0.096;
    
    // Prime dating age: 25-54 (sum of age brackets)
    const primeAgePct = (
      (c.age_25_29_cbsa || 7) +
      (c.age_30_34_cbsa || 7) +
      (c.age_35_39_cbsa || 6.5) +
      (c.age_40_44_cbsa || 6) +
      (c.age_45_49_cbsa || 6) +
      (c.age_50_54_cbsa || 6.5)
    ) / 100; // ~39% nationally
    
    // BMI filters
    const menBmi = Math.min(((c.bmi_elite_cbsa || 7) + (c.bmi_normal_cbsa || 22) + (c.bmi_overweight_cbsa || 31)) / 100 * (50 / (c.obesity_cbsa || 50)), 1);
    const womenBmi = Math.min((c.bmi_elite_cbsa || 7) / 100 * (50 / (c.obesity_cbsa || 50)), 1);
    
    // Fitness 4-6+ days for women
    const womenFitness = Math.min(((c.fitness_4_6_days_cbsa || 25) + (c.fitness_daily_cbsa || 10)) / 100 * ((c.activity_cbsa || 50) / 50), 1);
    
    // No smoking for both
    const noSmoking = Math.min((c.smoking_no_cbsa || 90) / 100 * ((c.smoking_cbsa || 50) / 50), 1);
    
    // IDEAL MEN: 25-54, $200k+, 6'0"+, bachelor's+, not obese, non-smoker
    const idealMen = available
      * ((c.male_cbsa || 49) / 100) * ((c.gender_man_cbsa || 50) / 50)
      * (1 - FELON_MEN) * (1 - DRUG_MEN)
      * ((c.relationship_single_cbsa || 39) / 100) * (flippedSingles / 50)
      * ((c.orientation_straight_cbsa || 93) / 100) * primeAgePct
      * (((c.education_bachelors_cbsa || 23) + (c.education_graduate_cbsa || 12)) / 100) * ((c.bachelors_cbsa || 50) / 50)
      * (((c.income_200k_300k_cbsa || 4) + (c.income_300k_500k_cbsa || 1.5) + (c.income_500k_750k_cbsa || 0.4) + (c.income_750k_plus_cbsa || 0.3)) / 100) * ((c.income_cbsa || 50) / 50)
      * ((c.height_72plus_cbsa || 31) / 100)
      * menBmi
      * noSmoking;
    
    // IDEAL WOMEN: 25-54, bachelor's+, elite BMI, fitness 4-6+, non-smoker, no kids
    const idealWomen = available
      * ((c.female_cbsa || 51) / 100) * ((c.gender_woman_cbsa || 50) / 50)
      * (1 - FELON_WOMEN) * (1 - DRUG_WOMEN)
      * ((c.relationship_single_cbsa || 39) / 100) * (flippedSingles / 50)
      * ((c.orientation_straight_cbsa || 93) / 100) * primeAgePct
      * (((c.education_bachelors_cbsa || 23) + (c.education_graduate_cbsa || 12)) / 100) * ((c.bachelors_cbsa || 50) / 50)
      * womenBmi
      * womenFitness
      * noSmoking
      * ((c.have_kids_no_cbsa || 61) / 100);
    
    return {
      idealMen: Math.round(idealMen),
      idealWomen: Math.round(idealWomen)
    };
  };
  
  // Determine which metros to show based on state:
  // State 1: No user data -> show top 15
  // State 2: User data, no relocation -> show top 15
  // State 3: User data with relocation -> show only relocation metros
  const metrosToShow = React.useMemo(() => {
    if (relocationMetros && relocationMetros.length > 0 && hasUserData) {
      // State 3: Filter to only user's relocation metros
      return allMetrosBase.filter(m => 
        relocationMetros.some(r => 
          r.toLowerCase().includes(m.name.toLowerCase()) || 
          m.name.toLowerCase().includes(r.toLowerCase())
        )
      );
    }
    // State 1 or 2: Show top 15 metros
    return allMetrosBase.slice(0, 15);
  }, [relocationMetros, hasUserData]);
  
  // Look up CBSA data for each metro and calculate full metrics
  const displayMetros = metrosToShow.map(metro => {
    let metroCbsa = null;
    if (cbsaData && Object.keys(cbsaData).length > 0) {
      metroCbsa = cbsaData[metro.cbsaKey];
      if (!metroCbsa) {
        const shortName = metro.name.toLowerCase();
        for (const [key, data] of Object.entries(cbsaData)) {
          if (key.toLowerCase().includes(shortName)) {
            metroCbsa = data;
            break;
          }
        }
      }
    }
    
    const metrics = calculateMetroMetrics(metroCbsa, userProfile);
    const idealPools = calculateIdealPools(metroCbsa);
    return {
      ...metro,
      metroCbsa,
      metrics,
      idealPools,
      displayPool: metrics?.hasUserData ? metrics.realisticMatches : metrics?.totalSingles
    };
  });
  
  // Calculate ideal pools for ALL CBSAs when in ideal pools mode
  const idealPoolsData = React.useMemo(() => {
    if (!idealPoolsMode || !cbsaData) return [];
    
    const IDEAL_THRESHOLD = 500;
    const results = [];
    
    // Coordinates MUST match allMetrosBase exactly for Top 15, plus additional metros
    const metroCoords = {
      // TOP 15 - EXACT MATCH to allMetrosBase
      'New York-Newark-Jersey City, NY-NJ': { x: 835, y: 205 },
      'Los Angeles-Long Beach-Anaheim, CA': { x: 85, y: 345 },
      'Chicago-Naperville-Elgin, IL-IN': { x: 605, y: 195 },
      'Dallas-Fort Worth-Arlington, TX': { x: 450, y: 420 },
      'Houston-Pasadena-The Woodlands, TX': { x: 510, y: 490 },
      'Washington-Arlington-Alexandria, DC-VA-MD-WV': { x: 785, y: 245 },
      'Miami-Fort Lauderdale-West Palm Beach, FL': { x: 805, y: 545 },
      'Philadelphia-Camden-Wilmington, PA-NJ-DE-MD': { x: 820, y: 205 },
      'Atlanta-Sandy Springs-Roswell, GA': { x: 680, y: 365 },
      'Phoenix-Mesa-Chandler, AZ': { x: 195, y: 375 },
      'Boston-Cambridge-Newton, MA-NH': { x: 860, y: 188 },
      'San Francisco-Oakland-Fremont, CA': { x: 50, y: 255 },
      'Seattle-Tacoma-Bellevue, WA': { x: 95, y: 35 },
      'Denver-Aurora-Centennial, CO': { x: 350, y: 260 },
      'Austin-Round Rock-San Marcos, TX': { x: 430, y: 465 },
      // Additional metros (positioned relative to Top 15)
      'Minneapolis-St. Paul-Bloomington, MN-WI': { x: 530, y: 135 },
      'Detroit-Warren-Dearborn, MI': { x: 677, y: 198 },
      'San Diego-Chula Vista-Carlsbad, CA': { x: 95, y: 370 },
      'Tampa-St. Petersburg-Clearwater, FL': { x: 745, y: 495 },
      'St. Louis, MO-IL': { x: 570, y: 285 },
      'Baltimore-Columbia-Towson, MD': { x: 800, y: 235 },
      'Orlando-Kissimmee-Sanford, FL': { x: 760, y: 485 },
      'Charlotte-Concord-Gastonia, NC-SC': { x: 730, y: 335 },
      'San Antonio-New Braunfels, TX': { x: 430, y: 485 },
      'Portland-Vancouver-Hillsboro, OR-WA': { x: 80, y: 80 },
      'Sacramento-Roseville-Folsom, CA': { x: 61, y: 228 },
      'Pittsburgh, PA': { x: 745, y: 225 },
      'Las Vegas-Henderson-Paradise, NV': { x: 155, y: 320 },
      'Cincinnati, OH-KY-IN': { x: 690, y: 265 },
      'Kansas City, MO-KS': { x: 505, y: 275 },
      'Columbus, OH': { x: 700, y: 240 },
      'Indianapolis-Carmel-Anderson, IN': { x: 635, y: 255 },
      'Cleveland-Elyria, OH': { x: 700, y: 210 },
      'San Jose-Sunnyvale-Santa Clara, CA': { x: 45, y: 275 },
      'Nashville-Davidson--Murfreesboro--Franklin, TN': { x: 630, y: 345 },
      'Virginia Beach-Norfolk-Newport News, VA-NC': { x: 810, y: 290 },
      'Providence-Warwick, RI-MA': { x: 870, y: 185 },
      'Milwaukee-Waukesha, WI': { x: 605, y: 175 },
      'Jacksonville, FL': { x: 765, y: 460 },
      'Oklahoma City, OK': { x: 470, y: 365 },
      'Raleigh-Cary, NC': { x: 765, y: 320 },
      'Memphis, TN-MS-AR': { x: 590, y: 345 },
      'Richmond, VA': { x: 785, y: 300 },
      'New Orleans-Metairie, LA': { x: 560, y: 475 },
      'Louisville/Jefferson County, KY-IN': { x: 640, y: 290 },
      'Salt Lake City, UT': { x: 220, y: 235 },
      'Hartford-East Hartford-Middletown, CT': { x: 855, y: 190 },
      'Buffalo-Cheektowaga, NY': { x: 760, y: 175 },
      'Birmingham-Hoover, AL': { x: 625, y: 375 },
      'Rochester, NY': { x: 775, y: 175 },
      'Grand Rapids-Kentwood, MI': { x: 620, y: 185 },
      'Tucson, AZ': { x: 205, y: 395 },
      'Tulsa, OK': { x: 485, y: 345 },
      'Fresno, CA': { x: 75, y: 300 },
      'Bridgeport-Stamford-Norwalk, CT': { x: 845, y: 195 },
      'Worcester, MA-CT': { x: 860, y: 178 },
      'Albuquerque, NM': { x: 270, y: 365 },
      'Omaha-Council Bluffs, NE-IA': { x: 445, y: 225 },
      'Bakersfield, CA': { x: 95, y: 325 },
      'Albany-Schenectady-Troy, NY': { x: 830, y: 160 },
      'Knoxville, TN': { x: 695, y: 340 },
      'Baton Rouge, LA': { x: 545, y: 465 },
      'El Paso, TX': { x: 280, y: 420 },
      'Allentown-Bethlehem-Easton, PA-NJ': { x: 815, y: 210 },
      'Dayton-Kettering, OH': { x: 670, y: 260 },
      'Riverside-San Bernardino-Ontario, CA': { x: 115, y: 355 },
    };
    
    for (const [cbsaName, cbsa] of Object.entries(cbsaData)) {
      if (!cbsa.cbsa_population || cbsa.cbsa_population < 10000) continue;
      
      const pools = calculateIdealPools(cbsa);
      const count = idealPoolsMode === 'men' ? pools.idealMen : pools.idealWomen;
      
      if (count >= IDEAL_THRESHOLD) {
        // Get coordinates - use lookup or estimate from lat/lng
        let coords = metroCoords[cbsaName];
        if (!coords && cbsa.latitude && cbsa.longitude) {
          // Approximate conversion (rough US map projection)
          const x = ((cbsa.longitude + 125) / 60) * 900 + 30;
          const y = ((50 - cbsa.latitude) / 28) * 500 + 50;
          coords = { x, y };
        }
        
        if (coords) {
          results.push({
            name: cbsaName,
            x: coords.x,
            y: coords.y,
            count,
            idealMen: pools.idealMen,
            idealWomen: pools.idealWomen,
            cbsa
          });
        }
      }
    }
    
    return results.sort((a, b) => b.count - a.count);
  }, [idealPoolsMode, cbsaData]);
  
  // Current location coordinates and CBSA lookup
  const locationCoords = {
    'Edwardsville, IL': { x: 590, y: 278, cbsaKey: 'St. Louis, MO-IL' },
    'St. Louis, MO': { x: 586, y: 282, cbsaKey: 'St. Louis, MO-IL' },
    'Boise, ID': { x: 170, y: 145, cbsaKey: 'Boise City, ID' },
    'Los Angeles, CA': { x: 85, y: 345, cbsaKey: 'Los Angeles-Long Beach-Anaheim, CA' },
    'Washington, DC': { x: 785, y: 245, cbsaKey: 'Washington-Arlington-Alexandria, DC-VA-MD-WV' },
    'Sacramento, CA': { x: 61, y: 228, cbsaKey: 'Sacramento-Roseville-Folsom, CA' },
    'Detroit, MI': { x: 677, y: 198, cbsaKey: 'Detroit-Warren-Dearborn, MI' },
    'Austin, TX': { x: 430, y: 465, cbsaKey: 'Austin-Round Rock-San Marcos, TX' },
  };
  
  const currentCoords = locationCoords[currentLocation] || { x: 570, y: 285, cbsaKey: 'St. Louis, MO-IL' };
  
  // Calculate current location metrics using SHARED MODULE (not the passed-in prop)
  const currentLocationMetrics = React.useMemo(() => {
    if (!hasUserData || !userProfile) return null;
    
    // Find CBSA for current location
    let currentCbsa = null;
    const cbsaKey = currentCoords.cbsaKey;
    if (cbsaData && Object.keys(cbsaData).length > 0) {
      currentCbsa = cbsaData[cbsaKey];
      if (!currentCbsa) {
        // Try partial match
        for (const [key, data] of Object.entries(cbsaData)) {
          if (key.toLowerCase().includes(cbsaKey.split(',')[0].toLowerCase())) {
            currentCbsa = data;
            break;
          }
        }
      }
    }
    
    if (!currentCbsa) return null;
    
    // Calculate using SHARED MODULE
    const rpp = currentCbsa.rpp || 100;
    const colFamily4 = 108000 * (rpp / 100);
    const { relateScore, incomeLocal } = calculateRelateScore(userProfile, currentCbsa, colFamily4);
    const { matchScore, matchPool, localSinglePool, targetGenderLabel } = calculateMatchScore(userProfile, currentCbsa, relateScore);
    
    return {
      relateScore,
      relateTier: Math.round(relateScore / 10),
      matchPool,
      localSinglePool,
      targetGenderLabel,
      incomeLocal
    };
  }, [hasUserData, userProfile, cbsaData, currentCoords.cbsaKey]);
  
  // Display value for current location
  const currentDisplayPool = currentLocationMetrics?.matchPool || currentMatchPool;
  
  // Real US state paths from public domain Wikipedia SVG (via robflaherty/us-map-raphael)
  const statePaths = {
    WA: "M102,7.6L106.4,9L116.1,11.8L124.7,13.7L144.7,19.4L167.7,25L182.9,28.2L169.2,91.8L156.8,88.3L141.3,84.7L126.1,84.8L125.6,83.4L120,85.6L115.4,84.8L113.3,83.3L112,83.9L107.2,83.8L105.5,82.4L100.3,80.3L99.5,80.5L95.1,78.9L93.2,80.8L87,80.5L81,76.3L81.8,75.4L81.9,67.7L79.7,63.9L75.6,63.3L74.9,60.8L72.6,60.3L69,61.5L66.8,58.3L67.1,55.4L69.9,55.1L71.5,51L68.9,49.9L69,46.2L73.4,45.6L70.7,42.8L69.2,35.7L69.9,32.8L69.9,24.9L68.1,21.6L70.3,12.2L72.4,12.7L74.9,15.6L77.6,18.2L80.8,20.2L85.4,22.3L88.4,22.9L91.4,24.4L94.7,25.3L97,25.2L97,22.8L98.3,21.6L100.4,20.3L100.7,21.5L101.1,23.2L98.8,23.7L98.5,25.8L100.2,27.3L101.4,29.7L102,31.6L103.5,31.5L103.6,30.2L102.7,28.9L102.2,25.7L103,23.9L102.3,22.4L102.3,20.2L104.1,16.6L103,14L100.6,9.2L100.9,8.4L102,7.6z",
    OR: "M148.7,175.5L157.5,140.7L158.6,136.5L160.9,130.8L160.3,129.7L157.8,129.6L156.5,127.9L157,126.5L157.5,123.2L161.9,117.7L163.8,116.7L164.9,115.5L166.4,111.9L170.4,106.3L174,102.4L174.2,99L171,96.5L169.2,91.8L156.5,88.2L141.4,84.7L126,84.8L125.5,83.4L120.1,85.5L115.6,84.9L113.2,83.3L111.9,84L107.2,83.8L105.5,82.4L100.3,80.3L99.5,80.5L95.1,79L93.2,80.8L87,80.5L81.1,76.3L81.8,75.5L82,67.8L79.7,63.9L75.6,63.3L74.9,60.8L72.5,60.3L66.7,62.4L64.5,68.9L61.2,78.9L58,85.3L53,99.4L46.5,113L38.5,125.6L36.5,128.5L35.7,137.1L36.1,149.2L148.7,175.5z",
    CA: "M144.6,382.1L148.6,381.7L150.1,379.6L150.6,376.7L147.1,376.1L146.5,375.4L147,373.4L146.9,372.8L148.8,372.2L151.8,369.4L152.4,364.4L153.8,361L155.7,358.8L159.3,357.2L160.9,355.6L161,353.5L160,352.9L159,351.9L157.8,346L155.1,341.2L155.7,337.7L153.3,336.6L84.2,232.5L103.1,164.9L36,149.2L34.5,153.9L34.4,161.3L29.2,173.1L26.1,175.7L25.8,176.9L24,177.7L22.6,181.9L21.8,185.1L24.5,189.3L26.1,193.5L27.2,197.1L26.9,203.5L25.1,206.6L24.5,212.4L23.5,216.1L25.3,220L28.1,224.5L30.3,229.4L31.6,233.4L31.3,236.7L31,237.2L31,239.3L36.6,245.6L36.1,248L35.5,250.2L34.8,252.2L35,260.4L37.1,264.1L39,266.7L41.8,267.2L42.8,270L41.6,273.5L39.5,275.1L38.4,275.1L37.6,279L38.1,281.9L41.3,286.3L42.9,291.6L44.4,296.3L45.7,299.4L49.1,305.2L50.5,307.8L51,310.7L52.6,311.7L52.6,314.1L51.8,316L50,323.2L49.6,325.1L52,327.8L56.2,328.3L60.7,330.1L64.6,332.2L67.5,332.2L70.4,335.3L73,340.1L74.1,342.4L78,344.5L82.9,345.3L84.3,347.4L85,350.6L83.5,351.3L83.8,352.3L87.1,353.1L89.8,353.2L93,351.5L96.9,355.7L97.7,358L100.2,362.2L100.6,365.4L100.6,374.8L101.1,376.6L111.1,378.1L130.8,380.8L144.6,382.1z",
    NV: "M196.3,185.5L172.7,314.3L170.9,314.7L169.3,317.1L166.9,317.1L165.5,314.4L162.8,314L162.1,312.9L161,312.8L158.2,314.5L157.9,321.3L157.6,327L157.2,335.6L155.8,337.7L153.3,336.6L84.3,232.4L103.3,164.9L196.3,185.5z",
    ID: "M148.4,176.4L157.2,141.2L158.6,137L161.1,131L159.8,128.8L157.3,128.9L156.5,127.8L157,126.7L157.3,123.6L161.8,118.1L163.6,117.7L164.7,116.5L165.3,113.3L166.2,112.6L170.1,106.8L174,102.5L174.2,98.7L170.8,96.1L169.3,91.7L182.9,28.3L196.4,30.8L192,52.2L195.6,59.7L194,64.4L196,69L199.1,70.3L202.9,79.8L206.4,84.3L206.9,85.4L210.3,86.6L210.7,88.6L203.7,106L203.5,108.6L206.1,111.9L207.1,111.9L212,108.8L212.6,107.7L214.2,108.4L213.9,113.8L216.7,126.3L220.6,129.5L222.3,131.7L221.5,135.8L222.6,138.6L223.7,139.7L226.2,137.3L229,137.4L231.9,138.7L234.7,138L238.5,137.9L242.5,139.5L245.2,139.2L245.7,136.1L248.6,135.4L249.9,136.9L250.3,139.8L251.8,141L243.4,194.6L148.4,176.4z",
    MT: "M369.2,56.9L338.5,54.1L309.2,50.6L280,46.5L247.6,41.2L229.2,37.8L196.5,30.9L192,52.2L195.4,59.7L194.1,64.3L195.9,68.9L199.1,70.3L203.7,81L206.4,84.2L206.9,85.3L210.3,86.5L210.7,88.5L203.7,106.2L203.7,108.7L206.2,111.9L207.1,111.9L211.9,108.9L212.6,107.8L214.2,108.4L213.9,113.7L216.7,126.3L219.7,128.8L220.6,129.5L222.4,131.8L221.9,135.2L222.6,138.6L223.8,139.5L226.1,137.2L228.8,137.2L232,138.8L234.5,137.9L238.6,137.9L242.3,139.5L245,139.1L245.5,136.1L248.5,135.4L249.8,136.8L250.3,140L251.7,140.8L253.6,129.8L360.4,143.2L369.2,56.9z",
    WY: "M360.3,143.2L253.6,129.8L239.5,218.2L352.8,231.8L360.3,143.2z",
    UT: "M259.4,310.1L175.7,298.2L196.3,185.6L243.1,194.4L241.6,205L239.3,218.2L247.1,219.1L263.5,220.9L271.7,221.8L259.4,310.1z",
    CO: "M380,320.9L384.9,234.6L271.5,221.9L259.3,309.9L380,320.9z",
    AZ: "M144.9,382.6L142.2,384.7L141.9,386.2L142.4,387.2L161.3,397.8L173.4,405.4L188.1,414L205,424L217.2,426.4L242.2,429.2L259.5,310L175.7,298.1L172.6,314.5L171,314.5L169.3,317.2L166.8,317L165.5,314.3L162.8,314L161.9,312.8L161,312.8L160,313.4L158.1,314.4L158,321.4L157.8,323.1L157.2,335.7L155.7,337.9L155.1,341.2L157.9,346.1L159.1,351.9L159.9,352.9L161,353.5L160.8,355.8L159.2,357.2L155.8,358.9L153.9,360.8L152.4,364.5L151.8,369.4L149,372.1L146.9,372.8L147,373.7L146.6,375.4L147,376.2L150.7,376.7L150.1,379.5L148.6,381.7L144.9,382.6z",
    NM: "M288.1,424L287.3,419.2L296,419.7L326.1,422.7L353.4,424.4L355.6,405.7L359.5,349.8L361.2,330.4L362.8,330.5L363.6,319.4L259.6,308.7L242.1,429.2L257.6,431.2L258.9,421.1L288.1,424z",
    ND: "M475.3,128.9L474.6,120.4L473,113.6L471.1,100.6L470.6,89.6L468.9,86.5L467.1,81.3L467.1,70.9L467.8,67.1L465.9,61.6L437.3,61L418.7,60.4L392.2,59.1L369.2,57L362.3,124.1L417.2,127.5L475.3,128.9z",
    SD: "M476.4,204L476.3,203.4L473.5,198.5L475.3,193.8L476.8,187.9L474,185.9L473.6,183.1L474.4,180.6L477.6,180.6L477.5,175.6L477.2,145.4L476.5,141.6L472.5,138.3L471.5,136.6L471.4,135L473.5,133.5L475,131.8L475.2,129.2L417,127.6L362.2,124.1L356.8,187.8L371.4,188.7L391.4,189.9L409.1,190.9L432.9,192.2L444.9,191.7L446.9,194L452.1,197.2L452.8,198L457.4,196.5L463.9,195.9L465.6,197.2L469.8,198.8L472.7,200.5L473.1,201.9L474.2,204.2L476.4,204z",
    NE: "M486,240.7L489.3,247.7L489.1,250L492.6,255.5L495.3,258.6L490.3,258.6L446.8,257.7L406,256.8L383.8,256L384.8,234.7L352.5,231.8L356.9,187.7L372.4,188.8L392.5,189.9L410.4,191.1L434.1,192.2L444.9,191.7L446.9,194L451.7,197L452.9,197.9L457.2,196.6L461.1,196.1L463.9,195.9L465.7,197.2L469.7,198.8L472.7,200.4L473.2,202L474.1,204.1L475.9,204.1L476.7,204.1L477.6,208.8L480.5,217.3L481.1,221L483.6,224.8L484.2,229.9L485.8,234.2L486,240.7z",
    KS: "M507.8,324.3L495.2,324.5L449.1,324.1L404.6,322L379.9,320.8L383.8,256.2L405.9,256.8L446.2,257.7L490.5,258.7L495.6,258.7L497.8,260.8L499.8,260.8L501.4,261.8L501.4,264.8L499.6,266.6L499.2,268.8L501.1,272.2L504,275.4L506.3,277L507.6,288.2L507.8,324.3z",
    OK: "M380.3,320.8L363.6,319.5L362.7,330.5L383.2,331.6L415.2,332.9L412.9,357.3L412.5,375.2L412.7,376.8L417,380.4L419.1,381.6L419.8,381.3L420.5,379.3L421.8,381.1L423.9,381.1L423.9,379.7L426.6,381.1L426.2,385L430.3,385.2L432.8,386.4L436.9,387.1L439.4,388.9L441.7,386.8L445.2,387.5L447.7,390.9L448.6,390.9L448.6,393.2L450.9,393.9L453.2,391.6L455,392.3L457.5,392.3L458.4,394.8L464.7,396.9L466.1,396.2L467.9,392.1L469.1,392.1L470.2,394.2L474.3,394.8L478,396.2L480.9,397.1L482.8,396.2L483.5,393.7L487.8,393.7L489.9,394.6L492.6,392.6L493.7,392.6L494.4,394.2L498.5,394.2L500.1,392.1L502,392.6L504,395.1L507.2,396.9L510.4,397.8L512.4,398.9L512,361.7L510.6,350.7L510.5,341.9L509,335.3L508.2,328.2L508.2,324.3L496,324.7L449.6,324.2L404.6,322.1L380.3,320.8z",
    TX: "M361.4,330.5L384.1,331.6L415.2,332.8L412.9,356.2L412.6,374.4L412.6,376.4L417,380.3L419,381.7L420.1,381.1L420.5,379.3L421.7,381.1L423.8,381.2L423.8,379.7L425.4,380.7L426.6,381.1L426.2,385.1L430.3,385.2L433.2,386.4L437.2,386.9L439.6,389L441.7,386.9L445.4,387.5L447.6,390.7L448.7,391.1L448.6,393L450.8,393.8L453.1,391.8L455.2,392.4L457.5,392.4L458.4,394.8L464.7,397L466.3,396.2L467.8,392L468.1,392L469.1,392.1L470.3,394.2L474.2,394.8L477.5,396L481,397.1L482.8,396.2L483.5,393.7L488,393.7L489.8,394.6L492.6,392.5L493.7,392.6L494.5,394.2L498.6,394.2L500.1,392.1L502,392.6L503.9,395L507.5,397L510.3,397.8L511.8,398.6L514.3,400.6L517.3,399.3L520,400.4L520.6,406.5L520.5,416.2L521.2,425.8L521.9,429.4L524.6,433.8L525.5,438.7L529.7,444.3L529.9,447.4L530.6,448.2L529.9,456.6L527,461.6L528.6,463.7L527.9,466.1L527.3,473.5L525.8,476.8L526.1,480.3L520.4,481.9L510.5,486.4L509.6,488.4L507,490.3L504.9,491.8L503.6,492.6L497.9,497.9L495.2,500L489.9,503.3L484.2,505.7L477.9,509.1L476.1,510.5L470.3,514.1L466.9,514.7L463,520.2L459,520.6L458,522.5L460.3,524.4L458.8,529.9L457.5,534.5L456.4,538.3L455.6,542.9L456.4,545.3L458.2,552.2L459.1,558.4L460.9,561.1L459.9,562.6L456.9,564.5L451.2,560.6L445.7,559.5L444.4,560L441.2,559.4L437,556.3L431.8,555.1L424.2,551.8L422.1,547.9L420.8,541.4L417.6,539.5L416.9,537.2L417.6,536.6L417.9,533.2L416.6,532.5L416,531.5L417.3,527.2L415.6,524.9L412.4,523.6L409,519.3L405.5,512.6L401.3,510L401.4,508.1L396.1,495.8L395.3,491.6L393.5,489.7L393.3,488.2L387.4,482.9L384.8,479.8L384.8,478.7L382.2,476.6L375.4,475.4L368,474.8L364.9,472.5L360.4,474.3L356.8,475.8L354.5,479L353.6,482.7L349.2,488.9L346.8,491.3L344.2,490.3L342.4,489.2L340.5,488.5L336.6,486.3L336.6,485.6L334.8,483.7L329.6,481.6L322.2,473.8L319.9,469.1L319.9,461.1L316.7,454.6L316.2,451.8L314.6,450.9L313.5,448.8L308.5,446.7L307.2,445.1L300.1,437.1L298.8,433.9L294.1,431.6L292.6,427.3L290,424.4L288.1,423.9L287.5,419.2L295.5,419.9L324.5,422.6L353.5,424.2L355.8,404.8L359.6,349.2L361.2,330.5L362.6,330.5z",
    MN: "M475.2,128.8L474.7,120.3L472.9,113L471.1,99.5L470.6,89.7L468.8,86.3L467.2,81.2L467.2,70.9L467.9,67L466.1,61.6L496.2,61.6L496.5,53.4L497.2,53.2L499.4,53.7L501.4,54.5L502.2,60L503.6,66.2L505.2,67.8L510.1,67.8L510.4,69.2L516.7,69.6L516.7,71.7L521.6,71.7L521.9,70.4L523,69.2L525.3,68.6L526.6,69.6L529.5,69.6L533.4,72.1L538.7,74.6L541.1,75L541.6,74.1L543.1,73.6L543.5,76.5L546.1,77.8L546.6,77.3L547.9,77.5L547.9,79.6L550.5,80.5L553.6,80.5L555.2,79.7L558.4,76.5L561,76L561.8,77.8L562.3,79.1L563.3,79.1L564.2,78.3L573.1,78L574.9,81L575.6,81L576.3,79.9L580.7,79.6L580.1,81.9L576.2,83.7L566.9,87.8L562.1,89.8L559.1,92.3L556.6,95.9L554.4,99.8L552.6,100.6L548.1,105.6L546.8,105.8L542.5,108.5L540,111.7L539.8,114.9L539.9,123L538.5,124.6L533.4,128.4L531.2,134.4L534,136.6L534.7,139.9L532.9,143.1L533,146.8L533.4,153.6L536.4,156.6L539.8,156.6L541.7,159.7L545,160.2L548.9,165.9L556,170L558.1,172.9L558.8,179.3L477.6,180.5L477.2,144.8L476.8,141.8L472.7,138.4L471.5,136.5L471.5,134.9L473.6,133.3L475,132L475.2,128.8z",
    IA: "M569.1,199.5L569.4,202.3L571.6,202.9L572.6,204.1L573.1,206L576.9,209.3L577.6,211.7L576.9,215.2L575.3,218.4L574.5,221.1L572.3,222.7L570.6,223.3L565,225.2L563.6,229L564.4,230.4L566.2,232.1L565.9,236.1L564.2,237.6L563.4,239.3L563.5,242.1L561.6,242.5L560,243.6L559.7,245L560,247.1L558.5,248.2L556,245.1L554.7,242.6L489,245.1L488.1,245.3L486,240.8L485.8,234.2L484.2,230L483.5,224.8L481.2,221.1L480.3,216.3L477.6,208.8L476.4,203.4L475.1,201.2L473.5,198.5L475.4,193.6L476.8,187.9L474,185.9L473.6,183.1L474.5,180.6L476.2,180.6L558.9,179.3L559.7,183.5L561.9,185.1L562.2,186.5L560.2,189.9L560.4,193.1L562.9,196.9L565.4,198.2L568.5,198.7L569.1,199.5z",
    MO: "M558.4,248.1L555.9,245L554.7,242.7L490.4,245.1L488.1,245.2L489.3,247.7L489.1,250L491.6,253.9L494.7,258L497.8,260.8L500,261L501.5,261.9L501.5,264.9L499.6,266.5L499.2,268.8L501.2,272.2L503.7,275.2L506.3,277L507.6,288.6L507.9,324.7L508.2,329.4L508.6,334.8L531.1,333.9L554.3,333.2L575.1,332.4L586.7,332.2L588.9,335.6L588.2,338.9L585.1,341.3L584.6,343.2L589.9,343.6L593.8,342.9L595.5,337.5L596.2,331.6L598.3,329L600.9,327.6L600.9,324.5L602,322.6L600.3,320L598.9,321L596.9,318.8L595.7,314L596.5,311.5L594.5,308.1L592.7,303.5L587.9,302.7L580.9,297.1L579.2,293L580,289.8L582.1,283.7L582.5,280.9L580.6,279.8L573.7,279L572.7,277.3L572.6,273.1L567.1,269.7L560.1,261.9L557.8,254.6L557.6,250.4L558.4,248.1z",
    AR: "M593.8,343L589.8,343.7L584.7,343.1L585.1,341.5L588.1,338.9L589,335.3L587.2,332.3L508.8,334.8L510.4,341.7L510.4,349.9L511.8,360.9L512,398.7L514.3,400.6L517.2,399.3L520,400.4L520.7,407L576.3,405.9L577.4,403.8L577.1,400.2L575.3,397.2L576.9,395.8L575.3,393.2L576,390.7L577.4,385.1L579.9,383.1L579.2,380.8L582.9,375.4L585.6,374L585.5,372.5L585.1,370.7L588,365.1L590.4,363.9L590.8,360.4L592.6,359.2L589.4,358.7L588.1,354.7L590.9,352.3L591.4,350.3L592.7,346.3L593.8,343z",
    LA: "M607.9,459.1L604.6,455.9L605.6,450.4L605,449.6L595.7,450.6L570.7,451L570,448.6L570.9,440.2L574.2,434.2L579.3,425.5L578.7,423.1L579.9,422.5L580.4,420.5L578.1,418.4L578,416.5L576.2,412.2L576,405.8L520.6,406.7L520.6,416.3L521.3,425.7L522,429.6L524.5,433.7L525.4,438.7L529.7,444.2L530,447.4L530.6,448.1L530,456.6L527,461.6L528.6,463.6L527.9,466.2L527.2,473.5L525.8,476.7L526,480.3L530.7,478.8L542.8,479L553.1,482.5L559.6,483.7L563.3,482.2L566.5,483.3L569.8,484.3L570.6,482.2L567.3,481.1L564.8,481.6L562,479.9L562.8,478.5L565.9,477.5L567.7,479L569.4,478L572.7,478.7L574.1,481.1L574.5,483.3L579,483.7L580.8,485.4L579.9,487.1L578.7,487.9L580.3,489.5L588.7,493L592.2,491.7L593.2,489.3L595.8,488.7L597.6,487.2L598.9,488.2L599.7,491.1L597.4,491.9L598.1,492.6L601.5,491.3L603.7,487.9L604.5,487.4L602.4,487.1L603.2,485.4L603.1,484L605.2,483.5L606.3,482.2L606.9,483L607.6,486.1L611.8,486.7L615.8,488.7L616.8,490.1L619.7,490.1L620.8,491.1L623.1,488L623.1,486.6L621.8,486.6L618.4,483.8L612.6,483L609.4,480.8L610.5,478L612.8,478.3L612.9,477.7L611.2,476.7L611.2,476.2L614.4,476.2L616.2,473.2L614.9,471.2L614.5,468.5L613.1,468.6L611.2,470.7L610.5,473.3L607.4,472.7L606.5,470.9L608.2,469L610.1,465.5L609.1,463.1L607.9,459.1z",
    WI: "M615,197.3L614.9,194.2L613.8,189.6L613.1,183.5L612,181.1L613,178L613.8,175.1L615.2,172.5L614.6,169.1L613.9,165.5L614.4,163.8L616.4,161.3L616.5,158.6L615.7,157.3L616.4,154.7L615.9,150.5L618.7,144.9L621.6,138.1L621.7,135.8L621.4,134.9L620.6,135.3L616.4,141.7L613.6,145.7L611.7,147.5L610.9,149.7L608.9,150.5L607.8,152.5L606.4,152.2L606.2,150.4L607.5,148L609.6,143.3L611.4,141.7L612.4,139.3L609.8,137.4L607.8,127L604.3,125.7L602.3,123.4L590.2,120.7L587.3,119.6L579.1,117.5L571.2,116.3L567.4,111.2L566.7,111.7L565.5,111.6L564.8,110.4L563.5,110.7L562.4,110.9L560.6,111.9L559.6,111.2L560.3,109.3L562.2,106.2L563.3,105.1L561.4,103.6L559.3,104.4L556.4,106.4L548.9,109.6L546,110.3L543.1,109.8L542.1,108.9L540,111.7L539.8,114.5L539.8,122.9L538.7,124.5L533.4,128.4L531.1,134.4L531.6,134.6L534.1,136.7L534.8,139.9L532.9,143.1L532.9,146.9L533.4,153.6L536.4,156.5L539.8,156.5L541.6,159.7L545.1,160.2L548.9,165.9L556,170L558.1,172.8L559,180.2L559.7,183.5L562,185.1L562.2,186.5L560.1,189.9L560.4,193.1L562.9,197L565.4,198.2L568.4,198.6L569.7,200L615,197.3z",
    IL: "M619.5,300.3L619.5,297.1L620.1,292.4L622.4,289.5L624.3,285.4L626.5,281.4L626.2,276.2L624.1,272.6L624,269.3L624.7,264L623.9,256.8L622.9,241.1L621.6,226L620.6,214.4L620.4,213.5L619.6,210.9L618.3,207.2L616.6,205.4L615.2,202.8L615,197.3L569.2,199.9L569.4,202.3L571.7,203L572.6,204.1L573,206L576.9,209.4L577.6,211.7L576.9,215.1L575.1,218.8L574.4,221.3L572.1,223.1L570.3,223.8L565,225.2L564.4,227L563.7,229L564.4,230.4L566.2,232L566,236.1L564.1,237.7L563.4,239.3L563.4,242.1L561.6,242.5L560,243.7L559.8,245L560,247.1L558.3,248.4L557.3,251.2L557.7,254.9L560,262.2L567.3,269.7L572.8,273.4L572.6,277.7L573.5,279.1L579.9,279.6L582.6,280.9L582,284.6L579.7,290.5L579,293.7L581.3,297.6L587.7,302.9L592.3,303.6L594.3,308.6L596.4,311.8L595.5,314.8L597.1,318.9L598.9,321L600.3,320.1L601.2,318L603.4,316.2L605.5,315.6L608.2,316.8L611.8,318.2L613,317.9L613.2,315.6L611.9,313.2L612.2,310.8L614,309.5L617,308.7L618.3,308.2L617.7,306.8L616.9,304.5L618.3,303.5L619.5,300.3z",
    IN: "M619.5,299.9L619.6,297.1L620.1,292.5L622.3,289.6L624.1,285.7L626.7,281.5L626.2,275.7L624.4,273L624.1,269.7L624.9,264.2L624.4,257.3L623.1,241.3L621.8,225.9L620.9,214.2L623.9,215.1L625.4,216.1L626.5,215.7L628.6,213.8L631.5,212.2L636.6,212L658.5,209.8L664.1,209.2L665.6,225.2L669.9,262L670.5,267.8L670.1,270.1L671.3,271.9L671.4,273.2L668.9,274.8L665.4,276.4L662.2,276.9L661.6,281.8L657,285.1L654.2,289.1L654.5,291.5L653.9,293L650.6,293L649,291.4L646.5,292.7L643.8,294.2L644,297.2L642.8,297.5L642.3,296.5L640.2,295L636.9,296.3L635.4,299.3L633.9,298.5L632.5,296.9L628,297.4L622.4,298.4L619.5,299.9z",
    MI: "M581.6,82.1L583.4,80L585.6,79.2L591,75.3L593.3,74.7L593.7,75.2L588.6,80.3L585.3,82.3L583.2,83.2L581.6,82.1zM667.8,114.2L668.4,116.7L671.7,116.9L673,115.6L672.9,114.2L672.6,114L670.9,112.2L668.8,112.4L667.1,112.6L666.8,113.7L667.8,114.2zM567.5,111.2L568.2,110.6L571,109.8L574.5,107.6L574.5,106.6L575.2,105.9L581.1,105L583.6,103L588,100.9L588.1,99.6L590,96.7L591.8,95.9L593.1,94.1L595.4,91.9L599.7,89.5L604.4,89L605.6,90.1L605.2,91.1L601.5,92L600.1,95.1L597.8,95.9L597.3,98.3L594.9,101.6L594.6,104.2L595.4,104.7L596.3,103.5L599.9,100.6L601.2,101.9L603.5,101.9L606.7,102.9L608.1,104L609.6,107.1L612.3,109.8L616.2,109.7L617.7,108.7L619.3,110L620.9,110.5L622.2,109.7L623.3,109.7L625,108.7L629,105.1L632.4,104L639,103.7L643.5,101.7L646.1,100.4L647.6,100.6L647.6,106.3L648.1,106.6L651,107.4L652.9,106.9L659.1,105.3L660.2,104.2L661.6,104.7L661.6,111.6L664.9,114.7L666.2,115.3L667.5,116.3L666.2,116.6L665.4,116.3L661.6,115.8L659.5,116.5L657.3,116.3L654.1,117.7L652.3,117.7L646.5,116.5L641.3,116.6L639.3,119.2L632.4,119.8L630,120.7L628.8,123.7L627.5,124.9L627.1,124.7L625.6,123.1L621.1,125.5L620.4,125.5L619.3,123.9L618.5,124.1L616.5,128.4L615.6,132.5L612.4,139.5L611.2,138.4L609.8,137.4L607.9,127.1L604.4,125.7L602.3,123.4L590.2,120.7L587.3,119.7L579.1,117.5L571.2,116.4L567.5,111.2zM697.8,177.2L694.6,168.9L692.3,159.9L689.9,156.7L687.3,154.9L685.7,156L681.8,157.8L679.9,162.8L677.1,166.5L676,167.2L674.5,166.5L672.1,164.4L672.6,159.4L676,158.1L676.8,154.7L677.4,152.1L679.9,150.5L679.5,140.5L677.9,138.2L676.6,137.4L675.8,135.3L676.6,134.5L678.2,134.8L678.4,133.2L676,131L674.7,128.4L672.1,128.4L667.6,126.9L662.1,123.5L659.3,123.5L658.7,124.2L657.7,123.7L654.6,121.4L651.7,123.2L648.8,125.5L649.2,129L650.1,129.3L652.2,129.8L652.7,130.6L650.1,131.4L647.5,131.8L646.1,133.5L645.8,135.6L646.1,137.3L646.4,142.8L642.8,144.9L642.2,144.7L642.2,140.5L643.5,138.1L644.1,135.6L643.3,134.8L641.4,135.6L640.4,139.8L637.7,141L635.9,142.9L635.7,143.9L636.4,144.7L635.7,147.3L633.5,147.8L633.5,148.9L634.3,151.3L633.1,157.5L631.5,161.5L632.2,166.2L632.7,167.3L631.9,169.8L631.5,170.6L631.2,173.3L634.8,179.3L637.7,185.8L639.1,190.6L638.3,195.3L637.3,201.3L634.9,206.4L634.6,209.2L631.3,212.3L635.8,212.1L657.2,209.9L664.4,208.9L664.5,210.5L671.4,209.3L681.7,207.8L685.5,207.4L685.7,206.8L685.8,205.3L687.9,201.6L689.9,199.9L689.7,194.8L691.3,193.2L692.4,192.9L692.6,189.3L694.2,186.3L695.2,186.9L695.4,187.5L696.2,187.7L698.1,186.7L697.8,177.2z",
    OH: "M735.3,193.3L729.2,197.3L725.3,199.6L721.9,203.3L717.9,207.2L714.6,208L711.7,208.5L706.2,211.1L704.1,211.2L700.7,208.2L695.6,208.8L693,207.4L690.6,206L685.7,206.7L675.5,208.3L664.3,210.5L665.6,225.1L667.4,238.9L670,262.3L670.5,267.2L674.7,267L677.1,266.2L680.4,267.7L682.5,272.1L687.6,272.1L689.5,274.2L691.3,274.1L693.8,272.8L696.3,273.1L701.8,273.6L703.5,271.5L705.8,270.2L707.9,269.5L708.6,272.3L710.3,273.2L713.8,275.6L716,275.5L717.3,275L717.5,272.3L719.1,270.8L719.2,266L720.2,261.9L721.5,261.3L722.8,262.4L723.4,264.1L725.1,263.1L725.5,261.6L724.4,259.7L724.5,257.4L725.2,256.4L727.4,253L728.4,251.5L730.5,252L732.8,250.4L735.9,247L738.6,242.9L739,237.8L739.4,232.8L739.3,227.5L738.3,224.6L738.7,223.4L740.5,221.7L738.2,212.6L735.3,193.3z",
    KY: "M725.9,295.2L723.7,297.6L720.1,301.6L715.1,307.1L713.9,308.8L713.9,310.9L709.5,313.1L703.8,316.5L696.6,318.3L644.7,323.2L629,324.9L624.4,325.4L620.5,325.4L620.3,329.6L612.1,329.8L605.1,330.4L597.1,330.4L598.3,329L600.8,327.5L601.1,324.3L602,322.5L600.4,319.9L601.2,318L603.4,316.3L605.5,315.6L608.3,316.9L611.9,318.2L613,317.9L613.1,315.6L611.9,313.2L612.2,310.9L614.1,309.5L616.7,308.8L618.3,308.2L617.5,306.4L616.9,304.5L618.4,303.5L619.6,299.8L622.7,298.3L628,297.4L632.5,296.9L633.9,298.5L635.4,299.4L637,296.3L640.2,295L642.4,296.5L642.8,297.5L644,297.2L643.8,294.2L646.9,292.5L649.1,291.4L650.6,293.1L653.9,293L654.5,291.5L654.1,289.2L656.7,285.2L661.5,281.8L662.2,276.9L665.2,276.5L668.9,274.8L671.4,273.1L671.2,271.6L670.1,270.1L670.6,267.1L674.8,267L677.1,266.2L680.4,267.7L682.5,272L687.6,272L689.7,274.3L691.3,274.1L693.9,272.8L699.1,273.4L701.7,273.6L703.4,271.6L706,270.1L707.9,269.4L708.5,272.3L710.6,273.3L713.2,275.4L713.4,281.1L714.2,282.7L716.8,284.2L717.5,286.5L721.7,289.9L723.5,293.6L725.9,295.2z",
    TN: "M696.6,318.2L644.7,323.2L629,325L624.4,325.5L620.5,325.5L620.3,329.6L612.1,329.8L605.1,330.5L597,330.4L595.6,337.4L593.9,342.9L590.6,345.7L589.3,350.1L589,352.6L584.9,354.9L586.4,358.5L585.4,362.8L584.4,363.6L692.6,353.2L693,349.2L694.8,347.8L697.6,347L698.3,343.3L702.4,340.6L706.5,339.1L710.5,335.5L715,333.5L715.5,330.4L719.6,326.4L720.1,326.3L721,327.5L722.9,327.8L725.2,324.2L727.2,323.6L729.5,323.9L731.1,320.3L734.1,317.7L734.5,315.8L734.8,312.1L732.6,311.9L730,313.9L723,313.9L704.7,316.3L696.6,318.2z",
    MS: "M631.5,459.3L631.3,460.6L626.1,460.6L624.6,459.7L622.5,459.4L615.7,461.4L614,460.6L611.4,464.8L610.3,465.5L609.1,463L608,459.2L604.6,456L605.7,450.4L605,449.5L603.2,449.7L595.3,450.6L570.7,451L570,448.7L570.8,440.4L574,434.7L579.2,425.6L578.7,423.1L580,422.5L580.4,420.5L578.1,418.5L578,416.3L576.1,412.2L576,406.2L577.4,403.8L577.1,400.3L575.4,397.3L576.9,395.8L575.3,393.3L575.8,391.6L577.4,385.1L579.8,383.1L579.2,380.7L582.9,375.4L585.7,374L585.5,372.4L585.2,370.7L588.1,365.1L590.4,363.9L590.6,363L627.9,359.1L628.1,365.4L628.2,382L627.4,413.1L627.3,427.1L630,445.9L631.5,459.3z",
    AL: "M631.3,460.4L629.8,446L627,427.3L627.2,413.2L628,382.2L627.8,365.5L628,359.1L672.5,355.5L672.3,357.7L672.5,359.8L673.1,363.2L676.5,371.1L679,381L680.4,387.1L682,392L683.5,398.9L685.6,405.2L688.2,408.6L688.7,412L690.6,412.8L690.8,414.9L689,419.8L688.5,423L688.3,424.9L689.9,429.3L690.3,434.6L689.5,437.1L690.1,437.9L691.6,438.7L691.9,441.6L686.3,441.2L679.5,441.9L654,444.8L643.6,446.2L643.3,449L645.1,450.8L647.7,452.8L648.3,460.7L642.7,463.3L640,463L642.7,461L642.7,460L639.7,454.1L637.4,453.4L635.9,457.8L634.7,460.5L634,460.4L631.3,460.4z",
    GA: "M672.2,355.5L672.2,357.7L672.4,359.8L673.1,363.2L676.4,371.1L678.9,381L680.3,387.1L681.9,392L683.4,398.9L685.5,405.2L688.1,408.6L688.6,412L690.5,412.8L690.7,414.9L688.9,419.8L688.4,423L688.2,424.9L689.9,429.3L690.2,434.6L689.4,437.1L690,437.9L691.5,438.7L691.7,441.9L693.9,445.2L696.2,447.4L704.1,447.6L714.9,446.9L736.4,445.6L741.9,445L746.4,445L746.6,447.9L749.2,448.7L749.5,444.3L747.9,439.8L749,438.2L754.9,439L759.8,439.3L759.1,433L761.3,423L762.8,418.8L762.3,416.2L765.6,410L765.1,408.6L763.2,409.3L760.6,408L760,405.9L758.7,402.4L756.4,400.3L753.8,399.6L752.2,394.8L749.3,388.4L745.1,386.5L743,384.6L741.7,382L739.6,380L737.3,378.7L735.1,375.8L732,373.6L727.5,371.8L727,370.3L724.5,367.4L724.1,366L720.7,361L717.1,361.1L713.4,358.7L712,357.4L711.6,355.7L712.5,353.7L714.7,352.6L714.1,350.5L672.2,355.5z",
    SC: "M764.9,408.1L763.1,409.1L760.5,407.8L759.9,405.7L758.6,402.1L756.3,400L753.7,399.4L752.1,394.5L749.4,388.6L745.2,386.6L743.1,384.7L741.8,382.1L739.7,380.1L737.4,378.9L735.1,375.9L732.1,373.7L727.6,371.9L727.1,370.4L724.6,367.5L724.2,366.1L720.8,360.9L717.4,361.1L713.3,358.6L712,357.4L711.7,355.6L712.5,353.6L714.8,352.7L714.3,350.4L720,348L729.2,343.5L736.9,342.6L753,342.2L755.7,344.1L757.4,347.5L761.7,346.8L774.3,345.4L777.2,346.2L789.8,353.8L799.9,361.9L794.5,367.4L791.9,373.5L791.4,379.8L789.8,380.6L788.7,383.4L786.2,384L784.1,387.6L781.4,390.3L779.1,393.7L777.5,394.5L773.9,397.9L771,398.1L772,401.3L767,406.8L764.9,408.1z",
    NC: "M834.9,294.3L837,299.2L840.6,305.6L843,308.1L843.6,310.3L841.2,310.5L842,311.1L841.7,315.3L839.1,316.6L838.5,318.7L837.2,321.7L833.5,323.3L831,322.9L829.6,322.8L828,321.5L828.3,322.8L828.3,323.8L830.2,323.8L831,325L829.1,331.4L833.3,331.4L833.9,333L836.2,330.7L837.5,330.2L835.6,333.8L832.5,338.6L831.2,338.6L830.1,338.1L827.3,338.8L822.1,341.2L815.7,346.5L812.3,351.2L810.3,357.7L809.9,360.1L805.2,360.6L799.7,362L789.8,353.7L777.2,346.1L774.3,345.3L761.6,346.8L757.4,347.5L755.7,344.3L752.8,342.2L736.3,342.7L729,343.5L720,348L713.8,350.6L692.6,353.2L693.1,349.1L694.9,347.7L697.7,347L698.3,343.3L702.5,340.6L706.4,339.1L710.6,335.6L715,333.5L715.6,330.4L719.5,326.5L720.1,326.3L720.9,327.5L722.9,327.8L725.1,324.2L727.3,323.6L729.5,323.9L731.1,320.4L734,317.8L734.5,315.7L734.7,312L739,312L746.2,311.1L761.9,308.9L777.1,306.8L798.7,302.1L818.7,297.8L829.9,295.4L834.9,294.3z",
    VA: "M834.9,294.3L776.8,306.9L739.3,312.2L732.6,311.8L730.1,313.7L722.7,313.9L714.3,314.9L703.4,316.5L713.9,310.9L713.9,308.9L715.4,306.7L726,295.2L729.9,299.7L733.7,300.6L736.2,299.5L738.5,298.2L741,299.5L744.9,298.1L746.8,293.6L749.4,294.1L752.3,292L754.1,292.5L756.9,288.8L757.2,286.7L756.3,285.4L757.3,283.6L762.5,271.3L763.2,265.5L764.4,265L766.6,267.5L770.5,267.2L772.4,259.6L775.2,259L776.3,256.3L778.9,253.9L781.6,248.2L781.7,243.2L791.5,247L792.4,241.9L796,243.5L796.1,246.5L801.9,247.8L804,249L805.7,251L805,254.7L803.1,257.3L803.2,259.3L803.8,261.2L808.7,262.4L813.2,262.5L816.3,263.4L818.2,263.7L818.9,266.8L822.1,267.2L823,268.4L822.5,273.1L823.9,274.2L823.4,276.2L824.7,276.9L824.4,278.3L821.7,278.2L821.8,279.9L824.1,281.4L824.2,282.8L826,284.6L826.5,287.1L823.9,288.5L825.5,290L831.3,288.3L834.9,294.3zM831.6,266L831.4,264.1L837.9,261.5L837.1,264.7L834.2,268.5L833.8,273.1L834.3,276.5L832.4,281.5L830.3,283.4L828.8,278.7L829.2,273.3L830.8,269.1L831.6,266z",
    WV: "M761.1,238.9L762.2,243.9L763.3,249.9L765.5,247.3L767.7,244.2L770.3,243.6L771.7,242.2L773.5,239.6L774.9,240.2L777.9,239.9L780.4,237.8L782.4,236.4L784.3,235.9L785.6,236.9L789.2,238.7L791.2,240.5L792.6,241.8L791.8,247.3L786,244.8L781.7,243.2L781.6,248.3L778.9,253.9L776.3,256.3L775.1,259.1L772.5,259.6L771.6,263.2L770.6,267.1L766.6,267.5L764.3,265L763.2,265.6L762.6,271L761.2,274.6L756.2,285.5L757.1,286.7L756.9,288.6L754.1,292.5L752.3,291.9L749.4,294.1L746.8,293.5L744.8,298.1L740.9,299.5L738.4,298.2L736.1,299.6L733.7,300.6L729.9,299.7L728.8,298.6L726.6,295.5L723.5,293.6L721.8,289.9L717.5,286.5L716.8,284.2L714.2,282.7L713.4,281.1L713.2,275.9L715.4,275.8L717.3,275L717.5,272.2L719.1,270.8L719.3,265.8L720.2,261.9L721.5,261.2L722.8,262.4L723.3,264.2L725.1,263.2L725.6,261.6L724.4,259.8L724.4,257.4L725.4,256.1L727.7,252.7L729,251.2L731.1,251.7L733.3,250.1L736.4,246.7L738.7,242.8L739,237.2L739.5,232.1L739.5,227.5L738.3,224.4L739.3,222.9L740.6,221.6L744.1,241.5L748.7,240.7L761.1,238.9z",
    PA: "M825.1,224.6L826.4,224.4L828.7,223.1L829.9,220.6L831.5,218.4L834.8,215.3L834.8,214.5L832.3,212.9L828.8,210.5L827.8,207.9L825.1,207.5L824.9,206.4L824.1,203.7L826.4,202.5L826.5,200.1L825.2,198.8L825.4,197.2L827.3,194.1L827.3,191.1L830,188.4L829.1,187.7L826.6,187.5L824.3,185.6L822.7,179.5L819.2,179.6L816.8,176.9L798.7,181.1L755.7,189.8L746.8,191.3L746.2,184.7L740.8,189.8L739.5,190.3L735.3,193.3L738.2,212.4L740.7,222.2L744.3,241.4L747.6,240.8L759.5,239.3L797.4,231.6L812.3,228.8L820.6,227.2L820.9,226.9L823,225.3L825.1,224.6z",
    NY: "M830.3,188.7L829.2,187.7L826.6,187.6L824.3,185.6L822.7,179.5L819.3,179.6L816.8,176.9L797.4,181.3L754.4,190L746.9,191.2L746.2,184.7L747.6,183.6L748.9,182.5L749.9,180.9L751.6,179.7L753.6,178L754.1,176.3L756.2,173.6L757.3,172.6L757.1,171.7L755.8,168.6L754.1,168.4L752.1,162.3L755,160.5L759.4,159.1L763.4,157.8L766.7,157.3L773,157.1L774.9,158.4L776.5,158.6L778.6,157.3L781.2,156.1L786.4,155.7L788.5,153.9L790.3,150.6L791.9,148.7L794,148.7L795.9,147.6L796.1,145.3L794.6,143.2L794.3,141.8L795.4,139.7L795.4,138.2L793.7,138.2L791.9,137.4L791.1,136.3L790.9,133.7L796.7,128.2L797.4,127.4L798.8,124.5L801.7,119.9L804.5,116.2L806.6,113.8L809,112L812.1,110.7L817.6,109.4L820.8,109.6L825.3,108.1L832.9,106.1L833.4,111L835.9,117.5L836.7,122.7L835.7,126.6L838.3,131.1L839.1,133.2L838.3,136.1L841.2,137.4L841.8,137.7L844.9,148.7L844.4,153.8L843.9,164.6L844.7,170.1L845.5,173.6L847,180.9L847,189L845.8,191.3L847.7,193.3L848.5,194.9L846.5,196.7L846.8,198L848.1,197.7L849.6,196.4L851.9,193.8L853,193.2L854.6,193.8L856.9,194L864.8,190.1L867.7,187.3L869,185.9L873.2,187.5L869.8,191.1L865.9,194L858.8,199.3L856.2,200.3L850.4,202.2L846.4,203.3L845.2,202.8L844.9,199.1L845.4,196.4L845.3,194.3L842.5,192.6L837.9,191.6L834,190.5L830.3,188.7z",
    NJ: "M829.6,188.4L827.3,191.1L827.3,194.2L825.4,197.3L825.2,198.9L826.5,200.2L826.3,202.6L824.1,203.8L824.9,206.5L825,207.6L827.8,208L828.8,210.5L832.3,213L834.7,214.6L834.7,215.4L831.8,218.1L830.1,220.4L828.7,223.1L826.4,224.4L826,226L825.7,227.2L825.1,229.8L826.2,232.1L829.4,235L834.3,237.2L838.3,237.9L838.5,239.3L837.7,240.3L838,243.1L838.8,243.1L840.9,240.6L841.7,235.8L844.5,231.7L847.5,225.3L848.7,219.8L848,218.6L847.9,209.3L846.2,205.9L845.1,206.7L842.4,207L841.9,206.5L843,205.5L845.1,203.6L845.2,202.5L844.8,199.1L845.4,196.3L845.3,194.4L842.4,192.6L837.4,191.4L833.2,190.1L829.6,188.4z",
    CT: "M874,178.8L870.3,163.9L865.6,164.9L844.4,169.6L845.4,172.8L846.8,180.1L847,189.1L845.8,191.2L847.7,193.2L852,189.3L855.6,186L857.5,183.9L858.3,184.6L861.1,183.1L866.2,182L874,178.8z",
    MA: "M855.4,152L873,147.4L875.3,146.7L877.2,143.9L881,142.3L883.9,146.7L881.4,151.9L881.1,153.3L883,155.9L884.2,155.1L886,155.1L888.2,157.7L892.1,163.7L895.7,164.1L897.9,163.2L899.7,161.4L898.9,158.6L896.8,157L895.3,157.8L894.4,156.5L894.8,156.1L896.9,155.9L898.7,156.7L900.7,159.1L901.6,162L902,164.5L897.8,165.9L893.9,167.9L890,172.4L888.1,173.8L888.1,172.9L890.5,171.4L891,169.6L890.2,166.6L887.2,168L886.4,169.5L886.9,171.7L884.9,172.7L882.1,168.2L878.7,163.8L876.6,162L870.1,163.9L865,165L844.3,169.6L843.7,164.8L844.3,154.2L848.6,153.3L855.4,152zM899.6,173.2L901.7,172.5L902.2,170.8L903.2,170.9L904.3,173.2L903,173.7L899.1,173.8L899.6,173.2zM890.2,174L892.5,171.4L894.1,171.4L895.9,172.9L893.5,173.9L891.3,174.9L890.2,174z",
    VT: "M844.4,154L844.8,148.7L841.9,137.9L841.2,137.6L838.3,136.3L839.1,133.4L838.3,131.3L835.6,126.6L836.6,122.7L835.8,117.6L833.3,111.1L832.5,106.2L859,99.4L859.3,105L861.2,107.7L861.2,111.7L857.5,116.8L854.9,117.9L854.9,119.1L856.2,120.6L855.9,128.7L855.3,137.9L855,143.5L856,144.8L855.8,149.4L855.4,151.1L856.4,151.8L848.9,153.3L844.4,154z",
    NH: "M880.7,142.4L881.6,141.3L882.7,138L880.2,137.1L879.7,134L875.8,132.9L875.5,130.1L868.2,106.7L863.6,92.2L862.7,92.2L862.1,93.8L861.4,93.3L860.4,92.3L859,94.3L858.9,99.3L859.2,105L861.2,107.7L861.2,111.7L857.5,116.8L854.9,117.9L854.9,119.1L856,120.8L856,129.4L855.2,138.6L855,143.5L856,144.8L855.9,149.3L855.4,151.1L856.3,151.8L873.1,147.4L875.3,146.8L877.1,144L880.7,142.4z",
    ME: "M922.8,78.8L924.7,80.9L927,84.6L927,86.5L924.9,91.2L923,91.9L919.6,94.9L914.7,100.4L913.4,100.4L912.4,98.3L910.7,98.5L909.7,100L907.3,101.4L906.3,102.9L907.9,104.3L907.4,105L906.9,107.7L905,107.6L905,105.9L904.7,104.6L903.2,105L901.5,101.7L899.3,103L900.6,104.5L901,105.6L900.2,106.9L900.5,110L900.6,111.6L899,114.2L896.1,114.7L895.8,117.6L890.5,120.7L889.2,121.1L887.5,119.7L884.5,123.2L885.4,126.5L884,127.8L883.8,132.1L882.7,138.4L880.2,137.2L879.8,134.2L875.9,133L875.6,130.3L868.3,106.8L863.6,92.2L865,92.1L866.5,92.5L866.5,89.9L867.8,85.4L870.4,80.7L871.9,76.7L869.9,74.3L869.9,68.3L870.7,67.3L871.5,64.6L871.4,63.1L871.2,58.2L873,53.4L875.9,44.5L878,40.3L879.3,40.3L880.6,40.5L880.6,41.6L881.9,43.9L884.6,44.5L885.4,43.7L885.4,42.7L889.5,39.8L891.3,38L892.7,38.2L898.7,40.6L900.6,41.6L909.7,71.5L915.7,71.5L916.5,73.4L916.6,78.3L919.6,80.6L920.4,80.6L920.5,80.1L920,78.9L922.8,78.8zM901.9,108.9L903.4,107.4L904.8,108.4L905.3,110.9L903.6,111.8L901.9,108.9zM908.6,103L910.3,104.9L911.6,104.6L911.9,102.6L912.8,101.8L912,100L909.9,100.8L908.6,103z",
    RI: "M874,178.8L870.3,163.9L876.6,162L878.8,164L882.1,168.3L884.8,172.7L881.8,174.3L880.5,174.2L879.4,175.9L876.9,177.9L874,178.8z",
    DE: "M825.6,228.2L825.9,226.1L826.3,224.4L824.7,224.8L823.1,225.3L820.9,227L822.6,232.1L824.9,237.7L827,247.4L828.6,253.7L833.6,253.6L839.7,252.4L837.5,245L836.5,245.5L832.9,243.1L831.2,238.4L829.2,234.8L826.1,231.9L825.2,229.8L825.6,228.2z",
    MD: "M839.7,252.4L833.7,253.6L828.6,253.7L826.7,246.8L824.8,237.6L822.2,231.4L821,227L813.5,228.6L798.6,231.5L761.1,239L762.3,244L763.2,249.7L763.6,249.4L765.7,246.9L767.9,244.3L770.3,243.7L771.8,242.2L773.6,239.7L774.9,240.3L777.8,240L780.4,237.9L782.4,236.4L784.2,235.9L785.9,237.1L788.8,238.5L790.7,240.3L791.9,241.8L796,243.5L796,246.4L801.5,247.7L802.7,248.3L804.1,246.2L807,248.2L805.7,250.7L804.9,254.7L803.2,257.3L803.2,259.4L803.8,261.2L808.9,262.5L813.2,262.4L816.3,263.4L818.4,263.7L819.3,261.6L817.9,259.5L817.9,257.8L815.4,255.7L813.3,250.2L814.6,244.8L814.5,242.7L813.2,241.4L814.6,239.2L815.1,237.1L817.1,235.8L819,234.2L819.5,235.1L818,236.7L816.7,240.5L817.1,241.6L818.8,241.9L819.3,247.4L817.2,248.4L817.5,251.9L818,251.8L819.2,249.8L820.8,251.6L819.2,252.9L818.8,256.3L821.4,259.7L825.3,260.2L826.9,259.4L830.2,263.6L831.5,264.1L838.2,261.3L840.2,257.3L839.7,252.4zM823.8,261.4L824.9,263.9L825.1,265.7L826.2,267.5L827.1,266.3L826.4,263.3L825.6,260.9L823.8,261.4z",
    FL: "M759.8,439.1L762,446.4L765.8,456.2L771.1,465.5L774.8,471.8L779.7,477.3L783.7,481L785.3,484L784.2,485.3L783.4,486.5L786.3,494L789.2,496.9L791.8,502.2L795.3,508L799.9,516.3L801.2,523.9L801.7,535.9L802.3,537.6L802,541L799.5,542.3L799.9,544.3L799.2,546.2L799.5,548.6L800,550.6L797.3,553.8L794.2,555.3L790.3,555.4L788.9,557L786.5,558L785.2,557.5L784,556.5L783.7,553.6L782.9,550.2L779.5,545.1L775.9,542.8L772.1,542.5L771.3,543.8L768.2,539.4L767.5,535.9L765,531.8L763.2,530.7L761.6,532.8L759.8,532.5L757.7,527.4L754.8,523.6L751.9,518.2L749.3,515.2L745.7,511.4L747.8,509L751.1,503.5L750.9,501.9L746.4,500.9L744.7,501.6L745.1,502.2L747.7,503.2L746.2,507.7L745.4,508.2L743.6,504.2L742.3,499.3L742,496.6L743.5,491.9L743.5,482.3L740.4,478.6L739.1,475.6L733.9,474.3L732,473.6L730.4,471L727,469.4L725.8,466L723.1,465L720.7,461.3L716.5,459.9L713.5,458.4L711,458.4L706.9,459.2L706.8,461.2L707.6,462.1L707.1,463.3L704,463.1L700.3,466.7L696.7,468.6L692.9,468.6L689.6,469.9L689.3,467.1L687.7,465.2L684.8,464.1L683.2,462.6L675.1,458.7L667.5,457L663.1,457.6L657.1,458.1L651.1,460.2L647.7,460.8L647.4,452.8L644.8,450.8L643.1,449L643.4,446L653.6,444.7L679.1,441.8L685.9,441.1L691.3,441.4L693.9,445.3L695.4,446.7L703.5,447.2L714.3,446.6L735.8,445.3L741.3,444.6L746.4,444.8L746.8,447.7L749,448.6L749.3,443.9L747.7,439.8L749,438.3L754.6,438.8L759.8,439.1zM772.3,571.5L774.7,570.9L776,570.6L777.5,568.3L779.8,566.6L781.1,567.1L782.8,567.5L783.2,568.5L779.7,569.7L775.5,571.2L773.2,572.4L772.3,571.5zM785.8,566.5L787,567.5L789.8,565.4L795.1,561.2L798.8,557.4L801.3,550.7L802.3,549L802.5,545.6L801.7,546.1L800.8,548.9L799.3,553.6L796.1,558.8L791.7,563L788.3,565L785.8,566.5z"
  };
  
  // Radius calculation - varies by mode
  const getRadius = (pool, isCurrent = false) => {
    if (!pool) return 12;
    
    // Ideal pools mode - smaller numbers
    if (idealPoolsMode) {
      if (pool >= 20000) return 20;
      if (pool >= 10000) return 17;
      if (pool >= 5000) return 14;
      if (pool >= 2000) return 12;
      return 10;
    }
    
    if (hasUserData) {
      // For match pools (user data mode)
      if (isCurrent) return 12;           // Current location: smallest
      if (pool >= 200000) return 18;      // Tier 1: 200k+ matches
      if (pool >= 100000) return 16;      // Tier 2: 100k-200k
      if (pool >= 50000) return 14;       // Tier 3: 50k-100k
      return 12;                          // Tier 4: under 50k
    } else {
      // For total singles (no user data mode)
      if (pool >= 2000000) return 20;     // Tier 1: 2M+ singles (NYC, LA)
      if (pool >= 1000000) return 17;     // Tier 2: 1M-2M 
      if (pool >= 500000) return 14;      // Tier 3: 500k-1M
      return 12;                          // Tier 4: under 500k
    }
  };
  
  return (
    <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', marginBottom: '16px', padding: '16px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '12px' }}>
        <h3 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: 0, textTransform: 'uppercase', letterSpacing: '0.05em' }}>U.S. Dating Economy</h3>
        
        {/* Map Mode Toggle - matches college grad jobs chart design */}
        <div style={{ display: 'flex', gap: '4px' }}>
          {[
            { key: null, label: hasUserData ? 'Your Matches' : 'Top 15' },
            { key: 'men', label: 'Ideal Men' },
            { key: 'women', label: 'Ideal Women' }
          ].map(({ key, label }) => (
            <button
              key={label}
              onClick={() => setIdealPoolsMode(key)}
              style={{
                height: '28px',
                padding: '0 12px',
                fontSize: '12px',
                fontWeight: '500',
                border: 'none',
                borderRadius: '4px',
                backgroundColor: idealPoolsMode === key ? '#5C5A4D' : 'white',
                color: idealPoolsMode === key ? 'white' : '#5C5A4D',
                cursor: 'pointer',
                transition: 'all 0.15s ease'
              }}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
      
      <div ref={svgRef} style={{ position: 'relative', paddingTop: '8px' }} 
           onMouseMove={(e) => {
             const rect = svgRef.current?.getBoundingClientRect();
             if (rect) setMousePos({ x: e.clientX - rect.left, y: e.clientY - rect.top });
           }}>
        <svg viewBox="0 0 960 620" style={{ width: '100%', height: 'auto' }}>
          {/* Background */}
          <rect x="0" y="0" width="960" height="620" fill="#FAF9F5" />
          
          {/* US States - real SVG paths from public domain Wikipedia map, shifted down 20px */}
          <g fill="#E5E2DA" stroke="#C5C4BC" strokeWidth="0.75" transform="translate(0, 20)">
            {Object.entries(statePaths).map(([stateId, pathData]) => (
              <path key={stateId} id={stateId} d={pathData} />
            ))}
          </g>
          
          {/* Ideal Pools Mode - show CBSAs with 500+ ideal singles */}
          {idealPoolsMode && idealPoolsData.map((metro, idx) => {
            const r = getRadius(metro.count);
            const isHovered = hoveredMetro === metro.name;
            // Men = light sky blue (#7dd3fc), Women = light rose (#fda4af) - matching chart tooltip colors
            const fillColor = idealPoolsMode === 'men' ? 'rgba(125, 211, 252, 0.6)' : 'rgba(253, 164, 175, 0.6)';
            const hoverFill = idealPoolsMode === 'men' ? 'rgba(125, 211, 252, 0.85)' : 'rgba(253, 164, 175, 0.85)';
            const strokeColor = idealPoolsMode === 'men' ? '#7dd3fc' : '#fda4af';
            return (
              <g key={metro.name} style={{ cursor: 'pointer' }}
                 onMouseEnter={() => setHoveredMetro(metro.name)}
                 onMouseLeave={() => setHoveredMetro(null)}>
                <circle
                  cx={metro.x}
                  cy={metro.y + 20}
                  r={isHovered ? r + 2 : r}
                  fill={isHovered ? hoverFill : fillColor}
                  stroke={strokeColor}
                  strokeWidth={isHovered ? 2 : 1.5}
                  style={{ transition: 'all 0.15s ease' }}
                />
                <text x={metro.x} y={metro.y + 24} textAnchor="middle" fontSize="9" fontWeight="600" fill="#3D3D3A">{formatPool(metro.count)}</text>
              </g>
            );
          })}
          
          {/* Standard Metro circles - show when NOT in ideal pools mode */}
          {!idealPoolsMode && displayMetros.map((metro) => {
            // Skip if too close to current location (only when we have user data)
            if (hasUserData) {
              const dist = Math.sqrt(Math.pow(metro.x - currentCoords.x, 2) + Math.pow(metro.y - currentCoords.y, 2));
              if (dist < 40) return null;
            }
            const displayVal = metro.displayPool || 50000;
            const r = getRadius(displayVal);
            const isHovered = hoveredMetro === metro.name;
            return (
              <g key={metro.name} style={{ cursor: 'pointer' }} 
                 onMouseEnter={() => setHoveredMetro(metro.name)} 
                 onMouseLeave={() => setHoveredMetro(null)}>
                <circle 
                  cx={metro.x} 
                  cy={metro.y + 20} 
                  r={isHovered ? r + 2 : r} 
                  fill={isHovered ? "rgba(196, 181, 240, 0.85)" : "rgba(196, 181, 240, 0.6)"} 
                  stroke={isHovered ? "#6B5B95" : "#8A74C9"} 
                  strokeWidth={isHovered ? 2 : 1.5} 
                  style={{ transition: 'all 0.15s ease' }}
                />
                <text x={metro.x} y={metro.y + 24} textAnchor="middle" fontSize="9" fontWeight="600" fill="#3D3D3A">{formatPool(displayVal)}</text>
              </g>
            );
          })}
          
          {/* Current location - dark purple on top (ONLY when user has data and NOT in ideal pools mode) */}
          {hasUserData && !idealPoolsMode && (
            <>
              <circle cx={currentCoords.x} cy={currentCoords.y + 20} r={getRadius(currentDisplayPool, true)} fill="rgba(138, 116, 201, 0.85)" stroke="#5B4A8A" strokeWidth="2" />
              <text x={currentCoords.x} y={currentCoords.y + 24} textAnchor="middle" fontSize="10" fontWeight="700" fill="white">{formatPool(currentDisplayPool)}</text>
            </>
          )}
        </svg>
        
        {/* Hover tooltip for ideal pools mode */}
        {idealPoolsMode && hoveredMetro && (() => {
          const metro = idealPoolsData.find(m => m.name === hoveredMetro);
          if (!metro) return null;
          
          const containerWidth = svgRef.current?.offsetWidth || 960;
          const containerHeight = svgRef.current?.offsetHeight || 620;
          const tooltipWidth = 280;
          const tooltipHeight = 240;
          
          let tooltipX = (metro.x / 960) * containerWidth;
          let tooltipY = ((metro.y + 20) / 620) * containerHeight;
          
          if (tooltipX + tooltipWidth > containerWidth - 10) tooltipX = tooltipX - tooltipWidth - 20;
          else tooltipX = tooltipX + 20;
          if (tooltipY + tooltipHeight > containerHeight - 10) tooltipY = containerHeight - tooltipHeight - 10;
          if (tooltipY < 10) tooltipY = 10;
          
          // Extract city, state abbrev from CBSA name
          const nameParts = metro.name.split(',');
          const city = nameParts[0].split('-')[0].trim();
          const stateMatch = nameParts[1]?.trim().split('-')[0].trim() || '';
          const header = `${city}, ${stateMatch}`;
          
          // Calculate single and all gender counts
          const c = metro.cbsa;
          const pop = c?.cbsa_population || 0;
          const flippedSingles = 100 - (c?.single_18_65_cbsa || 50);
          const genderLabel = idealPoolsMode === 'men' ? 'Men' : 'Women';
          
          // Felon/drug rates for bachelor's+
          const felonRate = idealPoolsMode === 'men' ? 0.026 : 0.006;
          const drugRate = idealPoolsMode === 'men' ? 0.128 : 0.096;
          
          // All [Gender] in metro (raw population)
          const genderPct = idealPoolsMode === 'men' ? (c?.male_cbsa || 49) : (c?.female_cbsa || 51);
          const allGender = pop * (genderPct / 100);
          
          // Single [Gender] with exclusions (available dating pool)
          // = population × gender% × 0.765 (universal) × (1-felon) × (1-drug) × single% × singleWeight
          const singleGender = pop 
            * (genderPct / 100)
            * 0.765 // universal exclusion (18-64, not homeless)
            * (1 - felonRate)
            * (1 - drugRate)
            * ((c?.relationship_single_cbsa || 39) / 100)
            * (flippedSingles / 50);
          
          // Ideal count and percentage of singles
          const idealCount = metro.count;
          const idealPctOfSingle = singleGender > 0 ? (idealCount / singleGender * 100).toFixed(2) : '0.00';
          const singlePctOfAll = allGender > 0 ? (singleGender / allGender * 100).toFixed(1) : '0.0';
          
          // Calculate relaxed ideal count
          // For men: $150k+ instead of $200k+ (add income_150k_200k_cbsa)
          // For women: remove kids filter
          let relaxedIdealCount = 0;
          if (idealPoolsMode === 'men') {
            // Same as ideal but with $150k+ income
            const available = pop * 0.765;
            const primeAgePct = (
              (c?.age_25_29_cbsa || 7) + (c?.age_30_34_cbsa || 7) + (c?.age_35_39_cbsa || 6.5) +
              (c?.age_40_44_cbsa || 6) + (c?.age_45_49_cbsa || 6) + (c?.age_50_54_cbsa || 6.5)
            ) / 100;
            const menBmi = Math.min(((c?.bmi_elite_cbsa || 7) + (c?.bmi_normal_cbsa || 22) + (c?.bmi_overweight_cbsa || 31)) / 100 * (50 / (c?.obesity_cbsa || 50)), 1);
            const noSmoking = Math.min((c?.smoking_no_cbsa || 90) / 100 * ((c?.smoking_cbsa || 50) / 50), 1);
            // $150k+ = 150k-200k + 200k-300k + 300k-500k + 500k-750k + 750k+
            const income150kPlus = ((c?.income_150k_200k_cbsa || 5) + (c?.income_200k_300k_cbsa || 4) + (c?.income_300k_500k_cbsa || 1.5) + (c?.income_500k_750k_cbsa || 0.4) + (c?.income_750k_plus_cbsa || 0.3)) / 100;
            relaxedIdealCount = Math.round(available
              * ((c?.male_cbsa || 49) / 100) * ((c?.gender_man_cbsa || 50) / 50)
              * (1 - 0.026) * (1 - 0.128)
              * ((c?.relationship_single_cbsa || 39) / 100) * (flippedSingles / 50)
              * ((c?.orientation_straight_cbsa || 93) / 100) * primeAgePct
              * (((c?.education_bachelors_cbsa || 23) + (c?.education_graduate_cbsa || 12)) / 100) * ((c?.bachelors_cbsa || 50) / 50)
              * income150kPlus * ((c?.income_cbsa || 50) / 50)
              * ((c?.height_72plus_cbsa || 31) / 100)
              * menBmi
              * noSmoking);
          } else {
            // Same as ideal but without kids filter
            const available = pop * 0.765;
            const primeAgePct = (
              (c?.age_25_29_cbsa || 7) + (c?.age_30_34_cbsa || 7) + (c?.age_35_39_cbsa || 6.5) +
              (c?.age_40_44_cbsa || 6) + (c?.age_45_49_cbsa || 6) + (c?.age_50_54_cbsa || 6.5)
            ) / 100;
            const womenBmi = Math.min((c?.bmi_elite_cbsa || 7) / 100 * (50 / (c?.obesity_cbsa || 50)), 1);
            const womenFitness = Math.min(((c?.fitness_4_6_days_cbsa || 25) + (c?.fitness_daily_cbsa || 10)) / 100 * ((c?.activity_cbsa || 50) / 50), 1);
            const noSmoking = Math.min((c?.smoking_no_cbsa || 90) / 100 * ((c?.smoking_cbsa || 50) / 50), 1);
            relaxedIdealCount = Math.round(available
              * ((c?.female_cbsa || 51) / 100) * ((c?.gender_woman_cbsa || 50) / 50)
              * (1 - 0.006) * (1 - 0.096)
              * ((c?.relationship_single_cbsa || 39) / 100) * (flippedSingles / 50)
              * ((c?.orientation_straight_cbsa || 93) / 100) * primeAgePct
              * (((c?.education_bachelors_cbsa || 23) + (c?.education_graduate_cbsa || 12)) / 100) * ((c?.bachelors_cbsa || 50) / 50)
              * womenBmi
              * womenFitness
              * noSmoking);
            // Note: no kids filter applied
          }
          const relaxedPctOfSingle = singleGender > 0 ? (relaxedIdealCount / singleGender * 100).toFixed(2) : '0.00';
          const relaxedLabel = idealPoolsMode === 'men' ? 'Ideal Men, $150k+' : 'Ideal Women, Any Kids';
          
          const idealColor = idealPoolsMode === 'men' ? '#7dd3fc' : '#fda4af';
          
          return (
            <div style={{
              position: 'absolute',
              left: tooltipX,
              top: tooltipY,
              backgroundColor: '#1f2937',
              borderRadius: '4px',
              padding: '12px',
              boxShadow: '0 4px 12px rgba(0,0,0,0.25)',
              zIndex: 20,
              pointerEvents: 'none',
              minWidth: '260px',
              maxWidth: '300px',
              fontSize: '11px',
              color: '#ffffff',
            }}>
              <div style={{ fontWeight: '600', marginBottom: '8px', paddingBottom: '6px', borderBottom: '1px solid #73726C' }}>
                {header}
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                <span style={{ color: '#d1d5db' }}>Ideal {genderLabel}</span>
                <span><span style={{ color: idealColor, fontWeight: '600' }}>{idealCount.toLocaleString()}</span><span style={{ color: '#fff' }}> or {idealPctOfSingle}%</span></span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                <span style={{ color: '#d1d5db' }}>{relaxedLabel}</span>
                <span style={{ color: '#fff', fontWeight: '500' }}>{relaxedIdealCount.toLocaleString()} or {relaxedPctOfSingle}%</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                <span style={{ color: '#d1d5db' }}>Single {genderLabel}</span>
                <span style={{ color: '#fff', fontWeight: '500' }}>{formatPool(singleGender)} or {singlePctOfAll}%</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                <span style={{ color: '#d1d5db' }}>All {genderLabel}</span>
                <span style={{ color: '#fff', fontWeight: '500' }}>{formatPool(allGender)}</span>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
                <span style={{ color: '#d1d5db' }}>Population</span>
                <span style={{ color: '#fff', fontWeight: '500' }}>{formatPool(pop)}</span>
              </div>
              <div style={{ borderTop: '1px solid #73726C', paddingTop: '8px', fontSize: '10px', color: '#9CA3AF', lineHeight: '1.4' }}>
                Studies show men and women filter their ideal matches based on predictable characteristics and demographics. While we each have varying degrees of understanding where we fit within the dating economy, we all generally agree on our preferred gender's high status and universal attractive traits. Public data allows us to put a number on that group's local availability.
              </div>
            </div>
          );
        })()}
        
        {/* Hover tooltip for standard mode - matches chart tooltip design exactly */}
        {!idealPoolsMode && hoveredMetro && (() => {
          const metro = displayMetros.find(m => m.name === hoveredMetro);
          if (!metro || !metro.metrics) return null;
          const m = metro.metrics;
          
          // Calculate tooltip position to stay inside container
          const containerWidth = svgRef.current?.offsetWidth || 960;
          const containerHeight = svgRef.current?.offsetHeight || 620;
          const tooltipWidth = 200;
          const tooltipHeight = hasUserData && m.hasUserData ? 180 : 90;
          
          // Convert SVG coords to percentage
          let tooltipX = (metro.x / 960) * containerWidth;
          let tooltipY = ((metro.y + 20) / 620) * containerHeight;
          
          // Adjust to keep tooltip inside bounds
          if (tooltipX + tooltipWidth > containerWidth - 10) tooltipX = tooltipX - tooltipWidth - 20;
          else tooltipX = tooltipX + 20;
          if (tooltipY + tooltipHeight > containerHeight - 10) tooltipY = containerHeight - tooltipHeight - 10;
          if (tooltipY < 10) tooltipY = 10;
          
          return (
            <div style={{
              position: 'absolute',
              left: tooltipX,
              top: tooltipY,
              backgroundColor: '#1f2937',
              borderRadius: '4px',
              padding: '12px',
              boxShadow: '0 4px 12px rgba(0,0,0,0.25)',
              zIndex: 20,
              pointerEvents: 'none',
              minWidth: '180px',
              maxWidth: '220px',
              fontSize: '11px',
              color: '#ffffff',
            }}>
              {/* Header */}
              <div style={{ fontWeight: '600', marginBottom: '8px', paddingBottom: '6px', borderBottom: '1px solid #73726C' }}>
                {metro.name}, {metro.state}
              </div>
              
              {hasUserData && m.hasUserData ? (
                <>
                  {/* Financial metrics */}
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                    <span style={{ color: '#d1d5db' }}>Income</span>
                    <span style={{ color: '#fff', fontWeight: '500' }}>{formatCurrency(m.income)}</span>
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                    <span style={{ color: '#d1d5db' }}>Purchase Power</span>
                    <span style={{ color: '#60a5fa', fontWeight: '500', filter: 'brightness(1.3)' }}>{formatCurrency(m.purchasePower)}</span>
                  </div>
                  
                  {/* Dating economy section */}
                  <div style={{ borderTop: '1px solid #73726C', marginTop: '6px', paddingTop: '6px', fontSize: '10px', lineHeight: '1.5' }}>
                    <div style={{ marginBottom: '6px' }}>
                      <div style={{ marginBottom: '3px' }}>
                        <span style={{ color: '#6650A1', fontWeight: '600' }}>{m.relateTier}/10</span>
                        <span style={{ color: '#d1d5db' }}> in local dating economy</span>
                      </div>
                      <div style={{ color: '#9ca3af' }}>{m.relateContext.charAt(0).toUpperCase() + m.relateContext.slice(1)}</div>
                    </div>
                    
                    <div>
                      <div style={{ marginBottom: '2px' }}>
                        <span style={{ color: '#A193D8', fontWeight: '600' }}>{formatPool(m.realisticMatches)}</span>
                        <span style={{ color: '#d1d5db' }}> realistic matches</span>
                      </div>
                      <div style={{ color: '#9ca3af' }}>
                        from {formatPool(m.localSinglePool)} single {m.targetGender}
                      </div>
                    </div>
                  </div>
                </>
              ) : (
                <>
                  {/* No user data yet - show total singles */}
                  <div style={{ marginBottom: '8px' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                      <span style={{ color: '#d1d5db' }}>Population</span>
                      <span style={{ color: '#fff', fontWeight: '500' }}>{formatPool(metro.metroCbsa?.cbsa_population)}</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between' }}>
                      <span style={{ color: '#d1d5db' }}>Total Singles</span>
                      <span style={{ color: '#A193D8', fontWeight: '600' }}>{formatPool(m.totalSingles)}</span>
                    </div>
                  </div>
                  <div style={{ fontSize: '9px', color: '#9ca3af', borderTop: '1px solid #73726C', paddingTop: '6px' }}>
                    Complete the calculator to see your personalized match pool.
                  </div>
                </>
              )}
            </div>
          );
        })()}
        
        {/* Legend - adapts to mode */}
        <div style={{ display: 'flex', gap: '24px', marginTop: '12px', justifyContent: 'center', flexWrap: 'wrap' }}>
          {hasUserData && !idealPoolsMode && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <div style={{ width: '12px', height: '12px', borderRadius: '50%', backgroundColor: '#8A74C9', border: '2px solid #5B4A8A' }}></div>
              <span style={{ fontSize: scaledFont(10), color: '#3D3D3A' }}>Your Location ({currentLocation})</span>
            </div>
          )}
          {!idealPoolsMode && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <div style={{ width: '12px', height: '12px', borderRadius: '50%', backgroundColor: '#C4B5F0', border: '1.5px solid #8A74C9' }}></div>
              <span style={{ fontSize: scaledFont(10), color: '#3D3D3A' }}>
                {relocationMetros && relocationMetros.length > 0 && hasUserData 
                  ? 'Your Relocation Targets' 
                  : 'Top 15 US Metros'}
              </span>
            </div>
          )}
          {idealPoolsMode === 'men' && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <div style={{ width: '12px', height: '12px', borderRadius: '50%', backgroundColor: 'rgba(125, 211, 252, 0.6)', border: '1.5px solid #7dd3fc' }}></div>
              <span style={{ fontSize: scaledFont(10), color: '#3D3D3A' }}>Metros with 500+ Ideal Men</span>
            </div>
          )}
          {idealPoolsMode === 'women' && (
            <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
              <div style={{ width: '12px', height: '12px', borderRadius: '50%', backgroundColor: 'rgba(253, 164, 175, 0.6)', border: '1.5px solid #fda4af' }}></div>
              <span style={{ fontSize: scaledFont(10), color: '#3D3D3A' }}>Metros with 500+ Ideal Women</span>
            </div>
          )}
          <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
            <span style={{ fontSize: scaledFont(10), color: '#73726C' }}>
              Circle size = {idealPoolsMode ? 'ideal pool size' : (hasUserData ? 'realistic matches' : 'total singles')}
            </span>
          </div>
        </div>
        
        {/* Summary text - STATE 2 & 3: User has data (not in ideal pools mode) */}
        {hasUserData && !idealPoolsMode && (() => {
          const largestMetro = displayMetros.reduce((max, m) => (m.displayPool || 0) > (max.displayPool || 0) ? m : max, displayMetros[0]);
          const isRelocation = relocationMetros && relocationMetros.length > 0;
          const multiplier = currentDisplayPool > 0 ? (largestMetro.displayPool / currentDisplayPool).toFixed(1) : '?';
          const metroCount = displayMetros.length;
          
          return (
            <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', lineHeight: '1.6', marginTop: '16px', marginBottom: 0 }}>
              {isRelocation ? (
                // STATE 3: User has relocation targets
                <>
                  Your current location of <span style={{ fontWeight: '600', color: '#141413' }}>{currentLocation}</span> offers approximately <span style={{ fontWeight: '600', color: '#141413' }}>{formatPool(currentDisplayPool)}</span> realistic matches. Among your {metroCount} relocation target{metroCount > 1 ? 's' : ''}, {largestMetro.name} offers the best opportunity with <span style={{ fontWeight: '600' }}>{formatPool(largestMetro.displayPool)}</span> potential matches, {multiplier}x your current market.
                </>
              ) : (
                // STATE 2: User data but no relocation targets
                <>
                  Your current location of <span style={{ fontWeight: '600', color: '#141413' }}>{currentLocation}</span> offers approximately <span style={{ fontWeight: '600', color: '#141413' }}>{formatPool(currentDisplayPool)}</span> realistic matches based on your demographic profile. Among the top 15 metros, {largestMetro.name} offers the largest pool with <span style={{ fontWeight: '600' }}>{formatPool(largestMetro.displayPool)}</span> potential matches, {multiplier}x your current market. Relocation decisions carry romantic implications alongside economic ones.
                </>
              )}
            </p>
          );
        })()}
        
        {/* Summary text - STATE 1: No user data, Top 15 mode */}
        {!hasUserData && !idealPoolsMode && (() => {
          const totalSinglesUS = displayMetros.reduce((sum, m) => sum + (m.displayPool || 0), 0);
          return (
            <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', lineHeight: '1.6', marginTop: '16px', marginBottom: 0 }}>
              The top 15 US metros contain approximately <span style={{ fontWeight: '600', color: '#141413' }}>{formatPool(totalSinglesUS)}</span> single adults combined. Complete the calculator to see your personalized match pool in each metro based on your demographics and preferences.
            </p>
          );
        })()}
        
        {/* Summary text - Ideal Men mode */}
        {idealPoolsMode === 'men' && (() => {
          // cbsaCount = metros with 500+ shown on map
          const cbsaCount = idealPoolsData.length;
          // nationalTotal = sum of ALL metros (not just 500+ threshold)
          let nationalTotal = 0;
          if (cbsaData) {
            for (const cbsa of Object.values(cbsaData)) {
              if (cbsa.cbsa_population && cbsa.cbsa_population >= 10000) {
                const pools = calculateIdealPools(cbsa);
                nationalTotal += pools.idealMen;
              }
            }
          }
          // Calculate percentage: 223 per 100k = 0.22%
          const perHundredK = 223;
          const pctOfSingles = (perHundredK / 1000).toFixed(2);
          
          // Find user's current metro ideal count if in State 2/3
          let userMetroIdeal = null;
          if (hasUserData && currentCoords.cbsaKey) {
            const userCbsa = cbsaData[currentCoords.cbsaKey];
            if (userCbsa) {
              const pools = calculateIdealPools(userCbsa);
              userMetroIdeal = pools.idealMen;
            }
          }
          
          return (
            <>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', lineHeight: '1.6', marginTop: '16px', marginBottom: 0 }}>
                <span style={{ fontWeight: '600', color: '#141413' }}>{cbsaCount}</span> metros contain at least 500 ideal men aka single men of prime dating age with at least a college degree, earning at least $200k annually, at least 6ft tall, and not obese. Across the United States, there are <span style={{ fontWeight: '600', color: '#141413' }}>{nationalTotal.toLocaleString()}</span> ideal men or <span style={{ fontWeight: '600', color: '#141413' }}>{pctOfSingles}%</span> of all single men. That's about <span style={{ fontWeight: '600', color: '#141413' }}>{perHundredK}</span> out of 100,000 single men. To simplify this snapshot, we have not included political views or religious beliefs, common dealbreakers when filtering for a partner. Doing so would have significantly limited totals and eliminated many metro areas displayed on the map. Calculations made available by U.S. Census Bureau, Bureau of Labor Statistics, and Centers for Disease Control and Prevention data.
              </p>
              {hasUserData && userMetroIdeal !== null && (
                <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', lineHeight: '1.6', marginTop: '12px', marginBottom: 0 }}>
                  In <span style={{ fontWeight: '600', color: '#141413' }}>{currentLocation}</span>, there are approximately <span style={{ fontWeight: '600', color: '#141413' }}>{formatPool(userMetroIdeal)}</span> ideal men before filtering for ethnicity preferences. Your personalized match calculations also filter for ethnicity matches.
                </p>
              )}
            </>
          );
        })()}
        
        {/* Summary text - Ideal Women mode */}
        {idealPoolsMode === 'women' && (() => {
          // cbsaCount = metros with 500+ shown on map
          const cbsaCount = idealPoolsData.length;
          // nationalTotal = sum of ALL metros (not just 500+ threshold)
          let nationalTotal = 0;
          if (cbsaData) {
            for (const cbsa of Object.values(cbsaData)) {
              if (cbsa.cbsa_population && cbsa.cbsa_population >= 10000) {
                const pools = calculateIdealPools(cbsa);
                nationalTotal += pools.idealWomen;
              }
            }
          }
          // Calculate percentage: 201 per 100k = 0.20%
          const perHundredK = 201;
          const pctOfSingles = (perHundredK / 1000).toFixed(2);
          
          // Find user's current metro ideal count if in State 2/3
          let userMetroIdeal = null;
          if (hasUserData && currentCoords.cbsaKey) {
            const userCbsa = cbsaData[currentCoords.cbsaKey];
            if (userCbsa) {
              const pools = calculateIdealPools(userCbsa);
              userMetroIdeal = pools.idealWomen;
            }
          }
          
          return (
            <>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', lineHeight: '1.6', marginTop: '16px', marginBottom: 0 }}>
                <span style={{ fontWeight: '600', color: '#141413' }}>{cbsaCount}</span> metros contain at least 500 ideal women aka single women of prime dating age with at least a college degree, no children, and not obese while maintaining regular weekly fitness routines. Across the United States, there are <span style={{ fontWeight: '600', color: '#141413' }}>{nationalTotal.toLocaleString()}</span> ideal women or <span style={{ fontWeight: '600', color: '#141413' }}>{pctOfSingles}%</span> of all single women. That's about <span style={{ fontWeight: '600', color: '#141413' }}>{perHundredK}</span> out of 100,000 single women. To simplify this snapshot, we have not included political views or religious beliefs, common dealbreakers when filtering for a partner. Doing so would have significantly limited totals and eliminated many metro areas displayed on the map. Calculations made available by U.S. Census Bureau, Bureau of Labor Statistics, and Centers for Disease Control and Prevention data.
              </p>
              {hasUserData && userMetroIdeal !== null && (
                <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', lineHeight: '1.6', marginTop: '12px', marginBottom: 0 }}>
                  In <span style={{ fontWeight: '600', color: '#141413' }}>{currentLocation}</span>, there are approximately <span style={{ fontWeight: '600', color: '#141413' }}>{formatPool(userMetroIdeal)}</span> ideal women before filtering for ethnicity preferences. Your personalized match calculations also filter for ethnicity matches.
                </p>
              )}
            </>
          );
        })()}
      </div>
    </div>
  );
};

export default function IncomeTrajectoryChart() {
  // GitHub data state - 917 CBSAs, 33,791 ZIPs
  const [cbsaDataLoaded, setCbsaDataLoaded] = useState(null);
  const [zipDataLoaded, setZipDataLoaded] = useState(null);
  const [dataLoading, setDataLoading] = useState(true);
  
  // Compute demo data using cbsaDataLoaded (real GitHub data) and Shared Calculation Module
  const data = React.useMemo(() => {
    if (!cbsaDataLoaded || !zipDataLoaded) return [];
    
    // Haversine distance calculation
    const haversineDistance = (lat1, lng1, lat2, lng2) => {
      const R = 6371;
      const dLat = (lat2 - lat1) * Math.PI / 180;
      const dLng = (lng2 - lng1) * Math.PI / 180;
      const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                Math.sin(dLng/2) * Math.sin(dLng/2);
      return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    };
    
    // Find nearest CBSA using ZIP centroid
    const findCBSAByZip = (zipCode) => {
      const zipCoords = zipDataLoaded[zipCode];
      if (!zipCoords) return null;
      
      let nearest = null;
      let minDist = Infinity;
      
      for (const [name, cbsa] of Object.entries(cbsaDataLoaded)) {
        const dist = haversineDistance(zipCoords.lat, zipCoords.lng, cbsa.lat, cbsa.lng);
        if (dist < minDist) {
          minDist = dist;
          nearest = { ...cbsa, name };
        }
      }
      return nearest;
    };
    
    // Default partner preferences for Demo (man seeking women)
    const demoPartnerPrefs = {
      ageMin: 25,
      ageMax: 45,
      minIncome: 0,
      ethnicity: 'no_preference',
      minEducation: 'no_preference',
      politicalViews: [],
      hasKids: 'no_preference',
      smoking: 'no',
      minHeight: null, // Not applicable for men seeking women
      bodyType: [],
      workoutFrequency: []
    };
    
    // Demo user profile attributes
    const demoUserProfile = {
      height: "5'10\"",
      bodyType: 'average',
      workoutFrequency: '2_3_days',
      politicalViews: 'moderate',
      smoking: 'no'
    };
    
    return demoBase.map(row => {
      const cbsa = findCBSAByZip(row.zipCode);
      if (!cbsa) return null;
      
      const rpp = cbsa.rpp || 100;
      const cpi = CPI_DATA[row.year];
      const cpi2025 = CPI_DATA[2025];
      
      // Income metrics
      const colFamily4 = Math.round(137822 * (rpp / 100) * (cpi / cpi2025));
      const greenLine = Math.round(colFamily4 * 1.35);
      const safe = Math.round(colFamily4 * 1.80);
      const purchasePower = Math.round(row.income * (100 / rpp));
      const equiv700k = Math.round(700000 * (cpi / cpi2025) * (100 / rpp));
      const medianHH = Math.round(MEDIAN_DATA[row.year] * (rpp / 100));
      const povertyLine = Math.round(POVERTY_DATA[row.year] * (rpp / 100));
      const pctToGoal = Math.round((row.income / row.goal) * 1000) / 10;
      const pctTo700k = Math.round((row.income / 700000) * 1000) / 10;
      
      // User profile for module
      const user = { 
        age: row.age, 
        income: row.income, 
        education: row.education, 
        gender: 'man', 
        ethnicity: 'white', 
        orientation: 'straight',
        hasKids: row.children, 
        relationshipStatus: row.relationship 
      };
      
      // Call Shared Calculation Module with real CBSA data
      const { relateScore, incomeLocal, components } = calculateRelateScore(user, cbsa, colFamily4);
      
      // Use three-tier calculation for dating metrics
      const threeTier = calculateThreeTierMatches(user, cbsa, demoPartnerPrefs, demoUserProfile);
      const percentile = Math.round(incomeLocal);
      
      return {
        year: row.year, location: row.location, age: row.age, income: row.income, goal: row.goal,
        label: row.label, context: row.context,
        relationship: row.relationship === 'married' ? 'Married' : 'Single',
        education: row.education, hasKids: row.children,
        purchasePower, equiv700k, colFamily4, greenLine, safe, medianHH, povertyLine, percentile, pctTo700k, pctToGoal,
        
        // Legacy fields (backward compatibility)
        relateScore: Math.round(relateScore * 10) / 10, 
        matchScore: threeTier.matchScore, 
        matchPool: threeTier.matchPool, 
        localSinglePool: threeTier.localSinglePool, 
        targetGenderLabel: threeTier.targetGenderLabel,
        relateComponents: components,
        
        // Three-tier fields
        realisticPool: threeTier.realisticPool,
        realisticMatches: threeTier.realisticMatches,
        realisticMatchRate: threeTier.realisticMatchRate,
        preferredPool: threeTier.preferredPool,
        preferredMatches: threeTier.preferredMatches,
        preferredMatchRate: threeTier.preferredMatchRate,
        idealPool: threeTier.idealPool,
        idealMatches: threeTier.idealMatches,
        idealMatchRate: threeTier.idealMatchRate,
        relateScoreOutOf10: threeTier.relateScoreOutOf10,
        filterPcts: threeTier.filterPcts,
        
        population: cbsa.cbsa_population,
        percentileT: transformForAxis(percentileToTop(percentile)), pctTo700kT: transformForAxis(pctTo700k), pctToGoalT: transformForAxis(pctToGoal),
        relateScoreT: transformForAxis(relateScore), matchScoreT: threeTier.matchScore !== null ? transformForAxis(threeTier.matchScore) : null
      };
    }).filter(Boolean);
  }, [cbsaDataLoaded, zipDataLoaded]);
  
  const [visibleLines, setVisibleLines] = useState({
    income: true, purchasePower: true, equiv700k: true, goal: true,
    achieve: false, safe: false, greenLine: false, medianHH: false,
    povertyLine: false, percentile: false, relateScore: false, matchScore: false,
  });

  const [openSections, setOpenSections] = useState({
    incomeTable: true,
    demographicsTable: false,
    keyFindings: false,
    rarityAnalysis: false,
    percentileThresholds: false,
    inflationImpact: false,
    contextByYear: true,
    scarcityMindset: false,
    whatYoureCreating: false,
    relationshipCalculation: false,
    relateScoreAnalysis: true,
    matchScoreAnalysis: true,
  });

  const [activeCard, setActiveCard] = useState(null);
  const [toggleMenuOpen, setToggleMenuOpen] = useState(false);
  const [useDropdownToggles, setUseDropdownToggles] = useState(false);
  const [useCollapsedCards, setUseCollapsedCards] = useState(false);
  const [cardsMenuOpen, setCardsMenuOpen] = useState(false);
  const [currentPage, setCurrentPage] = useState('home');
  const [homeMenuOpen, setHomeMenuOpen] = useState(false);
  const [currentProbeIndex, setCurrentProbeIndex] = useState(0);
  const [partnerPrefsPhase, setPartnerPrefsPhase] = useState('about_you'); // 'about_you', 'partner', 'complete'
  const [containerWidth, setContainerWidth] = useState(1100);
  const [windowWidth, setWindowWidth] = useState(typeof window !== 'undefined' ? window.innerWidth : 1200);
  const [dataSidebarExpanded, setDataSidebarExpanded] = useState(false);
  const [whyThresholdsExpanded, setWhyThresholdsExpanded] = useState(false);
  // Report page state (must be at top level per React hooks rules)
  const [reportVisibleLines, setReportVisibleLines] = useState({
    income: true, purchasePower: true, equiv700k: true, goal: true,
    achieve: false, safe: false, greenLine: false, medianHH: false,
    povertyLine: false, percentile: false, relateScore: false, matchScore: false,
  });
  const [reportToggleMenuOpen, setReportToggleMenuOpen] = useState(false);
  const [reportOpenSections, setReportOpenSections] = useState({ incomeTable: true, demographicsTable: false });
  // Narrative generation state
  const [narrativeContent, setNarrativeContent] = useState({});
  const [narrativeLoading, setNarrativeLoading] = useState({});
  const [narrativeErrors, setNarrativeErrors] = useState({});
  const [reportGenerating, setReportGenerating] = useState(false);
  const [generationProgress, setGenerationProgress] = useState({ current: 0, total: 0, cardName: '' });
  // Demo narrative state (separate from user's Report narratives)
  const [demoNarrativeContent, setDemoNarrativeContent] = useState({});
  const [demoGenerating, setDemoGenerating] = useState(false);
  const [demoGenerationProgress, setDemoGenerationProgress] = useState({ current: 0, total: 0, cardName: '' });
  const [narrativeSections, setNarrativeSections] = useState({
    // Universal cards
    keyFindings: true, percentileThresholds: true, rarityAnalysis: true,
    inflationImpact: false, relationshipCalc: false, relateScore: false, matchScore: false,
    // Mindset cards (one will be selected)
    scarcityMindsetGap: true, abundanceMindset: true, stabilityMindset: true,
    lossMindset: true, originExpectationGap: true, marketRealityCheck: true,
    // Future cards (one will be selected)
    whatYoureCreating: true, whatYoureBuilding: true
  });
  // Visualize page state
  const [vizSettings, setVizSettings] = useState({
    birthMonth: '',
    birthYear: '',
    workStartMonth: '',
    workStartYear: '',
    retireAge: '65'
  });
  const [vizSettingsExpanded, setVizSettingsExpanded] = useState(false);
  // Dating Matches card toggle state
  const [datingMatchLocation, setDatingMatchLocation] = useState('Current'); // 'Current', 'Relocate', 'National'
  const [datingMatchTier, setDatingMatchTier] = useState('Realistic'); // 'Realistic', 'Preferred', 'Ideal'
  // Relocation metros autocomplete search state
  const [relocationSearchTerm, setRelocationSearchTerm] = useState('');
  // Jobs chart state
  const [jobsGenderFilter, setJobsGenderFilter] = useState('all');
  const [jobsData, setJobsData] = useState(null);
  const [jobsLoading, setJobsLoading] = useState(true);
  const [jobsError, setJobsError] = useState(null);
  const measureRef = useRef(null);
  const dropdownThresholdRef = useRef(0);
  
  // Career Timeline constants (used in Calculator and Visualize)
  const months = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const birthYears = [];
  for (let y = 2010; y >= 1940; y--) birthYears.push(y);

  // Calculator form state
  const [formData, setFormData] = useState({
    // Demographics
    firstName: '',
    gender: '',
    ethnicity: '',
    orientation: '',
    // Career Context
    firstJobTitle: '',
    firstJobYear: '',
    currentJobTitle: '',
    firstSector: '',
    currentSector: '',
    sectorTransitionYear: '',
    sectorTransitionReason: '',
    // Income History (start with 3 rows, can add up to 15)
    incomeYears: [
      { year: '', location: '', zipCode: '', income: '', goal: '', age: '', married: '', children: '', education: '' },
      { year: '', location: '', zipCode: '', income: '', goal: '', age: '', married: '', children: '', education: '' },
      { year: '', location: '', zipCode: '', income: '', goal: '', age: '', married: '', children: '', education: '' },
    ],
    // About You (lifestyle - shown only if single)
    userProfile: {
      height: '',              // "5'10" format (men only)
      bodyType: '',            // 'lean_fit', 'average', 'overweight', 'obese'
      workoutFrequency: '',    // 'never', '1_day', '2_3_days', '4_6_days', 'daily'
      politicalViews: '',      // 'apolitical', 'liberal', 'moderate', 'conservative'
      smoking: ''              // 'yes', 'no'
    },
    // Preferred Partner (shown only if single)
    partnerPrefs: {
      ageMin: '',              // 18-65
      ageMax: '',              // 18-65
      minIncome: 0,             // slider value (starts at $0 to include unemployed)
      minHeight: '',           // 'no_preference' or "5'6" format (women only)
      bodyType: [],            // multi-select array
      workoutFrequency: [],    // multi-select array
      politicalViews: [],      // multi-select array
      hasKids: '',             // 'no_preference', 'no', 'yes'
      smoking: ''              // 'no_preference', 'no', 'yes'
    },
    // Relocation Metros (up to 6) - array of { cbsaCode, cbsaLabel }
    relocationMetros: [],
    // Probe Responses
    probeResponses: {}
  });

  // Detect which probes should be triggered based on form data
  const getTriggeredProbes = () => {
    const probes = [];
    const years = formData.incomeYears.filter(y => y.year && y.income);
    if (years.length < 2) return probes;

    const gender = formData.gender;
    const firstYear = years[0];
    const lastYear = years[years.length - 1];

    // Age 18 Parent Income Confirmation: First entry is at age 18
    if (firstYear && parseInt(firstYear.age) === 18) {
      probes.push({
        id: 'parentIncome',
        title: 'Origin / Family Background',
        why: 'Understanding whether this was your parents\' income or your own helps establish your true starting point and origin class.',
        question: `Your first entry is from ${firstYear.year} when you were 18, showing $${parseInt(firstYear.income).toLocaleString()} in ${firstYear.location}. Was this your parents' household income, or were you already earning your own money? If it was your family's income, tell me about what that meant for how you grew up. Was there stability? Anxiety about money? Did you feel middle class, comfortable, or like you were just getting by?`
      });
    }

    // Early Life / Family Origin: First income below ~$50k (only if not already asking about age 18)
    if (firstYear && parseInt(firstYear.income) < 50000 && parseInt(firstYear.age) !== 18) {
      probes.push({
        id: 'earlyLife',
        title: 'Early Life / Family Origin',
        why: 'Your starting income suggests you may have come from modest circumstances. Understanding your family background helps contextualize your entire trajectory.',
        question: `Your starting point was $${parseInt(firstYear.income).toLocaleString()} in ${firstYear.year}. Tell me about your family's financial situation growing up. Was money tight, comfortable, or somewhere in between?`
      });
    }

    // Woman 23+ Single Household Goal: Single woman at 23+ entering household income expectations
    for (let i = 0; i < years.length; i++) {
      const year = years[i];
      const age = parseInt(year.age);
      // Only trigger if explicitly marked as single (married = 'no'), not if field is empty
      const isExplicitlySingle = year.married === 'no';
      const hasGoal = year.goal && parseInt(year.goal) > 0;
      const income = parseInt(year.income);
      const goal = parseInt(year.goal);
      const goalExceedsIncome = hasGoal && goal > income;
      
      if (gender === 'woman' && age >= 23 && isExplicitlySingle && goalExceedsIncome) {
        const impliedPartner = goal - income;
        
        probes.push({
          id: `householdGoal_${year.year}`,
          title: 'Household Income Expectations',
          why: 'After 23, your goal represents expected household income, not just your own. This reveals expectations about partnership, lifestyle, and how you see your future.',
          question: `In ${year.year}, you were earning $${income.toLocaleString()} and your household goal was $${goal.toLocaleString()}. That gap of $${impliedPartner.toLocaleString()} represents what you expected from a future partner, the economy, or your own growth. I want to understand what was behind that number. Were you expecting to meet someone who earned well? Were you planning to grow your income significantly? What lifestyle or status did that goal represent? How did you think about the intersection of your career ambitions, your social life, and what you wanted as a woman, maybe as a future mother? Be honest about the pressures you felt, whether from yourself, family, or society.`
        });
        break; // Only ask once
      }
    }

    // Divorce / Relationship Transition: Marriage status changes from yes to no
    for (let i = 1; i < years.length; i++) {
      if (years[i-1].married === 'yes' && years[i].married === 'no') {
        const hasKids = years[i].children === 'yes' || years[i-1].children === 'yes';
        const nextLocation = years[i].location;
        const prevLocation = years[i-1].location;
        const locationChanged = nextLocation && prevLocation && nextLocation.toLowerCase() !== prevLocation.toLowerCase();
        const prevIncome = parseInt(years[i-1].income);
        const currIncome = parseInt(years[i].income);
        const incomeChanged = Math.abs(currIncome - prevIncome) / prevIncome > 0.15;
        
        let question = `I see your marriage ended around ${years[i].year}. `;
        
        // First, ask about money as a factor in the divorce
        question += `Before we get into the aftermath, I want to ask directly: did money play a role in why the marriage ended? Financial stress is the leading predictor of divorce, and money fights are rarely just about money. They are about values, priorities, and what each person expected from the partnership. `;
        
        if (gender === 'man') {
          question += `Walk me through that period. What was the financial impact? Think about maintaining two households, legal costs, support payments, and starting over.`;
          if (hasKids) {
            question += ` How did the split affect your time with your kids? Did custody arrangements shape any career or location decisions? What is the ongoing cost, both financially and in how you think about money now?`;
          }
          question += ` Looking back, how did this chapter change your relationship with work, money, and what you want from a future partner?`;
        } else {
          question += `Tell me about that transition. How did it change your relationship with work and financial independence? Did you have to rebuild financially?`;
          if (hasKids) {
            question += ` How did you balance being a single parent with your career? What sacrifices or trade-offs did you make? What does the ongoing economics of single parenthood look like?`;
          }
          question += ` Did this experience reshape what you want from a partner? Are your expectations different now about money and partnership?`;
        }
        
        if (locationChanged) {
          question += ` I also notice you moved to ${nextLocation} around this time. Was that connected to the divorce?`;
        }
        
        if (incomeChanged) {
          question += ` Your income ${currIncome > prevIncome ? 'increased' : 'decreased'} around this time. Was that related to the split, or a separate factor?`;
        }
        
        probes.push({ 
          id: `divorce_${years[i].year}`, 
          title: 'Relationship Transition', 
          why: 'Divorce is one of the most significant financial events in a person\'s life. Money is both a leading cause and a lasting consequence. Understanding both sides helps contextualize your trajectory.',
          question 
        });
        break; // Only ask about one divorce
      }
    }

    // Post-Divorce Single Years: If divorced and remained single 3+ years
    let divorceYear = null;
    for (let i = 1; i < years.length; i++) {
      if (years[i-1].married === 'yes' && years[i].married === 'no') {
        divorceYear = i;
        break;
      }
    }
    if (divorceYear !== null) {
      const postDivorceYears = years.slice(divorceYear);
      const stillSingle = postDivorceYears.every(y => y.married === 'no');
      const hasKids = postDivorceYears.some(y => y.children === 'yes');
      
      if (stillSingle && postDivorceYears.length >= 3) {
        const yearsCount = postDivorceYears.length;
        const divorceYearNum = years[divorceYear].year;
        
        let question = `It has been ${yearsCount} years since your divorce in ${divorceYearNum}, and you have remained single. `;
        
        if (hasKids) {
          question += `As a single parent, how has money shaped these years? Has the financial pressure of solo parenting affected your dating life or your standards for a partner? `;
          if (gender === 'woman') {
            question += `Many single mothers describe a tension between needing a partner who can contribute financially versus not wanting to depend on anyone again. Where do you fall on that spectrum?`;
          } else {
            question += `Many single fathers describe feeling like they need to prove they can provide even more to be seen as a viable partner. Has that been your experience?`;
          }
        } else {
          question += `How has your financial position shaped your approach to dating? Has the freedom or the pressure of being financially solo changed what you are looking for in a partner?`;
        }
        
        probes.push({
          id: `postDivorceSingle_${divorceYearNum}`,
          title: 'Post-Divorce Single Life',
          why: 'Extended single periods after divorce often involve both financial rebuilding and recalibrating expectations for partnership. Understanding this shapes the relationship analysis.',
          question
        });
      }
    }

    // Career Gap or Income Drop: Income decreases or stays flat for 2+ years
    for (let i = 1; i < years.length; i++) {
      const prevIncome = parseInt(years[i-1].income);
      const currIncome = parseInt(years[i].income);
      if (currIncome <= prevIncome * 1.02) { // flat or down
        const hadKidsDuring = years[i].children === 'yes' && years[i-1].children !== 'yes';
        let question;
        if (hadKidsDuring && gender === 'woman') {
          question = `Your income dipped around ${years[i].year} when your children were young. Did you step away from work? What was re-entry like?`;
        } else if (hadKidsDuring && gender === 'man') {
          question = `Your income leveled off around ${years[i].year} when your kids arrived. How did fatherhood change your career priorities or the pressure you felt?`;
        } else {
          question = `There's a pause in your trajectory around ${years[i].year}. What was happening then?`;
        }
        probes.push({ 
          id: `gap_${years[i].year}`, 
          title: 'Career Gap / Income Change', 
          why: 'Income pauses or drops often mark pivotal life moments, whether layoffs, health issues, caregiving, or intentional pivots. These stories add crucial context.',
          question 
        });
        break; // Only ask about one gap
      }
    }

    // Geographic Move: Location changes between consecutive data points (ask about each move)
    for (let i = 1; i < years.length; i++) {
      if (years[i-1].location && years[i].location && years[i-1].location.toLowerCase() !== years[i].location.toLowerCase()) {
        const wasMarried = years[i].married === 'yes';
        const wasSingle = years[i].married === 'no';
        const hadKids = years[i].children === 'yes';
        const justGotKids = years[i].children === 'yes' && years[i-1].children !== 'yes';
        const justGotMarried = years[i].married === 'yes' && years[i-1].married !== 'yes';
        
        let question = `You moved from ${years[i-1].location} to ${years[i].location} in ${years[i].year}. Tell me about that experience.`;
        
        // Add context-specific prompts
        if (justGotMarried) {
          question += ` I see this coincided with getting married. Was the move part of starting your life together?`;
        } else if (justGotKids) {
          question += ` This was also when your kids entered the picture. How did that shape where you wanted to be?`;
        } else if (wasSingle && gender === 'man') {
          question += ` You were single at the time. What was the dating scene like? Did the move affect your social life or relationships?`;
        } else if (wasSingle && gender === 'woman') {
          question += ` You were single during this chapter. How did the city treat you? Did the move change your personal life or relationships?`;
        } else if (wasMarried && hadKids) {
          question += ` You had a family at this point. What was that city like for raising kids? Was it the right place for your family?`;
        } else if (wasMarried) {
          question += ` You were married during this move. Was it a joint decision? How did your partner feel about the change?`;
        }
        
        question += ` What did you love or hate about living there?`;
        
        probes.push({
          id: `move_${years[i].year}_${i}`,
          title: `Geographic Move (${years[i].year})`,
          why: 'Every relocation reshapes your economic reality: cost of living, job market, social network, and proximity to family. Each move is its own story.',
          question
        });
        // No break, ask about each move
      }
    }

    // Income Acceleration: Income increases by 40%+ in a single year
    for (let i = 1; i < years.length; i++) {
      const prevIncome = parseInt(years[i-1].income);
      const currIncome = parseInt(years[i].income);
      if (currIncome >= prevIncome * 1.4) {
        probes.push({
          id: `acceleration_${years[i].year}`,
          title: 'Income Acceleration',
          why: 'A 40%+ income jump in a single year is rare and significant. Understanding what drove it helps identify the key levers in your career.',
          question: `Something shifted around ${years[i].year} and your income jumped significantly. What happened? Was it a promotion, new job, or a bet that paid off?`
        });
        break; // Only ask about one acceleration
      }
    }

    // Goal Inflation: Goal number increases across data points
    const goals = years.filter(y => y.goal).map(y => ({ year: y.year, goal: parseInt(y.goal) }));
    if (goals.length >= 2 && goals[goals.length-1].goal > goals[0].goal * 1.5) {
      probes.push({
        id: 'goalInflation',
        title: 'Goal Inflation',
        why: 'Your definition of "enough" evolved significantly over time. This pattern reveals how success changes our relationship with money.',
        question: `Your target went from $${goals[0].goal.toLocaleString()} to $${goals[goals.length-1].goal.toLocaleString()} over the years. Tell me about that shift. When you first started out, what did that original number represent to you? At what point did you realize you wanted more? Is there a number now that would feel like enough, or does the goalpost keep moving?`
      });
    }

    // Scarcity Mindset: Income exceeds goal by 150%+ AND started below median
    if (lastYear && lastYear.goal && parseInt(lastYear.income) >= parseInt(lastYear.goal) * 1.5 && parseInt(firstYear.income) < 50000) {
      probes.push({
        id: 'scarcityMindset',
        title: 'Scarcity Mindset',
        why: 'You have exceeded your goals by a wide margin but started from modest beginnings. This combination often creates a persistent gap between financial reality and emotional security.',
        question: `You have surpassed your original goal by a wide margin. But here is what I am curious about: does it feel like enough? Do you still worry about money even though the numbers say you have made it? People who grew up with less often carry that scarcity mindset long after the bank account says otherwise. When you look at a price tag or think about a purchase, do you still feel that old anxiety? Tell me what money feels like now versus what you thought it would feel like.`
      });
    }

    // Children and Provider Pressure: Children status changes to yes
    for (let i = 1; i < years.length; i++) {
      if (years[i-1].children !== 'yes' && years[i].children === 'yes') {
        const wasMarried = years[i].married === 'yes';
        const location = years[i].location;
        
        let question;
        if (gender === 'man') {
          question = `Kids arrived in ${years[i].year}. Tell me how that changed things. Did the weight of being a provider feel different once you had children depending on you?`;
          if (wasMarried) {
            question += ` How did you and your partner divide responsibilities? Did becoming a father change what you wanted from your career?`;
          }
        } else {
          question = `You became a mom in ${years[i].year}. Walk me through how that reshaped your career. Did you take time off? What was the transition like?`;
          if (wasMarried) {
            question += ` How did you and your partner navigate the new division of labor? Did having kids change what success meant to you professionally?`;
          }
        }
        
        question += ` What was ${location || 'your city'} like for raising young kids?`;
        
        probes.push({ 
          id: `kids_${years[i].year}`, 
          title: 'Children & Provider Pressure', 
          why: 'Becoming a parent fundamentally changes the stakes of work. The financial and emotional recalibration that follows shapes careers in profound ways.',
          question 
        });
        break; // Only ask once about children arriving
      }
    }

    // Sector Change: First sector differs from current sector
    if (formData.firstSector && formData.currentSector && formData.firstSector !== formData.currentSector) {
      const sectorLabels = {
        technology: 'Technology', finance: 'Finance', healthcare: 'Healthcare', government: 'Government',
        education: 'Education', manufacturing: 'Manufacturing', retail: 'Retail', energy: 'Energy',
        consulting: 'Consulting', legal: 'Legal', media: 'Media/Entertainment', nonprofit: 'Nonprofit', other: 'Other'
      };
      probes.push({
        id: 'sectorChange',
        title: 'Sector Change',
        why: 'Changing industries is a major career pivot that often involves risk, retraining, or reinvention. Understanding why helps explain your trajectory.',
        question: `You started in ${sectorLabels[formData.firstSector] || formData.firstSector} and ended up in ${sectorLabels[formData.currentSector] || formData.currentSector}. Walk me through that transition. Was it gradual, or was there a moment you decided to jump?`
      });
    }

    // Partner Preferences are now structured inputs (not a probe)
    // See userProfile and partnerPrefs in formData

    // Relocation Openness: Ask everyone about mobility
    const currentLocation = lastYear?.location || 'your current city';
    let relocQuestion = `Are you open to relocating in the near future, or are you rooted in ${currentLocation}? `;
    relocQuestion += `If you've thought about moving, what's driving that: career opportunities, cost of living, family, dating pool, lifestyle? `;
    relocQuestion += `If you're not open to moving, what's keeping you where you are? `;
    relocQuestion += `(Use the metro selector below to pick specific metros you're considering.)`;
    
    probes.push({
      id: 'relocationOpenness',
      title: 'Relocation Openness',
      why: 'Geographic flexibility dramatically affects both career trajectory and dating pool. Someone open to moving to a lower cost of living area or a city with better demographics has very different options than someone rooted in place.',
      question: relocQuestion
    });

    return probes;
  };

  const updateProbeResponse = (probeId, value) => {
    setFormData(prev => ({
      ...prev,
      probeResponses: { ...prev.probeResponses, [probeId]: value }
    }));
  };

  // Helper: Update userProfile field
  const updateUserProfile = (field, value) => {
    setFormData(prev => ({
      ...prev,
      userProfile: { ...prev.userProfile, [field]: value }
    }));
  };

  // Helper: Update partnerPrefs field
  const updatePartnerPrefs = (field, value) => {
    setFormData(prev => ({
      ...prev,
      partnerPrefs: { ...prev.partnerPrefs, [field]: value }
    }));
  };

  // Helper: Toggle multi-select with "No preference" logic
  const toggleMultiSelect = (field, value) => {
    setFormData(prev => {
      const currentValues = prev.partnerPrefs[field] || [];
      
      if (value === 'no_preference') {
        // Clicking "No preference" clears all other selections
        return {
          ...prev,
          partnerPrefs: { ...prev.partnerPrefs, [field]: ['no_preference'] }
        };
      } else {
        // Clicking any other option removes "No preference" if selected
        let newValues = currentValues.filter(v => v !== 'no_preference');
        
        if (newValues.includes(value)) {
          // Remove if already selected
          newValues = newValues.filter(v => v !== value);
        } else {
          // Add if not selected
          newValues = [...newValues, value];
        }
        
        return {
          ...prev,
          partnerPrefs: { ...prev.partnerPrefs, [field]: newValues }
        };
      }
    });
  };

  // Generate height options from 4'11" to 7'5"
  const heightOptions = [];
  for (let feet = 4; feet <= 7; feet++) {
    const startInch = feet === 4 ? 11 : 0;
    const endInch = feet === 7 ? 5 : 11;
    for (let inch = startInch; inch <= endInch; inch++) {
      heightOptions.push(`${feet}'${inch}"`);
    }
  }

  // Generate income slider values from $0 to $1M+ in $10k increments
  const incomeSliderValues = [0];
  for (let i = 10000; i <= 1000000; i += 10000) {
    incomeSliderValues.push(i);
  }
  incomeSliderValues.push(1000001); // $1M+

  // Format income for display
  const formatIncomeSlider = (value) => {
    if (value === 0) return '$0';
    if (value > 1000000) return '$1M+';
    if (value >= 1000000) return '$1M';
    return `$${(value / 1000).toFixed(0)}k`;
  };

  // Check if user is currently single (for showing partner preferences)
  const isUserCurrentlySingle = () => {
    const years = formData.incomeYears.filter(y => y.year && y.income);
    if (years.length === 0) return false;
    const lastYear = years[years.length - 1];
    return lastYear.married === 'no' || lastYear.married === 'single' || lastYear.married === 'Single';
  };

  // Check if About You section is complete
  const isAboutYouComplete = () => {
    const { bodyType, workoutFrequency, politicalViews, smoking } = formData.userProfile;
    const isMale = formData.gender === 'man' || formData.gender === 'male' || formData.gender === 'Man';
    
    // Men need height, everyone else needs the other fields
    if (isMale) {
      return formData.userProfile.height && bodyType && workoutFrequency && politicalViews && smoking;
    }
    return bodyType && workoutFrequency && politicalViews && smoking;
  };

  // Check if Partner Preferences section is complete
  const isPartnerPrefsComplete = () => {
    const { ageMin, ageMax, hasKids, smoking } = formData.partnerPrefs;
    return ageMin && ageMax && hasKids && smoking;
  };

  // Check if basic form is complete enough to show probes
  const isBasicFormComplete = () => {
    const hasDemo = formData.firstName && formData.gender;
    const hasJobs = formData.firstJobTitle && formData.firstJobYear && formData.currentJobTitle && formData.firstSector && formData.currentSector;
    const filledYears = formData.incomeYears.filter(y => y.year && y.location && y.zipCode && y.income && y.goal && y.age && y.married && y.children && y.education);
    return hasDemo && hasJobs && filledYears.length >= 5;
  };

  const triggeredProbes = getTriggeredProbes();

  const updateFormField = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const updateIncomeYear = (index, field, value) => {
    setFormData(prev => {
      const newYears = [...prev.incomeYears];
      newYears[index] = { ...newYears[index], [field]: value };
      
      // Auto-sort chronologically when a year field changes and has 4 digits
      if (field === 'year' && value.length === 4) {
        newYears.sort((a, b) => {
          // Empty years go to the end
          const yearA = a.year ? parseInt(a.year) : Infinity;
          const yearB = b.year ? parseInt(b.year) : Infinity;
          return yearA - yearB;
        });
      }
      
      return { ...prev, incomeYears: newYears };
    });
  };

  const addIncomeYear = () => {
    if (formData.incomeYears.length < 15) {
      setFormData(prev => ({
        ...prev,
        incomeYears: [...prev.incomeYears, { year: '', location: '', zipCode: '', income: '', goal: '', age: '', married: '', children: '', education: '' }]
      }));
    }
  };

  const removeIncomeYear = (index) => {
    if (formData.incomeYears.length > 5) {
      setFormData(prev => ({
        ...prev,
        incomeYears: prev.incomeYears.filter((_, i) => i !== index)
      }));
    }
  };

  // Font scale based on container width (1100 = 1.0, scales up/down from there)
  const fontScale = containerWidth / 1100;
  const scaledFont = (base) => `${Math.round(base * fontScale)}px`;

  // =============================================================================
  // PERSISTENT STORAGE - Save/restore user progress across sessions
  // =============================================================================
  const [storageLoaded, setStorageLoaded] = useState(false);
  const [hasUnsavedData, setHasUnsavedData] = useState(false);
  
  // Load saved data on mount
  useEffect(() => {
    const loadSavedData = async () => {
      if (typeof window === 'undefined' || !window.storage) {
        console.log('[Storage] No storage API available');
        setStorageLoaded(true);
        return;
      }
      
      try {
        // Load form data
        const savedFormData = await window.storage.get('salaryarc:formData');
        if (savedFormData && savedFormData.value) {
          const parsed = JSON.parse(savedFormData.value);
          console.log('[Storage] Restored formData');
          setFormData(parsed);
        }
        
        // Load current page
        const savedPage = await window.storage.get('salaryarc:currentPage');
        if (savedPage && savedPage.value && savedPage.value !== 'home') {
          console.log('[Storage] Restored page:', savedPage.value);
          setCurrentPage(savedPage.value);
        }
        
        // Load viz settings
        const savedVizSettings = await window.storage.get('salaryarc:vizSettings');
        if (savedVizSettings && savedVizSettings.value) {
          console.log('[Storage] Restored vizSettings');
          setVizSettings(JSON.parse(savedVizSettings.value));
        }
        
        // Load partner prefs phase
        const savedPrefsPhase = await window.storage.get('salaryarc:partnerPrefsPhase');
        if (savedPrefsPhase && savedPrefsPhase.value) {
          console.log('[Storage] Restored partnerPrefsPhase:', savedPrefsPhase.value);
          setPartnerPrefsPhase(savedPrefsPhase.value);
        }
        
        // Load narrative content (user report)
        const savedNarratives = await window.storage.get('salaryarc:narrativeContent');
        if (savedNarratives && savedNarratives.value) {
          console.log('[Storage] Restored narrativeContent');
          setNarrativeContent(JSON.parse(savedNarratives.value));
        }
        
        // Load demo narrative content
        const savedDemoNarratives = await window.storage.get('salaryarc:demoNarrativeContent');
        if (savedDemoNarratives && savedDemoNarratives.value) {
          console.log('[Storage] Restored demoNarrativeContent');
          setDemoNarrativeContent(JSON.parse(savedDemoNarratives.value));
        }
        
        setHasUnsavedData(true);
      } catch (err) {
        console.error('[Storage] Error loading saved data:', err);
      }
      
      setStorageLoaded(true);
    };
    
    loadSavedData();
  }, []);
  
  // Save form data when it changes (debounced)
  useEffect(() => {
    if (!storageLoaded || typeof window === 'undefined' || !window.storage) return;
    
    const saveTimeout = setTimeout(async () => {
      try {
        await window.storage.set('salaryarc:formData', JSON.stringify(formData));
        console.log('[Storage] Saved formData');
        setHasUnsavedData(true);
      } catch (err) {
        console.error('[Storage] Error saving formData:', err);
      }
    }, 1000); // 1 second debounce
    
    return () => clearTimeout(saveTimeout);
  }, [formData, storageLoaded]);
  
  // Save current page when it changes
  useEffect(() => {
    if (!storageLoaded || typeof window === 'undefined' || !window.storage) return;
    
    const savePage = async () => {
      try {
        await window.storage.set('salaryarc:currentPage', currentPage);
        console.log('[Storage] Saved currentPage:', currentPage);
      } catch (err) {
        console.error('[Storage] Error saving currentPage:', err);
      }
    };
    
    savePage();
  }, [currentPage, storageLoaded]);
  
  // Save viz settings when they change
  useEffect(() => {
    if (!storageLoaded || typeof window === 'undefined' || !window.storage) return;
    
    const saveViz = async () => {
      try {
        await window.storage.set('salaryarc:vizSettings', JSON.stringify(vizSettings));
        console.log('[Storage] Saved vizSettings');
      } catch (err) {
        console.error('[Storage] Error saving vizSettings:', err);
      }
    };
    
    saveViz();
  }, [vizSettings, storageLoaded]);
  
  // Save partner prefs phase
  useEffect(() => {
    if (!storageLoaded || typeof window === 'undefined' || !window.storage) return;
    
    const savePhase = async () => {
      try {
        await window.storage.set('salaryarc:partnerPrefsPhase', partnerPrefsPhase);
        console.log('[Storage] Saved partnerPrefsPhase:', partnerPrefsPhase);
      } catch (err) {
        console.error('[Storage] Error saving partnerPrefsPhase:', err);
      }
    };
    
    savePhase();
  }, [partnerPrefsPhase, storageLoaded]);
  
  // Save narrative content when it changes
  useEffect(() => {
    if (!storageLoaded || typeof window === 'undefined' || !window.storage) return;
    if (Object.keys(narrativeContent).length === 0) return;
    
    const saveNarratives = async () => {
      try {
        await window.storage.set('salaryarc:narrativeContent', JSON.stringify(narrativeContent));
        console.log('[Storage] Saved narrativeContent');
      } catch (err) {
        console.error('[Storage] Error saving narrativeContent:', err);
      }
    };
    
    saveNarratives();
  }, [narrativeContent, storageLoaded]);
  
  // Save demo narrative content when it changes
  useEffect(() => {
    if (!storageLoaded || typeof window === 'undefined' || !window.storage) return;
    if (Object.keys(demoNarrativeContent).length === 0) return;
    
    const saveDemoNarratives = async () => {
      try {
        await window.storage.set('salaryarc:demoNarrativeContent', JSON.stringify(demoNarrativeContent));
        console.log('[Storage] Saved demoNarrativeContent');
      } catch (err) {
        console.error('[Storage] Error saving demoNarrativeContent:', err);
      }
    };
    
    saveDemoNarratives();
  }, [demoNarrativeContent, storageLoaded]);
  
  // Clear all saved data function
  const clearSavedProgress = async () => {
    if (typeof window === 'undefined' || !window.storage) return;
    
    try {
      await window.storage.delete('salaryarc:formData');
      await window.storage.delete('salaryarc:currentPage');
      await window.storage.delete('salaryarc:vizSettings');
      await window.storage.delete('salaryarc:partnerPrefsPhase');
      await window.storage.delete('salaryarc:narrativeContent');
      await window.storage.delete('salaryarc:demoNarrativeContent');
      console.log('[Storage] Cleared all saved data');
      setHasUnsavedData(false);
      // Reset to initial state
      setFormData({
        firstName: '',
        gender: '',
        ethnicity: '',
        orientation: '',
        firstJobTitle: '',
        firstJobYear: '',
        currentJobTitle: '',
        firstSector: '',
        currentSector: '',
        sectorTransitionYear: '',
        sectorTransitionReason: '',
        incomeYears: [
          { year: '', location: '', zipCode: '', income: '', goal: '', age: '', married: '', children: '', education: '' },
          { year: '', location: '', zipCode: '', income: '', goal: '', age: '', married: '', children: '', education: '' },
          { year: '', location: '', zipCode: '', income: '', goal: '', age: '', married: '', children: '', education: '' },
        ],
        userProfile: { height: '', bodyType: '', workoutFrequency: '', politicalViews: '', smoking: '' },
        partnerPrefs: { ageMin: '', ageMax: '', minIncome: 0, minHeight: '', bodyType: [], workoutFrequency: [], politicalViews: [], hasKids: '', smoking: '' },
        relocationMetros: [],
        probeResponses: {}
      });
      setCurrentPage('home');
      setVizSettings({ birthMonth: '', birthYear: '', workStartMonth: '', workStartYear: '', retireAge: '65' });
      setPartnerPrefsPhase('about_you');
      setNarrativeContent({});
      setDemoNarrativeContent({});
    } catch (err) {
      console.error('[Storage] Error clearing data:', err);
    }
  };
  // =============================================================================
  // END PERSISTENT STORAGE
  // =============================================================================

  useEffect(() => {
    const checkResponsive = () => {
      setUseCollapsedCards(window.innerWidth < 650);
      setWindowWidth(window.innerWidth);
    };
    checkResponsive();
    window.addEventListener('resize', checkResponsive);
    return () => window.removeEventListener('resize', checkResponsive);
  }, []);

  // Fetch CBSA and ZIP data from GitHub repo on mount
  useEffect(() => {
    const fetchGeoData = async () => {
      try {
        // Fetch CBSA data (917 metros with full demographics)
        const cbsaResponse = await fetch('https://raw.githubusercontent.com/fromnineteen80/salaryarc/main/cbsa-data.js');
        const cbsaText = await cbsaResponse.text();
        // Find the object: starts after 'const CBSA_DATA = {' and ends with '};\n'
        const startMarker = 'const CBSA_DATA = ';
        const startIdx = cbsaText.indexOf(startMarker);
        if (startIdx !== -1) {
          const objStart = startIdx + startMarker.length;
          // Find the closing }; that ends the object (before module.exports)
          const endMarker = '};\n\nif';
          const endIdx = cbsaText.indexOf(endMarker, objStart);
          if (endIdx !== -1) {
            const objText = cbsaText.substring(objStart, endIdx + 1);
            const cbsaObj = eval('(' + objText + ')');
            console.log('[CBSA Load] Loaded', Object.keys(cbsaObj).length, 'metros');
            setCbsaDataLoaded(cbsaObj);
          } else {
            // Fallback: try to find just }; at line start
            const fallbackEnd = cbsaText.indexOf('\n};', objStart);
            if (fallbackEnd !== -1) {
              const objText = cbsaText.substring(objStart, fallbackEnd + 2);
              const cbsaObj = eval('(' + objText + ')');
              console.log('[CBSA Load] Loaded (fallback)', Object.keys(cbsaObj).length, 'metros');
              setCbsaDataLoaded(cbsaObj);
            } else {
              console.error('[CBSA Load] Could not find end of CBSA_DATA object');
            }
          }
        } else {
          console.error('[CBSA Load] Could not find CBSA_DATA in file');
        }
        
        // Fetch ZIP centroids (33,791 ZIPs with lat/lng)
        const zipResponse = await fetch('https://raw.githubusercontent.com/fromnineteen80/salaryarc/main/zip-centroids.js');
        const zipText = await zipResponse.text();
        // Find the object between 'const ZIP_CENTROIDS = {' and '};'
        const zipStartMarker = 'const ZIP_CENTROIDS = ';
        const zipStartIdx = zipText.indexOf(zipStartMarker);
        if (zipStartIdx !== -1) {
          const zipObjStart = zipStartIdx + zipStartMarker.length;
          const zipEndIdx = zipText.indexOf('\n};', zipObjStart);
          if (zipEndIdx !== -1) {
            const zipObjText = zipText.substring(zipObjStart, zipEndIdx + 2);
            const zipObj = eval('(' + zipObjText + ')');
            console.log('[ZIP Load] Loaded', Object.keys(zipObj).length, 'ZIPs');
            setZipDataLoaded(zipObj);
          }
        }
        
        setDataLoading(false);
      } catch (err) {
        console.error('Failed to fetch geo data:', err);
        setDataLoading(false);
      }
    };
    fetchGeoData();
  }, []);

  // Fetch FRED labor market data for jobs chart
  useEffect(() => {
    const fetchFREDData = async () => {
      try {
        setJobsLoading(true);
        setJobsError(null);
        
        // FRED series IDs for college graduates (25+ with bachelor's or higher)
        const seriesMap = {
          // All college grads
          epop_all: 'LNS12300072',      // Employment-Population Ratio
          lfpr_all: 'LNS11300072',      // Labor Force Participation Rate
          // Men
          epop_men: 'LNS12300085',
          lfpr_men: 'LNS11300085',
          // Women
          epop_women: 'LNS12300086',
          lfpr_women: 'LNS11300086',
        };
        
        // Fetch all series in parallel
        const fetchSeries = async (seriesId) => {
          const url = `https://api.stlouisfed.org/fred/series/observations?series_id=${seriesId}&file_type=json&observation_start=2007-01-01&api_key=DEMO_API`;
          try {
            const response = await fetch(url);
            if (!response.ok) throw new Error(`FRED API error: ${response.status}`);
            const data = await response.json();
            return data.observations || [];
          } catch (err) {
            console.warn(`[FRED] Failed to fetch ${seriesId}:`, err.message);
            return null;
          }
        };
        
        // Try FRED API first
        const results = {};
        let fredSuccess = false;
        
        for (const [key, seriesId] of Object.entries(seriesMap)) {
          const data = await fetchSeries(seriesId);
          if (data && data.length > 0) {
            results[key] = data;
            fredSuccess = true;
          }
        }
        
        // If FRED fails, use embedded fallback data (key economic periods)
        if (!fredSuccess) {
          console.log('[FRED] Using fallback data');
          // Fallback static data - monthly from 2007-2024 (simplified for demo)
          const fallbackData = generateFallbackJobsData();
          setJobsData(fallbackData);
          setJobsLoading(false);
          return;
        }
        
        // Transform FRED data into chart format
        const chartData = transformFREDData(results);
        setJobsData(chartData);
        setJobsLoading(false);
        
      } catch (err) {
        console.error('[FRED] Error:', err);
        setJobsError('Failed to load labor market data');
        // Use fallback on error
        const fallbackData = generateFallbackJobsData();
        setJobsData(fallbackData);
        setJobsLoading(false);
      }
    };
    
    // Helper to generate quarterly data from Q4 2014 to Q4 2024
    // Q4 2014 is needed to calculate QoQ change for Q1 2015
    const generateFallbackJobsData = () => {
      // Quarterly data: Q4 2014 through Q4 2024 = 41 quarters
      // Quarter 1 = Jan, Q2 = Apr, Q3 = Jul, Q4 = Oct
      const quarterMonths = { 1: 1, 2: 4, 3: 7, 4: 10 };
      const data = [];
      
      // Raw quarterly data - placeholder values to be replaced with real data
      // Format: [year, quarter, total_jobs, employed_all, jobs_created_all, sixfig_pct, lfpr_all, underemployment_all, unemployment_all]
      // Plus gender splits: [employed_men, jobs_created_men, lfpr_men, underemployment_men, employed_women, jobs_created_women, lfpr_women, underemployment_women]
      const quarterlyData = [
        // 2014 Q4 (baseline for QoQ calc)
        { year: 2014, quarter: 4, total_jobs: 140.0, employed_all: 44.2, jobs_created_all: 35.4, sixfig_pct: 16.5, lfpr_all: 77.2, underemployment_all: 12.8, unemployment_all: 2.9,
          employed_men: 20.8, jobs_created_men: 17.2, lfpr_men: 80.5, underemployment_men: 11.5, employed_women: 23.4, jobs_created_women: 18.2, lfpr_women: 74.2, underemployment_women: 14.0 },
        // 2015
        { year: 2015, quarter: 1, total_jobs: 141.0, employed_all: 44.5, jobs_created_all: 35.6, sixfig_pct: 16.8, lfpr_all: 77.4, underemployment_all: 12.6, unemployment_all: 2.8,
          employed_men: 21.0, jobs_created_men: 17.4, lfpr_men: 80.6, underemployment_men: 11.3, employed_women: 23.5, jobs_created_women: 18.2, lfpr_women: 74.4, underemployment_women: 13.8 },
        { year: 2015, quarter: 2, total_jobs: 141.5, employed_all: 44.8, jobs_created_all: 35.9, sixfig_pct: 16.9, lfpr_all: 77.5, underemployment_all: 12.4, unemployment_all: 2.7,
          employed_men: 21.1, jobs_created_men: 17.5, lfpr_men: 80.7, underemployment_men: 11.2, employed_women: 23.7, jobs_created_women: 18.4, lfpr_women: 74.5, underemployment_women: 13.5 },
        { year: 2015, quarter: 3, total_jobs: 142.0, employed_all: 45.1, jobs_created_all: 36.2, sixfig_pct: 17.0, lfpr_all: 77.6, underemployment_all: 12.2, unemployment_all: 2.6,
          employed_men: 21.2, jobs_created_men: 17.6, lfpr_men: 80.8, underemployment_men: 11.0, employed_women: 23.9, jobs_created_women: 18.6, lfpr_women: 74.6, underemployment_women: 13.3 },
        { year: 2015, quarter: 4, total_jobs: 142.5, employed_all: 45.4, jobs_created_all: 36.5, sixfig_pct: 17.1, lfpr_all: 77.7, underemployment_all: 12.0, unemployment_all: 2.5,
          employed_men: 21.4, jobs_created_men: 17.8, lfpr_men: 80.9, underemployment_men: 10.8, employed_women: 24.0, jobs_created_women: 18.7, lfpr_women: 74.7, underemployment_women: 13.1 },
        // 2016
        { year: 2016, quarter: 1, total_jobs: 143.0, employed_all: 45.7, jobs_created_all: 36.8, sixfig_pct: 17.3, lfpr_all: 77.8, underemployment_all: 11.8, unemployment_all: 2.5,
          employed_men: 21.5, jobs_created_men: 17.9, lfpr_men: 81.0, underemployment_men: 10.6, employed_women: 24.2, jobs_created_women: 18.9, lfpr_women: 74.8, underemployment_women: 12.9 },
        { year: 2016, quarter: 2, total_jobs: 143.5, employed_all: 46.0, jobs_created_all: 37.1, sixfig_pct: 17.4, lfpr_all: 77.9, underemployment_all: 11.6, unemployment_all: 2.4,
          employed_men: 21.6, jobs_created_men: 18.0, lfpr_men: 81.1, underemployment_men: 10.5, employed_women: 24.4, jobs_created_women: 19.1, lfpr_women: 74.9, underemployment_women: 12.7 },
        { year: 2016, quarter: 3, total_jobs: 144.0, employed_all: 46.3, jobs_created_all: 37.4, sixfig_pct: 17.5, lfpr_all: 78.0, underemployment_all: 11.4, unemployment_all: 2.4,
          employed_men: 21.8, jobs_created_men: 18.2, lfpr_men: 81.2, underemployment_men: 10.3, employed_women: 24.5, jobs_created_women: 19.2, lfpr_women: 75.0, underemployment_women: 12.5 },
        { year: 2016, quarter: 4, total_jobs: 144.5, employed_all: 46.6, jobs_created_all: 37.7, sixfig_pct: 17.6, lfpr_all: 78.1, underemployment_all: 11.2, unemployment_all: 2.3,
          employed_men: 21.9, jobs_created_men: 18.3, lfpr_men: 81.3, underemployment_men: 10.2, employed_women: 24.7, jobs_created_women: 19.4, lfpr_women: 75.1, underemployment_women: 12.3 },
        // 2017
        { year: 2017, quarter: 1, total_jobs: 145.0, employed_all: 46.9, jobs_created_all: 38.0, sixfig_pct: 17.8, lfpr_all: 78.2, underemployment_all: 11.0, unemployment_all: 2.3,
          employed_men: 22.0, jobs_created_men: 18.5, lfpr_men: 81.4, underemployment_men: 10.0, employed_women: 24.9, jobs_created_women: 19.5, lfpr_women: 75.2, underemployment_women: 12.0 },
        { year: 2017, quarter: 2, total_jobs: 145.5, employed_all: 47.2, jobs_created_all: 38.3, sixfig_pct: 17.9, lfpr_all: 78.3, underemployment_all: 10.9, unemployment_all: 2.2,
          employed_men: 22.2, jobs_created_men: 18.6, lfpr_men: 81.5, underemployment_men: 9.9, employed_women: 25.0, jobs_created_women: 19.7, lfpr_women: 75.3, underemployment_women: 11.8 },
        { year: 2017, quarter: 3, total_jobs: 146.0, employed_all: 47.5, jobs_created_all: 38.6, sixfig_pct: 18.0, lfpr_all: 78.4, underemployment_all: 10.8, unemployment_all: 2.2,
          employed_men: 22.3, jobs_created_men: 18.7, lfpr_men: 81.5, underemployment_men: 9.8, employed_women: 25.2, jobs_created_women: 19.9, lfpr_women: 75.4, underemployment_women: 11.7 },
        { year: 2017, quarter: 4, total_jobs: 146.5, employed_all: 47.8, jobs_created_all: 38.9, sixfig_pct: 18.1, lfpr_all: 78.5, underemployment_all: 10.7, unemployment_all: 2.1,
          employed_men: 22.4, jobs_created_men: 18.9, lfpr_men: 81.6, underemployment_men: 9.7, employed_women: 25.4, jobs_created_women: 20.0, lfpr_women: 75.5, underemployment_women: 11.6 },
        // 2018
        { year: 2018, quarter: 1, total_jobs: 147.0, employed_all: 48.1, jobs_created_all: 39.2, sixfig_pct: 18.3, lfpr_all: 78.6, underemployment_all: 10.6, unemployment_all: 2.1,
          employed_men: 22.6, jobs_created_men: 19.0, lfpr_men: 81.7, underemployment_men: 9.6, employed_women: 25.5, jobs_created_women: 20.2, lfpr_women: 75.6, underemployment_women: 11.5 },
        { year: 2018, quarter: 2, total_jobs: 147.5, employed_all: 48.4, jobs_created_all: 39.5, sixfig_pct: 18.4, lfpr_all: 78.7, underemployment_all: 10.5, unemployment_all: 2.0,
          employed_men: 22.7, jobs_created_men: 19.1, lfpr_men: 81.7, underemployment_men: 9.5, employed_women: 25.7, jobs_created_women: 20.4, lfpr_women: 75.7, underemployment_women: 11.4 },
        { year: 2018, quarter: 3, total_jobs: 148.0, employed_all: 48.7, jobs_created_all: 39.8, sixfig_pct: 18.5, lfpr_all: 78.8, underemployment_all: 10.4, unemployment_all: 2.0,
          employed_men: 22.8, jobs_created_men: 19.3, lfpr_men: 81.8, underemployment_men: 9.4, employed_women: 25.9, jobs_created_women: 20.5, lfpr_women: 75.8, underemployment_women: 11.3 },
        { year: 2018, quarter: 4, total_jobs: 148.5, employed_all: 49.0, jobs_created_all: 40.1, sixfig_pct: 18.6, lfpr_all: 78.9, underemployment_all: 10.3, unemployment_all: 2.0,
          employed_men: 23.0, jobs_created_men: 19.4, lfpr_men: 81.8, underemployment_men: 9.3, employed_women: 26.0, jobs_created_women: 20.7, lfpr_women: 75.9, underemployment_women: 11.2 },
        // 2019
        { year: 2019, quarter: 1, total_jobs: 149.0, employed_all: 49.3, jobs_created_all: 40.4, sixfig_pct: 18.8, lfpr_all: 79.0, underemployment_all: 10.2, unemployment_all: 2.0,
          employed_men: 23.1, jobs_created_men: 19.6, lfpr_men: 81.9, underemployment_men: 9.2, employed_women: 26.2, jobs_created_women: 20.8, lfpr_women: 76.0, underemployment_women: 11.1 },
        { year: 2019, quarter: 2, total_jobs: 149.5, employed_all: 49.6, jobs_created_all: 40.7, sixfig_pct: 18.9, lfpr_all: 79.1, underemployment_all: 10.1, unemployment_all: 1.9,
          employed_men: 23.2, jobs_created_men: 19.7, lfpr_men: 81.9, underemployment_men: 9.1, employed_women: 26.4, jobs_created_women: 21.0, lfpr_women: 76.1, underemployment_women: 11.0 },
        { year: 2019, quarter: 3, total_jobs: 150.0, employed_all: 49.9, jobs_created_all: 41.0, sixfig_pct: 19.0, lfpr_all: 79.2, underemployment_all: 10.0, unemployment_all: 1.9,
          employed_men: 23.4, jobs_created_men: 19.8, lfpr_men: 82.0, underemployment_men: 9.0, employed_women: 26.5, jobs_created_women: 21.2, lfpr_women: 76.2, underemployment_women: 10.9 },
        { year: 2019, quarter: 4, total_jobs: 150.5, employed_all: 50.2, jobs_created_all: 41.3, sixfig_pct: 19.1, lfpr_all: 79.3, underemployment_all: 9.9, unemployment_all: 1.9,
          employed_men: 23.5, jobs_created_men: 20.0, lfpr_men: 82.0, underemployment_men: 8.9, employed_women: 26.7, jobs_created_women: 21.3, lfpr_women: 76.3, underemployment_women: 10.8 },
        // 2020 - COVID impact
        { year: 2020, quarter: 1, total_jobs: 151.0, employed_all: 50.5, jobs_created_all: 41.6, sixfig_pct: 19.2, lfpr_all: 79.4, underemployment_all: 9.8, unemployment_all: 2.0,
          employed_men: 23.6, jobs_created_men: 20.1, lfpr_men: 82.1, underemployment_men: 8.9, employed_women: 26.9, jobs_created_women: 21.5, lfpr_women: 76.4, underemployment_women: 10.7 },
        { year: 2020, quarter: 2, total_jobs: 133.0, employed_all: 45.0, jobs_created_all: 36.0, sixfig_pct: 17.5, lfpr_all: 74.5, underemployment_all: 15.5, unemployment_all: 8.5,
          employed_men: 21.0, jobs_created_men: 17.2, lfpr_men: 77.0, underemployment_men: 14.0, employed_women: 24.0, jobs_created_women: 18.8, lfpr_women: 72.0, underemployment_women: 16.8 },
        { year: 2020, quarter: 3, total_jobs: 141.0, employed_all: 47.5, jobs_created_all: 38.5, sixfig_pct: 18.2, lfpr_all: 76.0, underemployment_all: 13.5, unemployment_all: 5.5,
          employed_men: 22.2, jobs_created_men: 18.5, lfpr_men: 79.0, underemployment_men: 12.0, employed_women: 25.3, jobs_created_women: 20.0, lfpr_women: 73.5, underemployment_women: 14.8 },
        { year: 2020, quarter: 4, total_jobs: 144.0, employed_all: 48.5, jobs_created_all: 39.5, sixfig_pct: 18.8, lfpr_all: 77.0, underemployment_all: 12.5, unemployment_all: 4.0,
          employed_men: 22.8, jobs_created_men: 19.0, lfpr_men: 79.8, underemployment_men: 11.2, employed_women: 25.7, jobs_created_women: 20.5, lfpr_women: 74.5, underemployment_women: 13.7 },
        // 2021 - Recovery
        { year: 2021, quarter: 1, total_jobs: 145.5, employed_all: 49.0, jobs_created_all: 40.0, sixfig_pct: 19.2, lfpr_all: 77.5, underemployment_all: 12.0, unemployment_all: 3.5,
          employed_men: 23.0, jobs_created_men: 19.2, lfpr_men: 80.2, underemployment_men: 10.8, employed_women: 26.0, jobs_created_women: 20.8, lfpr_women: 75.0, underemployment_women: 13.1 },
        { year: 2021, quarter: 2, total_jobs: 147.0, employed_all: 49.5, jobs_created_all: 40.5, sixfig_pct: 19.5, lfpr_all: 78.0, underemployment_all: 11.5, unemployment_all: 3.0,
          employed_men: 23.2, jobs_created_men: 19.4, lfpr_men: 80.5, underemployment_men: 10.4, employed_women: 26.3, jobs_created_women: 21.1, lfpr_women: 75.5, underemployment_women: 12.5 },
        { year: 2021, quarter: 3, total_jobs: 148.5, employed_all: 50.0, jobs_created_all: 41.0, sixfig_pct: 19.8, lfpr_all: 78.3, underemployment_all: 11.2, unemployment_all: 2.7,
          employed_men: 23.4, jobs_created_men: 19.6, lfpr_men: 80.8, underemployment_men: 10.1, employed_women: 26.6, jobs_created_women: 21.4, lfpr_women: 75.9, underemployment_women: 12.2 },
        { year: 2021, quarter: 4, total_jobs: 150.0, employed_all: 50.5, jobs_created_all: 41.5, sixfig_pct: 20.1, lfpr_all: 78.5, underemployment_all: 11.0, unemployment_all: 2.5,
          employed_men: 23.6, jobs_created_men: 19.8, lfpr_men: 81.0, underemployment_men: 9.9, employed_women: 26.9, jobs_created_women: 21.7, lfpr_women: 76.2, underemployment_women: 12.0 },
        // 2022
        { year: 2022, quarter: 1, total_jobs: 151.0, employed_all: 51.0, jobs_created_all: 42.0, sixfig_pct: 20.4, lfpr_all: 78.7, underemployment_all: 10.8, unemployment_all: 2.3,
          employed_men: 23.8, jobs_created_men: 20.0, lfpr_men: 81.2, underemployment_men: 9.7, employed_women: 27.2, jobs_created_women: 22.0, lfpr_women: 76.4, underemployment_women: 11.8 },
        { year: 2022, quarter: 2, total_jobs: 152.0, employed_all: 51.5, jobs_created_all: 42.3, sixfig_pct: 20.6, lfpr_all: 78.8, underemployment_all: 10.7, unemployment_all: 2.2,
          employed_men: 24.0, jobs_created_men: 20.1, lfpr_men: 81.3, underemployment_men: 9.6, employed_women: 27.5, jobs_created_women: 22.2, lfpr_women: 76.5, underemployment_women: 11.7 },
        { year: 2022, quarter: 3, total_jobs: 153.0, employed_all: 52.0, jobs_created_all: 42.6, sixfig_pct: 20.8, lfpr_all: 78.9, underemployment_all: 10.6, unemployment_all: 2.1,
          employed_men: 24.2, jobs_created_men: 20.2, lfpr_men: 81.4, underemployment_men: 9.5, employed_women: 27.8, jobs_created_women: 22.4, lfpr_women: 76.6, underemployment_women: 11.6 },
        { year: 2022, quarter: 4, total_jobs: 154.0, employed_all: 52.5, jobs_created_all: 42.9, sixfig_pct: 21.0, lfpr_all: 79.0, underemployment_all: 10.5, unemployment_all: 2.0,
          employed_men: 24.4, jobs_created_men: 20.3, lfpr_men: 81.5, underemployment_men: 9.4, employed_women: 28.1, jobs_created_women: 22.6, lfpr_women: 76.7, underemployment_women: 11.5 },
        // 2023
        { year: 2023, quarter: 1, total_jobs: 155.0, employed_all: 53.0, jobs_created_all: 43.2, sixfig_pct: 21.2, lfpr_all: 79.1, underemployment_all: 10.6, unemployment_all: 2.0,
          employed_men: 24.5, jobs_created_men: 20.4, lfpr_men: 81.5, underemployment_men: 9.5, employed_women: 28.5, jobs_created_women: 22.8, lfpr_women: 76.8, underemployment_women: 11.6 },
        { year: 2023, quarter: 2, total_jobs: 155.5, employed_all: 53.3, jobs_created_all: 43.4, sixfig_pct: 21.3, lfpr_all: 79.1, underemployment_all: 10.7, unemployment_all: 2.1,
          employed_men: 24.6, jobs_created_men: 20.4, lfpr_men: 81.4, underemployment_men: 9.6, employed_women: 28.7, jobs_created_women: 23.0, lfpr_women: 76.9, underemployment_women: 11.7 },
        { year: 2023, quarter: 3, total_jobs: 156.0, employed_all: 53.5, jobs_created_all: 43.5, sixfig_pct: 21.4, lfpr_all: 79.0, underemployment_all: 10.8, unemployment_all: 2.2,
          employed_men: 24.6, jobs_created_men: 20.3, lfpr_men: 81.3, underemployment_men: 9.7, employed_women: 28.9, jobs_created_women: 23.2, lfpr_women: 76.9, underemployment_women: 11.8 },
        { year: 2023, quarter: 4, total_jobs: 156.5, employed_all: 53.7, jobs_created_all: 43.6, sixfig_pct: 21.5, lfpr_all: 78.9, underemployment_all: 10.9, unemployment_all: 2.3,
          employed_men: 24.6, jobs_created_men: 20.2, lfpr_men: 81.2, underemployment_men: 9.8, employed_women: 29.1, jobs_created_women: 23.4, lfpr_women: 76.8, underemployment_women: 11.9 },
        // 2024
        { year: 2024, quarter: 1, total_jobs: 157.0, employed_all: 53.9, jobs_created_all: 43.7, sixfig_pct: 21.6, lfpr_all: 78.8, underemployment_all: 11.0, unemployment_all: 2.4,
          employed_men: 24.6, jobs_created_men: 20.1, lfpr_men: 81.0, underemployment_men: 9.9, employed_women: 29.3, jobs_created_women: 23.6, lfpr_women: 76.7, underemployment_women: 12.0 },
        { year: 2024, quarter: 2, total_jobs: 157.5, employed_all: 54.1, jobs_created_all: 43.8, sixfig_pct: 21.7, lfpr_all: 78.7, underemployment_all: 11.1, unemployment_all: 2.5,
          employed_men: 24.5, jobs_created_men: 20.0, lfpr_men: 80.8, underemployment_men: 10.0, employed_women: 29.6, jobs_created_women: 23.8, lfpr_women: 76.6, underemployment_women: 12.1 },
        { year: 2024, quarter: 3, total_jobs: 158.0, employed_all: 54.3, jobs_created_all: 43.9, sixfig_pct: 21.8, lfpr_all: 78.6, underemployment_all: 11.2, unemployment_all: 2.6,
          employed_men: 24.4, jobs_created_men: 19.9, lfpr_men: 80.6, underemployment_men: 10.1, employed_women: 29.9, jobs_created_women: 24.0, lfpr_women: 76.5, underemployment_women: 12.2 },
        { year: 2024, quarter: 4, total_jobs: 158.5, employed_all: 54.5, jobs_created_all: 44.0, sixfig_pct: 21.9, lfpr_all: 78.5, underemployment_all: 11.3, unemployment_all: 2.7,
          employed_men: 24.3, jobs_created_men: 19.8, lfpr_men: 80.4, underemployment_men: 10.2, employed_women: 30.2, jobs_created_women: 24.2, lfpr_women: 76.4, underemployment_women: 12.3 },
      ];
      
      // Convert to chart format
      quarterlyData.forEach(q => {
        const month = quarterMonths[q.quarter];
        const date = `${q.year}-${String(month).padStart(2, '0')}`;
        
        // Calculate sixfig absolute values from percentage
        const sixfig_all = q.jobs_created_all * (q.sixfig_pct / 100);
        const sixfig_men = q.jobs_created_men * (q.sixfig_pct / 100) * 1.15; // Men overrepresented
        const sixfig_women = q.jobs_created_women * (q.sixfig_pct / 100) * 0.85; // Women underrepresented
        
        data.push({
          date,
          year: q.year,
          quarter: q.quarter,
          total_jobs: q.total_jobs,
          employed_all: q.employed_all,
          jobs_created_all: q.jobs_created_all,
          sixfig_all: Math.round(sixfig_all * 10) / 10,
          lfpr_all: q.lfpr_all,
          underemployment_all: q.underemployment_all,
          unemployment_all: q.unemployment_all,
          employed_men: q.employed_men,
          jobs_created_men: q.jobs_created_men,
          sixfig_men: Math.round(sixfig_men * 10) / 10,
          lfpr_men: q.lfpr_men,
          underemployment_men: q.underemployment_men,
          unemployment_men: q.unemployment_all, // Use same as all for now
          employed_women: q.employed_women,
          jobs_created_women: q.jobs_created_women,
          sixfig_women: Math.round(sixfig_women * 10) / 10,
          lfpr_women: q.lfpr_women,
          underemployment_women: q.underemployment_women,
          unemployment_women: q.unemployment_all, // Use same as all for now
          sixfig_pct_all: q.sixfig_pct,
          sixfig_pct_men: Math.round(q.sixfig_pct * 1.15 * 10) / 10,
          sixfig_pct_women: Math.round(q.sixfig_pct * 0.85 * 10) / 10,
        });
      });
      
      // Filter to 2015+ for display, calculate derived metrics using Q1 2015 as baseline
      const displayData = data.filter(d => d.year >= 2015);
      const baseline = displayData[0]; // Q1 2015
      
      if (baseline) {
        const menBaseline = baseline.employed_men;
        const womenBaseline = baseline.employed_women;
        const totalDegreeJobsBaseline = baseline.jobs_created_men + baseline.jobs_created_women;
        const menPortionBaseline = (baseline.jobs_created_men / totalDegreeJobsBaseline) * 100;
        const womenPortionBaseline = (baseline.jobs_created_women / totalDegreeJobsBaseline) * 100;
        
        displayData.forEach(d => {
          // Growth indexed to 50
          d.growth_men = Math.round(((d.employed_men / menBaseline) * 50) * 10) / 10;
          d.growth_women = Math.round(((d.employed_women / womenBaseline) * 50) * 10) / 10;
          // Raw percent change
          d.pct_change_men = Math.round(((d.employed_men - menBaseline) / menBaseline) * 100 * 10) / 10;
          d.pct_change_women = Math.round(((d.employed_women - womenBaseline) / womenBaseline) * 100 * 10) / 10;
          // Baselines
          d.baseline_men = menBaseline;
          d.baseline_women = womenBaseline;
          // Portion of degree jobs change
          const totalDegreeJobs = d.jobs_created_men + d.jobs_created_women;
          const menPortion = (d.jobs_created_men / totalDegreeJobs) * 100;
          const womenPortion = (d.jobs_created_women / totalDegreeJobs) * 100;
          d.portion_change_men = Math.round((menPortion - menPortionBaseline) * 100) / 100;
          d.portion_change_women = Math.round((womenPortion - womenPortionBaseline) * 100) / 100;
          d.portion_gap = Math.round(Math.abs(d.portion_change_men - d.portion_change_women) * 100) / 100;
        });
      }
      
      return displayData;
    };
    
    // Transform FRED API responses into unified chart data
    const transformFREDData = (results) => {
      // Build a map of date -> values
      const dataMap = new Map();
      
      for (const [key, observations] of Object.entries(results)) {
        if (!observations) continue;
        for (const obs of observations) {
          const date = obs.date.substring(0, 7); // YYYY-MM
          if (!dataMap.has(date)) {
            dataMap.set(date, { date, year: parseInt(date.substring(0, 4)), month: parseInt(date.substring(5, 7)) });
          }
          const val = parseFloat(obs.value);
          if (!isNaN(val)) {
            dataMap.get(date)[key] = val;
          }
        }
      }
      
      // Convert to array and sort
      return Array.from(dataMap.values())
        .filter(d => d.year >= 2007)
        .sort((a, b) => a.date.localeCompare(b.date));
    };
    
    fetchFREDData();
  }, []);

  // Toggle dropdown based on container width (12 toggles need ~1300px to fit on one row with padding)
  // Only show inline toggles at the widest container settings
  useEffect(() => {
    setUseDropdownToggles(containerWidth < 1300 || windowWidth < 1300);
  }, [containerWidth, windowWidth]);

  // Auto-generate Demo narratives when Demo page is viewed and data is ready
  useEffect(() => {
    const generateDemoNarratives = async () => {
      console.log('[Demo Gen] useEffect triggered', { currentPage, hasCbsa: !!cbsaDataLoaded, hasZip: !!zipDataLoaded, narrativeKeys: Object.keys(demoNarrativeContent).length, demoGenerating });
      
      if (currentPage !== 'demo') {
        console.log('[Demo Gen] Not on demo page, skipping');
        return;
      }
      if (!cbsaDataLoaded || !zipDataLoaded) {
        console.log('[Demo Gen] Data not loaded yet, skipping');
        return;
      }
      if (Object.keys(demoNarrativeContent).length > 0) {
        console.log('[Demo Gen] Already have narratives, skipping');
        return;
      }
      if (demoGenerating) {
        console.log('[Demo Gen] Already generating, skipping');
        return;
      }
      
      // Wait for computed data to be available
      if (!data || data.length === 0) {
        console.log('[Demo Gen] Data not ready yet, waiting...');
        return;
      }
      
      console.log('[Demo Gen] Starting generation...');
      setDemoGenerating(true);
      setDemoGenerationProgress({ current: 0, total: 9, cardName: 'Starting...' });
      
      try {
        // Use the already-computed data array which has correct relateScore, matchScore, etc.
        // This ensures the narrative generation uses the same values as the chart/tooltip
        const demoReportData = data.map(row => ({
          year: row.year,
          location: row.location,
          age: row.age,
          income: row.income,
          goal: row.goal,
          greenLine: row.greenLine,
          percentile: row.percentile,
          married: row.relationship === 'Married' ? 'yes' : 'no',
          children: row.hasKids,
          education: row.education,
          relateScore: row.relateScore,
          relateComponents: row.relateComponents,
          matchScore: row.matchScore,
          matchPool: row.matchPool,
          localSinglePool: row.localSinglePool,
          population: row.population,
          targetGenderLabel: row.targetGenderLabel
        }));
        
        console.log('[Demo Gen] Calling generateAllNarratives with', demoReportData.length, 'rows');
        console.log('[Demo Gen] Last row relateScore:', demoReportData[demoReportData.length - 1]?.relateScore);
        const narratives = await generateAllNarratives(
          demoReportData,
          DEMO_FORM_DATA,
          (progress) => {
            console.log('[Demo Gen] Progress:', progress);
            setDemoGenerationProgress(progress);
          }
        );
        
        console.log('[Demo Gen] Generation complete, setting narratives');
        setDemoNarrativeContent(narratives);
      } catch (error) {
        console.error('[Demo Gen] Error:', error);
      } finally {
        setDemoGenerating(false);
      }
    };
    
    generateDemoNarratives();
  }, [currentPage, cbsaDataLoaded, zipDataLoaded]);

  // Auto-generate Report narratives when Report page is viewed and data is ready
  useEffect(() => {
    const generateReportNarratives = async () => {
      if (currentPage !== 'report') return;
      if (!cbsaDataLoaded || !zipDataLoaded) return;
      if (Object.keys(narrativeContent).length > 0) return; // Already generated
      if (reportGenerating) return; // Already in progress
      
      // Check we have enough data
      const filledYears = formData.incomeYears.filter(y => y.year && y.income && y.location && y.zipCode);
      if (filledYears.length < 5) return;
      
      setReportGenerating(true);
      setGenerationProgress({ current: 0, total: 9, cardName: 'Starting...' });
      
      try {
        // Haversine distance calculation for CBSA lookup
        const haversineDistance = (lat1, lng1, lat2, lng2) => {
          const R = 6371;
          const dLat = (lat2 - lat1) * Math.PI / 180;
          const dLng = (lng2 - lng1) * Math.PI / 180;
          const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                    Math.sin(dLng/2) * Math.sin(dLng/2);
          return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        };
        
        // Find nearest CBSA using ZIP centroid
        const findCBSAByZip = (zipCode) => {
          const zipCoords = zipDataLoaded[zipCode];
          if (!zipCoords) return null;
          
          let nearest = null;
          let minDist = Infinity;
          
          for (const [name, cbsa] of Object.entries(cbsaDataLoaded)) {
            const dist = haversineDistance(zipCoords.lat, zipCoords.lng, cbsa.lat, cbsa.lng);
            if (dist < minDist) {
              minDist = dist;
              nearest = { ...cbsa, name };
            }
          }
          return nearest;
        };
        
        // Build reportData using proper CBSA calculations
        const reportData = filledYears.map((row) => {
          const yearNum = parseInt(row.year);
          const income = parseInt(row.income);
          const age = parseInt(row.age) || 30;
          const married = row.married || 'no';
          const children = row.children || 'no';
          const education = row.education || 'bachelors';
          const goal = parseInt(row.goal) || 150000;
          
          // CBSA lookup for proper calculations
          const cbsa = findCBSAByZip(row.zipCode);
          const rpp = cbsa?.rpp || 100;
          const cpi = CPI_DATA[yearNum] || CPI_DATA[2025];
          const cpi2025 = CPI_DATA[2025];
          
          const colFamily4 = Math.round(137822 * (rpp / 100) * (cpi / cpi2025));
          const greenLine = Math.round(colFamily4 * 1.35);
          
          // User profile for calculation module
          const user = {
            age,
            income,
            education,
            gender: formData.gender || 'man',
            ethnicity: formData.ethnicity || 'white',
            orientation: formData.orientation || 'straight',
            hasKids: children === 'yes',
            relationshipStatus: married
          };
          
          // Partner preferences from formData (if available)
          const partnerPrefs = formData.partnerPrefs || {};
          
          // User profile attributes for sigmoid calculation
          const userProfile = {
            height: formData.height || null,
            bodyType: formData.bodyType || 'average',
            workoutFrequency: formData.workoutFrequency || 'never',
            politicalViews: formData.politicalViews || 'moderate',
            smoking: formData.smoking || 'no'
          };
          
          // Use SHARED CALCULATION MODULE for proper scores
          const { relateScore, incomeLocal, components: relateComponents } = calculateRelateScore(user, cbsa || DEFAULT_CBSA, colFamily4);
          
          // Use three-tier calculation for dating metrics
          const threeTier = calculateThreeTierMatches(user, cbsa || DEFAULT_CBSA, partnerPrefs, userProfile);
          const percentile = Math.round(incomeLocal);
          
          return {
            year: yearNum,
            location: row.location,
            age,
            income,
            goal,
            greenLine,
            percentile,
            married,
            children,
            education,
            relateScore: Math.round(relateScore * 10) / 10,
            relateComponents,
            // Legacy fields
            matchScore: threeTier.matchScore,
            matchPool: threeTier.matchPool,
            localSinglePool: threeTier.localSinglePool,
            // Three-tier fields
            realisticPool: threeTier.realisticPool,
            realisticMatches: threeTier.realisticMatches,
            realisticMatchRate: threeTier.realisticMatchRate,
            preferredPool: threeTier.preferredPool,
            preferredMatches: threeTier.preferredMatches,
            preferredMatchRate: threeTier.preferredMatchRate,
            idealPool: threeTier.idealPool,
            idealMatches: threeTier.idealMatches,
            idealMatchRate: threeTier.idealMatchRate,
            relateScoreOutOf10: threeTier.relateScoreOutOf10,
            population: cbsa?.cbsa_population || 100000,
            targetGenderLabel: threeTier.targetGenderLabel
          };
        }).sort((a, b) => a.year - b.year);
        
        console.log('[Report Gen] Last row relateScore:', reportData[reportData.length - 1]?.relateScore);
        
        const narratives = await generateAllNarratives(
          reportData,
          formData,
          (progress) => setGenerationProgress(progress)
        );
        
        setNarrativeContent(narratives);
      } catch (error) {
        console.error('Error generating report narratives:', error);
      } finally {
        setReportGenerating(false);
      }
    };
    
    generateReportNarratives();
  }, [currentPage, cbsaDataLoaded, zipDataLoaded, narrativeContent, reportGenerating, formData]);

  const cardSectionMap = {
    start: ['contextByYear'],
    current: ['keyFindings'],
    multiple: ['rarityAnalysis'],
    percentile: ['percentileThresholds'],
    vsGoal: ['whatYoureCreating'],
    vs700k: ['inflationImpact'],
    relateScore: ['relateScoreAnalysis'],
    matchScore: ['matchScoreAnalysis'],
  };

  const handleCardClick = (cardKey) => {
    if (activeCard === cardKey) {
      setActiveCard(null);
      const sectionsToClose = cardSectionMap[cardKey] || [];
      setOpenSections(prev => {
        const newState = { ...prev };
        sectionsToClose.forEach(s => newState[s] = false);
        return newState;
      });
    } else {
      setActiveCard(cardKey);
      const allMappedSections = Object.values(cardSectionMap).flat();
      const sectionsToOpen = cardSectionMap[cardKey] || [];
      setOpenSections(prev => {
        const newState = { ...prev };
        allMappedSections.forEach(s => newState[s] = false);
        sectionsToOpen.forEach(s => newState[s] = true);
        return newState;
      });
    }
  };

  const demographics = data.map(d => ({
    year: d.year, location: d.location, income: d.income, relateScore: d.relateScore, matchPool: d.matchPool,
    gender: 'Male', age: d.age, ethnicity: 'White', orientation: 'Straight',
    relationship: d.relationship, education: d.year < 2008 ? (d.year < 2004 ? 'HS Grad' : 'Bachelors') : 'Graduate',
    children: d.year >= 2015 ? 'Yes' : 'No'
  }));

  const toggleSection = (key) => {
    setOpenSections(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const toggle = (key) => setVisibleLines(prev => ({ ...prev, [key]: !prev[key] }));
  const hasPercent = visibleLines.percentile || visibleLines.achieve || visibleLines.relateScore || visibleLines.matchScore;
  const hasDollar = visibleLines.income || visibleLines.purchasePower || visibleLines.equiv700k || visibleLines.goal || visibleLines.safe || visibleLines.greenLine || visibleLines.medianHH || visibleLines.povertyLine;
  const anyToggleActive = hasPercent || hasDollar;

  // Compute chart data with band height for shading (only if data available)
  const chartData = data.length > 0 ? data.map(d => ({
    ...d,
    bandHeight: d.equiv700k - d.greenLine
  })) : [];

  // Calculate years lived below functional poverty (interpolating all years)
  const startYear = data.length > 0 ? data[0].year : 1998;
  const endYear = data.length > 0 ? data[data.length - 1].year : 2025;
  let yearsBelowFunctional = 0;
  
  if (data.length > 0) {
    for (let year = startYear; year <= endYear; year++) {
      // Find surrounding data points for interpolation
      let prevPoint = data[0];
      let nextPoint = data[data.length - 1];
    
    for (let i = 0; i < data.length - 1; i++) {
      if (data[i].year <= year && data[i + 1].year >= year) {
        prevPoint = data[i];
        nextPoint = data[i + 1];
        break;
      }
    }
    
    // Interpolate income and greenLine for this year
    let income, greenLine;
    if (year === prevPoint.year) {
      income = prevPoint.income;
      greenLine = prevPoint.greenLine;
    } else if (year === nextPoint.year) {
      income = nextPoint.income;
      greenLine = nextPoint.greenLine;
    } else {
      const t = (year - prevPoint.year) / (nextPoint.year - prevPoint.year);
      income = prevPoint.income + t * (nextPoint.income - prevPoint.income);
      greenLine = prevPoint.greenLine + t * (nextPoint.greenLine - prevPoint.greenLine);
    }
    
    if (income < greenLine) {
      yearsBelowFunctional++;
    }
  }
  } // end if (data.length > 0)

  // Dynamic stats cards based on computed data
  const firstDataPoint = data[0] || {};
  const lastDataPoint = data[data.length - 1] || {};
  const incomeMultiple = firstDataPoint.income && lastDataPoint.income 
    ? (lastDataPoint.income / firstDataPoint.income).toFixed(1) 
    : '—';
  const percentileGain = lastDataPoint.percentile && firstDataPoint.percentile
    ? lastDataPoint.percentile - firstDataPoint.percentile
    : 0;
  const vsGoalPct = lastDataPoint.goal && lastDataPoint.income
    ? Math.round((lastDataPoint.income / lastDataPoint.goal) * 100)
    : 0;
  
  const statsCards = [
    { key: 'start', label: `Start at ${firstDataPoint.age || 18}`, value: formatCurrency(firstDataPoint.income || 0), sub: `${firstDataPoint.year || ''} ${firstDataPoint.location || ''}`, highlight: false },
    { key: 'current', label: `CURRENT at ${lastDataPoint.age || 45}`, value: formatCurrency(lastDataPoint.income || 0), sub: `${lastDataPoint.year || ''} ${lastDataPoint.location || ''}`, highlight: false },
    { key: 'percentile', label: 'Percentile', value: lastDataPoint.percentile >= 99 ? 'Top 1%' : `${lastDataPoint.percentile || 50}th`, sub: `Grew by ${percentileGain} points`, highlight: true },
    { key: 'multiple', label: 'Multiple', value: `${incomeMultiple}x`, sub: `Growth since age ${firstDataPoint.age || 18}`, highlight: true },
    { key: 'belowFunctional', label: 'Below Functional', value: `${yearsBelowFunctional} Years`, sub: 'Lived below functional poverty', highlight: false },
    { key: 'vsGoal', label: 'vs Goal', value: `${vsGoalPct}%`, sub: `${(vsGoalPct / 100).toFixed(1)}x target`, highlight: true },
    { key: 'relateScore', label: 'Relate Score', value: lastDataPoint.relateScore ? `${(lastDataPoint.relateScore / 10).toFixed(1)}/10` : '—', sub: `${lastDataPoint.year || ''} ${lastDataPoint.location || ''}`, highlight: false },
    { key: 'matchScore', label: 'Match Score', value: lastDataPoint.matchPool ? (lastDataPoint.matchPool >= 1000000 ? `${(lastDataPoint.matchPool/1000000).toFixed(1)}M` : `${Math.round(lastDataPoint.matchPool/1000)}k`) : '—', sub: 'Realistic matches', highlight: false },
  ];

  // Form input styling
  const inputStyle = {
    width: '100%',
    padding: '8px 12px',
    fontSize: scaledFont(11),
    border: '1px solid #E5E2DA',
    borderRadius: '4px',
    backgroundColor: 'white',
    color: '#141413',
    outline: 'none',
  };

  const selectStyle = {
    ...inputStyle,
    cursor: 'pointer',
  };

  const labelStyle = {
    display: 'block',
    fontSize: scaledFont(10),
    fontWeight: '600',
    color: '#5C5A4D',
    marginBottom: '4px',
    textTransform: 'uppercase',
    letterSpacing: '0.03em',
  };

  // Home Landing Page
  if (currentPage === 'home') {
    
    // Responsive font size for hero text (smaller)
    const getHeroFontSize = () => {
      if (windowWidth < 480) return '20px';
      if (windowWidth < 640) return '24px';
      if (windowWidth < 800) return '28px';
      if (windowWidth < 1024) return '32px';
      return '38px';
    };
    
    const navLinkStyle = (isActive = false) => ({
      height: '28px',
      padding: '0 12px',
      border: 'none',
      borderRadius: '4px',
      backgroundColor: isActive ? '#E5E2DA' : 'transparent',
      cursor: 'pointer',
      fontSize: '12px',
      fontWeight: '500',
      color: '#3D3929',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      transition: 'background-color 0.15s ease',
    });
    
    return (
      <div style={{ 
        width: '100%', 
        minHeight: '100vh', 
        backgroundColor: '#FAF9F5', 
        fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif',
        display: 'flex',
        flexDirection: 'column',
      }}>
        {/* Header */}
        <header style={{
          display: 'flex',
          justifyContent: 'space-between',
          alignItems: 'center',
          padding: windowWidth < 640 ? '24px 20px' : '32px 32px',
        }}>
          {/* Logo */}
          <div style={{
            fontFamily: 'Georgia, serif',
            fontSize: windowWidth < 640 ? '20px' : '24px',
            fontWeight: '400',
            color: '#C96442',
            letterSpacing: '0.01em',
          }}>
            Relate
          </div>
          
          {/* Desktop Navigation */}
          {windowWidth > 640 ? (
            <nav style={{ display: 'flex', alignItems: 'center', gap: '4px' }}>
              <button 
                onClick={() => setCurrentPage('calculator')} 
                style={navLinkStyle()}
                onMouseEnter={(e) => e.target.style.backgroundColor = '#E5E2DA'}
                onMouseLeave={(e) => e.target.style.backgroundColor = 'transparent'}
              >
                Calculator
              </button>
              <button 
                onClick={() => setCurrentPage('calculator')} 
                style={navLinkStyle()}
                onMouseEnter={(e) => e.target.style.backgroundColor = '#E5E2DA'}
                onMouseLeave={(e) => e.target.style.backgroundColor = 'transparent'}
              >
                Assessment
              </button>
              <button 
                onClick={() => {}} 
                style={navLinkStyle()}
                onMouseEnter={(e) => e.target.style.backgroundColor = '#E5E2DA'}
                onMouseLeave={(e) => e.target.style.backgroundColor = 'transparent'}
              >
                Coaching
              </button>
              <button 
                onClick={() => {}} 
                style={navLinkStyle()}
                onMouseEnter={(e) => e.target.style.backgroundColor = '#E5E2DA'}
                onMouseLeave={(e) => e.target.style.backgroundColor = 'transparent'}
              >
                About
              </button>
            </nav>
          ) : (
            /* Mobile Hamburger */
            <div style={{ position: 'relative' }}>
              <button
                onClick={() => setHomeMenuOpen(!homeMenuOpen)}
                style={{
                  width: '36px',
                  height: '36px',
                  border: 'none',
                  borderRadius: '4px',
                  backgroundColor: homeMenuOpen ? '#E5E2DA' : 'transparent',
                  cursor: 'pointer',
                  display: 'flex',
                  flexDirection: 'column',
                  alignItems: 'center',
                  justifyContent: 'center',
                  gap: '4px',
                }}
              >
                <div style={{ width: '18px', height: '2px', backgroundColor: '#3D3929', borderRadius: '1px' }} />
                <div style={{ width: '18px', height: '2px', backgroundColor: '#3D3929', borderRadius: '1px' }} />
                <div style={{ width: '18px', height: '2px', backgroundColor: '#3D3929', borderRadius: '1px' }} />
              </button>
              
              {homeMenuOpen && (
                <div style={{
                  position: 'absolute',
                  top: '44px',
                  right: '0',
                  backgroundColor: 'white',
                  border: '1px solid #E5E2DA',
                  borderRadius: '6px',
                  padding: '8px',
                  boxShadow: '0 4px 12px rgba(0,0,0,0.08)',
                  zIndex: 100,
                  minWidth: '140px',
                  display: 'flex',
                  flexDirection: 'column',
                  gap: '4px',
                }}>
                  <button 
                    onClick={() => { setCurrentPage('calculator'); setHomeMenuOpen(false); }} 
                    style={{ ...navLinkStyle(), width: '100%', justifyContent: 'flex-start' }}
                  >
                    Calculator
                  </button>
                  <button 
                    onClick={() => { setCurrentPage('calculator'); setHomeMenuOpen(false); }} 
                    style={{ ...navLinkStyle(), width: '100%', justifyContent: 'flex-start' }}
                  >
                    Assessment
                  </button>
                  <button 
                    onClick={() => { setHomeMenuOpen(false); }} 
                    style={{ ...navLinkStyle(), width: '100%', justifyContent: 'flex-start' }}
                  >
                    Coaching
                  </button>
                  <button 
                    onClick={() => { setHomeMenuOpen(false); }} 
                    style={{ ...navLinkStyle(), width: '100%', justifyContent: 'flex-start' }}
                  >
                    About
                  </button>
                </div>
              )}
            </div>
          )}
        </header>
        
        {/* Hero Content */}
        <main style={{
          flex: 1,
          display: 'flex',
          alignItems: windowWidth < 640 ? 'flex-start' : 'flex-end',
          justifyContent: windowWidth < 640 ? 'center' : 'flex-start',
          padding: windowWidth < 640 ? '24px 20px' : '32px 32px',
        }}>
          <p style={{
            fontFamily: 'Georgia, serif',
            fontSize: windowWidth < 640 ? '20px' : getHeroFontSize(),
            fontWeight: '400',
            color: '#5C5A4D',
            lineHeight: '1.35',
            maxWidth: windowWidth < 640 ? '100%' : '85%',
            margin: 0,
            textAlign: 'left',
          }}>
            <span style={{ fontStyle: 'italic', color: '#C96442' }}>Relate</span> is the <span style={{ fontStyle: 'italic', color: '#C96442' }}>first</span> market intelligence platform for relationships and dating. With the help of Claude and public datasets, we help users measure their local dating economy, uncovering key insights hidden by leading dating apps. Relate offers a <span style={{ fontStyle: 'italic', textDecoration: 'underline' }}>calculator</span> to understand how income, geography, demographics, and preferences in dating shape opportunity. We also offer a <span style={{ fontStyle: 'italic', textDecoration: 'underline' }}>personality assessment</span> and custom <span style={{ fontStyle: 'italic', textDecoration: 'underline' }}>AI coaching</span> to refine dating goals and <span style={{ fontStyle: 'italic', color: '#C96442' }}>improve outcomes</span>.
          </p>
        </main>
      </div>
    );
  }

  // Calculator Page
  if (currentPage === 'calculator') {
    return (
      <div style={{ width: '100%', padding: '32px 32px', backgroundColor: '#FAF9F5', minHeight: '100vh', fontFamily: 'Georgia, serif' }}>
        <div style={{ maxWidth: `${containerWidth}px`, margin: '0 auto' }}>
          
          {/* Header */}
          <PageHeader 
            currentPage={currentPage} 
            setCurrentPage={setCurrentPage} 
            scaledFont={scaledFont} 
            windowWidth={windowWidth} 
            containerWidth={containerWidth} 
            setContainerWidth={setContainerWidth} 
          />

          {/* Summary */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.6' }}>
              Relate Markets reconstructs your complete income trajectory and translates every data point into comparable terms across time and place. A single income number tells you almost nothing without context. Earning $150,000 means something very different in San Francisco than in St. Louis, in 2008 than in 2024, at age 28 than at age 45. This tool adjusts for inflation, regional cost of living, and national income distribution so you can see real progress rather than nominal changes. The result is a map of the economic landscape you've navigated, with markers showing where you were fragile, where you stabilized, and where you finally pulled ahead. And we have added scores that show how income, education, and some basic identity markers shape your relationships and the local dating economy.
            </p>
          </div>

          {/* Instructions */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Instructions</h2>
            <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.6' }}>
              Complete the sections below in order. Start with your demographic information, then career context, then your income history. For income history, you need at least 3 years but can add up to 15. Choose years that represent inflection points in your journey: first job, promotions, moves, major life changes. Include your current year as the final entry. All information is used solely to generate your personalized analysis and is never shared.
            </p>
          </div>

          {/* Demographics Section */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 16px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Demographics</h2>
            
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px' }}>
              <div>
                <label style={labelStyle}>First Name</label>
                <input
                  type="text"
                  value={formData.firstName}
                  onChange={(e) => updateFormField('firstName', e.target.value)}
                  style={inputStyle}
                  placeholder="Your first name"
                />
              </div>
              
              <div>
                <label style={labelStyle}>Gender</label>
                <select
                  value={formData.gender}
                  onChange={(e) => updateFormField('gender', e.target.value)}
                  style={selectStyle}
                >
                  <option value="">Select...</option>
                  <option value="man">Man</option>
                  <option value="woman">Woman</option>
                </select>
              </div>
              
              <div>
                <label style={labelStyle}>Ethnicity</label>
                <select
                  value={formData.ethnicity}
                  onChange={(e) => updateFormField('ethnicity', e.target.value)}
                  style={selectStyle}
                >
                  <option value="">Select...</option>
                  <option value="white">White</option>
                  <option value="hispanic">Hispanic/Latino</option>
                  <option value="black">Black</option>
                  <option value="asian">Asian</option>
                  <option value="native">Native American</option>
                  <option value="pacific">Pacific Islander</option>
                  <option value="other">Other/Mixed</option>
                </select>
              </div>
              
              <div>
                <label style={labelStyle}>Orientation</label>
                <select
                  value={formData.orientation}
                  onChange={(e) => updateFormField('orientation', e.target.value)}
                  style={selectStyle}
                >
                  <option value="">Select...</option>
                  <option value="straight">Straight</option>
                  <option value="gay">Gay/Lesbian</option>
                  <option value="bisexual">Bisexual</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>
          </div>
          
          {/* Your Career Timeline Section */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 16px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Your Career Timeline</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px' }}>
              <div>
                <label style={labelStyle}>Birth Month & Year</label>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                  <select value={vizSettings.birthMonth} onChange={(e) => setVizSettings({...vizSettings, birthMonth: e.target.value})} style={selectStyle}>
                    <option value="">Month</option>
                    {months.map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                  <select value={vizSettings.birthYear} onChange={(e) => setVizSettings({...vizSettings, birthYear: e.target.value})} style={selectStyle}>
                    <option value="">Year</option>
                    {birthYears.map(y => <option key={y} value={y}>{y}</option>)}
                  </select>
                </div>
              </div>
              
              <div>
                <label style={labelStyle}>Started Working</label>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '8px' }}>
                  <select value={vizSettings.workStartMonth} onChange={(e) => setVizSettings({...vizSettings, workStartMonth: e.target.value})} style={selectStyle}>
                    <option value="">Month</option>
                    {months.map(m => <option key={m} value={m}>{m}</option>)}
                  </select>
                  <select value={vizSettings.workStartYear} onChange={(e) => setVizSettings({...vizSettings, workStartYear: e.target.value})} style={selectStyle}>
                    <option value="">Year</option>
                    {birthYears.map(y => <option key={y} value={y}>{y}</option>)}
                  </select>
                </div>
              </div>
              
              <div>
                <label style={labelStyle}>Planned Retirement Age</label>
                <select value={vizSettings.retireAge} onChange={(e) => setVizSettings({...vizSettings, retireAge: e.target.value})} style={selectStyle}>
                  {[50, 52, 55, 57, 60, 62, 65, 67, 70, 72, 75, 80, 85, 90].map(age => <option key={age} value={age}>{age}</option>)}
                </select>
              </div>
            </div>
          </div>

          {/* First Job Section */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 16px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>First Job</h2>
            <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 16px', lineHeight: '1.5' }}>
              Tell us about where you started your career after completing your highest level of education.
            </p>
            
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '16px' }}>
              <div>
                <label style={labelStyle}>Job Title</label>
                <input
                  type="text"
                  value={formData.firstJobTitle}
                  onChange={(e) => updateFormField('firstJobTitle', e.target.value)}
                  style={inputStyle}
                  placeholder="e.g., Junior Analyst"
                />
              </div>
              
              <div>
                <label style={labelStyle}>Year</label>
                <input
                  type="number"
                  value={formData.firstJobYear}
                  onChange={(e) => updateFormField('firstJobYear', e.target.value)}
                  style={inputStyle}
                  placeholder="e.g., 2004"
                  min="1950"
                  max="2025"
                />
              </div>
              
              <div>
                <label style={labelStyle}>Industry Sector</label>
                <select
                  value={formData.firstSector}
                  onChange={(e) => updateFormField('firstSector', e.target.value)}
                  style={selectStyle}
                >
                  <option value="">Select...</option>
                  <option value="technology">Technology</option>
                  <option value="finance">Finance</option>
                  <option value="healthcare">Healthcare</option>
                  <option value="government">Government</option>
                  <option value="education">Education</option>
                  <option value="manufacturing">Manufacturing</option>
                  <option value="retail">Retail</option>
                  <option value="energy">Energy</option>
                  <option value="consulting">Consulting</option>
                  <option value="legal">Legal</option>
                  <option value="media">Media/Entertainment</option>
                  <option value="nonprofit">Nonprofit</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>
          </div>

          {/* Income History Section */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
              <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: 0, textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                Income History ({formData.incomeYears.length} of 15 years)
              </h2>
              {formData.incomeYears.length < 15 && (
                <button
                  onClick={addIncomeYear}
                  style={{
                    height: '28px',
                    padding: '0 12px',
                    border: 'none',
                    borderRadius: '4px',
                    backgroundColor: '#F5F3ED',
                    cursor: 'pointer',
                    fontSize: '11px',
                    fontWeight: '500',
                    color: '#3D3929',
                    display: 'flex',
                    alignItems: 'center',
                    gap: '4px',
                  }}
                >
                  + Add Year
                </button>
              )}
            </div>

            {formData.gender === 'woman' ? (
              <>
                <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.5' }}>
                  Please fill out the following information about your career journey. You may start with your parents' household income when you were 18 (common if they supported you through college or early career). Or you may start with your first job as an adult. For the goal field, think back to what your financial expectations or goals were at that time. What did you view as your ideal salary? What income level did you aspire to reach in your career at that point in your life?
                </p>
                <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.5' }}>
                  Do not worry if you delete a year or add a year out of order. Relate Markets automatically sorts your entries in chronological order when delivering your report.
                </p>
                <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.5' }}>
                  We start with three years, but you can add up to 15. Not every year must be added over your entire career arc.
                </p>
                <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 16px', lineHeight: '1.5' }}>
                  You must fill in all fields.
                </p>
              </>
            ) : (
              <>
                <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.5' }}>
                  Please fill out the following information about your career journey. You may start with your parents' household income when you were 18 (common if they supported you through college or early career). Or you may start with your first job as an adult. For the goal field, think back to what your financial expectations or goals were at that time. What did you view as your ideal salary? What income level did you aspire to reach in your career at that point in your life?
                </p>
                <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.5' }}>
                  Do not worry if you delete a year or add a year out of order. Relate Markets automatically sorts your entries in chronological order when delivering your report.
                </p>
                <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.5' }}>
                  We start with three years, but you can add up to 15. Not every year must be added over your entire career arc.
                </p>
                <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 16px', lineHeight: '1.5' }}>
                  You must fill in all fields.
                </p>
              </>
            )}
            
            {/* Desktop: Table layout */}
            {windowWidth > 900 ? (
              <div style={{ overflowX: 'auto' }}>
                <table style={{ width: '100%', fontSize: scaledFont(10), borderCollapse: 'collapse' }}>
                  <thead>
                    <tr style={{ backgroundColor: '#FAF9F5' }}>
                      <th style={{ padding: '8px 6px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap', width: '30px' }}>#</th>
                      <th style={{ padding: '8px 6px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Year</th>
                      <th style={{ padding: '8px 6px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Your Age</th>
                      <th style={{ padding: '8px 6px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Location</th>
                      <th style={{ padding: '8px 6px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>ZIP Code</th>
                      <th style={{ padding: '8px 6px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Income</th>
                      <th style={{ padding: '8px 6px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Goal</th>
                      <th style={{ padding: '8px 6px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Married</th>
                      <th style={{ padding: '8px 6px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Children</th>
                      <th style={{ padding: '8px 6px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Education</th>
                      {formData.incomeYears.length > 5 && (
                        <th style={{ padding: '8px 6px', textAlign: 'center', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', width: '40px' }}></th>
                      )}
                    </tr>
                  </thead>
                  <tbody>
                    {formData.incomeYears.map((yearData, i) => (
                      <tr key={i} style={{ backgroundColor: i % 2 ? '#FAFAF8' : 'white' }}>
                        <td style={{ padding: '6px', fontWeight: '600', color: '#73726C' }}>{i + 1}</td>
                        <td style={{ padding: '4px' }}>
                          <input
                            type="number"
                            value={yearData.year}
                            onChange={(e) => updateIncomeYear(i, 'year', e.target.value)}
                            onWheel={(e) => e.target.blur()}
                            style={{ ...inputStyle, padding: '6px 8px', width: '70px' }}
                            placeholder="2020"
                            min="1970"
                            max="2025"
                          />
                        </td>
                        <td style={{ padding: '4px' }}>
                          <input
                            type="number"
                            value={yearData.age}
                            onChange={(e) => updateIncomeYear(i, 'age', e.target.value)}
                            onWheel={(e) => e.target.blur()}
                            style={{ ...inputStyle, padding: '6px 8px', width: '55px' }}
                            placeholder="25"
                            min="16"
                            max="100"
                          />
                        </td>
                        <td style={{ padding: '4px' }}>
                          <input
                            type="text"
                            value={yearData.location}
                            onChange={(e) => updateIncomeYear(i, 'location', e.target.value)}
                            style={{ ...inputStyle, padding: '6px 8px', minWidth: '120px' }}
                            placeholder="City, ST"
                          />
                        </td>
                        <td style={{ padding: '4px' }}>
                          <input
                            type="text"
                            value={yearData.zipCode}
                            onChange={(e) => updateIncomeYear(i, 'zipCode', e.target.value.replace(/\D/g, '').slice(0, 5))}
                            style={{ ...inputStyle, padding: '6px 8px', width: '70px' }}
                            placeholder="12345"
                            maxLength={5}
                          />
                        </td>
                        <td style={{ padding: '4px' }}>
                          <input
                            type="number"
                            value={yearData.income}
                            onChange={(e) => updateIncomeYear(i, 'income', e.target.value)}
                            onWheel={(e) => e.target.blur()}
                            style={{ ...inputStyle, padding: '6px 8px', width: '90px' }}
                            placeholder="75000"
                          />
                        </td>
                        <td style={{ padding: '4px' }}>
                          <input
                            type="number"
                            value={yearData.goal}
                            onChange={(e) => updateIncomeYear(i, 'goal', e.target.value)}
                            onWheel={(e) => e.target.blur()}
                            style={{ ...inputStyle, padding: '6px 8px', width: '90px' }}
                            placeholder="100000"
                          />
                        </td>
                        <td style={{ padding: '4px' }}>
                          <select
                            value={yearData.married}
                            onChange={(e) => updateIncomeYear(i, 'married', e.target.value)}
                            style={{ ...selectStyle, padding: '6px 4px', width: '70px' }}
                          >
                            <option value="">...</option>
                            <option value="no">No</option>
                            <option value="yes">Yes</option>
                          </select>
                        </td>
                        <td style={{ padding: '4px' }}>
                          <select
                            value={yearData.children}
                            onChange={(e) => updateIncomeYear(i, 'children', e.target.value)}
                            style={{ ...selectStyle, padding: '6px 4px', width: '70px' }}
                          >
                            <option value="">...</option>
                            <option value="no">No</option>
                            <option value="yes">Yes</option>
                          </select>
                        </td>
                        <td style={{ padding: '4px' }}>
                          <select
                            value={yearData.education}
                            onChange={(e) => updateIncomeYear(i, 'education', e.target.value)}
                            style={{ ...selectStyle, padding: '6px 4px', width: '100px' }}
                          >
                            <option value="">Select...</option>
                            <option value="hs">High School</option>
                            <option value="some_college">Some College</option>
                            <option value="trade">Trade School</option>
                            <option value="associate">Associate</option>
                            <option value="bachelors">Bachelor's</option>
                            <option value="graduate">Graduate</option>
                          </select>
                        </td>
                        {formData.incomeYears.length > 5 && (
                          <td style={{ padding: '4px', textAlign: 'center' }}>
                            <button
                              onClick={() => removeIncomeYear(i)}
                              style={{
                                width: '24px',
                                height: '24px',
                                border: 'none',
                                borderRadius: '4px',
                                backgroundColor: '#F5F3ED',
                                cursor: 'pointer',
                                fontSize: '14px',
                                color: '#73726C',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                              }}
                            >
                              ×
                            </button>
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              /* Mobile: Card layout with 3 rows per year */
              <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                {formData.incomeYears.map((yearData, i) => (
                  <div key={i} style={{ 
                    backgroundColor: i % 2 ? '#FAFAF8' : 'white', 
                    border: '1px solid #e5e7eb', 
                    borderRadius: '4px', 
                    padding: '12px',
                  }}>
                    {/* Header with year number and delete */}
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '10px' }}>
                      <span style={{ fontSize: scaledFont(11), fontWeight: '600', color: '#141413' }}>Year {i + 1}</span>
                      {formData.incomeYears.length > 5 && (
                        <button
                          onClick={() => removeIncomeYear(i)}
                          style={{
                            width: '24px',
                            height: '24px',
                            border: 'none',
                            borderRadius: '4px',
                            backgroundColor: '#F5F3ED',
                            cursor: 'pointer',
                            fontSize: '14px',
                            color: '#73726C',
                          }}
                        >
                          ×
                        </button>
                      )}
                    </div>
                    
                    {/* Row 1: Year, Age, Location */}
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1.5fr', gap: '8px', marginBottom: '8px' }}>
                      <div>
                        <label style={{ ...labelStyle, fontSize: scaledFont(9) }}>Year</label>
                        <input
                          type="number"
                          value={yearData.year}
                          onChange={(e) => updateIncomeYear(i, 'year', e.target.value)}
                          onWheel={(e) => e.target.blur()}
                          style={{ ...inputStyle, padding: '6px 8px', width: '100%' }}
                          placeholder="2020"
                        />
                      </div>
                      <div>
                        <label style={{ ...labelStyle, fontSize: scaledFont(9) }}>Age</label>
                        <input
                          type="number"
                          value={yearData.age}
                          onChange={(e) => updateIncomeYear(i, 'age', e.target.value)}
                          onWheel={(e) => e.target.blur()}
                          style={{ ...inputStyle, padding: '6px 8px', width: '100%' }}
                          placeholder="25"
                        />
                      </div>
                      <div>
                        <label style={{ ...labelStyle, fontSize: scaledFont(9) }}>Location</label>
                        <input
                          type="text"
                          value={yearData.location}
                          onChange={(e) => updateIncomeYear(i, 'location', e.target.value)}
                          style={{ ...inputStyle, padding: '6px 8px', width: '100%' }}
                          placeholder="City, ST"
                        />
                      </div>
                    </div>
                    
                    {/* Row 2: ZIP, Income, Goal */}
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: '8px', marginBottom: '8px' }}>
                      <div>
                        <label style={{ ...labelStyle, fontSize: scaledFont(9) }}>ZIP</label>
                        <input
                          type="text"
                          value={yearData.zipCode}
                          onChange={(e) => updateIncomeYear(i, 'zipCode', e.target.value.replace(/\D/g, '').slice(0, 5))}
                          style={{ ...inputStyle, padding: '6px 8px', width: '100%' }}
                          placeholder="12345"
                        />
                      </div>
                      <div>
                        <label style={{ ...labelStyle, fontSize: scaledFont(9) }}>Income</label>
                        <input
                          type="number"
                          value={yearData.income}
                          onChange={(e) => updateIncomeYear(i, 'income', e.target.value)}
                          onWheel={(e) => e.target.blur()}
                          style={{ ...inputStyle, padding: '6px 8px', width: '100%' }}
                          placeholder="75000"
                        />
                      </div>
                      <div>
                        <label style={{ ...labelStyle, fontSize: scaledFont(9) }}>Goal</label>
                        <input
                          type="number"
                          value={yearData.goal}
                          onChange={(e) => updateIncomeYear(i, 'goal', e.target.value)}
                          onWheel={(e) => e.target.blur()}
                          style={{ ...inputStyle, padding: '6px 8px', width: '100%' }}
                          placeholder="100000"
                        />
                      </div>
                    </div>
                    
                    {/* Row 3: Married, Children, Education */}
                    <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1.5fr', gap: '8px' }}>
                      <div>
                        <label style={{ ...labelStyle, fontSize: scaledFont(9) }}>Married</label>
                        <select
                          value={yearData.married}
                          onChange={(e) => updateIncomeYear(i, 'married', e.target.value)}
                          style={{ ...selectStyle, padding: '6px 4px', width: '100%' }}
                        >
                          <option value="">...</option>
                          <option value="no">No</option>
                          <option value="yes">Yes</option>
                        </select>
                      </div>
                      <div>
                        <label style={{ ...labelStyle, fontSize: scaledFont(9) }}>Children</label>
                        <select
                          value={yearData.children}
                          onChange={(e) => updateIncomeYear(i, 'children', e.target.value)}
                          style={{ ...selectStyle, padding: '6px 4px', width: '100%' }}
                        >
                          <option value="">...</option>
                          <option value="no">No</option>
                          <option value="yes">Yes</option>
                        </select>
                      </div>
                      <div>
                        <label style={{ ...labelStyle, fontSize: scaledFont(9) }}>Education</label>
                        <select
                          value={yearData.education}
                          onChange={(e) => updateIncomeYear(i, 'education', e.target.value)}
                          style={{ ...selectStyle, padding: '6px 4px', width: '100%' }}
                        >
                          <option value="">Select...</option>
                          <option value="hs">High School</option>
                          <option value="some_college">Some College</option>
                          <option value="trade">Trade School</option>
                          <option value="associate">Associate</option>
                          <option value="bachelors">Bachelor's</option>
                          <option value="graduate">Graduate</option>
                        </select>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Current Job Section */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 16px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Current Job</h2>
            <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 16px', lineHeight: '1.5' }}>
              Your current position and industry.
            </p>
            
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '16px' }}>
              <div>
                <label style={labelStyle}>Job Title</label>
                <input
                  type="text"
                  value={formData.currentJobTitle}
                  onChange={(e) => updateFormField('currentJobTitle', e.target.value)}
                  style={inputStyle}
                  placeholder="e.g., Senior Director"
                />
              </div>
              
              <div>
                <label style={labelStyle}>Industry Sector</label>
                <select
                  value={formData.currentSector}
                  onChange={(e) => updateFormField('currentSector', e.target.value)}
                  style={selectStyle}
                >
                  <option value="">Select...</option>
                  <option value="technology">Technology</option>
                  <option value="finance">Finance</option>
                  <option value="healthcare">Healthcare</option>
                  <option value="government">Government</option>
                  <option value="education">Education</option>
                  <option value="manufacturing">Manufacturing</option>
                  <option value="retail">Retail</option>
                  <option value="energy">Energy</option>
                  <option value="consulting">Consulting</option>
                  <option value="legal">Legal</option>
                  <option value="media">Media/Entertainment</option>
                  <option value="nonprofit">Nonprofit</option>
                  <option value="other">Other</option>
                </select>
              </div>
            </div>

            {formData.firstSector && formData.currentSector && formData.firstSector !== formData.currentSector && (
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '16px', paddingTop: '16px', marginTop: '16px', borderTop: '1px solid #EBE8E0' }}>
                <div>
                  <label style={labelStyle}>Sector Transition Year</label>
                  <input
                    type="number"
                    value={formData.sectorTransitionYear}
                    onChange={(e) => updateFormField('sectorTransitionYear', e.target.value)}
                    onWheel={(e) => e.target.blur()}
                    style={inputStyle}
                    placeholder="e.g., 2015"
                    min="1970"
                    max="2025"
                  />
                </div>
                
                <div>
                  <label style={labelStyle}>What Drove the Change?</label>
                  <input
                    type="text"
                    value={formData.sectorTransitionReason}
                    onChange={(e) => updateFormField('sectorTransitionReason', e.target.value)}
                    style={inputStyle}
                    placeholder="e.g., Better opportunity, relocation, etc."
                  />
                </div>
              </div>
            )}
          </div>

          {/* Action Button - only appears when form is complete */}
          {isBasicFormComplete() && (
            <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '16px' }}>
              <button
                onClick={() => {
                  if (triggeredProbes.length > 0) {
                    setCurrentProbeIndex(0);
                    setCurrentPage('interview');
                  } else {
                    setCurrentPage('report');
                  }
                }}
                style={{
                  height: '44px',
                  padding: '0 32px',
                  border: 'none',
                  borderRadius: '6px',
                  backgroundColor: '#C96442',
                  cursor: 'pointer',
                  fontSize: scaledFont(13),
                  fontWeight: '600',
                  color: 'white',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  letterSpacing: '0.02em',
                }}
              >
                {triggeredProbes.length > 0 ? 'Continue' : 'Generate Analysis'}
              </button>
            </div>
          )}

          {/* Footer */}
          <div style={{ padding: '10px 12px', backgroundColor: '#F5F3ED', borderRadius: '4px', fontSize: scaledFont(9), color: '#73726C', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '8px' }}>
            <span>Your data is processed locally and used solely to generate your personalized Relate Markets analysis. Nothing is stored or shared.</span>
            {hasUnsavedData && (
              <button 
                onClick={() => {
                  if (confirm('Clear all saved progress? This cannot be undone.')) {
                    clearSavedProgress();
                  }
                }}
                style={{ 
                  background: 'none', 
                  border: 'none', 
                  color: '#9C9A91', 
                  fontSize: scaledFont(9), 
                  cursor: 'pointer',
                  textDecoration: 'underline',
                  padding: 0,
                }}
              >
                Clear saved progress
              </button>
            )}
          </div>
        </div>
      </div>
    );
  }

  // Contextual Interview Page
  if (currentPage === 'interview') {
    const currentProbe = triggeredProbes[currentProbeIndex];
    const isCurrentAnswered = formData.probeResponses[currentProbe?.id]?.trim();
    const isLastProbe = currentProbeIndex === triggeredProbes.length - 1;
    const isFirstProbe = currentProbeIndex === 0;

    // Handler to generate report when clicking "Generate Analysis"
    const handleGenerateReport = async () => {
      setReportGenerating(true);
      setGenerationProgress({ current: 0, total: 9, cardName: 'Validating data...' });
      
      try {
        const filledYears = formData.incomeYears.filter(y => y.year && y.income && y.location && y.zipCode);
        
        // =============================================================================
        // VALIDATION GATE - Check all data before proceeding
        // =============================================================================
        const validationErrors = [];
        
        // Check 1: GitHub CBSA data loaded
        if (!cbsaDataLoaded || Object.keys(cbsaDataLoaded).length === 0) {
          validationErrors.push('Metro area data failed to load. Please refresh the page.');
        }
        
        // Check 2: ZIP data loaded
        if (!zipDataLoaded || Object.keys(zipDataLoaded).length === 0) {
          validationErrors.push('ZIP code data failed to load. Please refresh the page.');
        }
        
        // Check 3: Required user profile fields
        if (!formData.gender) {
          validationErrors.push('Please select your gender in the Calculator.');
        }
        if (!formData.ethnicity) {
          validationErrors.push('Please select your ethnicity in the Calculator.');
        }
        
        // If critical errors, stop early
        if (validationErrors.length > 0) {
          setReportGenerating(false);
          alert('Cannot generate report:\\n\\n' + validationErrors.join('\\n'));
          return;
        }
        
        // Haversine distance calculation for CBSA lookup
        const haversineDistance = (lat1, lng1, lat2, lng2) => {
          const R = 6371;
          const dLat = (lat2 - lat1) * Math.PI / 180;
          const dLng = (lng2 - lng1) * Math.PI / 180;
          const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                    Math.sin(dLng/2) * Math.sin(dLng/2);
          return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        };
        
        // Find nearest CBSA using ZIP centroid
        const findCBSAByZip = (zipCode) => {
          const zipCoords = zipDataLoaded[zipCode];
          if (!zipCoords) return null;
          
          let nearest = null;
          let minDist = Infinity;
          
          for (const [name, cbsa] of Object.entries(cbsaDataLoaded)) {
            const dist = haversineDistance(zipCoords.lat, zipCoords.lng, cbsa.lat, cbsa.lng);
            if (dist < minDist) {
              minDist = dist;
              nearest = { ...cbsa, name };
            }
          }
          return nearest;
        };
        
        // Check 4: Validate each year has CBSA match with required fields
        const requiredCbsaFields = [
          'cbsa_population', 'rpp', 'income_cbsa', 'bachelors_cbsa', 'pct_white_cbsa',
          'gender_woman_cbsa', 'gender_man_cbsa', 'female_cbsa', 'male_cbsa',
          'relationship_single_cbsa', 'single_18_65_cbsa'
        ];
        
        const yearErrors = [];
        filledYears.forEach(row => {
          const cbsa = findCBSAByZip(row.zipCode);
          if (!cbsa) {
            yearErrors.push(`Year ${row.year}: Could not find metro for ZIP ${row.zipCode}. Please verify the ZIP code.`);
          } else {
            const missing = requiredCbsaFields.filter(f => cbsa[f] === undefined || cbsa[f] === null);
            if (missing.length > 0) {
              yearErrors.push(`Year ${row.year}: Metro "${cbsa.name}" is missing data. Try a nearby major city.`);
            }
          }
        });
        
        if (yearErrors.length > 0) {
          setReportGenerating(false);
          alert('Cannot generate report - location issues:\\n\\n' + yearErrors.join('\\n'));
          return;
        }
        // =============================================================================
        // END VALIDATION GATE - All data verified, proceed with calculations
        // =============================================================================
        
        setGenerationProgress({ current: 0, total: 9, cardName: 'Building data...' });
        
        // Build reportData using proper CBSA calculations
        const reportData = filledYears.map((row) => {
          const yearNum = parseInt(row.year);
          const income = parseInt(row.income);
          const age = parseInt(row.age) || 30;
          const married = row.married || 'no';
          const children = row.children || 'no';
          const education = row.education || 'bachelors';
          const goal = parseInt(row.goal) || 150000;
          
          // CBSA lookup for proper calculations
          const cbsa = findCBSAByZip(row.zipCode);
          const rpp = cbsa?.rpp || 100;
          const cpi = CPI_DATA[yearNum] || CPI_DATA[2025];
          const cpi2025 = CPI_DATA[2025];
          
          const colFamily4 = Math.round(137822 * (rpp / 100) * (cpi / cpi2025));
          const greenLine = Math.round(colFamily4 * 1.35);
          const medianHH = Math.round(MEDIAN_DATA[yearNum] * (rpp / 100));
          const povertyLine = Math.round(POVERTY_DATA[yearNum] * (rpp / 100));
          
          // User profile for calculation module
          const user = {
            age,
            income,
            education,
            gender: formData.gender || 'man',
            ethnicity: formData.ethnicity || 'white',
            orientation: formData.orientation || 'straight',
            hasKids: children === 'yes',
            relationshipStatus: married
          };
          
          // Partner preferences from formData (if available)
          const partnerPrefs = formData.partnerPrefs || {};
          
          // User profile attributes for sigmoid calculation
          const userProfile = {
            height: formData.height || null,
            bodyType: formData.bodyType || 'average',
            workoutFrequency: formData.workoutFrequency || 'never',
            politicalViews: formData.politicalViews || 'moderate',
            smoking: formData.smoking || 'no'
          };
          
          // Use SHARED CALCULATION MODULE for proper scores
          const { relateScore, incomeLocal, components: relateComponents } = calculateRelateScore(user, cbsa || DEFAULT_CBSA, colFamily4);
          
          // Use three-tier calculation for dating metrics
          const threeTier = calculateThreeTierMatches(user, cbsa || DEFAULT_CBSA, partnerPrefs, userProfile);
          const percentile = Math.round(incomeLocal);
          
          return {
            year: yearNum,
            location: row.location,
            age,
            income,
            goal,
            greenLine,
            medianHH,
            povertyLine,
            percentile,
            married,
            children,
            education,
            relateScore: Math.round(relateScore * 10) / 10,
            relateComponents,
            // Legacy fields
            matchScore: threeTier.matchScore,
            matchPool: threeTier.matchPool,
            localSinglePool: threeTier.localSinglePool,
            // Three-tier fields
            realisticPool: threeTier.realisticPool,
            realisticMatches: threeTier.realisticMatches,
            realisticMatchRate: threeTier.realisticMatchRate,
            preferredPool: threeTier.preferredPool,
            preferredMatches: threeTier.preferredMatches,
            preferredMatchRate: threeTier.preferredMatchRate,
            idealPool: threeTier.idealPool,
            idealMatches: threeTier.idealMatches,
            idealMatchRate: threeTier.idealMatchRate,
            relateScoreOutOf10: threeTier.relateScoreOutOf10,
            population: cbsa?.cbsa_population || 100000,
            targetGenderLabel: threeTier.targetGenderLabel
          };
        }).sort((a, b) => a.year - b.year);
        
        // Generate all narratives
        const narratives = await generateAllNarratives(
          reportData, 
          formData,
          (progress) => setGenerationProgress(progress)
        );
        
        // Store the generated content
        setNarrativeContent(narratives);
        
        // Navigate to report
        setCurrentPage('report');
      } catch (error) {
        console.error('Error generating report:', error);
        alert('Error generating report. Please try again.');
      } finally {
        setReportGenerating(false);
      }
    };

    // Show generating overlay if in progress
    if (reportGenerating) {
      return (
        <div style={{ width: '100%', padding: '32px 32px', backgroundColor: '#FAF9F5', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', display: 'flex', flexDirection: 'column' }}>
          <div style={{ maxWidth: `${containerWidth}px`, margin: '0 auto', width: '100%', flex: 1, display: 'flex', flexDirection: 'column' }}>
            <PageHeader 
              currentPage={currentPage} 
              setCurrentPage={setCurrentPage} 
              scaledFont={scaledFont} 
              windowWidth={windowWidth} 
              containerWidth={containerWidth} 
              setContainerWidth={setContainerWidth} 
            />
            <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '48px 24px', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
              <div style={{ fontSize: scaledFont(18), fontWeight: '700', color: '#141413', marginBottom: '8px', textAlign: 'center' }}>
                {generationProgress.trajectoryName || 'Your Journey'}
              </div>
              <div style={{ fontSize: scaledFont(14), color: '#C96442', fontWeight: '600', marginBottom: '24px', textAlign: 'center' }}>
                {generationProgress.cardName || 'Starting...'}
              </div>
              <div style={{ height: '8px', backgroundColor: '#E5E2DA', borderRadius: '4px', overflow: 'hidden', maxWidth: '300px', width: '100%' }}>
                <div style={{ height: '100%', backgroundColor: '#C96442', borderRadius: '4px', width: `${(generationProgress.current / generationProgress.total) * 100}%`, transition: 'width 0.3s ease' }} />
              </div>
              <div style={{ fontSize: scaledFont(11), color: '#9A9891', marginTop: '12px', textAlign: 'center' }}>
                {generationProgress.current} of {generationProgress.total}
              </div>
              <div style={{ fontSize: scaledFont(11), color: '#73726C', marginTop: '16px', textAlign: 'center' }}>
                Claude AI is analyzing your answers and generating your report
              </div>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div style={{ width: '100%', padding: '32px 32px', backgroundColor: '#FAF9F5', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
        <div style={{ maxWidth: `${containerWidth}px`, margin: '0 auto' }}>
          
          {/* Header */}
          <PageHeader 
            currentPage={currentPage} 
            setCurrentPage={setCurrentPage} 
            scaledFont={scaledFont} 
            windowWidth={windowWidth} 
            containerWidth={containerWidth} 
            setContainerWidth={setContainerWidth} 
          />

          {/* Progress Bar */}
          <div style={{ marginBottom: '16px' }}>
            <div style={{ height: '4px', backgroundColor: '#E5E2DA', borderRadius: '2px', overflow: 'hidden' }}>
              <div 
                style={{ 
                  height: '100%', 
                  backgroundColor: '#C96442', 
                  borderRadius: '2px',
                  width: `${((currentProbeIndex + (isCurrentAnswered ? 1 : 0)) / triggeredProbes.length) * 100}%`,
                  transition: 'width 0.3s ease'
                }} 
              />
            </div>
          </div>

          {/* Partner Preferences Sections - Only for single users */}
          {isUserCurrentlySingle() && partnerPrefsPhase !== 'complete' && (
            <>
              {/* About You Section */}
              {partnerPrefsPhase === 'about_you' && (
                <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '24px', marginBottom: '16px' }}>
                  <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 16px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    About You
                  </h2>
                  
                  <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 20px', lineHeight: '1.6' }}>
                    Since you're currently single, we want to understand a little bit more about you and what you're looking for in a partner. First, let's start with some questions about you and your lifestyle.
                  </p>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                    {/* Height - Men only */}
                    {(formData.gender === 'man' || formData.gender === 'male' || formData.gender === 'Man') && (
                      <div>
                        <label style={{ display: 'block', fontSize: scaledFont(11), fontWeight: '600', color: '#5C5A4D', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                          How tall are you?
                        </label>
                        <select
                          value={formData.userProfile.height}
                          onChange={(e) => updateUserProfile('height', e.target.value)}
                          style={{
                            width: '100%',
                            maxWidth: '200px',
                            padding: '10px 12px',
                            fontSize: scaledFont(12),
                            border: '1px solid #E5E2DA',
                            borderRadius: '4px',
                            backgroundColor: 'white',
                            color: '#141413',
                            cursor: 'pointer',
                          }}
                        >
                          <option value="">Select height</option>
                          {heightOptions.map(h => (
                            <option key={h} value={h}>{h}</option>
                          ))}
                        </select>
                      </div>
                    )}

                    {/* Body Type */}
                    <div>
                      <label style={{ display: 'block', fontSize: scaledFont(11), fontWeight: '600', color: '#5C5A4D', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                        How would you characterize your body type?
                      </label>
                      <select
                        value={formData.userProfile.bodyType}
                        onChange={(e) => updateUserProfile('bodyType', e.target.value)}
                        style={{
                          width: '100%',
                          maxWidth: '200px',
                          padding: '10px 12px',
                          fontSize: scaledFont(12),
                          border: '1px solid #E5E2DA',
                          borderRadius: '4px',
                          backgroundColor: 'white',
                          color: '#141413',
                          cursor: 'pointer',
                        }}
                      >
                        <option value="">Select body type</option>
                        <option value="lean_fit">Lean or Fit</option>
                        <option value="average">Average</option>
                        <option value="overweight">Overweight</option>
                        <option value="obese">Obese</option>
                      </select>
                    </div>

                    {/* Workout Frequency */}
                    <div>
                      <label style={{ display: 'block', fontSize: scaledFont(11), fontWeight: '600', color: '#5C5A4D', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                        How often do you work out each week?
                      </label>
                      <select
                        value={formData.userProfile.workoutFrequency}
                        onChange={(e) => updateUserProfile('workoutFrequency', e.target.value)}
                        style={{
                          width: '100%',
                          maxWidth: '200px',
                          padding: '10px 12px',
                          fontSize: scaledFont(12),
                          border: '1px solid #E5E2DA',
                          borderRadius: '4px',
                          backgroundColor: 'white',
                          color: '#141413',
                          cursor: 'pointer',
                        }}
                      >
                        <option value="">Select frequency</option>
                        <option value="never">Never</option>
                        <option value="1_day">1 day a week</option>
                        <option value="2_3_days">2 to 3 days a week</option>
                        <option value="4_6_days">4 to 6 days a week</option>
                        <option value="daily">Every day</option>
                      </select>
                    </div>

                    {/* Political Views */}
                    <div>
                      <label style={{ display: 'block', fontSize: scaledFont(11), fontWeight: '600', color: '#5C5A4D', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                        How would you describe your political views?
                      </label>
                      <select
                        value={formData.userProfile.politicalViews}
                        onChange={(e) => updateUserProfile('politicalViews', e.target.value)}
                        style={{
                          width: '100%',
                          maxWidth: '200px',
                          padding: '10px 12px',
                          fontSize: scaledFont(12),
                          border: '1px solid #E5E2DA',
                          borderRadius: '4px',
                          backgroundColor: 'white',
                          color: '#141413',
                          cursor: 'pointer',
                        }}
                      >
                        <option value="">Select political views</option>
                        <option value="apolitical">Apolitical</option>
                        <option value="liberal">Liberal</option>
                        <option value="moderate">Moderate</option>
                        <option value="conservative">Conservative</option>
                      </select>
                    </div>

                    {/* Smoking */}
                    <div>
                      <label style={{ display: 'block', fontSize: scaledFont(11), fontWeight: '600', color: '#5C5A4D', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                        Do you smoke?
                      </label>
                      <select
                        value={formData.userProfile.smoking}
                        onChange={(e) => updateUserProfile('smoking', e.target.value)}
                        style={{
                          width: '100%',
                          maxWidth: '200px',
                          padding: '10px 12px',
                          fontSize: scaledFont(12),
                          border: '1px solid #E5E2DA',
                          borderRadius: '4px',
                          backgroundColor: 'white',
                          color: '#141413',
                          cursor: 'pointer',
                        }}
                      >
                        <option value="">Select</option>
                        <option value="yes">Yes</option>
                        <option value="no">No</option>
                      </select>
                    </div>
                  </div>

                  {/* Continue Button */}
                  <div style={{ marginTop: '24px', display: 'flex', justifyContent: 'flex-end' }}>
                    <button
                      onClick={() => setPartnerPrefsPhase('partner')}
                      disabled={!isAboutYouComplete()}
                      style={{
                        height: '44px',
                        padding: '0 32px',
                        border: 'none',
                        borderRadius: '6px',
                        backgroundColor: isAboutYouComplete() ? '#C96442' : '#E5E2DA',
                        cursor: isAboutYouComplete() ? 'pointer' : 'not-allowed',
                        fontSize: scaledFont(13),
                        fontWeight: '600',
                        color: isAboutYouComplete() ? 'white' : '#9A9891',
                      }}
                    >
                      Continue →
                    </button>
                  </div>
                </div>
              )}

              {/* Preferred Partner Section */}
              {partnerPrefsPhase === 'partner' && (
                <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '24px', marginBottom: '16px' }}>
                  <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 16px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>
                    Tell Us About Your Preferred Partner
                  </h2>
                  
                  <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 20px', lineHeight: '1.6' }}>
                    Now tell us about the type of person you would like to date and would be willing to enter into a serious relationship with.
                  </p>

                  <div style={{ display: 'flex', flexDirection: 'column', gap: '20px' }}>
                    {/* Age Range */}
                    <div>
                      <label style={{ display: 'block', fontSize: scaledFont(11), fontWeight: '600', color: '#5C5A4D', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                        What age range would you consider in a partner?
                      </label>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '12px' }}>
                        <select
                          value={formData.partnerPrefs.ageMin}
                          onChange={(e) => updatePartnerPrefs('ageMin', e.target.value)}
                          style={{
                            padding: '10px 12px',
                            fontSize: scaledFont(12),
                            border: '1px solid #E5E2DA',
                            borderRadius: '4px',
                            backgroundColor: 'white',
                            color: '#141413',
                            cursor: 'pointer',
                          }}
                        >
                          <option value="">Min age</option>
                          {Array.from({ length: 48 }, (_, i) => i + 18).map(age => (
                            <option key={age} value={age}>{age}</option>
                          ))}
                        </select>
                        <span style={{ color: '#73726C', fontSize: scaledFont(12) }}>to</span>
                        <select
                          value={formData.partnerPrefs.ageMax}
                          onChange={(e) => updatePartnerPrefs('ageMax', e.target.value)}
                          style={{
                            padding: '10px 12px',
                            fontSize: scaledFont(12),
                            border: '1px solid #E5E2DA',
                            borderRadius: '4px',
                            backgroundColor: 'white',
                            color: '#141413',
                            cursor: 'pointer',
                          }}
                        >
                          <option value="">Max age</option>
                          {Array.from({ length: 48 }, (_, i) => i + 18).map(age => (
                            <option key={age} value={age}>{age}</option>
                          ))}
                        </select>
                      </div>
                    </div>

                    {/* Minimum Income Slider */}
                    <div>
                      <label style={{ display: 'block', fontSize: scaledFont(11), fontWeight: '600', color: '#5C5A4D', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                        What is their minimum income?
                      </label>
                      <div style={{ display: 'flex', alignItems: 'center', gap: '16px' }}>
                        <input
                          type="range"
                          min="0"
                          max={incomeSliderValues.length - 1}
                          value={incomeSliderValues.indexOf(formData.partnerPrefs.minIncome) >= 0 ? incomeSliderValues.indexOf(formData.partnerPrefs.minIncome) : 0}
                          onChange={(e) => updatePartnerPrefs('minIncome', incomeSliderValues[parseInt(e.target.value)])}
                          style={{ flex: 1, cursor: 'pointer' }}
                        />
                        <span style={{ minWidth: '70px', fontSize: scaledFont(13), fontWeight: '600', color: '#141413' }}>
                          {formatIncomeSlider(formData.partnerPrefs.minIncome)}
                        </span>
                      </div>
                    </div>

                    {/* Minimum Height - Women only */}
                    {(formData.gender === 'woman' || formData.gender === 'female' || formData.gender === 'Woman') && (
                      <div>
                        <label style={{ display: 'block', fontSize: scaledFont(11), fontWeight: '600', color: '#5C5A4D', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                          What is their minimum height?
                        </label>
                        <select
                          value={formData.partnerPrefs.minHeight}
                          onChange={(e) => updatePartnerPrefs('minHeight', e.target.value)}
                          style={{
                            width: '100%',
                            maxWidth: '200px',
                            padding: '10px 12px',
                            fontSize: scaledFont(12),
                            border: '1px solid #E5E2DA',
                            borderRadius: '4px',
                            backgroundColor: 'white',
                            color: '#141413',
                            cursor: 'pointer',
                          }}
                        >
                          <option value="">Select</option>
                          <option value="no_preference">No preference</option>
                          {heightOptions.map(h => (
                            <option key={h} value={h}>{h}</option>
                          ))}
                        </select>
                      </div>
                    )}

                    {/* Body Type - Multi-select */}
                    <div>
                      <label style={{ display: 'block', fontSize: scaledFont(11), fontWeight: '600', color: '#5C5A4D', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                        What is their ideal body type?
                      </label>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                        {[
                          { value: 'no_preference', label: 'No preference' },
                          { value: 'lean_fit', label: 'Lean or Fit' },
                          { value: 'average', label: 'Average' },
                          { value: 'overweight', label: 'Overweight' },
                          { value: 'obese', label: 'Obese' },
                        ].map(opt => (
                          <button
                            key={opt.value}
                            onClick={() => toggleMultiSelect('bodyType', opt.value)}
                            style={{
                              padding: '8px 16px',
                              fontSize: scaledFont(11),
                              border: '1px solid',
                              borderColor: (formData.partnerPrefs.bodyType || []).includes(opt.value) ? '#C96442' : '#E5E2DA',
                              borderRadius: '20px',
                              backgroundColor: (formData.partnerPrefs.bodyType || []).includes(opt.value) ? '#FDF2EE' : 'white',
                              color: (formData.partnerPrefs.bodyType || []).includes(opt.value) ? '#C96442' : '#3D3929',
                              cursor: 'pointer',
                              fontWeight: '500',
                            }}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Workout Frequency - Multi-select */}
                    <div>
                      <label style={{ display: 'block', fontSize: scaledFont(11), fontWeight: '600', color: '#5C5A4D', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                        How often do they work out each week?
                      </label>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                        {[
                          { value: 'no_preference', label: 'No preference' },
                          { value: 'never', label: 'Never' },
                          { value: '1_day', label: '1 day a week' },
                          { value: '2_3_days', label: '2 to 3 days a week' },
                          { value: '4_6_days', label: '4 to 6 days a week' },
                          { value: 'daily', label: 'Every day' },
                        ].map(opt => (
                          <button
                            key={opt.value}
                            onClick={() => toggleMultiSelect('workoutFrequency', opt.value)}
                            style={{
                              padding: '8px 16px',
                              fontSize: scaledFont(11),
                              border: '1px solid',
                              borderColor: (formData.partnerPrefs.workoutFrequency || []).includes(opt.value) ? '#C96442' : '#E5E2DA',
                              borderRadius: '20px',
                              backgroundColor: (formData.partnerPrefs.workoutFrequency || []).includes(opt.value) ? '#FDF2EE' : 'white',
                              color: (formData.partnerPrefs.workoutFrequency || []).includes(opt.value) ? '#C96442' : '#3D3929',
                              cursor: 'pointer',
                              fontWeight: '500',
                            }}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Political Views - Multi-select */}
                    <div>
                      <label style={{ display: 'block', fontSize: scaledFont(11), fontWeight: '600', color: '#5C5A4D', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                        How would you describe their political views?
                      </label>
                      <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                        {[
                          { value: 'no_preference', label: 'No preference' },
                          { value: 'apolitical', label: 'Apolitical' },
                          { value: 'liberal', label: 'Liberal' },
                          { value: 'moderate', label: 'Moderate' },
                          { value: 'conservative', label: 'Conservative' },
                        ].map(opt => (
                          <button
                            key={opt.value}
                            onClick={() => toggleMultiSelect('politicalViews', opt.value)}
                            style={{
                              padding: '8px 16px',
                              fontSize: scaledFont(11),
                              border: '1px solid',
                              borderColor: (formData.partnerPrefs.politicalViews || []).includes(opt.value) ? '#C96442' : '#E5E2DA',
                              borderRadius: '20px',
                              backgroundColor: (formData.partnerPrefs.politicalViews || []).includes(opt.value) ? '#FDF2EE' : 'white',
                              color: (formData.partnerPrefs.politicalViews || []).includes(opt.value) ? '#C96442' : '#3D3929',
                              cursor: 'pointer',
                              fontWeight: '500',
                            }}
                          >
                            {opt.label}
                          </button>
                        ))}
                      </div>
                    </div>

                    {/* Has Kids */}
                    <div>
                      <label style={{ display: 'block', fontSize: scaledFont(11), fontWeight: '600', color: '#5C5A4D', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                        Do they have kids?
                      </label>
                      <select
                        value={formData.partnerPrefs.hasKids}
                        onChange={(e) => updatePartnerPrefs('hasKids', e.target.value)}
                        style={{
                          width: '100%',
                          maxWidth: '200px',
                          padding: '10px 12px',
                          fontSize: scaledFont(12),
                          border: '1px solid #E5E2DA',
                          borderRadius: '4px',
                          backgroundColor: 'white',
                          color: '#141413',
                          cursor: 'pointer',
                        }}
                      >
                        <option value="">Select</option>
                        <option value="no_preference">No preference</option>
                        <option value="no">No</option>
                        <option value="yes">Yes</option>
                      </select>
                    </div>

                    {/* Smoking */}
                    <div>
                      <label style={{ display: 'block', fontSize: scaledFont(11), fontWeight: '600', color: '#5C5A4D', marginBottom: '6px', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                        Do they smoke?
                      </label>
                      <select
                        value={formData.partnerPrefs.smoking}
                        onChange={(e) => updatePartnerPrefs('smoking', e.target.value)}
                        style={{
                          width: '100%',
                          maxWidth: '200px',
                          padding: '10px 12px',
                          fontSize: scaledFont(12),
                          border: '1px solid #E5E2DA',
                          borderRadius: '4px',
                          backgroundColor: 'white',
                          color: '#141413',
                          cursor: 'pointer',
                        }}
                      >
                        <option value="">Select</option>
                        <option value="no_preference">No preference</option>
                        <option value="no">No</option>
                        <option value="yes">Yes</option>
                      </select>
                    </div>
                  </div>

                  {/* Navigation */}
                  <div style={{ marginTop: '24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <button
                      onClick={() => setPartnerPrefsPhase('about_you')}
                      style={{
                        height: '40px',
                        padding: '0 20px',
                        border: '1px solid #E5E2DA',
                        borderRadius: '6px',
                        backgroundColor: 'white',
                        cursor: 'pointer',
                        fontSize: scaledFont(12),
                        fontWeight: '500',
                        color: '#3D3929',
                      }}
                    >
                      ← Back
                    </button>
                    <button
                      onClick={() => setPartnerPrefsPhase('complete')}
                      disabled={!isPartnerPrefsComplete()}
                      style={{
                        height: '44px',
                        padding: '0 32px',
                        border: 'none',
                        borderRadius: '6px',
                        backgroundColor: isPartnerPrefsComplete() ? '#C96442' : '#E5E2DA',
                        cursor: isPartnerPrefsComplete() ? 'pointer' : 'not-allowed',
                        fontSize: scaledFont(13),
                        fontWeight: '600',
                        color: isPartnerPrefsComplete() ? 'white' : '#9A9891',
                      }}
                    >
                      Continue to Interview →
                    </button>
                  </div>
                </div>
              )}
            </>
          )}

          {/* Intro (only on first question, and only after partner prefs are complete or user is not single) */}
          {(!isUserCurrentlySingle() || partnerPrefsPhase === 'complete') && isFirstProbe && (
            <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.6' }}>
                Based on your data, several patterns emerged that deserve deeper exploration. The numbers tell part of your story, but the context behind them tells the rest. These responses will be woven into your personalized analysis. The more detail you provide, the richer and more accurate your Relate Markets will be.
              </p>
            </div>
          )}

          {/* Current Probe - only show after partner prefs complete or user is not single */}
          {(!isUserCurrentlySingle() || partnerPrefsPhase === 'complete') && currentProbe && (
            <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '24px', marginBottom: '16px' }}>
              <div style={{ fontSize: scaledFont(10), fontWeight: '600', color: '#5C5A4D', marginBottom: '8px', textTransform: 'uppercase', letterSpacing: '0.03em' }}>
                {currentProbe.title}
              </div>
              
              <p style={{ fontSize: scaledFont(12), color: '#73726C', margin: '0 0 12px', lineHeight: '1.5' }}>
                <em>Why we're asking:</em> {currentProbe.why}
              </p>
              
              <p style={{ fontSize: scaledFont(13), color: '#141413', margin: '0 0 16px', lineHeight: '1.6', fontWeight: '500' }}>
                {currentProbe.question}
              </p>
              
              <textarea
                value={formData.probeResponses[currentProbe.id] || ''}
                onChange={(e) => updateProbeResponse(currentProbe.id, e.target.value)}
                style={{
                  width: '100%',
                  minHeight: '180px',
                  padding: '14px 16px',
                  fontSize: scaledFont(12),
                  border: '1px solid #E5E2DA',
                  borderRadius: '4px',
                  backgroundColor: 'white',
                  color: '#141413',
                  outline: 'none',
                  resize: 'vertical',
                  lineHeight: '1.7',
                  fontFamily: 'inherit',
                }}
                placeholder="Share your story. There's no character limit, so include as much detail as feels right..."
                autoFocus
              />
              
              {/* Relocation Metros Autocomplete - only show for relocationOpenness probe */}
              {currentProbe.id === 'relocationOpenness' && (
                <div style={{ marginTop: '20px', paddingTop: '20px', borderTop: '1px solid #E5E2DA' }}>
                  <div style={{ fontSize: scaledFont(12), fontWeight: '600', color: '#141413', marginBottom: '8px' }}>
                    Select Metro Areas You'd Consider (up to 6)
                  </div>
                  <p style={{ fontSize: scaledFont(11), color: '#73726C', margin: '0 0 12px', lineHeight: '1.5' }}>
                    Start typing to search metros. These selections help us calculate your dating pool in potential relocation destinations.
                  </p>
                  
                  {/* Autocomplete Input */}
                  <div style={{ position: 'relative', marginBottom: '12px' }}>
                    <input
                      type="text"
                      value={relocationSearchTerm}
                      onChange={(e) => setRelocationSearchTerm(e.target.value)}
                      disabled={formData.relocationMetros.length >= 6}
                      style={{
                        width: '100%',
                        padding: '10px 14px',
                        fontSize: scaledFont(12),
                        border: '1px solid #E5E2DA',
                        borderRadius: '4px',
                        backgroundColor: formData.relocationMetros.length >= 6 ? '#F5F4F0' : 'white',
                        color: '#141413',
                        outline: 'none',
                      }}
                      placeholder={formData.relocationMetros.length >= 6 ? 'Maximum 6 metros selected' : 'Search metros (e.g., "Austin" or "Denver")...'}
                    />
                    
                    {/* Autocomplete Dropdown */}
                    {relocationSearchTerm.length >= 2 && cbsaDataLoaded && (
                      <div style={{
                        position: 'absolute',
                        top: '100%',
                        left: 0,
                        right: 0,
                        backgroundColor: 'white',
                        border: '1px solid #E5E2DA',
                        borderTop: 'none',
                        borderRadius: '0 0 4px 4px',
                        maxHeight: '200px',
                        overflowY: 'auto',
                        zIndex: 100,
                        boxShadow: '0 4px 6px rgba(0,0,0,0.1)',
                      }}>
                        {(() => {
                          const searchLower = relocationSearchTerm.toLowerCase();
                          const matches = Object.entries(cbsaDataLoaded)
                            .filter(([code, cbsa]) => {
                              const label = cbsa.cbsa_label || cbsa.name || code;
                              return label.toLowerCase().includes(searchLower) &&
                                !formData.relocationMetros.some(m => m.cbsaCode === code);
                            })
                            .slice(0, 8);
                          
                          if (matches.length === 0) {
                            return (
                              <div style={{ padding: '12px 14px', fontSize: scaledFont(11), color: '#73726C' }}>
                                No matching metros found
                              </div>
                            );
                          }
                          
                          return matches.map(([code, cbsa]) => {
                            const label = cbsa.cbsa_label || cbsa.name || code;
                            return (
                              <div
                                key={code}
                                onClick={() => {
                                  if (formData.relocationMetros.length < 6) {
                                    setFormData(prev => ({
                                      ...prev,
                                      relocationMetros: [...prev.relocationMetros, { cbsaCode: code, cbsaLabel: label }]
                                    }));
                                    setRelocationSearchTerm('');
                                  }
                                }}
                                style={{
                                  padding: '10px 14px',
                                  fontSize: scaledFont(12),
                                  color: '#141413',
                                  cursor: 'pointer',
                                  borderBottom: '1px solid #F5F4F0',
                                }}
                                onMouseEnter={(e) => e.target.style.backgroundColor = '#FAF9F5'}
                                onMouseLeave={(e) => e.target.style.backgroundColor = 'white'}
                              >
                                {label}
                                {cbsa.cbsa_population && (
                                  <span style={{ color: '#9A9891', marginLeft: '8px', fontSize: scaledFont(10) }}>
                                    ({(cbsa.cbsa_population / 1000000).toFixed(1)}M)
                                  </span>
                                )}
                              </div>
                            );
                          });
                        })()}
                      </div>
                    )}
                  </div>
                  
                  {/* Selected Metros Pills */}
                  {formData.relocationMetros.length > 0 && (
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '8px' }}>
                      {formData.relocationMetros.map((metro, idx) => (
                        <div
                          key={metro.cbsaCode}
                          style={{
                            display: 'inline-flex',
                            alignItems: 'center',
                            gap: '6px',
                            padding: '6px 10px',
                            backgroundColor: '#FAF9F5',
                            border: '1px solid #E5E2DA',
                            borderRadius: '16px',
                            fontSize: scaledFont(11),
                            color: '#3D3929',
                          }}
                        >
                          {metro.cbsaLabel}
                          <button
                            onClick={() => {
                              setFormData(prev => ({
                                ...prev,
                                relocationMetros: prev.relocationMetros.filter((_, i) => i !== idx)
                              }));
                            }}
                            style={{
                              background: 'none',
                              border: 'none',
                              padding: '0',
                              cursor: 'pointer',
                              fontSize: '14px',
                              color: '#9A9891',
                              lineHeight: 1,
                            }}
                          >
                            ×
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </div>
          )}

          {/* Navigation - only show after partner prefs complete or user is not single */}
          {(!isUserCurrentlySingle() || partnerPrefsPhase === 'complete') && (
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px' }}>
            <div>
              {!isFirstProbe && (
                <button
                  onClick={() => setCurrentProbeIndex(prev => prev - 1)}
                  style={{
                    height: '40px',
                    padding: '0 20px',
                    border: '1px solid #E5E2DA',
                    borderRadius: '6px',
                    backgroundColor: 'white',
                    cursor: 'pointer',
                    fontSize: scaledFont(12),
                    fontWeight: '500',
                    color: '#3D3929',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                  }}
                >
                  ← Previous
                </button>
              )}
            </div>
            
            <button
              onClick={() => {
                if (isLastProbe) {
                  handleGenerateReport();
                } else {
                  setCurrentProbeIndex(prev => prev + 1);
                }
              }}
              disabled={!isCurrentAnswered}
              style={{
                height: '44px',
                padding: '0 32px',
                border: 'none',
                borderRadius: '6px',
                backgroundColor: isCurrentAnswered ? '#C96442' : '#E5E2DA',
                cursor: isCurrentAnswered ? 'pointer' : 'not-allowed',
                fontSize: scaledFont(13),
                fontWeight: '600',
                color: isCurrentAnswered ? 'white' : '#9A9891',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                letterSpacing: '0.02em',
              }}
            >
              {isLastProbe ? 'Generate Analysis' : 'Next →'}
            </button>
          </div>
          )}

          {/* Footer */}
          <div style={{ padding: '10px 12px', backgroundColor: '#F5F3ED', borderRadius: '4px', fontSize: scaledFont(9), color: '#73726C' }}>
            Your responses are used solely to generate your personalized Relate Markets analysis. Nothing is stored or shared.
          </div>
        </div>
      </div>
    );
  }

  // Analysis Page
  if (currentPage === 'demo') {
  // Show generating overlay
  if (demoGenerating) {
    return (
      <div style={{ width: '100%', padding: '32px 32px', backgroundColor: '#FAF9F5', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', display: 'flex', flexDirection: 'column' }}>
        <div style={{ maxWidth: `${containerWidth}px`, margin: '0 auto', width: '100%', flex: 1, display: 'flex', flexDirection: 'column' }}>
          <PageHeader currentPage={currentPage} setCurrentPage={setCurrentPage} scaledFont={scaledFont} windowWidth={windowWidth} containerWidth={containerWidth} setContainerWidth={setContainerWidth} />
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '48px 24px', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
            <div style={{ fontSize: scaledFont(18), fontWeight: '700', color: '#141413', marginBottom: '8px', textAlign: 'center' }}>
              {demoGenerationProgress.trajectoryName || 'Your Journey'}
            </div>
            <div style={{ fontSize: scaledFont(14), color: '#C96442', fontWeight: '600', marginBottom: '24px', textAlign: 'center' }}>
              {demoGenerationProgress.cardName || 'Starting...'}
            </div>
            <div style={{ height: '8px', backgroundColor: '#E5E2DA', borderRadius: '4px', overflow: 'hidden', maxWidth: '300px', width: '100%' }}>
              <div style={{ height: '100%', backgroundColor: '#C96442', borderRadius: '4px', width: `${(demoGenerationProgress.current / demoGenerationProgress.total) * 100}%`, transition: 'width 0.3s ease' }} />
            </div>
            <div style={{ fontSize: scaledFont(11), color: '#9A9891', marginTop: '12px', textAlign: 'center' }}>
              {demoGenerationProgress.current} of {demoGenerationProgress.total}
            </div>
            <div style={{ fontSize: scaledFont(11), color: '#73726C', marginTop: '16px', textAlign: 'center' }}>
              Claude AI is analyzing your data and generating your report
            </div>
          </div>
        </div>
      </div>
    );
  }
  
  // Show loading while CBSA data is being fetched
  if (!cbsaDataLoaded || data.length === 0) {
    return (
      <div style={{ width: '100%', padding: '32px 32px', backgroundColor: '#FAF9F5', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', display: 'flex', flexDirection: 'column' }}>
        <div style={{ maxWidth: `${containerWidth}px`, margin: '0 auto', width: '100%', flex: 1, display: 'flex', flexDirection: 'column' }}>
          <PageHeader currentPage={currentPage} setCurrentPage={setCurrentPage} scaledFont={scaledFont} windowWidth={windowWidth} containerWidth={containerWidth} setContainerWidth={setContainerWidth} />
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '32px', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
            <div style={{ fontSize: scaledFont(14), color: '#73726C', textAlign: 'center' }}>Loading demographic data...</div>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div style={{ width: '100%', padding: '32px 32px', backgroundColor: '#FAF9F5', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
      <div style={{ maxWidth: `${containerWidth}px`, margin: '0 auto' }}>
        
        {/* Header */}
        <PageHeader 
          currentPage={currentPage} 
          setCurrentPage={setCurrentPage} 
          scaledFont={scaledFont} 
          windowWidth={windowWidth} 
          containerWidth={containerWidth} 
          setContainerWidth={setContainerWidth} 
        />

        {/* Key Stats Cards */}
        {useCollapsedCards ? (
          <div style={{ marginBottom: '16px', backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb' }}>
            <button
              onClick={() => setCardsMenuOpen(!cardsMenuOpen)}
              style={{
                width: '100%',
                padding: '10px 16px',
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
                border: 'none',
                backgroundColor: 'transparent',
                cursor: 'pointer',
                fontSize: '11px',
                fontWeight: '600',
                color: '#374151',
                textTransform: 'uppercase',
                letterSpacing: '0.05em',
              }}
            >
              <span>Key Stats</span>
              <span style={{ fontSize: '10px', color: '#9A9891' }}>{cardsMenuOpen ? '▲' : '▼'}</span>
            </button>
            {cardsMenuOpen && (
              <div style={{ padding: '0 16px 16px', borderTop: '1px solid #e5e7eb' }}>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', paddingTop: '12px' }}>
                  {statsCards.map((card, i) => (
                    <div 
                      key={card.key} 
                      style={{ 
                        padding: '8px 0',
                        borderBottom: i < statsCards.length - 2 ? '1px solid #EBE8E0' : 'none',
                        cursor: 'pointer',
                        textAlign: 'center'
                      }}
                      onClick={() => handleCardClick(card.key)}
                    >
                      <div style={{ fontSize: '18px', fontWeight: '700', color: '#141413', fontFamily: 'monospace', textDecoration: card.highlight ? 'underline' : 'none', textDecorationColor: '#d1d5db', textUnderlineOffset: '3px', marginBottom: '4px' }}>{card.value}</div>
                      <div style={{ fontSize: '10px', color: '#73726C', textTransform: 'uppercase', letterSpacing: '0.03em', marginBottom: '2px' }}>{card.label}</div>
                      <div style={{ fontSize: '9px', color: '#9A9891' }}>{card.sub}</div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        ) : (
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '16px' }}>
            {statsCards.map((card) => (
              <StatCard 
                key={card.key}
                label={card.label} 
                value={card.value} 
                sub={card.sub} 
                highlight={card.highlight}
                onClick={() => handleCardClick(card.key)} 
                isActive={activeCard === card.key} 
              />
            ))}
          </div>
        )}

        {/* Toggles - Responsive */}
        <div style={{ marginBottom: '16px', backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb' }}>
          {useDropdownToggles ? (
            <>
              <button
                onClick={() => setToggleMenuOpen(!toggleMenuOpen)}
                style={{
                  width: '100%',
                  padding: '10px 16px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  border: 'none',
                  backgroundColor: 'transparent',
                  cursor: 'pointer',
                  fontSize: '11px',
                  fontWeight: '600',
                  color: '#374151',
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em',
                }}
              >
                <span>Chart Toggles</span>
                <span style={{ fontSize: '10px', color: '#9A9891' }}>{toggleMenuOpen ? '▲' : '▼'}</span>
              </button>
              {toggleMenuOpen && (
                <div style={{ padding: '8px 16px 16px', borderTop: '1px solid #e5e7eb', display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: '8px' }}>
                  {Object.entries(lineConfig).map(([k, c]) => (
                    <Toggle key={k} active={visibleLines[k]} color={c.color} label={c.label} onClick={() => toggle(k)} />
                  ))}
                </div>
              )}
            </>
          ) : (
            <div style={{ padding: '10px 16px', display: 'flex', justifyContent: 'center' }}>
              <div ref={measureRef} style={{ display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap', justifyContent: 'center', rowGap: '8px' }}>
                {Object.entries(lineConfig).map(([k, c]) => (
                  <Toggle key={k} active={visibleLines[k]} color={c.color} label={c.label} onClick={() => toggle(k)} />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Chart */}
        {anyToggleActive ? (
          <div style={{ height: 340, backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px', position: 'relative', transition: 'height 0.2s ease' }}>
            <ResponsiveContainer>
              <ComposedChart data={chartData} margin={{ top: 20, right: hasPercent ? 0 : 8, left: 0, bottom: 0 }}>
                <CartesianGrid strokeDasharray="2 2" stroke="#EBE8E0" />
                <XAxis 
                  dataKey="year" 
                  type="number" 
                  domain={[Math.min(...data.map(d => d.year)), Math.max(...data.map(d => d.year))]} 
                  ticks={data.map(d => d.year)}
                  tickFormatter={(year) => {
                    const years = data.map(d => d.year);
                    const first1900s = years.filter(y => y < 2000).sort((a,b) => a-b)[0];
                    const first2000s = years.filter(y => y >= 2000).sort((a,b) => a-b)[0];
                    if (year === first1900s || year === first2000s) return String(year);
                    return `'${String(year).slice(-2)}`;
                  }}
                  tick={{ fill: '#73726C', fontSize: 10 }} 
                  tickLine={{ stroke: '#e5e7eb' }} 
                  axisLine={{ stroke: '#e5e7eb' }}
                  interval={0}
                />
                <YAxis 
                  yAxisId="dollar" 
                  width={42}
                  tickFormatter={formatCurrency} 
                  tick={({ x, y, payload }) => {
                    const ticks = generateDollarTicks(data, visibleLines);
                    const is100k = payload.value === 100000 && ticks.includes(100000);
                    return (
                      <text x={x} y={y} dy={4} textAnchor="end" fill={is100k ? '#9A9891' : '#73726C'} fontSize={10}>
                        {formatCurrency(payload.value)}
                      </text>
                    );
                  }}
                  tickLine={false} 
                  axisLine={false} 
                  domain={[0, Math.max(...generateDollarTicks(data, visibleLines))]} 
                  ticks={generateDollarTicks(data, visibleLines)} 
                  hide={!hasDollar} 
                />
                <YAxis 
                  yAxisId="percent" 
                  orientation="right" 
                  width={hasPercent ? 36 : 0}
                  tickFormatter={formatPercentTick} 
                  tick={{ fill: '#9A9891', fontSize: 10 }} 
                  tickLine={false} 
                  axisLine={false} 
                  domain={[0, Math.max(...generatePercentTicks(data, visibleLines))]} 
                  ticks={generatePercentTicks(data, visibleLines)} 
                  hide={!hasPercent} 
                />
                <Tooltip content={<CustomTooltip visibleLines={visibleLines} chartData={chartData} />} />
                
                {visibleLines.income && <Line yAxisId="dollar" type="monotone" dataKey="income" stroke={lineConfig.income.color} strokeWidth={2} dot={{ r: 2 }} isAnimationActive={false} />}
                {visibleLines.purchasePower && <Line yAxisId="dollar" type="monotone" dataKey="purchasePower" stroke={lineConfig.purchasePower.color} strokeWidth={2} strokeDasharray="2 4" dot={false} isAnimationActive={false} />}
                {visibleLines.equiv700k && <Line yAxisId="dollar" type="monotone" dataKey="equiv700k" stroke={lineConfig.equiv700k.color} strokeWidth={2} dot={{ r: 2 }} isAnimationActive={false} />}
                {visibleLines.goal && <Line yAxisId="dollar" type="monotone" dataKey="goal" stroke={lineConfig.goal.color} strokeWidth={1.5} strokeDasharray="2 3 2 3 2 3 10 3" dot={false} isAnimationActive={false} />}
                {visibleLines.achieve && <Line yAxisId="percent" type="monotone" dataKey="pctToGoalT" stroke={lineConfig.achieve.color} strokeWidth={1.5} strokeDasharray="2 3 2 3 2 3 10 3" dot={false} isAnimationActive={false} />}
                {visibleLines.safe && <Line yAxisId="dollar" type="monotone" dataKey="safe" stroke={lineConfig.safe.color} strokeWidth={1.5} strokeDasharray="4 4" dot={false} isAnimationActive={false} />}
                {visibleLines.greenLine && <Line yAxisId="dollar" type="monotone" dataKey="greenLine" stroke={lineConfig.greenLine.color} strokeWidth={1.5} strokeDasharray="4 4" dot={false} isAnimationActive={false} />}
                {visibleLines.medianHH && <Line yAxisId="dollar" type="monotone" dataKey="medianHH" stroke={lineConfig.medianHH.color} strokeWidth={1.5} strokeDasharray="4 4" dot={false} isAnimationActive={false} />}
                {visibleLines.povertyLine && <Line yAxisId="dollar" type="monotone" dataKey="povertyLine" stroke={lineConfig.povertyLine.color} strokeWidth={1.5} strokeDasharray="4 4" dot={false} isAnimationActive={false} />}
                {visibleLines.percentile && <Line yAxisId="percent" type="monotone" dataKey="percentileT" stroke={lineConfig.percentile.color} strokeWidth={1} dot={false} isAnimationActive={false} />}
                {visibleLines.relateScore && <Line yAxisId="percent" type="monotone" dataKey="relateScoreT" stroke={lineConfig.relateScore.color} strokeWidth={1.25} strokeDasharray="4 2 1 2" dot={false} isAnimationActive={false} />}
                {visibleLines.matchScore && <Line yAxisId="percent" type="monotone" dataKey="matchScoreT" stroke={lineConfig.matchScore.color} strokeWidth={1.25} strokeDasharray="4 2 1 2" dot={false} connectNulls={false} isAnimationActive={false} />}
                
                {/* Aspiration Zone Shading - green between Safe and Goal */}
                {visibleLines.safe && visibleLines.goal && <Customized component={(props) => <AspirationBand {...props} data={chartData} />} />}
                {/* Functional Zone Shading - yellow between income and greenLine (when income > greenLine) */}
                {visibleLines.greenLine && visibleLines.income && <Customized component={(props) => <FunctionalBand {...props} data={chartData} />} />}
                
                {/* Goal Achievement Shading - between goal and income (when income > goal) */}
                {visibleLines.goal && visibleLines.income && <Customized component={(props) => <GoalBand {...props} data={chartData} />} />}
              </ComposedChart>
            </ResponsiveContainer>
          </div>
        ) : (
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '10px 16px', marginBottom: '16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
            <span style={{ fontSize: '11px', fontWeight: '600', color: '#374151', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Income Chart</span>
            <span style={{ fontSize: '10px', color: '#9A9891' }}>Select a toggle above to display</span>
          </div>
        )}

        {/* Income Table */}
        <div style={{ marginBottom: '11px' }}>
          <Section title="Income Table" isOpen={openSections.incomeTable} onToggle={() => toggleSection('incomeTable')}>
            <div style={{ overflow: 'auto' }}>
              <table style={{ width: '100%', fontSize: scaledFont(10), borderCollapse: 'collapse', tableLayout: 'fixed' }}>
                <colgroup>
                  <col style={{ width: '55px' }} />
                  <col style={{ width: '130px' }} />
                  <col style={{ width: '75px' }} />
                </colgroup>
                <thead>
                  <tr style={{ backgroundColor: '#FAF9F5' }}>
                    <th style={{ padding: '8px 10px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Year</th>
                    <th style={{ padding: '8px 10px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Location</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Income</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Power</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Equiv</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Goal</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Achieved</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Safe</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Survive</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Median</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Poverty</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Pctl</th>
                  </tr>
                </thead>
                <tbody>
                  {data.map((d, i) => {
                    const powerPct = Math.round(((d.purchasePower - d.income) / d.income) * 100);
                    const powerStr = powerPct >= 0 ? `+${powerPct}%` : `${powerPct}%`;
                    return (
                    <tr key={i} style={{ backgroundColor: i % 2 ? '#fafafa' : 'white' }}>
                      <td style={{ padding: '8px 10px', textAlign: 'left', fontWeight: '600', color: '#141413', whiteSpace: 'nowrap' }}>{d.year}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'left', fontWeight: '600', color: '#141413', whiteSpace: 'nowrap' }}>{d.location}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '600', color: '#141413', whiteSpace: 'nowrap' }}>{formatCurrency(d.income)}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: powerPct >= 0 ? '#347613' : '#B53232', whiteSpace: 'nowrap' }}>{powerStr}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{formatCurrency(d.equiv700k)}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{formatCurrency(d.goal)}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.pctToGoal}%</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{formatCurrency(d.safe)}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{formatCurrency(d.greenLine)}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{formatCurrency(d.medianHH)}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{formatCurrency(d.povertyLine)}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.percentile === 99 ? 'Top 1%' : `${d.percentile}th`}</td>
                    </tr>
                  )})}
                </tbody>
              </table>
            </div>
          </Section>
        </div>

        {/* Demographics Table */}
        <div style={{ marginBottom: '11px' }}>
          <Section title="Demographics Table" isOpen={openSections.demographicsTable} onToggle={() => toggleSection('demographicsTable')}>
            <div style={{ overflow: 'auto' }}>
              <table style={{ width: '100%', fontSize: scaledFont(10), borderCollapse: 'collapse', tableLayout: 'fixed' }}>
                <colgroup>
                  <col style={{ width: '55px' }} />
                  <col style={{ width: '130px' }} />
                  <col style={{ width: '75px' }} />
                </colgroup>
                <thead>
                  <tr style={{ backgroundColor: '#FAF9F5' }}>
                    <th style={{ padding: '8px 10px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Year</th>
                    <th style={{ padding: '8px 10px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Location</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Income</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Gender</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Relate</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Match</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Age</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Ethnicity</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Orient</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Status</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Edu</th>
                    <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Kids</th>
                  </tr>
                </thead>
                <tbody>
                  {demographics.map((d, i) => (
                    <tr key={i} style={{ backgroundColor: i % 2 ? '#fafafa' : 'white' }}>
                      <td style={{ padding: '8px 10px', textAlign: 'left', fontWeight: '600', color: '#141413', whiteSpace: 'nowrap' }}>{d.year}</td>
                      <td style={{ padding: '8px 10px', textAlign: 'left', fontWeight: '600', color: '#141413', whiteSpace: 'nowrap' }}>{d.location}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '600', color: '#141413', whiteSpace: 'nowrap' }}>{formatCurrency(d.income)}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.gender}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{Math.round(d.relateScore / 10)}/10</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.matchPool === null ? '—' : d.matchPool >= 1000000 ? `${(d.matchPool/1000000).toFixed(1)}M` : `${Math.round(d.matchPool/1000)}k`}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.age}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.ethnicity}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.orientation}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.relationship}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.education}</td>
                      <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.children}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Section>
        </div>

        {/* Context by Year - Full Width */}
        <div style={{ marginBottom: '11px' }}>
          <Section title="Context by Year" isOpen={openSections.contextByYear} onToggle={() => toggleSection('contextByYear')}>
            <div style={{ display: 'grid', gridTemplateColumns: 'calc(50% - 12px) calc(50% - 12px)', gap: '24px' }}>
              <div>
                {data.slice(0, 7).map((d, i) => (
                  <div key={i} style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: i < 6 ? '1px solid #EBE8E0' : 'none' }}>
                    <div style={{ fontWeight: '600', fontSize: scaledFont(11), marginBottom: '4px' }}>{d.year} · {d.location} · Age {d.age}</div>
                    <div style={{ color: '#3D3D3A', fontSize: scaledFont(12) }}>{(demoNarrativeContent.contextByYear && demoNarrativeContent.contextByYear[d.year]) || d.context}{getFunctionalContext(d, i, data)}{getRelateMatchContext(d)}</div>
                  </div>
                ))}
              </div>
              <div>
                {data.slice(7).map((d, i) => (
                  <div key={i} style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: i < data.length - 8 ? '1px solid #EBE8E0' : 'none' }}>
                    <div style={{ fontWeight: '600', fontSize: scaledFont(11), marginBottom: '4px' }}>{d.year} · {d.location} · Age {d.age}</div>
                    <div style={{ color: '#3D3D3A', fontSize: scaledFont(12) }}>{(demoNarrativeContent.contextByYear && demoNarrativeContent.contextByYear[d.year]) || d.context}{getFunctionalContext(d, i + 7, data)}{getRelateMatchContext(d)}</div>
                  </div>
                ))}
              </div>
            </div>
          </Section>
        </div>

        {/* Analysis Modules */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '11px', marginBottom: '11px' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: '11px' }}>
            <Section title="Key Findings" isOpen={openSections.keyFindings} onToggle={() => toggleSection('keyFindings')}>
              <div style={{ fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }} dangerouslySetInnerHTML={{ __html: formatNarrativeText(demoNarrativeContent.keyFindings || `**1. You were poor.** Your father's $29k income represented just 76% of median in the cheapest measured city, falling $19k short of what a family of four needed to cover basic cost of living. At only 1.75x the poverty line, this was close enough to feel its proximity and placed the household firmly in survival mode rather than working class stability.

**2. You treaded water for 17 years.** From 1998 to 2015, every income increase was consumed by cost of living increases from relocating to expensive metros. The path from Boise to Los Angeles to Washington to Sacramento meant running faster just to maintain the same relative position.

**3. Divorce created a wealth shock.** The 2015 split established a dual-household financial burden spanning 2,000 miles, with Sacramento rent, Illinois child support, and $800 flights every few weeks all competing for the same income. The 78th percentile felt closer to poverty when funding two separate lives.

**4. The 2015 to 2025 period produced a breakout.** A 6x or greater nominal income increase occurred during the worst inflation since 1981. This trajectory is statistically rare, as you outpaced inflation by 5x while most Americans lost ground during this period.

**5. Geographic arbitrage closed the gap.** Landing $700k in Edwardsville with a Regional Price Parity of 96.3 instead of Sacramento at 108.9 adds $60,000 to $80,000 in effective purchasing power annually. The strategy shifted from earning more to keeping more of what you earn.`) }} />
            </Section>

            <Section title="Percentile Thresholds (2025)" isOpen={openSections.percentileThresholds} onToggle={() => toggleSection('percentileThresholds')}>
              <table style={{ width: '100%', fontSize: '11px', marginBottom: '16px' }}>
                <tbody>
                  <tr><td style={{ padding: '4px 0', color: '#73726C' }}>Median (50th)</td><td style={{ textAlign: 'right' }}>$83,592</td><td style={{ textAlign: 'right', fontWeight: '600' }}>{lastDataPoint.percentile >= 50 ? '✓' : ''}</td></tr>
                  <tr><td style={{ padding: '4px 0', color: '#73726C' }}>Top 10%</td><td style={{ textAlign: 'right' }}>$251,036</td><td style={{ textAlign: 'right', fontWeight: '600' }}>{lastDataPoint.percentile >= 90 ? '✓' : ''}</td></tr>
                  <tr><td style={{ padding: '4px 0', color: '#73726C' }}>Top 5%</td><td style={{ textAlign: 'right' }}>$335,575</td><td style={{ textAlign: 'right', fontWeight: '600' }}>{lastDataPoint.percentile >= 95 ? '✓' : ''}</td></tr>
                  <tr><td style={{ padding: '4px 0', color: '#73726C' }}>Top 1%</td><td style={{ textAlign: 'right' }}>$659,060</td><td style={{ textAlign: 'right', fontWeight: '600' }}>{lastDataPoint.percentile >= 99 ? '✓' : ''}</td></tr>
                  <tr style={{ fontWeight: '600' }}><td style={{ padding: '4px 0', borderTop: '1px solid #e5e7eb', paddingTop: '8px' }}>Your Income</td><td style={{ textAlign: 'right', borderTop: '1px solid #e5e7eb', paddingTop: '8px' }}>{formatCurrency(lastDataPoint.income || 0)}</td><td style={{ borderTop: '1px solid #e5e7eb', paddingTop: '8px' }}></td></tr>
                </tbody>
              </table>
              <div style={{ fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }} dangerouslySetInnerHTML={{ __html: formatNarrativeText(demoNarrativeContent.percentileThresholds || `Your income exceeds the top 1% threshold by $40,940, placing you among approximately 1.3 million households out of 134 million total American households. This represents 8.4x the median household income and 24x your father's 1998 nominal income.

**The trajectory summary:** You climbed from the 38th percentile to the 45th, then to the 78th, and finally to the top 1%, representing a 61 percentile point ascent over 27 years from below median to the top of the distribution.`) }} />
            </Section>

            <Section title="Inflation Impact" isOpen={openSections.inflationImpact} onToggle={() => toggleSection('inflationImpact')}>
              <div style={{ fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }} dangerouslySetInnerHTML={{ __html: formatNarrativeText(demoNarrativeContent.inflationImpact || `**1. The $700k equivalent remained flat from 1998 to 2005.** Moving from Boise with a Regional Price Parity of 93.4 to Washington at 108.6 offset approximately 20% of cumulative inflation during this period. The geographic penalty effectively neutralized seven years of temporal gains, as relocating to expensive cities gave back everything that inflation adjustments would have provided.

**2. The 2015 to 2025 period produced explosive growth.** A combination of 36% Consumer Price Index inflation and relocation to a cheaper market (Sacramento at 108.9 to O'Fallon at 96.3) created a 54% total purchasing power delta. For the first time, geography worked in your favor rather than against you.

**3. The post-pandemic period delivered a shock.** Approximately 25% inflation occurred in just three years from 2021 to 2023, representing the worst inflationary period since 1981. While most Americans lost ground during this time, you increased your income by 7x, the equivalent of swimming upstream in a flood and somehow reaching higher ground.

**4. The hidden story explains the flat equivalent line.** The $700k equivalent appears nearly flat from 1998 to 2005 not because inflation was low, but because you kept offsetting gains with geographic choices that increased your cost of living. Only from 2015 to 2025 did geography finally begin working in your favor.`) }} />
            </Section>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: '11px' }}>
            <Section title="Rarity Analysis" isOpen={openSections.rarityAnalysis} onToggle={() => toggleSection('rarityAnalysis')}>
              <div style={{ fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }} dangerouslySetInnerHTML={{ __html: formatNarrativeText(demoNarrativeContent.rarityAnalysis || `**1. Intergenerational mobility at this scale is rare.** Children born to parents earning $29k, which places them in the bottom 40% of the income distribution, reach the top 1% in fewer than 2% of cases nationally. You belong to a statistically uncommon cohort, as most people born at your starting point remain within 20 percentile points of where they began.

**2. Your divorce recovery defied statistical norms.** Research indicates that most men experience a 10% to 40% long-term income decrease following divorce due to disruption, stress, and divided resources. You achieved 6x income growth in the decade following your divorce, representing not merely recovery but active defiance of the expected trajectory.

**3. Inflation-adjusted gains compound the difficulty.** Crossing from below median to the top 1% during the highest inflation period in 40 years substantially increases the difficulty of the achievement. The challenge resembles climbing a mountain that is actively growing taller as you ascend.

**4. The traditional employment path is increasingly uncommon.** Your wealth did not derive from inheritance, startup equity, or a windfall. Reaching the top 1% through traditional employment income has become rare, as most households at this level have business ownership, capital gains, or generational wealth. Yours is earned income from salary and bonus.

**5. The co-parenting factor adds complexity.** You accomplished this trajectory while flying across the country every few weeks, maintaining two households, and navigating custody arrangements across 2,000 miles. Most people facing these constraints would have plateaued, but you accelerated.`) }} />
            </Section>

            <Section title="The Scarcity Mindset Gap" isOpen={openSections.scarcityMindset} onToggle={() => toggleSection('scarcityMindset')}>
              <div style={{ fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }} dangerouslySetInnerHTML={{ __html: formatNarrativeText(demoNarrativeContent.scarcityMindset || `**1. Seventeen years of constraint versus ten years of growth.** Your nervous system was calibrated by the period from 1998 to 2015, and the abundance of 2015 to 2025 has not fully rewritten that programming. The internalized experience of scarcity does not yet match the current financial reality.

**2. Your "felt rich" ceiling was set too low.** You never imagined earning beyond $200k because that represented the upper limit of your aspirational frame. You now earn 3.5x that amount, a level of income you literally never fantasized about because it existed outside your frame of reference.

**3. Poverty proximity memory persists.** You started at 1.75x the poverty line and now sit at 21.8x, but the body retains the memory of being at 1.75x. The brain still flinches at expenses that have become trivial relative to current income.

**4. The median multiple shift is difficult to internalize.** Your father earned 0.76x median income, below the middle in the cheapest city measured. You now earn 8.4x median income, but that multiplier does not feel real when formative years were spent at 0.76x.

**5. The gap represents the remaining work.** You have solved the money problem. The remaining work involves convincing your nervous system that the financial threat has ended and updating your internal model to match external reality.`) }} />
            </Section>

            <Section title="What You're Creating" isOpen={openSections.whatYoureCreating} onToggle={() => toggleSection('whatYoureCreating')}>
              <div style={{ fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }} dangerouslySetInnerHTML={{ __html: formatNarrativeText(demoNarrativeContent.whatYoureCreating || `**1. Your children start at a different percentile.** They are not beginning at the 38th percentile in Boise as you did. They are starting in the top 5% to 10% in O'Fallon, representing a complete transformation of the baseline within a single generation.

**2. You represent a generational inflection point.** One generation moved from below median to the top 1%, and two generations separated you from whatever economic circumstances preceded Boise. You serve as the hinge point in your family's economic history.

**3. Optionality has been created.** At your current income level in a low cost of living area, a 50% to 60% savings rate is achievable. Work becomes optional within 10 to 15 years if you choose that path, meaning you are not merely earning income but building the ability to stop working entirely.

**4. Educational access has expanded dramatically.** Your children have access to opportunities that simply did not exist in your frame of reference growing up, including private schools, tutors, travel, unpaid internships, and graduate school without loans. These options are now financially available.

**5. An asymmetry exists in lived experience.** You understand what life feels like at the bottom of the income distribution, but your children will not share that experience. This represents a feature rather than a flaw, though it means they will need to develop resilience through different mechanisms than you did.`) }} />
            </Section>
          </div>
        </div>

        {/* Relationship Calculation - Full Width */}
        <div style={{ marginBottom: '11px' }}>
          <Section title="Relationship Calculation" isOpen={openSections.relationshipCalculation} onToggle={() => toggleSection('relationshipCalculation')}>
            <p style={{ marginBottom: '11px', fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }}>
              Income trajectory analysis provides half of the picture: where you came from, where you are, and what that means statistically. Relationship calculation provides the other half by translating financial position into partnership market dynamics. Modern dating platforms use algorithmic matching systems derived from Elo rating methodology, originally developed for chess rankings, which assign users a desirability score based on who swipes right on whom and who matches with whom. A user who receives interest from high-rated profiles sees their own rating increase, while rejection from highly-rated users decreases it. These systems create stratified matching pools where users are primarily shown to and shown profiles of others at similar desirability tiers.
            </p>
            <p style={{ marginBottom: '20px', fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }}>
              Income, while not directly visible, correlates strongly with proxy signals that these algorithms detect: neighborhood, education, profession, photos reflecting lifestyle, and activity patterns. Understanding where your financial position places you in these algorithmic hierarchies transforms abstract percentile rankings into concrete relationship market positioning. The two scores below, Relate Score and Match Score, address different questions: how well a potential partner can understand your lived experience versus how statistically likely a match becomes given demographic and economic realities.
            </p>
            <div style={{ display: 'grid', gridTemplateColumns: 'calc(50% - 12px) calc(50% - 12px)', gap: '24px' }}>
              <div>
                <div style={{ fontWeight: '600', fontSize: '12px', marginBottom: '12px', paddingBottom: '8px', borderBottom: '2px solid #e5e7eb', color: '#141413' }}>Relate Score</div>
                <div style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: '1px solid #EBE8E0' }}>
                  <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Purpose</div>
                  <div style={{ color: '#3D3D3A', fontSize: '11px' }}>The Relate Score measures experiential compatibility, specifically the degree to which a potential partner can genuinely understand your financial journey rather than merely tolerate or benefit from its outcome. This score addresses the psychological isolation that accompanies significant economic mobility, where neither those who started wealthy nor those who remained at your origin point fully comprehend the transition you experienced.</div>
                </div>
                <div style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: '1px solid #EBE8E0' }}>
                  <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Inputs</div>
                  <div style={{ color: '#3D3D3A', fontSize: '11px' }}>The calculation incorporates origin percentile, current percentile, trajectory velocity measured as percentile points per year, geographic mobility patterns, family structure changes including divorce and co-parenting, and the scarcity-to-abundance transition timing. Each input receives a weight based on research into what factors most strongly predict mutual comprehension of financial stress and financial success.</div>
                </div>
                <div style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: '1px solid #EBE8E0' }}>
                  <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Methodology</div>
                  <div style={{ color: '#3D3D3A', fontSize: '11px' }}>The score applies a distance function across multiple dimensions, measuring how far a hypothetical partner's profile sits from yours on each weighted factor. Partners who experienced similar origin conditions, similar trajectory shapes, or similar life disruptions score higher. The function penalizes both excessive distance, meaning they cannot relate, and zero distance, meaning identical experiences often create competition rather than complementarity.</div>
                </div>
                <div style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: '1px solid #EBE8E0' }}>
                  <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Scale</div>
                  <div style={{ color: '#3D3D3A', fontSize: '11px' }}>The score ranges from 0 to 10, where 10 represents maximum potential for experiential understanding. Scores above 7 indicate high relatability pools exist in the dating market. Scores between 4 and 7 suggest moderate relatability requiring intentional filtering. Scores below 4 indicate that most available partners will struggle to comprehend your financial journey at a visceral level.</div>
                </div>
                <div>
                  <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Limitations</div>
                  <div style={{ color: '#3D3D3A', fontSize: '11px' }}>The score cannot measure emotional intelligence, communication skill, or willingness to learn. A partner with low experiential overlap but high empathic capacity may outperform predictions, while a partner with similar trajectory but poor emotional attunement may underperform. The score identifies probability of baseline comprehension, not guarantee of connection quality.</div>
                </div>
              </div>
              <div>
                <div style={{ fontWeight: '600', fontSize: '12px', marginBottom: '12px', paddingBottom: '8px', borderBottom: '2px solid #e5e7eb', color: '#141413' }}>Match Score</div>
                <div style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: '1px solid #EBE8E0' }}>
                  <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Purpose</div>
                  <div style={{ color: '#3D3D3A', fontSize: '11px' }}>The Match Score estimates the statistical probability of achieving a committed relationship with a partner meeting specified criteria, expressed as a percentage. This score addresses the fundamental supply and demand problem in dating markets: how many people exist who meet your criteria, how many of them would consider you, and what percentage of that overlap is realistically accessible given age, geography, and platform dynamics.</div>
                </div>
                <div style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: '1px solid #EBE8E0' }}>
                  <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Elo Foundation</div>
                  <div style={{ color: '#3D3D3A', fontSize: '11px' }}>Dating platforms including Tinder, Hinge, and Bumble employ Elo-derived systems where each user carries a hidden desirability rating. When a high-rated user swipes right on you, your rating increases more than when a low-rated user does. When you swipe right on someone who does not reciprocate, your rating decreases. This creates feedback loops where users converge into tiers and primarily see profiles within their tier, making cross-tier matching statistically rare.</div>
                </div>
                <div style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: '1px solid #EBE8E0' }}>
                  <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Inputs</div>
                  <div style={{ color: '#3D3D3A', fontSize: '11px' }}>The calculation incorporates your demographic profile including age, gender, location, education, income percentile, and physical presentation estimates. It then cross-references against population distributions for your specified partner criteria, applying Elo-tier probability adjustments based on where your profile likely ranks and where your desired partners likely rank within platform hierarchies.</div>
                </div>
                <div style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: '1px solid #EBE8E0' }}>
                  <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Calculation</div>
                  <div style={{ color: '#3D3D3A', fontSize: '11px' }}>The score multiplies the base rate of partners meeting your criteria in the population by the probability that such partners exist in your Elo tier by the probability of mutual interest given tier overlap by the probability of conversion from match to relationship. Each multiplication reduces the final percentage, often dramatically, which explains why high-criteria searches yield low match probabilities even for highly desirable users.</div>
                </div>
                <div>
                  <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Interpretation</div>
                  <div style={{ color: '#3D3D3A', fontSize: '11px' }}>Scores above 30% indicate favorable market conditions where patience and volume will likely yield results. Scores between 10% and 30% indicate challenging but viable conditions requiring strategic optimization of profile, criteria, or both. Scores below 10% indicate that current criteria may be statistically incompatible with available supply, suggesting either criteria adjustment or acceptance of extended timelines measured in years rather than months.</div>
                </div>
              </div>
            </div>
          </Section>
        </div>

        {/* Relate Score and Match Score - Side by Side */}
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '11px', alignItems: 'start' }}>
          <Section title="Relate Score Analysis" isOpen={openSections.relateScoreAnalysis} onToggle={() => toggleSection('relateScoreAnalysis')}>
            <div style={{ fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }} dangerouslySetInnerHTML={{ __html: formatNarrativeText(demoNarrativeContent.relateScoreAnalysis || 'Relate Score analysis will be generated...') }} />
          </Section>
          <Section title="Match Score Analysis" isOpen={openSections.matchScoreAnalysis} onToggle={() => toggleSection('matchScoreAnalysis')}>
            <div style={{ fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }} dangerouslySetInnerHTML={{ __html: formatNarrativeText(demoNarrativeContent.matchScoreAnalysis || 'Match Score analysis will be generated...') }} />
          </Section>
        </div>

        {/* Footer */}
        <div style={{ marginTop: '32px', padding: '10px 12px', backgroundColor: '#F5F3ED', borderRadius: '4px', fontSize: scaledFont(9), color: '#73726C' }}>
          <strong>Sources:</strong> Bureau of Economic Analysis Regional Price Parities 2023, Census Bureau Historical Income Tables (H-8), Bureau of Labor Statistics Consumer Expenditure Survey, HHS Poverty Guidelines, Michael Green's Functional Threshold methodology, Census Bureau American Community Survey demographic data by CBSA. <span onClick={() => setCurrentPage('glossary')} style={{ color: '#3b82f6', cursor: 'pointer', textDecoration: 'underline' }}>Glossary</span>
        </div>
      </div>
    </div>
  );
  }

  // Report Page (user's calculated data - placeholder for now)
  if (currentPage === 'report') {
    // Show generating overlay
    if (reportGenerating) {
      return (
        <div style={{ width: '100%', padding: '32px 32px', backgroundColor: '#FAF9F5', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', display: 'flex', flexDirection: 'column' }}>
          <div style={{ maxWidth: `${containerWidth}px`, margin: '0 auto', width: '100%', flex: 1, display: 'flex', flexDirection: 'column' }}>
            <PageHeader currentPage={currentPage} setCurrentPage={setCurrentPage} scaledFont={scaledFont} windowWidth={windowWidth} containerWidth={containerWidth} setContainerWidth={setContainerWidth} />
            <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '48px 24px', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
              <div style={{ fontSize: scaledFont(18), fontWeight: '700', color: '#141413', marginBottom: '8px', textAlign: 'center' }}>
                {generationProgress.trajectoryName || 'Your Journey'}
              </div>
              <div style={{ fontSize: scaledFont(14), color: '#C96442', fontWeight: '600', marginBottom: '24px', textAlign: 'center' }}>
                {generationProgress.cardName || 'Starting...'}
              </div>
              <div style={{ height: '8px', backgroundColor: '#E5E2DA', borderRadius: '4px', overflow: 'hidden', maxWidth: '300px', width: '100%' }}>
                <div style={{ height: '100%', backgroundColor: '#C96442', borderRadius: '4px', width: `${(generationProgress.current / generationProgress.total) * 100}%`, transition: 'width 0.3s ease' }} />
              </div>
              <div style={{ fontSize: scaledFont(11), color: '#9A9891', marginTop: '12px', textAlign: 'center' }}>
                {generationProgress.current} of {generationProgress.total}
              </div>
              <div style={{ fontSize: scaledFont(11), color: '#73726C', marginTop: '16px', textAlign: 'center' }}>
                Claude AI is analyzing your answers and generating your report
              </div>
            </div>
          </div>
        </div>
      );
    }
    
    // Show loading state while fetching CBSA/ZIP data from GitHub
    if (dataLoading) {
      return (
        <div style={{ width: '100%', padding: '32px 32px', backgroundColor: '#FAF9F5', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', display: 'flex', flexDirection: 'column' }}>
          <div style={{ maxWidth: `${containerWidth}px`, margin: '0 auto', width: '100%', flex: 1, display: 'flex', flexDirection: 'column' }}>
            <PageHeader currentPage={currentPage} setCurrentPage={setCurrentPage} scaledFont={scaledFont} windowWidth={windowWidth} containerWidth={containerWidth} setContainerWidth={setContainerWidth} />
            <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '32px', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
              <div style={{ fontSize: scaledFont(14), color: '#73726C', textAlign: 'center' }}>Loading geographic data (917 CBSAs, 33,791 ZIPs)...</div>
            </div>
          </div>
        </div>
      );
    }
    
    // =============================================================================
    // CALCULATION ENGINE (per report-calculations.md Section 8)
    // =============================================================================
    //
    // CBSA DATA ARCHITECTURE: LOCAL WEIGHTS ↔ NATIONAL PERCENTAGES
    //
    // The GitHub repo (cbsa-data.js) contains 917 CBSAs with two types of fields:
    //
    // TYPE 1: LOCAL WEIGHTS (0-100 scale, 50 = national average)
    // These indicate how a metro compares to national average for that dimension.
    //
    // TYPE 2: NATIONAL PERCENTAGES (baseline distributions)
    // These are the same across all metros - national baselines weighted by local weights.
    //
    // THE CORRESPONDENCE MAP:
    // ┌─────────────────────────┬──────────────────────────────────────────────────┐
    // │ LOCAL WEIGHT            │ NATIONAL PERCENTAGES IT WEIGHTS                  │
    // ├─────────────────────────┼──────────────────────────────────────────────────┤
    // │ income_cbsa             │ income_under_35k_cbsa ... income_750k_plus_cbsa  │
    // │ bachelors_cbsa          │ education_less_hs_cbsa ... education_graduate    │
    // │ pct_white_cbsa          │ ethnicity_white_cbsa ... ethnicity_other_cbsa    │
    // │ age_25_45_cbsa          │ age_18_19_cbsa ... age_85_120_cbsa               │
    // │ single_18_65_cbsa       │ relationship_single/married/dating/separated     │
    // │ male_cbsa / female_cbsa │ gender_man/woman/other_cbsa                      │
    // └─────────────────────────┴──────────────────────────────────────────────────┘
    //
    // FORMULA: LocalValue = Population × (LocalWeight / 50) × (NationalPct / 100)
    //
    // =============================================================================
    
    // Haversine distance calculation (km)
    const haversineDistance = (lat1, lng1, lat2, lng2) => {
      const R = 6371; // Earth's radius in km
      const dLat = (lat2 - lat1) * Math.PI / 180;
      const dLng = (lng2 - lng1) * Math.PI / 180;
      const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
                Math.sin(dLng/2) * Math.sin(dLng/2);
      return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    };
    
    // Find nearest CBSA using haversine distance from ZIP centroid
    const findNearestCBSA = (zipCode) => {
      if (!zipCode || !zipDataLoaded || !cbsaDataLoaded) return null;
      const zipCoords = zipDataLoaded[zipCode];
      if (!zipCoords) return null;
      
      let nearest = null;
      let minDist = Infinity;
      
      for (const [name, cbsa] of Object.entries(cbsaDataLoaded)) {
        const dist = haversineDistance(zipCoords.lat, zipCoords.lng, cbsa.lat, cbsa.lng);
        if (dist < minDist) {
          minDist = dist;
          nearest = { ...cbsa, name };
        }
      }
      return nearest;
    };
    
    // Find CBSA by name match (fuzzy)
    const findCBSAByName = (location) => {
      if (!location || !cbsaDataLoaded) return null;
      const loc = location.toLowerCase();
      
      for (const [name, cbsa] of Object.entries(cbsaDataLoaded)) {
        // Check if any part of CBSA name matches location
        const cbsaLower = name.toLowerCase();
        const parts = cbsaLower.split(/[-,]/);
        for (const part of parts) {
          if (loc.includes(part.trim()) || part.trim().includes(loc)) {
            return { ...cbsa, name };
          }
        }
      }
      return null;
    };
    
    // Master function to get CBSA data for a location (uses fetched GitHub data)
    const getCBSAForLocation = (zipCode, location) => {
      // Try ZIP first (haversine to nearest CBSA)
      let cbsa = findNearestCBSA(zipCode);
      if (cbsa) return cbsa;
      
      // Try location name match
      cbsa = findCBSAByName(location);
      if (cbsa) return cbsa;
      
      // Return null if no match (will use DEFAULT_CBSA)
      return null;
    };
    
    const BASE_FAMILY_OF_4_COST = 137822;
    const FUNCTIONAL_THRESHOLD_MULTIPLIER = 1.35;
    const SAFE_THRESHOLD_MULTIPLIER = 1.80;
    
    // Parse partner preferences from natural language response
    const parsePartnerPreferences = (response) => {
      if (!response) return null;
      const text = response.toLowerCase();
      const prefs = {};
      
      // Age range parsing
      const agePatterns = [
        /(\d{2})\s*(?:to|-|–|and)\s*(\d{2})/,  // "25 to 35", "25-35"
        /between\s*(\d{2})\s*(?:and|-)\s*(\d{2})/,  // "between 25 and 35"
        /(?:at least|minimum|min)\s*(\d{2})/,  // "at least 25"
        /(?:no older than|max|maximum|under)\s*(\d{2})/,  // "no older than 40"
        /(\d{2})\s*(?:years?\s*)?(?:older|younger)/,  // "5 years older"
        /(?:my age|same age|around my age)/,  // relative references
        /younger\s*(?:than me|women|men)?/,
        /older\s*(?:than me|women|men)?/
      ];
      
      for (const pattern of agePatterns) {
        const match = text.match(pattern);
        if (match) {
          if (match[1] && match[2]) {
            prefs.ageMin = parseInt(match[1]);
            prefs.ageMax = parseInt(match[2]);
          } else if (match[1]) {
            if (text.includes('least') || text.includes('min') || text.includes('older')) {
              prefs.ageMin = parseInt(match[1]);
            } else if (text.includes('under') || text.includes('max') || text.includes('younger')) {
              prefs.ageMax = parseInt(match[1]);
            }
          }
          break;
        }
      }
      if (text.includes('my age') || text.includes('same age')) prefs.ageRelative = 'same';
      if (text.includes('younger')) prefs.ageRelative = 'younger';
      if (text.includes('older')) prefs.ageRelative = 'older';
      
      // Ethnicity parsing
      const ethnicities = ['white', 'black', 'hispanic', 'latina', 'latino', 'asian', 'indian', 'middle eastern', 'mixed', 'any', 'doesn\'t matter', 'don\'t care', 'no preference', 'open to'];
      for (const eth of ethnicities) {
        if (text.includes(eth)) {
          if (eth === 'any' || eth === 'doesn\'t matter' || eth === 'don\'t care' || eth === 'no preference' || eth === 'open to') {
            prefs.ethnicityPref = 'any';
          } else if (eth === 'latina' || eth === 'latino') {
            prefs.ethnicityPref = 'hispanic';
          } else {
            prefs.ethnicityPref = eth;
          }
          break;
        }
      }
      
      // Education parsing
      const eduKeywords = {
        'college': 'bachelors', 'degree': 'bachelors', 'bachelor': 'bachelors', 'university': 'bachelors',
        'graduate': 'graduate', 'master': 'graduate', 'phd': 'graduate', 'doctorate': 'graduate', 'advanced': 'graduate',
        'high school': 'hs', 'hs': 'hs', 'ged': 'hs',
        'doesn\'t matter': 'any', 'don\'t care': 'any', 'no preference': 'any', 'not important': 'any'
      };
      for (const [key, val] of Object.entries(eduKeywords)) {
        if (text.includes(key)) {
          prefs.educationMin = val;
          break;
        }
      }
      
      // Income parsing
      const incomePatterns = [
        /\$?(\d{2,3})k/i,  // "$50k", "100k"
        /\$?(\d{1,3}),?(\d{3})/,  // "$50,000", "100000"
        /(?:at least|minimum|min)\s*\$?(\d+)/,
        /(?:more than|over|above)\s*(?:me|mine|my income)/,
        /(?:same|similar|comparable)\s*(?:income|salary)/,
        /doesn't matter|don't care|no preference|not important/
      ];
      
      for (const pattern of incomePatterns) {
        const match = text.match(pattern);
        if (match) {
          if (match[1] && match[2]) {
            prefs.incomeMin = parseInt(match[1] + match[2]);
          } else if (match[1]) {
            const num = parseInt(match[1]);
            prefs.incomeMin = num < 1000 ? num * 1000 : num;
          }
          break;
        }
      }
      if (text.includes('more than me') || text.includes('more than mine') || text.includes('above my')) prefs.incomeRelative = 'higher';
      if (text.includes('same') || text.includes('similar') || text.includes('comparable')) prefs.incomeRelative = 'similar';
      if (text.includes('doesn\'t matter') || text.includes('don\'t care') || text.includes('not important')) prefs.incomeMin = 0;
      
      // Kids preference parsing
      if (text.includes('dealbreaker') || text.includes('deal breaker') || text.includes('no kids') || text.includes('without kids') || text.includes('child-free') || text.includes('childfree')) {
        prefs.openToKids = false;
      } else if (text.includes('open to') || text.includes('fine with') || text.includes('okay with') || text.includes('don\'t mind') || text.includes('doesn\'t matter')) {
        prefs.openToKids = true;
      } else if (text.includes('prefer not') || text.includes('rather not') || text.includes('ideally not')) {
        prefs.openToKids = 'prefer_no';
      }
      
      return Object.keys(prefs).length > 0 ? prefs : null;
    };
    
    // Parse relocation openness from natural language response
    // Matches locations against actual 917 CBSAs from GitHub data
    // Returns unmatched location strings for potential async lookup
    const parseRelocationResponse = (response, cbsaData) => {
      if (!response) return null;
      const text = response.toLowerCase();
      const reloc = {};
      
      // Openness level
      if (text.includes('not open') || text.includes('rooted') || text.includes('staying') || text.includes('not moving') || text.includes('no plans') || text.includes('settled')) {
        reloc.openToRelocation = 'no';
      } else if (text.includes('definitely') || text.includes('actively looking') || text.includes('planning to') || text.includes('want to move') || text.includes('need to move')) {
        reloc.openToRelocation = 'yes';
      } else if (text.includes('open to') || text.includes('considering') || text.includes('might') || text.includes('could see') || text.includes('thought about') || text.includes('maybe')) {
        reloc.openToRelocation = 'maybe';
      }
      
      // Extract potential location mentions using regex patterns
      // Look for "City, ST" or "City ST" or just city names followed by state-like patterns
      const locationPatterns = [
        /([a-z\s]+),?\s*([a-z]{2})\b/gi,  // "Austin, TX" or "Austin TX"
        /([a-z\s]{3,})\s+(?:area|metro|region)/gi,  // "Bay Area", "Denver metro"
      ];
      
      const potentialLocations = [];
      for (const pattern of locationPatterns) {
        let match;
        while ((match = pattern.exec(response)) !== null) {
          const city = match[1].trim();
          const state = match[2] ? match[2].toUpperCase() : null;
          if (city.length > 2) {
            potentialLocations.push({ city, state, raw: match[0] });
          }
        }
      }
      
      // Match against actual CBSA data
      reloc.matchedCBSAs = [];
      reloc.unmatchedLocations = [];
      
      if (cbsaData && Object.keys(cbsaData).length > 0) {
        for (const loc of potentialLocations) {
          let matched = false;
          const searchCity = loc.city.toLowerCase();
          
          for (const [cbsaName, data] of Object.entries(cbsaData)) {
            const cbsaLower = cbsaName.toLowerCase();
            
            // Check if city name appears in CBSA name
            if (cbsaLower.includes(searchCity)) {
              // If state provided, verify it matches
              if (loc.state) {
                const stateMatch = cbsaName.match(/,\s*([A-Z]{2})/);
                if (stateMatch && stateMatch[1] === loc.state) {
                  reloc.matchedCBSAs.push({ name: cbsaName, ...data });
                  matched = true;
                  break;
                }
              } else {
                // No state provided, accept first match
                reloc.matchedCBSAs.push({ name: cbsaName, ...data });
                matched = true;
                break;
              }
            }
          }
          
          if (!matched && loc.city.length > 3) {
            // Couldn't match - flag for potential web lookup
            reloc.unmatchedLocations.push(loc.raw);
          }
        }
      }
      
      // Dedupe matched CBSAs by name
      const seenCBSAs = new Set();
      reloc.matchedCBSAs = reloc.matchedCBSAs.filter(cbsa => {
        if (seenCBSAs.has(cbsa.name)) return false;
        seenCBSAs.add(cbsa.name);
        return true;
      });
      
      // Convenience: list of CBSA names
      reloc.consideredLocations = reloc.matchedCBSAs.map(c => c.name);
      
      // Flag for international (not in US CBSA data, can't be matched)
      const intlPatterns = /\b(abroad|europe|asia|canada|mexico|international|overseas|uk|london|paris|tokyo|berlin|amsterdam|australia|singapore)\b/i;
      reloc.consideringInternational = intlPatterns.test(text);
      
      // Motivations
      reloc.motivations = [];
      if (text.includes('career') || text.includes('job') || text.includes('work') || text.includes('opportunity') || text.includes('promotion')) {
        reloc.motivations.push('career');
      }
      if (text.includes('cost of living') || text.includes('cheaper') || text.includes('affordable') || text.includes('expensive') || text.includes('save money') || text.includes('housing')) {
        reloc.motivations.push('cost_of_living');
      }
      if (text.includes('family') || text.includes('parents') || text.includes('kids') || text.includes('closer to')) {
        reloc.motivations.push('family');
      }
      if (text.includes('dating') || text.includes('partner') || text.includes('relationship') || text.includes('meet people') || text.includes('singles')) {
        reloc.motivations.push('dating');
      }
      if (text.includes('weather') || text.includes('climate') || text.includes('outdoor') || text.includes('lifestyle') || text.includes('culture') || text.includes('vibe')) {
        reloc.motivations.push('lifestyle');
      }
      
      // What's keeping them (if not open)
      if (reloc.openToRelocation === 'no') {
        reloc.anchors = [];
        if (text.includes('family') || text.includes('parents') || text.includes('kids')) reloc.anchors.push('family');
        if (text.includes('job') || text.includes('career') || text.includes('work')) reloc.anchors.push('career');
        if (text.includes('friends') || text.includes('community') || text.includes('network')) reloc.anchors.push('social');
        if (text.includes('house') || text.includes('home') || text.includes('property') || text.includes('mortgage')) reloc.anchors.push('property');
        if (text.includes('custody') || text.includes('co-parent')) reloc.anchors.push('custody');
      }
      
      return Object.keys(reloc).length > 0 ? reloc : null;
    };
    
    // Haversine functions for ZIP code to CBSA lookup
    const haversineDistanceCalc = (lat1, lng1, lat2, lng2) => {
      const R = 3959;
      const dLat = (lat2 - lat1) * Math.PI / 180;
      const dLng = (lng2 - lng1) * Math.PI / 180;
      const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) * Math.sin(dLng / 2) * Math.sin(dLng / 2);
      return R * 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    };
    
    const findNearestCBSACalc = (lat, lng, cbsaArray) => {
      let nearest = null, minDistance = Infinity;
      for (const cbsa of cbsaArray) {
        const cbsaLat = cbsa.latitude || cbsa.lat;
        const cbsaLng = cbsa.longitude || cbsa.lng;
        if (cbsaLat === undefined || cbsaLng === undefined) continue;
        const distance = haversineDistanceCalc(lat, lng, cbsaLat, cbsaLng);
        if (distance < minDistance) { minDistance = distance; nearest = cbsa; }
      }
      return nearest;
    };
    
    const CPI_BY_YEAR_CALC = { 1980: 28.5, 1985: 33.6, 1990: 41.2, 1991: 42.8, 1992: 44.1, 1993: 45.4, 1994: 46.5, 1995: 47.8, 1996: 49.2, 1997: 50.4, 1998: 51.2, 1999: 52.3, 2000: 54.5, 2001: 55.9, 2002: 56.8, 2003: 58.1, 2004: 59.7, 2005: 62.3, 2006: 64.2, 2007: 66.1, 2008: 68.6, 2009: 68.4, 2010: 70.1, 2011: 72.3, 2012: 73.8, 2013: 74.9, 2014: 75.6, 2015: 75.8, 2016: 76.8, 2017: 78.4, 2018: 80.4, 2019: 81.8, 2020: 82.4, 2021: 86.3, 2022: 93.1, 2023: 97.0, 2024: 99.0, 2025: 100.0 };
    const getCPICalc = (year) => {
      if (CPI_BY_YEAR_CALC[year]) return CPI_BY_YEAR_CALC[year];
      const years = Object.keys(CPI_BY_YEAR_CALC).map(Number).sort((a, b) => a - b);
      if (year < years[0]) return CPI_BY_YEAR_CALC[years[0]];
      if (year > years[years.length - 1]) return CPI_BY_YEAR_CALC[years[years.length - 1]];
      for (let i = 0; i < years.length - 1; i++) {
        if (year >= years[i] && year <= years[i + 1]) {
          const ratio = (year - years[i]) / (years[i + 1] - years[i]);
          return CPI_BY_YEAR_CALC[years[i]] + ratio * (CPI_BY_YEAR_CALC[years[i + 1]] - CPI_BY_YEAR_CALC[years[i]]);
        }
      }
      return 100;
    };
    
    const MEDIAN_INCOME_BY_YEAR_CALC = { 1980: 21023, 1985: 26433, 1990: 29943, 1995: 34076, 1998: 38885, 2000: 42148, 2001: 42228, 2002: 42409, 2003: 43318, 2004: 44334, 2005: 46326, 2006: 48201, 2007: 50233, 2008: 50303, 2009: 49777, 2010: 49276, 2011: 50054, 2012: 51017, 2013: 51939, 2014: 53657, 2015: 56516, 2016: 59039, 2017: 61372, 2018: 63179, 2019: 68703, 2020: 67521, 2021: 70784, 2022: 74580, 2023: 77540, 2024: 79350, 2025: 80610 };
    const getMedianIncomeCalc = (year) => {
      if (MEDIAN_INCOME_BY_YEAR_CALC[year]) return MEDIAN_INCOME_BY_YEAR_CALC[year];
      const years = Object.keys(MEDIAN_INCOME_BY_YEAR_CALC).map(Number).sort((a, b) => a - b);
      if (year < years[0]) return MEDIAN_INCOME_BY_YEAR_CALC[years[0]];
      if (year > years[years.length - 1]) return MEDIAN_INCOME_BY_YEAR_CALC[years[years.length - 1]];
      for (let i = 0; i < years.length - 1; i++) {
        if (year >= years[i] && year <= years[i + 1]) {
          const ratio = (year - years[i]) / (years[i + 1] - years[i]);
          return Math.round(MEDIAN_INCOME_BY_YEAR_CALC[years[i]] + ratio * (MEDIAN_INCOME_BY_YEAR_CALC[years[i + 1]] - MEDIAN_INCOME_BY_YEAR_CALC[years[i]]));
        }
      }
      return 80610;
    };
    
    const POVERTY_LINE_BY_YEAR_CALC = { 1980: 8414, 1985: 10989, 1990: 13359, 1995: 15569, 1998: 16530, 2000: 17603, 2001: 18104, 2002: 18392, 2003: 18810, 2004: 19307, 2005: 19971, 2006: 20614, 2007: 21203, 2008: 21834, 2009: 21954, 2010: 22113, 2011: 22811, 2012: 23283, 2013: 23624, 2014: 24008, 2015: 24257, 2016: 24339, 2017: 24600, 2018: 25100, 2019: 25750, 2020: 26200, 2021: 26500, 2022: 27750, 2023: 30000, 2024: 31200, 2025: 32150 };
    const getPovertyLineCalc = (year) => {
      if (POVERTY_LINE_BY_YEAR_CALC[year]) return POVERTY_LINE_BY_YEAR_CALC[year];
      const years = Object.keys(POVERTY_LINE_BY_YEAR_CALC).map(Number).sort((a, b) => a - b);
      if (year < years[0]) return POVERTY_LINE_BY_YEAR_CALC[years[0]];
      if (year > years[years.length - 1]) return POVERTY_LINE_BY_YEAR_CALC[years[years.length - 1]];
      for (let i = 0; i < years.length - 1; i++) {
        if (year >= years[i] && year <= years[i + 1]) {
          const ratio = (year - years[i]) / (years[i + 1] - years[i]);
          return Math.round(POVERTY_LINE_BY_YEAR_CALC[years[i]] + ratio * (POVERTY_LINE_BY_YEAR_CALC[years[i + 1]] - POVERTY_LINE_BY_YEAR_CALC[years[i]]));
        }
      }
      return 32150;
    };
    
    const PERCENTILE_THRESHOLDS_2025 = { 1: 0, 5: 15000, 10: 20000, 15: 25000, 20: 30000, 25: 35000, 30: 40000, 35: 45000, 38: 48000, 40: 50000, 45: 57000, 48: 62000, 50: 67000, 55: 75000, 60: 85000, 65: 95000, 68: 105000, 70: 110000, 75: 130000, 77: 140000, 78: 145000, 80: 155000, 85: 190000, 86: 200000, 89: 235000, 90: 251036, 91: 270000, 92: 290000, 93: 315000, 94: 345000, 95: 335575, 96: 420000, 97: 500000, 98: 580000, 99: 659060 };
    const getIncomePercentileCalc = (income, year) => {
      const medianYear = getMedianIncomeCalc(year);
      const median2025 = MEDIAN_INCOME_BY_YEAR_CALC[2025];
      const scaleFactor = medianYear / median2025;
      const percentiles = Object.keys(PERCENTILE_THRESHOLDS_2025).map(Number).sort((a, b) => b - a);
      for (const p of percentiles) {
        const threshold2025 = PERCENTILE_THRESHOLDS_2025[p];
        const thresholdYear = threshold2025 * scaleFactor;
        if (income >= thresholdYear) return p;
      }
      return 1;
    };
    
    const DEFAULT_CBSA = {
      name: 'National Average', rpp: 100, cbsa_population: 330000000, latitude: 39.8283, longitude: -98.5795,
      // Normalized scores (50 = national avg)
      income_cbsa: 50, bachelors_cbsa: 50, pct_white_cbsa: 50, age_25_45_cbsa: 50, single_18_65_cbsa: 50, male_cbsa: 50, female_cbsa: 50,
      // Actual percentages - age ranges
      age_18_19_cbsa: 3, age_20_24_cbsa: 7, age_25_29_cbsa: 7, age_30_34_cbsa: 7, age_35_39_cbsa: 7, age_40_44_cbsa: 6, age_45_49_cbsa: 6, age_50_54_cbsa: 6, age_55_59_cbsa: 7, age_60_64_cbsa: 7, age_65_69_cbsa: 6, age_70_74_cbsa: 5, age_75_79_cbsa: 4, age_80_84_cbsa: 3, age_85_120_cbsa: 2,
      // Actual percentages - other
      have_kids_yes_cbsa: 40, have_kids_no_cbsa: 60,
      orientation_straight_cbsa: 91, orientation_gay_lesbian_cbsa: 4, orientation_bisexual_cbsa: 4, orientation_other_cbsa: 1,
      gender_man_cbsa: 49, gender_woman_cbsa: 51, gender_other_cbsa: 0,
      relationship_single_cbsa: 35, relationship_married_cbsa: 48, relationship_dating_cbsa: 12, relationship_separated_cbsa: 5,
      ethnicity_white_cbsa: 60, ethnicity_hispanic_cbsa: 19, ethnicity_black_cbsa: 13, ethnicity_asian_cbsa: 6, ethnicity_native_cbsa: 1, ethnicity_pacific_cbsa: 0.2, ethnicity_other_cbsa: 0.8,
      education_less_hs_cbsa: 10, education_hs_grad_cbsa: 27, education_trade_cbsa: 5, education_associate_cbsa: 8, education_some_college_cbsa: 19, education_bachelors_cbsa: 21, education_graduate_cbsa: 10,
      income_under_35k_cbsa: 25, income_35k_50k_cbsa: 12, income_50k_75k_cbsa: 16, income_75k_100k_cbsa: 12, income_100k_150k_cbsa: 15, income_150k_200k_cbsa: 8, income_200k_300k_cbsa: 7, income_300k_500k_cbsa: 3, income_500k_750k_cbsa: 1, income_750k_plus_cbsa: 1,
    };
    
    const calculateDataRowCalc = (row, lastYearIncome, cbsaData, globalGender, globalEthnicity, globalOrientation, partnerPrefs) => {
      const year = parseInt(row.year);
      const income = parseInt(row.income);
      const goal = parseInt(row.goal) || 0;
      const rpp = cbsaData?.rpp || 100;
      const cpi = getCPICalc(year);
      const cpiFinal = getCPICalc(2025);
      const colFamily4 = BASE_FAMILY_OF_4_COST * (rpp / 100) * (cpi / cpiFinal);
      const greenLine = colFamily4 * FUNCTIONAL_THRESHOLD_MULTIPLIER;
      const safe = colFamily4 * SAFE_THRESHOLD_MULTIPLIER;
      const purchasePower = income * (100 / rpp);
      const equiv = lastYearIncome * (cpi / cpiFinal) * (100 / rpp);
      
      // LOCAL median and poverty (national × RPP adjustment)
      const nationalMedian = getMedianIncomeCalc(year);
      const nationalPoverty = getPovertyLineCalc(year);
      const medianHH = Math.round(nationalMedian * (rpp / 100));
      const povertyLine = Math.round(nationalPoverty * (rpp / 100));
      
      const pctToGoal = goal > 0 ? Math.round((income / goal) * 100) : 0;
      
      const user = {
        age: parseInt(row.age) || 30,
        income: income,
        education: row.education || 'bachelors',
        gender: globalGender || 'man',
        ethnicity: globalEthnicity || 'white',
        orientation: globalOrientation || 'straight',
        hasKids: row.children === 'yes' || row.children === 'Yes',
        relationshipStatus: row.married || 'single'
      };
      
      // User profile attributes for sigmoid calculation
      const userProfile = {
        height: null,
        bodyType: 'average',
        workoutFrequency: 'never',
        politicalViews: 'moderate',
        smoking: 'no'
      };
      
      // Use SHARED CALCULATION MODULE (project instructions Section 8.12-8.13)
      const { relateScore, incomeLocal, components: relateComponents } = calculateRelateScore(user, cbsaData || DEFAULT_CBSA, colFamily4);
      
      // Use three-tier calculation for dating metrics
      const threeTier = calculateThreeTierMatches(user, cbsaData || DEFAULT_CBSA, partnerPrefs || {}, userProfile);
      
      // For display, use the incomeLocal from shared module as percentile
      const percentile = Math.round(incomeLocal);
      
      return {
        year, location: row.location, income, goal, age: user.age,
        gender: user.gender, ethnicity: user.ethnicity, orientation: user.orientation,
        relationship: user.relationshipStatus === 'yes' ? 'Married' : (user.relationshipStatus === 'no' ? 'Single' : user.relationshipStatus),
        education: row.education || 'Graduate', children: user.hasKids ? 'Yes' : 'No',
        purchasePower: Math.round(purchasePower), equiv700k: Math.round(equiv),
        greenLine: Math.round(greenLine), safe: Math.round(safe),
        medianHH, povertyLine, percentile, pctToGoal, colFamily4: Math.round(colFamily4),
        relateScore, relateComponents,
        // Legacy fields
        matchScore: threeTier.matchScore, 
        matchPool: threeTier.matchPool, 
        localSinglePool: threeTier.localSinglePool, 
        targetGenderLabel: threeTier.targetGenderLabel,
        // Three-tier fields
        realisticPool: threeTier.realisticPool,
        realisticMatches: threeTier.realisticMatches,
        realisticMatchRate: threeTier.realisticMatchRate,
        preferredPool: threeTier.preferredPool,
        preferredMatches: threeTier.preferredMatches,
        preferredMatchRate: threeTier.preferredMatchRate,
        idealPool: threeTier.idealPool,
        idealMatches: threeTier.idealMatches,
        idealMatchRate: threeTier.idealMatchRate,
        relateScoreOutOf10: threeTier.relateScoreOutOf10,
        population: cbsaData?.cbsa_population || 100000,
        rpp, // Include RPP for display
        incomeCbsa: cbsaData?.income_cbsa || 50, // For tooltip context
        bachelorsCbsa: cbsaData?.bachelors_cbsa || 50, // For tooltip context
        pctWhiteCbsa: cbsaData?.pct_white_cbsa || 50, // For tooltip context
        percentileT: transformForAxis(100 - percentile), pctToGoalT: transformForAxis(pctToGoal),
        relateScoreT: transformForAxis(relateScore), matchScoreT: threeTier.matchScore !== null ? transformForAxis(threeTier.matchScore) : null
      };
    };
    // =============================================================================
    // END CALCULATION ENGINE
    // =============================================================================
    
    // Check if user has completed enough data in Calculator
    const filledYears = formData.incomeYears.filter(y => y.year && y.location && y.zipCode && y.income && y.goal && y.age && y.married && y.children && y.education);
    const hasEnoughData = filledYears.length >= 3;
    
    if (!hasEnoughData) {
      return (
        <div style={{ width: '100%', padding: '32px 32px', backgroundColor: '#FAF9F5', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', display: 'flex', flexDirection: 'column' }}>
          <div style={{ maxWidth: `${containerWidth}px`, margin: '0 auto', width: '100%', flex: 1, display: 'flex', flexDirection: 'column' }}>
            <PageHeader currentPage={currentPage} setCurrentPage={setCurrentPage} scaledFont={scaledFont} windowWidth={windowWidth} containerWidth={containerWidth} setContainerWidth={setContainerWidth} />
            <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '32px', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
              <div style={{ maxWidth: '500px', width: '100%', textAlign: 'center' }}>
                <h2 style={{ fontSize: scaledFont(16), fontWeight: '700', color: '#141413', margin: '0 0 16px' }}>Your Personalized Report</h2>
                <p style={{ fontSize: scaledFont(14), color: '#73726C', margin: '0 0 16px', lineHeight: '1.6' }}>
                  Complete at least 3 years in the Calculator to generate your personalized Relate Markets report.
                </p>
                <p style={{ fontSize: scaledFont(14), color: '#73726C', margin: '0 0 24px', lineHeight: '1.6' }}>
                  Your income trajectory, adjusted for inflation and cost of living, will appear here along with context about your results and new scores about how income has shaped our relationships, dating, and community.
                </p>
                <button onClick={() => setCurrentPage('calculator')} style={{ padding: '10px 16px', backgroundColor: '#C96442', color: 'white', border: 'none', borderRadius: '4px', fontSize: scaledFont(11), fontWeight: '600', cursor: 'pointer', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Start Calculator</button>
              </div>
            </div>
          </div>
        </div>
      );
    }
    
    // =============================================================================
    // DATA VALIDATION GATE - Force resolution before proceeding
    // =============================================================================
    const validateReportData = () => {
      const errors = [];
      
      // Check 1: GitHub CBSA data loaded
      if (!cbsaDataLoaded || Object.keys(cbsaDataLoaded).length === 0) {
        errors.push({
          type: 'CBSA_DATA_NOT_LOADED',
          message: 'Metro area data failed to load from server.',
          resolution: 'Please refresh the page. If this persists, check your internet connection.'
        });
        return errors; // Can't proceed without CBSA data
      }
      
      // Check 2: ZIP data loaded
      if (!zipDataLoaded || Object.keys(zipDataLoaded).length === 0) {
        errors.push({
          type: 'ZIP_DATA_NOT_LOADED',
          message: 'ZIP code data failed to load from server.',
          resolution: 'Please refresh the page. If this persists, check your internet connection.'
        });
        return errors; // Can't proceed without ZIP data
      }
      
      // Check 3: Each year has valid CBSA match
      const requiredCbsaFields = [
        'cbsa_population', 'rpp', 'income_cbsa', 'bachelors_cbsa', 'pct_white_cbsa',
        'gender_woman_cbsa', 'gender_man_cbsa', 'female_cbsa', 'male_cbsa',
        'relationship_single_cbsa', 'single_18_65_cbsa'
      ];
      
      filledYears.forEach((row, idx) => {
        const matchedCBSA = getCBSAForLocation(row.zipCode, row.location);
        
        if (!matchedCBSA) {
          errors.push({
            type: 'CBSA_LOOKUP_FAILED',
            year: row.year,
            location: row.location,
            zipCode: row.zipCode,
            message: `Could not find metro area for "${row.location}" (ZIP: ${row.zipCode}).`,
            resolution: `Please verify the ZIP code is correct for ${row.location}, or try a nearby major city.`
          });
        } else {
          // Check required fields exist in matched CBSA
          const missingFields = requiredCbsaFields.filter(f => 
            matchedCBSA[f] === undefined || matchedCBSA[f] === null
          );
          if (missingFields.length > 0) {
            errors.push({
              type: 'CBSA_MISSING_FIELDS',
              year: row.year,
              location: row.location,
              cbsaName: matchedCBSA.name || 'Unknown',
              missingFields,
              message: `Metro "${matchedCBSA.name}" is missing required data fields.`,
              resolution: 'This is a data issue. Please contact support or try a nearby major metro area.'
            });
          }
        }
      });
      
      // Check 4: Required user profile fields
      if (!formData.gender) {
        errors.push({
          type: 'MISSING_USER_FIELD',
          field: 'gender',
          message: 'Gender is required for dating market calculations.',
          resolution: 'Please go back to the Calculator and select your gender.'
        });
      }
      if (!formData.ethnicity) {
        errors.push({
          type: 'MISSING_USER_FIELD',
          field: 'ethnicity',
          message: 'Ethnicity is required for demographic calculations.',
          resolution: 'Please go back to the Calculator and select your ethnicity.'
        });
      }
      
      return errors;
    };
    
    const validationErrors = validateReportData();
    
    // If validation fails, show error state with resolution steps
    if (validationErrors.length > 0) {
      return (
        <div style={{ width: '100%', padding: '32px 32px', backgroundColor: '#FAF9F5', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif', display: 'flex', flexDirection: 'column' }}>
          <div style={{ maxWidth: `${containerWidth}px`, margin: '0 auto', width: '100%', flex: 1, display: 'flex', flexDirection: 'column' }}>
            <PageHeader currentPage={currentPage} setCurrentPage={setCurrentPage} scaledFont={scaledFont} windowWidth={windowWidth} containerWidth={containerWidth} setContainerWidth={setContainerWidth} />
            <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #B53232', padding: '32px', flex: 1, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center' }}>
              <div style={{ maxWidth: '500px', width: '100%' }}>
                <h2 style={{ fontSize: scaledFont(16), fontWeight: '700', color: '#B53232', margin: '0 0 16px', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
                  <span style={{ fontSize: scaledFont(20) }}>⚠</span> Unable to Generate Report
                </h2>
                <p style={{ fontSize: scaledFont(13), color: '#73726C', margin: '0 0 20px', lineHeight: '1.6', textAlign: 'center' }}>
                  We found {validationErrors.length} issue{validationErrors.length > 1 ? 's' : ''} that must be resolved before your report can be generated:
                </p>
                
                <div style={{ display: 'flex', flexDirection: 'column', gap: '16px', marginBottom: '24px' }}>
                  {validationErrors.map((error, idx) => (
                    <div key={idx} style={{ 
                      backgroundColor: '#FEF2F2', 
                      border: '1px solid #FECACA', 
                      borderRadius: '4px', 
                      padding: '16px' 
                    }}>
                      <div style={{ fontSize: scaledFont(13), fontWeight: '600', color: '#991B1B', marginBottom: '8px' }}>
                        {error.year ? `Year ${error.year}: ` : ''}{error.message}
                      </div>
                      <div style={{ fontSize: scaledFont(12), color: '#73726C', lineHeight: '1.5' }}>
                        <strong>How to fix:</strong> {error.resolution}
                      </div>
                      {error.missingFields && (
                        <div style={{ fontSize: scaledFont(11), color: '#9CA3AF', marginTop: '8px', fontFamily: 'monospace' }}>
                          Missing: {error.missingFields.join(', ')}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                
                <div style={{ display: 'flex', gap: '12px', justifyContent: 'center' }}>
                  <button 
                    onClick={() => setCurrentPage('calculator')} 
                    style={{ 
                      padding: '10px 16px', 
                      backgroundColor: '#C96442', 
                      color: 'white', 
                      border: 'none', 
                      borderRadius: '4px', 
                      fontSize: scaledFont(11), 
                      fontWeight: '600', 
                      cursor: 'pointer', 
                      textTransform: 'uppercase', 
                      letterSpacing: '0.05em' 
                    }}
                  >
                    Edit Calculator
                  </button>
                  <button 
                    onClick={() => window.location.reload()} 
                    style={{ 
                      padding: '10px 16px', 
                      backgroundColor: 'white', 
                      color: '#73726C', 
                      border: '1px solid #e5e7eb', 
                      borderRadius: '4px', 
                      fontSize: scaledFont(11), 
                      fontWeight: '600', 
                      cursor: 'pointer', 
                      textTransform: 'uppercase', 
                      letterSpacing: '0.05em' 
                    }}
                  >
                    Refresh Page
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      );
    }
    // =============================================================================
    // END VALIDATION GATE - All data verified, proceed with calculations
    // =============================================================================
    
    // Calculate report data from formData
    const sortedYears = [...filledYears].sort((a, b) => parseInt(a.year) - parseInt(b.year));
    const lastYearIncome = parseInt(sortedYears[sortedYears.length - 1].income);
    const globalGender = formData.gender || 'man';
    const globalEthnicity = formData.ethnicity || 'white';
    const globalOrientation = formData.orientation || 'straight';
    
    // Parse partner preferences from probe response (only applies to current year if single)
    const partnerPrefsRaw = formData.probeResponses?.partnerPreferences;
    const parsedPartnerPrefs = parsePartnerPreferences(partnerPrefsRaw);
    
    // Parse relocation openness from probe response (matches against actual CBSA data)
    const relocationRaw = formData.probeResponses?.relocationOpenness;
    const parsedRelocation = parseRelocationResponse(relocationRaw, cbsaDataLoaded);
    
    // If there are unmatched locations, we could potentially do an async lookup
    // For now, store them for display or future web search integration
    const relocationData = parsedRelocation || { 
      openToRelocation: null, 
      matchedCBSAs: [], 
      unmatchedLocations: [],
      consideredLocations: [],
      motivations: [],
      consideringInternational: false
    };
    
    const reportData = sortedYears.map((row, idx) => {
      // Look up CBSA by ZIP code or location name (uses fetched GitHub data with 917 CBSAs)
      const matchedCBSA = getCBSAForLocation(row.zipCode, row.location);
      
      // Start with DEFAULT_CBSA, then overlay ALL GitHub data (no selective fallbacks)
      // This ensures: 1) All required fields exist from defaults, 2) GitHub data wins when present
      const cbsaData = matchedCBSA ? {
        ...DEFAULT_CBSA,
        ...matchedCBSA,  // GitHub data overwrites defaults - no manual mappings with fallbacks
        name: matchedCBSA.name || matchedCBSA.cbsa_name || 'Unknown Metro',
        cbsa_population: matchedCBSA.cbsa_population || matchedCBSA.population,
        latitude: matchedCBSA.lat,
        longitude: matchedCBSA.lng,
      } : DEFAULT_CBSA;
      // Only apply partner prefs to the most recent year (idx === sortedYears.length - 1)
      const usePrefs = idx === sortedYears.length - 1 ? parsedPartnerPrefs : null;
      return calculateDataRowCalc(row, lastYearIncome, cbsaData, globalGender, globalEthnicity, globalOrientation, usePrefs);
    });
    
    const reportChartData = reportData.map(d => ({ ...d, bandHeight: d.equiv700k - d.greenLine }));
    
    // Calculate stats for cards
    const reportFirstYear = reportData[0];
    const reportLastYear = reportData[reportData.length - 1];
    const percentileGrowth = reportLastYear.percentile - reportFirstYear.percentile;
    const incomeMultiple = (reportLastYear.income / reportFirstYear.income).toFixed(1);
    
    // Calculate years below functional
    const reportStartYear = reportFirstYear.year;
    const reportEndYear = reportLastYear.year;
    let reportYearsBelowFunctional = 0;
    for (let year = reportStartYear; year <= reportEndYear; year++) {
      let prevPoint = reportData[0];
      let nextPoint = reportData[reportData.length - 1];
      for (let i = 0; i < reportData.length - 1; i++) {
        if (reportData[i].year <= year && reportData[i + 1].year >= year) {
          prevPoint = reportData[i];
          nextPoint = reportData[i + 1];
          break;
        }
      }
      let income, greenLine;
      if (year === prevPoint.year) { income = prevPoint.income; greenLine = prevPoint.greenLine; }
      else if (year === nextPoint.year) { income = nextPoint.income; greenLine = nextPoint.greenLine; }
      else {
        const t = (year - prevPoint.year) / (nextPoint.year - prevPoint.year);
        income = prevPoint.income + t * (nextPoint.income - prevPoint.income);
        greenLine = prevPoint.greenLine + t * (nextPoint.greenLine - prevPoint.greenLine);
      }
      if (income < greenLine) reportYearsBelowFunctional++;
    }
    
    const reportStatsCards = [
      { key: 'start', label: `Start at ${reportFirstYear.age}`, value: `$${Math.round(reportFirstYear.income / 1000)}k`, sub: `${reportFirstYear.year} ${reportFirstYear.location}`, highlight: false },
      { key: 'current', label: `CURRENT at ${reportLastYear.age}`, value: `$${Math.round(reportLastYear.income / 1000)}k`, sub: `${reportLastYear.year} ${reportLastYear.location}`, highlight: false },
      { key: 'percentile', label: 'Percentile', value: reportLastYear.percentile >= 99 ? 'Top 1%' : `${reportLastYear.percentile}th`, sub: `Grew by ${percentileGrowth} points`, highlight: true },
      { key: 'multiple', label: 'Multiple', value: `${incomeMultiple}x`, sub: `Growth since age ${reportFirstYear.age}`, highlight: true },
      { key: 'belowFunctional', label: 'Below Functional', value: `${reportYearsBelowFunctional} Years`, sub: 'Lived below functional poverty', highlight: false },
      { key: 'vsGoal', label: 'vs Goal', value: `${reportLastYear.pctToGoal}%`, sub: `${(reportLastYear.pctToGoal / 100).toFixed(1)}x target`, highlight: true },
      { key: 'relateScore', label: 'Relate Score', value: `${Math.round(reportLastYear.relateScore / 10)}/10`, sub: `${reportLastYear.year} ${reportLastYear.location}`, highlight: false },
      { key: 'matchScore', label: 'Match Score', value: reportLastYear.matchPool !== null ? `${Math.round(reportLastYear.matchPool / 1000)}k` : 'N/A', sub: reportLastYear.matchPool ? 'Realistic matches' : 'Married', highlight: false },
    ];
    
    // Report toggle and section state (defined at component top level per React hooks rules)
    const reportToggle = (key) => setReportVisibleLines(prev => ({ ...prev, [key]: !prev[key] }));
    const reportHasPercent = reportVisibleLines.percentile || reportVisibleLines.achieve || reportVisibleLines.relateScore || reportVisibleLines.matchScore;
    const reportHasDollar = reportVisibleLines.income || reportVisibleLines.purchasePower || reportVisibleLines.equiv700k || reportVisibleLines.goal || reportVisibleLines.safe || reportVisibleLines.greenLine || reportVisibleLines.medianHH || reportVisibleLines.povertyLine;
    const reportAnyToggleActive = reportHasPercent || reportHasDollar;
    
    // Dynamic lineConfig for Report - updates equiv700k label to user's actual last income
    const lastIncomeK = Math.round(reportLastYear.income / 1000);
    const reportLineConfig = {
      ...lineConfig,
      equiv700k: { ...lineConfig.equiv700k, label: `$${lastIncomeK}k Equivalent` }
    };
    
    // Custom tooltip for report
    const ReportCustomTooltip = ({ active, payload, label }) => {
      if (active && payload && payload.length) {
        const d = reportData.find(d => d.year === label);
        if (!d) return null;
        const showRelateMatch = reportVisibleLines.relateScore || reportVisibleLines.matchScore;
        const relateTier = Math.round(d.relateScore / 10);
        const formatPoolLocal = (n) => n >= 1000000 ? `${(n/1000000).toFixed(1)}M` : n >= 1000 ? `${Math.round(n/1000)}k` : n;
        const formatPopLocal = (n) => n >= 1000000 ? `${(n/1000000).toFixed(1)}M` : `${(n/1000).toFixed(0)}k`;
        return (
          <div style={{ backgroundColor: '#1f2937', padding: '12px', borderRadius: '4px', fontSize: '11px', color: '#ffffff', minWidth: '220px' }}>
            <div style={{ fontWeight: '600', marginBottom: '8px', paddingBottom: '6px', borderBottom: '1px solid #73726C' }}>{label} · {d?.location}</div>
            {reportVisibleLines.income && <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}><span style={{ color: '#d1d5db' }}>Income</span><span style={{ color: '#ffffff', fontWeight: '500', filter: 'brightness(1.3)' }}>{formatCurrency(d.income)}</span></div>}
            {reportVisibleLines.purchasePower && <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}><span style={{ color: '#d1d5db' }}>Purchase Power</span><span style={{ color: lineConfig.purchasePower.color, fontWeight: '500', filter: 'brightness(1.3)' }}>{formatCurrency(d.purchasePower)}</span></div>}
            {reportVisibleLines.equiv700k && <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}><span style={{ color: '#d1d5db' }}>${Math.round(reportLastYear.income/1000)}k Equiv</span><span style={{ color: lineConfig.equiv700k.hoverColor, fontWeight: '500', filter: 'brightness(1.3)' }}>{formatCurrency(d.equiv700k)}</span></div>}
            {reportVisibleLines.goal && <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}><span style={{ color: '#d1d5db' }}>Initial Goal</span><span style={{ color: lineConfig.goal.color, fontWeight: '500', filter: 'brightness(1.3)' }}>{formatCurrency(d.goal)}</span></div>}
            {reportVisibleLines.achieve && <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}><span style={{ color: '#d1d5db' }}>Achieved</span><span style={{ color: lineConfig.achieve.color, fontWeight: '500', filter: 'brightness(1.3)' }}>{d.pctToGoal}%</span></div>}
            {reportVisibleLines.safe && <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}><span style={{ color: '#d1d5db' }}>Safe Family Of Four</span><span style={{ color: lineConfig.safe.color, fontWeight: '500', filter: 'brightness(1.3)' }}>{formatCurrency(d.safe)}</span></div>}
            {reportVisibleLines.greenLine && <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}><span style={{ color: '#d1d5db' }}>Functional Survival</span><span style={{ color: lineConfig.greenLine.color, fontWeight: '500', filter: 'brightness(1.3)' }}>{formatCurrency(d.greenLine)}</span></div>}
            {reportVisibleLines.medianHH && <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}><span style={{ color: '#d1d5db' }}>Median Household</span><span style={{ color: lineConfig.medianHH.color, fontWeight: '500', filter: 'brightness(1.3)' }}>{formatCurrency(d.medianHH)}</span></div>}
            {reportVisibleLines.povertyLine && <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}><span style={{ color: '#d1d5db' }}>Poverty Line</span><span style={{ color: lineConfig.povertyLine.color, fontWeight: '500', filter: 'brightness(1.3)' }}>{formatCurrency(d.povertyLine)}</span></div>}
            {reportVisibleLines.percentile && <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}><span style={{ color: '#d1d5db' }}>Percentile</span><span style={{ color: lineConfig.percentile.color, fontWeight: '500', filter: 'brightness(1.3)' }}>{d.percentile === 99 ? 'Top 1%' : `${d.percentile}th`}</span></div>}
            {showRelateMatch && (() => {
              const relateTier = Math.round(d.relateScore / 10);
              const gap = d.greenLine - d.income;
              const surplus = d.income - d.greenLine;
              const c = d.relateComponents || {};
              
              // Dynamic explanation based on data point characteristics (THE GOOD PROSE)
              let relateContext;
              const isMarried = d.matchScore === null;
              const nearPoverty = d.income < d.povertyLine * 1.5;
              const belowFunctional = d.income < d.greenLine;
              const aboveSafe = d.income > d.safe;
              const aboveGoal = d.income > d.goal;
              
              if (nearPoverty && d.percentile < 30) {
                relateContext = 'financial pressure limiting options';
              } else if (nearPoverty && d.percentile < 45) {
                relateContext = 'stretched thin in expensive market';
              } else if (belowFunctional && d.year < 2005) {
                relateContext = 'early career in high-cost area';
              } else if (belowFunctional && d.percentile >= 50) {
                relateContext = 'income decent but costs eating it';
              } else if (belowFunctional) {
                relateContext = 'local expenses outpacing earnings';
              } else if (isMarried && aboveGoal) {
                relateContext = 'peak earning years, settled down';
              } else if (isMarried && d.percentile >= 75) {
                relateContext = 'strong provider, off market';
              } else if (isMarried) {
                relateContext = 'married during building years';
              } else if (aboveGoal && d.percentile >= 90) {
                relateContext = 'income dominating this market';
              } else if (aboveSafe && d.percentile >= 85) {
                relateContext = 'earnings giving you real leverage';
              } else if (aboveSafe && surplus > 50000) {
                relateContext = 'comfortable surplus above survival';
              } else if (d.percentile >= 75 && surplus > 20000) {
                relateContext = 'solid position with breathing room';
              } else if (d.age >= 40 && relateTier >= 7) {
                relateContext = 'experience and earnings aligned';
              } else if (d.age < 30 && relateTier >= 6) {
                relateContext = 'ahead of curve for your age';
              } else if (d.age < 30 && d.percentile >= 50) {
                relateContext = 'building momentum early';
              } else if (relateTier >= 7) {
                relateContext = 'well positioned locally';
              } else if (relateTier >= 5) {
                relateContext = 'competitive but room to grow';
              } else {
                relateContext = 'facing headwinds in this market';
              }
              
              // NEW: Build "what's holding back 10" explanation
              let holdingBack = null;
              if (relateTier >= 7 && relateTier < 10) {
                const drags = [];
                if (c.ageScore < 90) drags.push('age');
                if (c.childrenScore < 65) drags.push('kids');
                if (c.incomeLocal < 90) drags.push('income');
                if (c.eduLocal < 65) drags.push('education');
                if (c.ethnicityScore < 55) drags.push('demographics');
                
                if (drags.length > 0) {
                  holdingBack = drags.slice(0, 2).join(' and ') + ' keeping you from a 10';
                }
              }
              
              // Warning states
              let warningColor = null;
              if (d.income < d.povertyLine) warningColor = '#B53232';
              else if (gap > 0) warningColor = '#eab308';
              
              // Preference-filtered pool calculation
              let prefFilteredPool = null;
              let prefLabel = null;
              if (d.matchScore !== null && d.localSinglePool) {
                if (parsedPartnerPrefs) {
                  // User answered preferences - calculate filtered pool
                  let prefMult = 1.0;
                  const prefParts = [];
                  if (parsedPartnerPrefs.ethnicityPref && parsedPartnerPrefs.ethnicityPref !== 'any') {
                    const ethPct = (cbsaDataLoaded?.[`ethnicity_${parsedPartnerPrefs.ethnicityPref}_cbsa`] || 20) / 100;
                    prefMult *= ethPct;
                    prefParts.push(parsedPartnerPrefs.ethnicityPref);
                  }
                  if (parsedPartnerPrefs.openToKids === false) {
                    const noKidsPct = (cbsaDataLoaded?.have_kids_no_cbsa || 60) / 100;
                    prefMult *= noKidsPct;
                    prefParts.push('no kids');
                  }
                  if (parsedPartnerPrefs.educationMin === 'bachelors' || parsedPartnerPrefs.educationMin === 'graduate') {
                    const eduPct = ((cbsaDataLoaded?.education_bachelors_cbsa || 21) + (cbsaDataLoaded?.education_graduate_cbsa || 10)) / 100;
                    prefMult *= eduPct;
                    prefParts.push('degree');
                  }
                  if (parsedPartnerPrefs.incomeMin) {
                    let incPct = 0.3; // default ~30% above 75k
                    if (parsedPartnerPrefs.incomeMin >= 100000) incPct = 0.15;
                    if (parsedPartnerPrefs.incomeMin >= 150000) incPct = 0.08;
                    prefMult *= incPct;
                    prefParts.push(`$${Math.round(parsedPartnerPrefs.incomeMin/1000)}k+`);
                  }
                  prefFilteredPool = Math.round(d.localSinglePool * prefMult * (d.matchPool / d.localSinglePool));
                  prefLabel = prefParts.length > 0 ? prefParts.join(', ') : 'your preferences';
                } else {
                  // Default: match user's race and education
                  const isWhite = d.ethnicity?.toLowerCase() === 'white';
                  const hasDegree = ['Graduate', 'Bachelors', "Bachelor's"].includes(d.education);
                  let defMult = 1.0;
                  const defParts = [];
                  
                  if (isWhite) {
                    defMult *= (cbsaDataLoaded?.ethnicity_white_cbsa || 58) / 100;
                    defParts.push('white');
                  } else {
                    defMult *= (100 - (cbsaDataLoaded?.ethnicity_white_cbsa || 58)) / 100;
                    defParts.push('POC');
                  }
                  if (hasDegree) {
                    defMult *= ((cbsaDataLoaded?.education_bachelors_cbsa || 21) + (cbsaDataLoaded?.education_graduate_cbsa || 10)) / 100;
                    defParts.push('degree');
                  }
                  prefFilteredPool = Math.round(d.localSinglePool * defMult * (d.matchPool / d.localSinglePool));
                  prefLabel = defParts.join(' + ');
                }
              }
              
              return (
                <div style={{ borderTop: '1px solid #73726C', marginTop: '6px', paddingTop: '6px', fontSize: '10px', lineHeight: '1.5' }}>
                  {reportVisibleLines.relateScore && (
                    <div style={{ marginBottom: reportVisibleLines.matchScore ? '6px' : '0' }}>
                      <div style={{ marginBottom: '3px' }}>
                        <span style={{ color: lineConfig.relateScore.color, fontWeight: '600' }}>{relateTier}/10</span>
                        <span style={{ color: '#d1d5db' }}> in local dating economy</span>
                      </div>
                      <div style={{ color: warningColor || '#9ca3af' }}>
                        {relateContext.charAt(0).toUpperCase() + relateContext.slice(1)}
                      </div>
                      {holdingBack && (
                        <div style={{ color: '#9ca3af', marginTop: '2px' }}>
                          {holdingBack.charAt(0).toUpperCase() + holdingBack.slice(1)}
                        </div>
                      )}
                    </div>
                  )}
                  {reportVisibleLines.matchScore && (
                    <div>
                      {d.matchScore === null ? (
                        <span style={{ color: '#9ca3af' }}>Off market during marriage</span>
                      ) : (
                        <>
                          <div style={{ marginBottom: '2px' }}>
                            <span style={{ color: lineConfig.matchScore.color, fontWeight: '600' }}>{formatPoolLocal(d.realisticMatches || d.matchPool)}</span>
                            <span style={{ color: '#d1d5db' }}> realistic matches</span>
                          </div>
                          <div style={{ marginBottom: '2px' }}>
                            <span style={{ color: '#A193D8', fontWeight: '600' }}>{formatPoolLocal(d.preferredMatches || Math.round((d.matchPool || 0) * 0.6))}</span>
                            <span style={{ color: '#d1d5db' }}> preferred matches</span>
                          </div>
                          <div style={{ marginBottom: '2px' }}>
                            <span style={{ color: '#C4B5F0', fontWeight: '600' }}>{formatPoolLocal(d.idealMatches || Math.round((d.matchPool || 0) * 0.25))}</span>
                            <span style={{ color: '#d1d5db' }}> ideal matches</span>
                          </div>
                          <div style={{ color: '#9ca3af', fontSize: '10px', marginTop: '4px' }}>
                            from {formatPoolLocal(d.realisticPool || d.localSinglePool)} local single {d.targetGenderLabel || 'people'}
                          </div>
                        </>
                      )}
                    </div>
                  )}
                </div>
              );
            })()}
          </div>
        );
      }
      return null;
    };
    
    // Band components for report chart
    // Functional Band - yellow shaded area between income and greenLine
    const ReportFunctionalBand = ({ xAxisMap, yAxisMap, data: chartData }) => {
      if (!xAxisMap || !yAxisMap || !chartData) return null;
      const xAxis = Object.values(xAxisMap)[0];
      const yAxis = Object.values(yAxisMap).find(a => a.yAxisId === 'dollar');
      if (!xAxis || !yAxis || !xAxis.scale || !yAxis.scale) return null;
      const xScale = xAxis.scale;
      const yScale = yAxis.scale;
      const getTop = d => d.income;
      const getBot = d => d.greenLine;
      const topPts = [];
      const botPts = [];
      for (let i = 0; i < chartData.length; i++) {
        const d = chartData[i];
        if (d.income >= d.greenLine) { topPts.push(`${xScale(d.year)},${yScale(d.income)}`); botPts.push(`${xScale(d.year)},${yScale(d.greenLine)}`); }
        else { topPts.push(`${xScale(d.year)},${yScale(d.income)}`); botPts.push(`${xScale(d.year)},${yScale(d.income)}`); }
        if (i < chartData.length - 1) {
          const diff1 = getTop(chartData[i]) - getBot(chartData[i]);
          const diff2 = getTop(chartData[i+1]) - getBot(chartData[i+1]);
          if ((diff1 > 0) !== (diff2 > 0)) {
            const t = diff1 / (diff1 - diff2);
            const crossYear = chartData[i].year + t * (chartData[i+1].year - chartData[i].year);
            const crossValue = getTop(chartData[i]) + t * (getTop(chartData[i+1]) - getTop(chartData[i]));
            topPts.push(`${xScale(crossYear)},${yScale(crossValue)}`);
            botPts.push(`${xScale(crossYear)},${yScale(crossValue)}`);
          }
        }
      }
      const points = topPts.join(' ') + ' ' + botPts.reverse().join(' ');
      return <polygon points={points} fill="#eab308" fillOpacity={0.08} stroke="none" />;
    };
    
    // Aspiration Band - green shaded area between Safe and Goal
    const ReportAspirationBand = ({ xAxisMap, yAxisMap, data: chartData }) => {
      if (!xAxisMap || !yAxisMap || !chartData) return null;
      const xAxis = Object.values(xAxisMap)[0];
      const yAxis = Object.values(yAxisMap).find(a => a.yAxisId === 'dollar');
      if (!xAxis || !yAxis || !xAxis.scale || !yAxis.scale) return null;
      const xScale = xAxis.scale;
      const yScale = yAxis.scale;
      const topPts = [];
      const botPts = [];
      for (let i = 0; i < chartData.length; i++) {
        const d = chartData[i];
        if (d.goal > d.safe) {
          topPts.push(`${xScale(d.year)},${yScale(d.goal)}`);
          botPts.push(`${xScale(d.year)},${yScale(d.safe)}`);
        } else {
          topPts.push(`${xScale(d.year)},${yScale(d.safe)}`);
          botPts.push(`${xScale(d.year)},${yScale(d.safe)}`);
        }
      }
      const points = topPts.join(' ') + ' ' + botPts.reverse().join(' ');
      return <polygon points={points} fill="#86efac" fillOpacity={0.25} stroke="none" />;
    };
    
    const ReportGoalBand = ({ xAxisMap, yAxisMap, data: chartData }) => {
      if (!xAxisMap || !yAxisMap || !chartData) return null;
      const xAxis = Object.values(xAxisMap)[0];
      const yAxis = Object.values(yAxisMap).find(a => a.yAxisId === 'dollar');
      if (!xAxis || !yAxis || !xAxis.scale || !yAxis.scale) return null;
      const xScale = xAxis.scale;
      const yScale = yAxis.scale;
      const getTop = d => d.income;
      const getBot = d => d.goal;
      const topPts = [];
      const botPts = [];
      for (let i = 0; i < chartData.length; i++) {
        const d = chartData[i];
        if (d.income >= d.goal) { topPts.push(`${xScale(d.year)},${yScale(d.income)}`); botPts.push(`${xScale(d.year)},${yScale(d.goal)}`); }
        else { topPts.push(`${xScale(d.year)},${yScale(d.income)}`); botPts.push(`${xScale(d.year)},${yScale(d.income)}`); }
        if (i < chartData.length - 1) {
          const diff1 = getTop(chartData[i]) - getBot(chartData[i]);
          const diff2 = getTop(chartData[i+1]) - getBot(chartData[i+1]);
          if ((diff1 > 0) !== (diff2 > 0)) {
            const t = diff1 / (diff1 - diff2);
            const crossYear = chartData[i].year + t * (chartData[i+1].year - chartData[i].year);
            const crossValue = getTop(chartData[i]) + t * (getTop(chartData[i+1]) - getTop(chartData[i]));
            topPts.push(`${xScale(crossYear)},${yScale(crossValue)}`);
            botPts.push(`${xScale(crossYear)},${yScale(crossValue)}`);
          }
        }
      }
      const points = topPts.join(' ') + ' ' + botPts.reverse().join(' ');
      return <polygon points={points} fill="#E3EED5" fillOpacity={0.075} stroke="none" />;
    };
    
    const ReportOverlapBand = ({ xAxisMap, yAxisMap, data: chartData }) => {
      if (!xAxisMap || !yAxisMap || !chartData) return null;
      const xAxis = Object.values(xAxisMap)[0];
      const yAxis = Object.values(yAxisMap).find(a => a.yAxisId === 'dollar');
      if (!xAxis || !yAxis || !xAxis.scale || !yAxis.scale) return null;
      const xScale = xAxis.scale;
      const yScale = yAxis.scale;
      const getTop = d => d.income;
      const getBot = d => Math.max(d.goal, d.greenLine);
      const topPts = [];
      const botPts = [];
      for (let i = 0; i < chartData.length; i++) {
        const d = chartData[i];
        const thresh = Math.max(d.goal, d.greenLine);
        if (d.income >= thresh) { topPts.push(`${xScale(d.year)},${yScale(d.income)}`); botPts.push(`${xScale(d.year)},${yScale(thresh)}`); }
        else { topPts.push(`${xScale(d.year)},${yScale(d.income)}`); botPts.push(`${xScale(d.year)},${yScale(d.income)}`); }
        if (i < chartData.length - 1) {
          const diff1 = getTop(chartData[i]) - getBot(chartData[i]);
          const diff2 = getTop(chartData[i+1]) - getBot(chartData[i+1]);
          if ((diff1 > 0) !== (diff2 > 0)) {
            const t = diff1 / (diff1 - diff2);
            const crossYear = chartData[i].year + t * (chartData[i+1].year - chartData[i].year);
            const crossValue = getTop(chartData[i]) + t * (getTop(chartData[i+1]) - getTop(chartData[i]));
            topPts.push(`${xScale(crossYear)},${yScale(crossValue)}`);
            botPts.push(`${xScale(crossYear)},${yScale(crossValue)}`);
          }
        }
      }
      const points = topPts.join(' ') + ' ' + botPts.reverse().join(' ');
      return <polygon points={points} fill="#64748b" fillOpacity={0.06} stroke="none" />;
    };
    
    return (
      <div style={{ width: '100%', padding: '32px 32px', backgroundColor: '#FAF9F5', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
        <div style={{ maxWidth: `${containerWidth}px`, margin: '0 auto' }}>
          
          {/* Header */}
          <PageHeader currentPage={currentPage} setCurrentPage={setCurrentPage} scaledFont={scaledFont} windowWidth={windowWidth} containerWidth={containerWidth} setContainerWidth={setContainerWidth} />

          {/* Key Stats Cards */}
          {useCollapsedCards ? (
            <div style={{ marginBottom: '16px', backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb' }}>
              <button
                onClick={() => setCardsMenuOpen(!cardsMenuOpen)}
                style={{
                  width: '100%',
                  padding: '10px 16px',
                  display: 'flex',
                  justifyContent: 'space-between',
                  alignItems: 'center',
                  border: 'none',
                  backgroundColor: 'transparent',
                  cursor: 'pointer',
                  fontSize: '11px',
                  fontWeight: '600',
                  color: '#374151',
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em',
                }}
              >
                <span>Key Stats</span>
                <span style={{ fontSize: '10px', color: '#9A9891' }}>{cardsMenuOpen ? '▲' : '▼'}</span>
              </button>
              {cardsMenuOpen && (
                <div style={{ padding: '0 16px 16px', borderTop: '1px solid #e5e7eb' }}>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', paddingTop: '12px' }}>
                    {reportStatsCards.map((card, i) => (
                      <div 
                        key={card.key} 
                        style={{ 
                          padding: '8px 0',
                          borderBottom: i < reportStatsCards.length - 2 ? '1px solid #EBE8E0' : 'none',
                          cursor: 'pointer',
                          textAlign: 'center'
                        }}
                        onClick={() => handleCardClick(card.key)}
                      >
                        <div style={{ fontSize: '18px', fontWeight: '700', color: '#141413', fontFamily: 'monospace', textDecoration: card.highlight ? 'underline' : 'none', textDecorationColor: '#d1d5db', textUnderlineOffset: '3px', marginBottom: '4px' }}>{card.value}</div>
                        <div style={{ fontSize: '10px', color: '#73726C', textTransform: 'uppercase', letterSpacing: '0.03em', marginBottom: '2px' }}>{card.label}</div>
                        <div style={{ fontSize: '9px', color: '#9A9891' }}>{card.sub}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: '16px', marginBottom: '16px' }}>
              {reportStatsCards.map((card) => (
                <StatCard 
                  key={card.key}
                  label={card.label} 
                  value={card.value} 
                  sub={card.sub} 
                  highlight={card.highlight}
                  onClick={() => handleCardClick(card.key)} 
                  isActive={activeCard === card.key} 
                />
              ))}
            </div>
          )}

          {/* Toggles - Responsive */}
          <div style={{ marginBottom: '16px', backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb' }}>
            {useDropdownToggles ? (
              <>
                <button
                  onClick={() => setReportToggleMenuOpen(!reportToggleMenuOpen)}
                  style={{
                    width: '100%',
                    padding: '10px 16px',
                    display: 'flex',
                    justifyContent: 'space-between',
                    alignItems: 'center',
                    border: 'none',
                    backgroundColor: 'transparent',
                    cursor: 'pointer',
                    fontSize: '11px',
                    fontWeight: '600',
                    color: '#374151',
                    textTransform: 'uppercase',
                    letterSpacing: '0.05em',
                  }}
                >
                  <span>Chart Options</span>
                  <span style={{ fontSize: '10px', color: '#9A9891' }}>{reportToggleMenuOpen ? '▲' : '▼'}</span>
                </button>
                {reportToggleMenuOpen && (
                  <div style={{ padding: '0 16px 12px', borderTop: '1px solid #e5e7eb' }}>
                    <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: '8px', paddingTop: '12px' }}>
                      {Object.entries(lineConfig).map(([key, config]) => (
                        <label key={key} style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '10px' }}>
                          <input
                            type="checkbox"
                            checked={reportVisibleLines[key]}
                            onChange={() => setReportVisibleLines(prev => ({ ...prev, [key]: !prev[key] }))}
                            style={{ accentColor: config.color }}
                          />
                          <span style={{ color: reportVisibleLines[key] ? config.color : '#9A9891' }}>{config.label}</span>
                        </label>
                      ))}
                    </div>
                  </div>
                )}
              </>
            ) : (
              <div style={{ padding: '10px 16px', display: 'flex', flexWrap: 'wrap', gap: '12px' }}>
                {Object.entries(lineConfig).map(([key, config]) => (
                  <label key={key} style={{ display: 'flex', alignItems: 'center', gap: '6px', cursor: 'pointer', fontSize: '10px' }}>
                    <input
                      type="checkbox"
                      checked={reportVisibleLines[key]}
                      onChange={() => setReportVisibleLines(prev => ({ ...prev, [key]: !prev[key] }))}
                      style={{ accentColor: config.color }}
                    />
                    <span style={{ color: reportVisibleLines[key] ? config.color : '#9A9891' }}>{config.label}</span>
                  </label>
                ))}
              </div>
            )}
          </div>

          {/* Chart */}
          <div>
            <div style={{ height: 340, backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px', position: 'relative', transition: 'height 0.2s ease' }}>
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart data={reportChartData} margin={{ top: 20, right: 8, left: 0, bottom: 20 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#e5e7eb" />
                  <XAxis 
                    dataKey="year" 
                    tick={{ fontSize: scaledFont(10), fill: '#73726C' }} 
                    axisLine={{ stroke: '#e5e7eb' }}
                    tickLine={false}
                    type="number"
                    domain={['dataMin', 'dataMax']}
                    ticks={reportChartData.map(d => d.year)}
                    tickFormatter={(val) => `'${String(val).slice(2)}`}
                    scale="linear"
                    interval={0}
                  />
                  <YAxis 
                    yAxisId="left" 
                    tick={{ fontSize: scaledFont(10), fill: '#73726C' }} 
                    axisLine={{ stroke: '#e5e7eb' }}
                    tickLine={false}
                    tickFormatter={formatCurrency} 
                    width={72}
                    domain={[0, 'auto']}
                    tickCount={6}
                    label={({ viewBox }) => (
                      <text x={viewBox.x + 8} y={viewBox.y + 16} fontSize={10} fill="#73726C">
                        {formatCurrency(Math.max(...reportChartData.map(d => d.income)))}
                      </text>
                    )}
                  />
                  <YAxis 
                    yAxisId="right" 
                    orientation="right" 
                    tick={{ fontSize: scaledFont(10), fill: '#73726C' }}
                    axisLine={{ stroke: '#e5e7eb' }}
                    tickLine={false}
                    tickFormatter={formatPercentTick} 
                    domain={[0, transformPercentile(100)]}
                    ticks={[0, 25, 50, 75, 90, 95, 99].map(transformPercentile)}
                    width={36}
                  />
                  <Tooltip content={<ReportCustomTooltip />} />
                  
                  {/* Aspiration Zone Shading - green between Safe and Goal */}
                  <Customized component={(props) => <ReportAspirationBand {...props} chartData={reportChartData} visibleLines={reportVisibleLines} />} />
                  {/* Functional Zone Shading - yellow between income and greenLine */}
                  <Customized component={(props) => <ReportFunctionalBand {...props} chartData={reportChartData} visibleLines={reportVisibleLines} />} />
                  {/* Goal Achievement Shading - between goal and income (when income > goal) */}
                  <Customized component={(props) => <ReportGoalBand {...props} chartData={reportChartData} visibleLines={reportVisibleLines} />} />
                  
                  {reportVisibleLines.income && <Line yAxisId="left" type="monotone" dataKey="income" stroke="#ffffff" strokeWidth={3} dot={false} filter="drop-shadow(0 0 2px rgba(0,0,0,0.5))" />}
                  {reportVisibleLines.purchasePower && <Line yAxisId="left" type="monotone" dataKey="purchasePower" stroke={lineConfig.purchasePower.color} strokeWidth={2} dot={false} />}
                  {reportVisibleLines.equiv700k && <Line yAxisId="left" type="monotone" dataKey="equiv700k" stroke={lineConfig.equiv700k.color} strokeWidth={1.5} strokeDasharray="4 2" dot={false} />}
                  {reportVisibleLines.goal && <Line yAxisId="left" type="monotone" dataKey="goal" stroke={lineConfig.goal.color} strokeWidth={1.5} strokeDasharray="4 2" dot={false} />}
                  {reportVisibleLines.safe && <Line yAxisId="left" type="monotone" dataKey="safe" stroke={lineConfig.safe.color} strokeWidth={1.5} dot={false} />}
                  {reportVisibleLines.greenLine && <Line yAxisId="left" type="monotone" dataKey="greenLine" stroke={lineConfig.greenLine.color} strokeWidth={1.5} dot={false} />}
                  {reportVisibleLines.medianHH && <Line yAxisId="left" type="monotone" dataKey="medianHH" stroke={lineConfig.medianHH.color} strokeWidth={1} strokeDasharray="2 2" dot={false} />}
                  {reportVisibleLines.povertyLine && <Line yAxisId="left" type="monotone" dataKey="povertyLine" stroke={lineConfig.povertyLine.color} strokeWidth={1} strokeDasharray="2 2" dot={false} />}
                  {reportVisibleLines.percentile && <Line yAxisId="right" type="monotone" dataKey="percentileTransformed" stroke={lineConfig.percentile.color} strokeWidth={2} dot={false} />}
                  {reportVisibleLines.relateScore && <Line yAxisId="right" type="monotone" dataKey="relateTransformed" stroke={lineConfig.relateScore.color} strokeWidth={2} dot={false} />}
                  {reportVisibleLines.matchScore && <Line yAxisId="right" type="monotone" dataKey="matchTransformed" stroke={lineConfig.matchScore.color} strokeWidth={2} dot={false} />}
                </ComposedChart>
              </ResponsiveContainer>
            </div>
            <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '10px 16px', marginBottom: '16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
              <span style={{ fontSize: scaledFont(10), color: '#73726C' }}>
                {reportData.length} data points · {reportFirstYear.year} to {reportLastYear.year} · {reportLastYear.location}
              </span>
            </div>
          </div>

          {/* Income Table */}
          <div style={{ marginBottom: '11px' }}>
            <Section title="Income Table" isOpen={reportOpenSections.incomeTable} onToggle={() => setReportOpenSections(prev => ({ ...prev, incomeTable: !prev.incomeTable }))}>
              <div style={{ overflow: 'auto' }}>
                <table style={{ width: '100%', fontSize: scaledFont(10), borderCollapse: 'collapse', tableLayout: 'fixed' }}>
                  <colgroup>
                    <col style={{ width: '55px' }} />
                    <col style={{ width: '130px' }} />
                    <col style={{ width: '75px' }} />
                  </colgroup>
                  <thead>
                    <tr style={{ backgroundColor: '#FAF9F5' }}>
                      <th style={{ padding: '8px 10px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Year</th>
                      <th style={{ padding: '8px 10px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Location</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Income</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Power</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Equiv</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Goal</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Achieved</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Safe</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Survive</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Median</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Poverty</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Pctl</th>
                    </tr>
                  </thead>
                  <tbody>
                    {reportData.map((d, i) => {
                      const powerPct = Math.round(((d.purchasePower - d.income) / d.income) * 100);
                      const powerStr = powerPct >= 0 ? `+${powerPct}%` : `${powerPct}%`;
                      return (
                      <tr key={i} style={{ backgroundColor: i % 2 ? '#fafafa' : 'white' }}>
                        <td style={{ padding: '8px 10px', textAlign: 'left', fontWeight: '600', color: '#141413', whiteSpace: 'nowrap' }}>{d.year}</td>
                        <td style={{ padding: '8px 10px', textAlign: 'left', fontWeight: '600', color: '#141413', whiteSpace: 'nowrap' }}>{d.location}</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '600', color: '#141413', whiteSpace: 'nowrap' }}>{formatCurrency(d.income)}</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: powerPct >= 0 ? '#347613' : '#B53232', whiteSpace: 'nowrap' }}>{powerStr}</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{formatCurrency(d.equiv700k)}</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{formatCurrency(d.goal)}</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.pctToGoal}%</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{formatCurrency(d.safe)}</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{formatCurrency(d.greenLine)}</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{formatCurrency(d.medianHH)}</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{formatCurrency(d.povertyLine)}</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.percentile === 99 ? 'Top 1%' : `${d.percentile}th`}</td>
                      </tr>
                    )})}
                  </tbody>
                </table>
              </div>
            </Section>
          </div>

          {/* Demographics Table */}
          <div style={{ marginBottom: '11px' }}>
            <Section title="Demographics Table" isOpen={reportOpenSections.demographicsTable} onToggle={() => setReportOpenSections(prev => ({ ...prev, demographicsTable: !prev.demographicsTable }))}>
              <div style={{ overflow: 'auto' }}>
                <table style={{ width: '100%', fontSize: scaledFont(10), borderCollapse: 'collapse', tableLayout: 'fixed' }}>
                  <colgroup>
                    <col style={{ width: '55px' }} />
                    <col style={{ width: '130px' }} />
                    <col style={{ width: '75px' }} />
                  </colgroup>
                  <thead>
                    <tr style={{ backgroundColor: '#FAF9F5' }}>
                      <th style={{ padding: '8px 10px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Year</th>
                      <th style={{ padding: '8px 10px', textAlign: 'left', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Location</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Age</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '600', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Status</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Kids</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Education</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Metro Pop</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Single Pool</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Relate</th>
                      <th style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#5C5A4D', borderBottom: '1px solid #e5e7eb', textTransform: 'uppercase', letterSpacing: '0.03em', whiteSpace: 'nowrap' }}>Match</th>
                    </tr>
                  </thead>
                  <tbody>
                    {reportData.map((d, i) => {
                      const formatPop = (n) => n >= 1000000 ? `${(n/1000000).toFixed(1)}M` : `${(n/1000).toFixed(0)}k`;
                      const formatPool = (n) => n >= 1000000 ? `${(n/1000000).toFixed(1)}M` : n >= 1000 ? `${Math.round(n/1000)}k` : n;
                      return (
                      <tr key={i} style={{ backgroundColor: i % 2 ? '#fafafa' : 'white' }}>
                        <td style={{ padding: '8px 10px', textAlign: 'left', fontWeight: '600', color: '#141413', whiteSpace: 'nowrap' }}>{d.year}</td>
                        <td style={{ padding: '8px 10px', textAlign: 'left', fontWeight: '600', color: '#141413', whiteSpace: 'nowrap' }}>{d.location}</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '600', color: '#141413', whiteSpace: 'nowrap' }}>{d.age}</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#141413', whiteSpace: 'nowrap' }}>{d.relationship}</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.children}</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.education}</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{formatPop(d.metroPop)}</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.matchScore !== null ? formatPool(d.realisticPool) : 'N/A'}</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.relateScore.toFixed(1)}/10</td>
                        <td style={{ padding: '8px 6px', textAlign: 'right', fontWeight: '400', color: '#73726C', whiteSpace: 'nowrap' }}>{d.matchScore !== null ? `${formatPool(d.realisticPool)} (${d.matchScore.toFixed(1)}%)` : 'Married'}</td>
                      </tr>
                    )})}
                  </tbody>
                </table>
              </div>
            </Section>
          </div>

          {/* Context by Year - Full Width */}
          <div style={{ marginBottom: '11px' }}>
            <Section title="Context by Year" isOpen={reportOpenSections.contextByYear !== false} onToggle={() => setReportOpenSections(prev => ({ ...prev, contextByYear: !(prev.contextByYear !== false) }))}>
              <div style={{ display: 'grid', gridTemplateColumns: 'calc(50% - 12px) calc(50% - 12px)', gap: '24px' }}>
                <div>
                  {reportData.slice(0, Math.ceil(reportData.length / 2)).map((d, i) => (
                    <div key={i} style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: i < Math.ceil(reportData.length / 2) - 1 ? '1px solid #EBE8E0' : 'none' }}>
                      <div style={{ fontWeight: '600', fontSize: scaledFont(11), marginBottom: '4px' }}>{d.year} · {d.location} · Age {d.age}</div>
                      <div style={{ color: '#3D3D3A', fontSize: scaledFont(12) }}>{(narrativeContent.contextByYear && narrativeContent.contextByYear[d.year]) || d.context || 'Context will be generated.'}{getRelateMatchContext(d)}</div>
                    </div>
                  ))}
                </div>
                <div>
                  {reportData.slice(Math.ceil(reportData.length / 2)).map((d, i) => (
                    <div key={i} style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: i < reportData.length - Math.ceil(reportData.length / 2) - 1 ? '1px solid #EBE8E0' : 'none' }}>
                      <div style={{ fontWeight: '600', fontSize: scaledFont(11), marginBottom: '4px' }}>{d.year} · {d.location} · Age {d.age}</div>
                      <div style={{ color: '#3D3D3A', fontSize: scaledFont(12) }}>{(narrativeContent.contextByYear && narrativeContent.contextByYear[d.year]) || d.context || 'Context will be generated.'}{getRelateMatchContext(d)}</div>
                    </div>
                  ))}
                </div>
              </div>
            </Section>
          </div>

          {/* Analysis Modules */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '11px', marginBottom: '11px' }}>
            <div style={{ display: 'flex', flexDirection: 'column', gap: '11px' }}>
              <Section title="Key Findings" isOpen={reportOpenSections.keyFindings !== false} onToggle={() => setReportOpenSections(prev => ({ ...prev, keyFindings: !(prev.keyFindings !== false) }))}>
                <div style={{ fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }} dangerouslySetInnerHTML={{ __html: formatNarrativeText(narrativeContent.keyFindings || 'Key findings will be generated based on your trajectory.') }} />
              </Section>

              <Section title="Percentile Thresholds (2025)" isOpen={reportOpenSections.percentileThresholds !== false} onToggle={() => setReportOpenSections(prev => ({ ...prev, percentileThresholds: !(prev.percentileThresholds !== false) }))}>
                <table style={{ width: '100%', fontSize: '11px', marginBottom: '16px' }}>
                  <tbody>
                    <tr><td style={{ padding: '4px 0', color: '#73726C' }}>Median (50th)</td><td style={{ textAlign: 'right' }}>$83,592</td><td style={{ textAlign: 'right', fontWeight: '600' }}>{reportLastYear.percentile >= 50 ? '✓' : ''}</td></tr>
                    <tr><td style={{ padding: '4px 0', color: '#73726C' }}>Top 10%</td><td style={{ textAlign: 'right' }}>$251,036</td><td style={{ textAlign: 'right', fontWeight: '600' }}>{reportLastYear.percentile >= 90 ? '✓' : ''}</td></tr>
                    <tr><td style={{ padding: '4px 0', color: '#73726C' }}>Top 5%</td><td style={{ textAlign: 'right' }}>$335,575</td><td style={{ textAlign: 'right', fontWeight: '600' }}>{reportLastYear.percentile >= 95 ? '✓' : ''}</td></tr>
                    <tr><td style={{ padding: '4px 0', color: '#73726C' }}>Top 1%</td><td style={{ textAlign: 'right' }}>$659,060</td><td style={{ textAlign: 'right', fontWeight: '600' }}>{reportLastYear.percentile >= 99 ? '✓' : ''}</td></tr>
                    <tr style={{ fontWeight: '600' }}><td style={{ padding: '4px 0', borderTop: '1px solid #e5e7eb', paddingTop: '8px' }}>Your Income</td><td style={{ textAlign: 'right', borderTop: '1px solid #e5e7eb', paddingTop: '8px' }}>{formatCurrency(reportLastYear.income)}</td><td style={{ borderTop: '1px solid #e5e7eb', paddingTop: '8px' }}></td></tr>
                  </tbody>
                </table>
                <div style={{ fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }} dangerouslySetInnerHTML={{ __html: formatNarrativeText(narrativeContent.percentileThresholds || `Your income places you at the ${reportLastYear.percentile === 99 ? 'top 1%' : `${reportLastYear.percentile}th percentile`} of American households.`) }} />
              </Section>

              <Section title="Inflation Impact" isOpen={reportOpenSections.inflationImpact !== false} onToggle={() => setReportOpenSections(prev => ({ ...prev, inflationImpact: !(prev.inflationImpact !== false) }))}>
                <div style={{ fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }} dangerouslySetInnerHTML={{ __html: formatNarrativeText(narrativeContent.inflationImpact || 'Inflation impact analysis will be generated based on your income trajectory.') }} />
              </Section>
            </div>

            <div style={{ display: 'flex', flexDirection: 'column', gap: '11px' }}>
              <Section title="Rarity Analysis" isOpen={reportOpenSections.rarityAnalysis !== false} onToggle={() => setReportOpenSections(prev => ({ ...prev, rarityAnalysis: !(prev.rarityAnalysis !== false) }))}>
                <div style={{ fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }} dangerouslySetInnerHTML={{ __html: formatNarrativeText(narrativeContent.rarityAnalysis || 'Rarity analysis will be generated based on your trajectory.') }} />
              </Section>

              <Section title={
                narrativeContent.persona?.mindsetCard === 'abundanceMindset' ? 'The Abundance Mindset' :
                narrativeContent.persona?.mindsetCard === 'stabilityMindset' ? 'The Stability Mindset' :
                narrativeContent.persona?.mindsetCard === 'lossMindset' ? 'The Loss Mindset' :
                'The Scarcity Mindset Gap'
              } isOpen={reportOpenSections.scarcityMindset !== false} onToggle={() => setReportOpenSections(prev => ({ ...prev, scarcityMindset: !(prev.scarcityMindset !== false) }))}>
                <div style={{ fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }} dangerouslySetInnerHTML={{ __html: formatNarrativeText(narrativeContent[narrativeContent.persona?.mindsetCard] || narrativeContent.scarcityMindset || 'Mindset analysis will be generated based on your persona.') }} />
              </Section>

              <Section title={
                narrativeContent.persona?.futureCard === 'whatYoureBuilding' ? "What You're Building" : "What You're Creating"
              } isOpen={reportOpenSections.whatYoureCreating !== false} onToggle={() => setReportOpenSections(prev => ({ ...prev, whatYoureCreating: !(prev.whatYoureCreating !== false) }))}>
                <div style={{ fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }} dangerouslySetInnerHTML={{ __html: formatNarrativeText(narrativeContent[narrativeContent.persona?.futureCard] || narrativeContent.whatYoureCreating || 'Future outlook will be generated based on your trajectory.') }} />
              </Section>
            </div>
          </div>

          {/* Relationship Calculation - Full Width */}
          <div style={{ marginBottom: '11px' }}>
            <Section title="Relationship Calculation" isOpen={reportOpenSections.relationshipCalculation !== false} onToggle={() => setReportOpenSections(prev => ({ ...prev, relationshipCalculation: !(prev.relationshipCalculation !== false) }))}>
              <p style={{ marginBottom: '11px', fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }}>
                Income trajectory analysis provides half of the picture: where you came from, where you are, and what that means statistically. Relationship calculation provides the other half by translating financial position into partnership market dynamics. Modern dating platforms use algorithmic matching systems derived from Elo rating methodology, originally developed for chess rankings, which assign users a desirability score based on who swipes right on whom and who matches with whom. A user who receives interest from high-rated profiles sees their own rating increase, while rejection from highly-rated users decreases it. These systems create stratified matching pools where users are primarily shown to and shown profiles of others at similar desirability tiers.
              </p>
              <p style={{ marginBottom: '20px', fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }}>
                Income, while not directly visible, correlates strongly with proxy signals that these algorithms detect: neighborhood, education, profession, photos reflecting lifestyle, and activity patterns. Understanding where your financial position places you in these algorithmic hierarchies transforms abstract percentile rankings into concrete relationship market positioning. The two scores below, Relate Score and Match Score, address different questions: how well a potential partner can understand your lived experience versus how statistically likely a match becomes given demographic and economic realities.
              </p>
              <div style={{ display: 'grid', gridTemplateColumns: 'calc(50% - 12px) calc(50% - 12px)', gap: '24px' }}>
                <div>
                  <div style={{ fontWeight: '600', fontSize: '12px', marginBottom: '12px', paddingBottom: '8px', borderBottom: '2px solid #e5e7eb', color: '#141413' }}>Relate Score</div>
                  <div style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: '1px solid #EBE8E0' }}>
                    <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Purpose</div>
                    <div style={{ color: '#3D3D3A', fontSize: '11px' }}>The Relate Score measures experiential compatibility, specifically the degree to which a potential partner can genuinely understand your financial journey rather than merely tolerate or benefit from its outcome. This score addresses the psychological isolation that accompanies significant economic mobility, where neither those who started wealthy nor those who remained at your origin point fully comprehend the transition you experienced.</div>
                  </div>
                  <div style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: '1px solid #EBE8E0' }}>
                    <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Inputs</div>
                    <div style={{ color: '#3D3D3A', fontSize: '11px' }}>The calculation incorporates origin percentile, current percentile, trajectory velocity measured as percentile points per year, geographic mobility patterns, family structure changes including divorce and co-parenting, and the scarcity-to-abundance transition timing. Each input receives a weight based on research into what factors most strongly predict mutual comprehension of financial stress and financial success.</div>
                  </div>
                  <div style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: '1px solid #EBE8E0' }}>
                    <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Methodology</div>
                    <div style={{ color: '#3D3D3A', fontSize: '11px' }}>The score applies a distance function across multiple dimensions, measuring how far a hypothetical partner's profile sits from yours on each weighted factor. Partners who experienced similar origin conditions, similar trajectory shapes, or similar life disruptions score higher. The function penalizes both excessive distance, meaning they cannot relate, and zero distance, meaning identical experiences often create competition rather than complementarity.</div>
                  </div>
                  <div style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: '1px solid #EBE8E0' }}>
                    <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Scale</div>
                    <div style={{ color: '#3D3D3A', fontSize: '11px' }}>The score ranges from 0 to 10, where 10 represents maximum potential for experiential understanding. Scores above 7 indicate high relatability pools exist in the dating market. Scores between 4 and 7 suggest moderate relatability requiring intentional filtering. Scores below 4 indicate that most available partners will struggle to comprehend your financial journey at a visceral level.</div>
                  </div>
                  <div>
                    <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Limitations</div>
                    <div style={{ color: '#3D3D3A', fontSize: '11px' }}>The score cannot measure emotional intelligence, communication skill, or willingness to learn. A partner with low experiential overlap but high empathic capacity may outperform predictions, while a partner with similar trajectory but poor emotional attunement may underperform. The score identifies probability of baseline comprehension, not guarantee of connection quality.</div>
                  </div>
                </div>
                <div>
                  <div style={{ fontWeight: '600', fontSize: '12px', marginBottom: '12px', paddingBottom: '8px', borderBottom: '2px solid #e5e7eb', color: '#141413' }}>Match Score</div>
                  <div style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: '1px solid #EBE8E0' }}>
                    <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Purpose</div>
                    <div style={{ color: '#3D3D3A', fontSize: '11px' }}>The Match Score estimates the statistical probability of achieving a committed relationship with a partner meeting specified criteria, expressed as a percentage. This score addresses the fundamental supply and demand problem in dating markets: how many people exist who meet your criteria, how many of them would consider you, and what percentage of that overlap is realistically accessible given age, geography, and platform dynamics.</div>
                  </div>
                  <div style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: '1px solid #EBE8E0' }}>
                    <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Elo Foundation</div>
                    <div style={{ color: '#3D3D3A', fontSize: '11px' }}>Dating platforms including Tinder, Hinge, and Bumble employ Elo-derived systems where each user carries a hidden desirability rating. When a high-rated user swipes right on you, your rating increases more than when a low-rated user does. When you swipe right on someone who does not reciprocate, your rating decreases. This creates feedback loops where users converge into tiers and primarily see profiles within their tier, making cross-tier matching statistically rare.</div>
                  </div>
                  <div style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: '1px solid #EBE8E0' }}>
                    <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Inputs</div>
                    <div style={{ color: '#3D3D3A', fontSize: '11px' }}>The calculation incorporates your demographic profile including age, gender, location, education, income percentile, and physical presentation estimates. It then cross-references against population distributions for your specified partner criteria, applying Elo-tier probability adjustments based on where your profile likely ranks and where your desired partners likely rank within platform hierarchies.</div>
                  </div>
                  <div style={{ marginBottom: '11px', paddingBottom: '12px', borderBottom: '1px solid #EBE8E0' }}>
                    <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Calculation</div>
                    <div style={{ color: '#3D3D3A', fontSize: '11px' }}>The score multiplies the base rate of partners meeting your criteria in the population by the probability that such partners exist in your Elo tier by the probability of mutual interest given tier overlap by the probability of conversion from match to relationship. Each multiplication reduces the final percentage, often dramatically, which explains why high-criteria searches yield low match probabilities even for highly desirable users.</div>
                  </div>
                  <div>
                    <div style={{ fontWeight: '600', fontSize: '11px', marginBottom: '4px' }}>Interpretation</div>
                    <div style={{ color: '#3D3D3A', fontSize: '11px' }}>Scores above 30% indicate favorable market conditions where patience and volume will likely yield results. Scores between 10% and 30% indicate challenging but viable conditions requiring strategic optimization of profile, criteria, or both. Scores below 10% indicate that current criteria may be statistically incompatible with available supply, suggesting either criteria adjustment or acceptance of extended timelines measured in years rather than months.</div>
                  </div>
                </div>
              </div>
            </Section>
          </div>

          {/* Relate Score and Match Score - Side by Side */}
          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '11px', marginBottom: '11px' }}>
            <Section title="Relate Score Analysis" isOpen={reportOpenSections.relateScoreAnalysis !== false} onToggle={() => setReportOpenSections(prev => ({ ...prev, relateScoreAnalysis: !(prev.relateScoreAnalysis !== false) }))}>
              <div style={{ fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }}>
                <div style={{ marginBottom: '12px', padding: '10px', backgroundColor: '#f0fdf4', borderRadius: '4px', textAlign: 'center' }}>
                  <div style={{ fontSize: '24px', fontWeight: '700', color: '#347613' }}>{reportLastYear.relateScore.toFixed(1)}/10</div>
                  <div style={{ fontSize: '10px', color: '#73726C' }}>Relate Score</div>
                </div>
                <div dangerouslySetInnerHTML={{ __html: formatNarrativeText(narrativeContent.relateScoreAnalysis || 'Relate Score analysis will be generated.') }} />
              </div>
            </Section>
            <Section title="Match Score Analysis" isOpen={reportOpenSections.matchScoreAnalysis !== false} onToggle={() => setReportOpenSections(prev => ({ ...prev, matchScoreAnalysis: !(prev.matchScoreAnalysis !== false) }))}>
              {reportLastYear.matchScore === null ? (
                <div style={{ padding: '20px', textAlign: 'center', fontSize: '11px', color: '#73726C' }}>
                  Match Score not applicable (currently married).
                </div>
              ) : (
                <div style={{ fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }}>
                  <div style={{ marginBottom: '12px', padding: '10px', backgroundColor: '#fdf4ff', borderRadius: '4px', textAlign: 'center' }}>
                    <div style={{ fontSize: '24px', fontWeight: '700', color: '#8A74C9' }}>{Math.round(reportLastYear.realisticPool / 1000)}k</div>
                    <div style={{ fontSize: '10px', color: '#73726C' }}>Realistic Matches ({reportLastYear.matchScore.toFixed(1)}%)</div>
                  </div>
                  <div dangerouslySetInnerHTML={{ __html: formatNarrativeText(narrativeContent.matchScoreAnalysis || 'Match Score analysis will be generated.') }} />
                </div>
              )}
            </Section>
          </div>

          {/* Partner Preferences Analysis - appears if user provided preferences */}
          {parsedPartnerPrefs && (
            <div style={{ marginBottom: '11px' }}>
              <Section title="Partner Preferences Analysis" isOpen={reportOpenSections.partnerPreferences !== false} onToggle={() => setReportOpenSections(prev => ({ ...prev, partnerPreferences: !(prev.partnerPreferences !== false) }))}>
                <div style={{ padding: '16px', fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }}>
                  <div style={{ marginBottom: '12px' }}>
                    <strong>Your stated preferences:</strong>
                  </div>
                  <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '16px', marginBottom: '16px' }}>
                    <div>
                      {parsedPartnerPrefs.ageMin && parsedPartnerPrefs.ageMax && <div style={{ marginBottom: '4px' }}>Age: {parsedPartnerPrefs.ageMin} to {parsedPartnerPrefs.ageMax}</div>}
                      {parsedPartnerPrefs.incomeMin !== undefined && <div style={{ marginBottom: '4px' }}>Income: {parsedPartnerPrefs.incomeMin > 0 ? `$${parsedPartnerPrefs.incomeMin.toLocaleString()}+` : 'Any'}</div>}
                      {parsedPartnerPrefs.education && <div style={{ marginBottom: '4px' }}>Education: {parsedPartnerPrefs.education}</div>}
                    </div>
                    <div>
                      {parsedPartnerPrefs.ethnicity && <div style={{ marginBottom: '4px' }}>Ethnicity: {parsedPartnerPrefs.ethnicity}</div>}
                      {parsedPartnerPrefs.kidsPreference && <div style={{ marginBottom: '4px' }}>Kids: {parsedPartnerPrefs.kidsPreference}</div>}
                      {parsedPartnerPrefs.fitness && <div style={{ marginBottom: '4px' }}>Fitness: {parsedPartnerPrefs.fitness}</div>}
                    </div>
                  </div>
                  <div style={{ color: '#73726C', fontStyle: 'italic' }}>
                    Detailed preference analysis and pool calculations coming from persona system.
                  </div>
                </div>
              </Section>
            </div>
          )}

          {/* Relocation Analysis - appears if user mentioned relocation */}
          {relocationData.openToRelocation !== null && (
            <div style={{ marginBottom: '11px' }}>
              <Section title="Relocation Analysis" isOpen={reportOpenSections.relocationAnalysis !== false} onToggle={() => setReportOpenSections(prev => ({ ...prev, relocationAnalysis: !(prev.relocationAnalysis !== false) }))}>
                <div style={{ padding: '16px', fontSize: '11px', color: '#3D3D3A', lineHeight: '1.6' }}>
                  <div style={{ marginBottom: '12px' }}>
                    <strong>Relocation openness:</strong> {relocationData.openToRelocation ? 'Yes' : 'No'}
                  </div>
                  {relocationData.matchedCBSAs && relocationData.matchedCBSAs.length > 0 && (
                    <div style={{ marginBottom: '16px' }}>
                      <div style={{ fontWeight: '600', marginBottom: '8px' }}>Metros you mentioned:</div>
                      {relocationData.matchedCBSAs.map((cbsa, i) => (
                        <div key={i} style={{ marginBottom: '8px', padding: '8px', backgroundColor: '#f9fafb', borderRadius: '4px' }}>
                          <div style={{ fontWeight: '500' }}>{cbsa.name}</div>
                          <div style={{ color: '#73726C', fontSize: '10px' }}>RPP: {cbsa.rpp} · Pop: {cbsa.cbsa_population >= 1000000 ? `${(cbsa.cbsa_population/1000000).toFixed(1)}M` : `${Math.round(cbsa.cbsa_population/1000)}k`}</div>
                        </div>
                      ))}
                    </div>
                  )}
                  {relocationData.unmatchedLocations && relocationData.unmatchedLocations.length > 0 && (
                    <div style={{ marginBottom: '16px', padding: '8px', backgroundColor: '#fef3c7', borderRadius: '4px', color: '#92400e', fontSize: '10px' }}>
                      <strong>Could not match:</strong> {relocationData.unmatchedLocations.join(', ')}
                    </div>
                  )}
                  <div style={{ color: '#73726C', fontStyle: 'italic' }}>
                    Detailed relocation comparison (thresholds, Relate/Match scores, partner preference filtering) coming from persona system.
                  </div>
                </div>
              </Section>
            </div>
          )}

          {/* Footer */}
          <div style={{ marginTop: '32px', padding: '10px 12px', backgroundColor: '#F5F3ED', borderRadius: '4px', fontSize: scaledFont(9), color: '#73726C' }}>
            <strong>Sources:</strong> Bureau of Economic Analysis Regional Price Parities 2023, Census Bureau Historical Income Tables (H-8), Bureau of Labor Statistics Consumer Expenditure Survey, HHS Poverty Guidelines, Michael Green's Functional Threshold methodology, Census Bureau American Community Survey demographic data by CBSA. <span onClick={() => setCurrentPage('glossary')} style={{ color: '#3b82f6', cursor: 'pointer', textDecoration: 'underline' }}>Glossary</span>
          </div>
        </div>
      </div>
    );
  }


  // Visualize Page - Life in Weeks
  if (currentPage === 'visualize') {
    // Show loading while CBSA data is being fetched
    if (!cbsaDataLoaded) {
      return (
        <div style={{ width: '100%', padding: '32px 32px', backgroundColor: '#FAF9F5', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
          <div style={{ maxWidth: `${containerWidth}px`, margin: '0 auto' }}>
            <PageHeader currentPage={currentPage} setCurrentPage={setCurrentPage} scaledFont={scaledFont} windowWidth={windowWidth} containerWidth={containerWidth} setContainerWidth={setContainerWidth} />
            <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '32px', textAlign: 'center' }}>
              <div style={{ fontSize: scaledFont(14), color: '#73726C' }}>Loading demographic data...</div>
            </div>
          </div>
        </div>
      );
    }
    const labelStyle = { fontSize: scaledFont(10), fontWeight: '600', color: '#5C5A4D', marginBottom: '6px', display: 'block', textTransform: 'uppercase', letterSpacing: '0.03em' };
    const selectStyle = { width: '100%', padding: '10px 12px', border: '1px solid #e5e7eb', borderRadius: '4px', fontSize: scaledFont(12), backgroundColor: '#FAF9F5', color: '#141413', cursor: 'pointer' };
    
    // Check if user has filled out the Calculator/Report
    // For testing: use demo data; later switch to formData
    const hasReportData = formData.incomeYears.some(y => y.year && y.income && y.location) || data.length > 0;
    
    // Check if career timeline is filled out
    const hasTimelineData = vizSettings.birthYear && vizSettings.birthMonth && vizSettings.workStartYear && vizSettings.workStartMonth;
    
    const calculateWeeksData = () => {
      if (!vizSettings.birthYear || !vizSettings.birthMonth || !vizSettings.workStartYear || !vizSettings.workStartMonth) {
        return null;
      }
      
      const birthDate = new Date(parseInt(vizSettings.birthYear), months.indexOf(vizSettings.birthMonth), 1);
      const workStartDate = new Date(parseInt(vizSettings.workStartYear), months.indexOf(vizSettings.workStartMonth), 1);
      const retireAge = parseInt(vizSettings.retireAge) || 65;
      const retireDate = new Date(birthDate.getFullYear() + retireAge, birthDate.getMonth(), birthDate.getDate());
      const now = new Date();
      
      // Total weeks from WORK START to retirement
      const totalWeeks = Math.ceil((retireDate - workStartDate) / (7 * 24 * 60 * 60 * 1000));
      const weeksWorked = Math.max(0, Math.ceil((now - workStartDate) / (7 * 24 * 60 * 60 * 1000)));
      const weeksRemaining = Math.max(0, totalWeeks - weeksWorked);
      
      // Build income data by year from demo data
      const incomeByYear = {};
      data.forEach(d => {
        incomeByYear[d.year] = { income: d.income, povertyLine: d.povertyLine, medianHH: d.medianHH, greenLine: d.greenLine, safe: d.safe, goal: d.goal };
      });
      
      const sortedYears = data.map(d => d.year).sort((a, b) => a - b);
      const firstDataYear = sortedYears[0];
      
      // Generate weeks array starting from work start
      const weeks = [];
      for (let w = 0; w < totalWeeks; w++) {
        const weekDate = new Date(workStartDate.getTime() + w * 7 * 24 * 60 * 60 * 1000);
        const weekYear = weekDate.getFullYear();
        const isPast = weekDate < now;
        
        let color = '#E5E2DA'; // Future (light grey)
        let status = 'future';
        
        if (isPast) {
          let yearData = incomeByYear[weekYear];
          if (!yearData) {
            for (let y = weekYear; y >= firstDataYear; y--) {
              if (incomeByYear[y]) { yearData = incomeByYear[y]; break; }
            }
          }
          if (!yearData && weekYear < firstDataYear) yearData = incomeByYear[firstDataYear];
          
          if (yearData) {
            const { income, povertyLine, medianHH, greenLine, safe, goal } = yearData;
            if (income < povertyLine) { color = '#5C5A4D'; status = 'below-poverty'; }
            else if (income < medianHH) { color = '#B53232'; status = 'below-median'; }
            else if (income < greenLine) { color = '#C86A45'; status = 'below-functional'; }
            else if (income < safe) { color = '#eab308'; status = 'below-safe'; }
            else if (income < goal || safe >= goal) { color = '#347613'; status = 'above-safe'; }
            else { color = '#2E8AD8'; status = 'above-goal'; }
          }
        }
        weeks.push({ week: w, color, status, year: weekDate.getFullYear() });
      }
      
      return { weeks, totalWeeks, weeksWorked, weeksRemaining };
    };
    
    const weeksData = calculateWeeksData();
    
    // Calculate comprehensive summary data from demo data
    const calculateSummaryData = () => {
      if (!weeksData) return null;
      
      const now = new Date();
      const workStartDate = new Date(parseInt(vizSettings.workStartYear), months.indexOf(vizSettings.workStartMonth), 1);
      const birthDate = new Date(parseInt(vizSettings.birthYear), months.indexOf(vizSettings.birthMonth), 1);
      const retireAge = parseInt(vizSettings.retireAge) || 65;
      const retireDate = new Date(birthDate.getFullYear() + retireAge, birthDate.getMonth(), birthDate.getDate());
      
      // Time worked calculations
      const msWorked = now - workStartDate;
      const daysWorked = Math.floor(msWorked / (24 * 60 * 60 * 1000));
      const weeksWorkedCalc = Math.floor(daysWorked / 7);
      const monthsWorked = Math.floor(daysWorked / 30.44);
      const yearsWorked = Math.floor(daysWorked / 365.25);
      
      // Hours calculations (40 hr week, ~28% in meetings based on research)
      const totalWorkHours = weeksWorkedCalc * 40;
      const meetingHours = Math.round(totalWorkHours * 0.28);
      const deskHours = totalWorkHours - meetingHours;
      
      // Gross earnings from demo data
      let grossEarnings = 0;
      const sortedData = [...data].sort((a, b) => a.year - b.year);
      const workStartYear = parseInt(vizSettings.workStartYear);
      const currentYear = now.getFullYear();
      
      for (let year = workStartYear; year <= currentYear; year++) {
        let yearData = sortedData.find(d => d.year === year);
        if (!yearData) {
          // Use most recent prior year's data
          for (let y = year; y >= sortedData[0].year; y--) {
            const found = sortedData.find(d => d.year === y);
            if (found) { yearData = found; break; }
          }
        }
        if (yearData) {
          // Prorate first and last year
          if (year === workStartYear) {
            const monthsInFirstYear = 12 - months.indexOf(vizSettings.workStartMonth);
            grossEarnings += yearData.income * (monthsInFirstYear / 12);
          } else if (year === currentYear) {
            const monthsInCurrentYear = now.getMonth() + 1;
            grossEarnings += yearData.income * (monthsInCurrentYear / 12);
          } else {
            grossEarnings += yearData.income;
          }
        }
      }
      
      // Estimate net earnings (simplified: assume ~25% effective tax rate)
      const netEarnings = grossEarnings * 0.75;
      
      // Count moves and calculate miles - count EVERY location change, not just unique
      const cityCoords = {
        'Boise, ID': { lat: 43.6150, lng: -116.2023 },
        'Los Angeles, CA': { lat: 34.0522, lng: -118.2437 },
        'Washington, DC': { lat: 38.9072, lng: -77.0369 },
        'Sacramento, CA': { lat: 38.5816, lng: -121.4944 },
        'St. Louis, MO': { lat: 38.6270, lng: -90.1994 },
        'Edwardsville, IL': { lat: 38.8114, lng: -89.9531 },
        'Detroit, MI': { lat: 42.3314, lng: -83.0458 },
        'Austin, TX': { lat: 30.2672, lng: -97.7431 }
      };
      
      const haversineDistance = (coord1, coord2) => {
        const R = 3959; // Earth's radius in miles
        const dLat = (coord2.lat - coord1.lat) * Math.PI / 180;
        const dLng = (coord2.lng - coord1.lng) * Math.PI / 180;
        const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                  Math.cos(coord1.lat * Math.PI / 180) * Math.cos(coord2.lat * Math.PI / 180) *
                  Math.sin(dLng/2) * Math.sin(dLng/2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        return R * c;
      };
      
      // Track all location changes in sequence
      const locationSequence = [];
      let lastLocation = null;
      sortedData.forEach(d => {
        if (d.year >= workStartYear) {
          if (d.location !== lastLocation) {
            locationSequence.push(d.location);
            lastLocation = d.location;
          }
        }
      });
      
      let totalMiles = 0;
      for (let i = 1; i < locationSequence.length; i++) {
        const from = cityCoords[locationSequence[i-1]];
        const to = cityCoords[locationSequence[i]];
        if (from && to) {
          totalMiles += haversineDistance(from, to);
        }
      }
      const moveCount = Math.max(0, locationSequence.length - 1);
      
      // Time remaining to retirement
      const msRemaining = retireDate - now;
      const daysRemaining = Math.max(0, Math.floor(msRemaining / (24 * 60 * 60 * 1000)));
      const weeksRemaining = Math.floor(daysRemaining / 7);
      const monthsRemaining = Math.floor(daysRemaining / 30.44);
      const yearsRemaining = Math.floor(daysRemaining / 365.25);
      const hoursRemaining = weeksRemaining * 40;
      
      // Retirement savings needed (4% rule)
      const latestData = sortedData[sortedData.length - 1];
      let targetIncome = latestData.medianHH; // Default to median
      
      if (latestData.income >= latestData.goal && latestData.goal > latestData.safe) {
        targetIncome = (latestData.income + latestData.goal) / 2;
      } else if (latestData.income >= latestData.safe) {
        targetIncome = (latestData.income + latestData.safe) / 2;
      } else if (latestData.income >= latestData.greenLine) {
        targetIncome = latestData.greenLine;
      } else if (latestData.income >= latestData.medianHH) {
        targetIncome = latestData.medianHH;
      } else {
        targetIncome = latestData.income;
      }
      
      const retirementSavingsNeeded = targetIncome / 0.04;
      
      // Current threshold status
      let currentThreshold = 'below poverty';
      if (latestData.income >= latestData.goal) currentThreshold = 'above your goal';
      else if (latestData.income >= latestData.safe) currentThreshold = 'above safe';
      else if (latestData.income >= latestData.greenLine) currentThreshold = 'above functional';
      else if (latestData.income >= latestData.medianHH) currentThreshold = 'above median';
      else if (latestData.income >= latestData.povertyLine) currentThreshold = 'above poverty';
      
      // =========================================
      // INFLATION AND COST OF LIVING DATA
      // =========================================
      
      // CPI-U Annual Averages (BLS data, 1982-84 = 100)
      const cpiByYear = {
        1980: 82.4, 1981: 90.9, 1982: 96.5, 1983: 99.6, 1984: 103.9,
        1985: 107.6, 1986: 109.6, 1987: 113.6, 1988: 118.3, 1989: 124.0,
        1990: 130.7, 1991: 136.2, 1992: 140.3, 1993: 144.5, 1994: 148.2,
        1995: 152.4, 1996: 156.9, 1997: 160.5, 1998: 163.0, 1999: 166.6,
        2000: 172.2, 2001: 177.1, 2002: 179.9, 2003: 184.0, 2004: 188.9,
        2005: 195.3, 2006: 201.6, 2007: 207.3, 2008: 215.3, 2009: 214.5,
        2010: 218.1, 2011: 224.9, 2012: 229.6, 2013: 233.0, 2014: 236.7,
        2015: 237.0, 2016: 240.0, 2017: 245.1, 2018: 251.1, 2019: 255.7,
        2020: 258.8, 2021: 271.0, 2022: 292.7, 2023: 304.7, 2024: 314.5, 2025: 320.0
      };
      
      // Median existing home prices (NAR data, 3BR approximated as median)
      const homePriceByYear = {
        1980: 63700, 1985: 75500, 1990: 95500, 1995: 113100, 2000: 143600,
        2005: 224900, 2006: 227100, 2007: 219000, 2008: 198600, 2009: 173200,
        2010: 173100, 2011: 166200, 2012: 177700, 2013: 197400, 2014: 209500,
        2015: 223900, 2016: 235500, 2017: 248800, 2018: 261600, 2019: 274600,
        2020: 307800, 2021: 369800, 2022: 386300, 2023: 389800, 2024: 407600, 2025: 420000
      };
      
      // Average new vehicle transaction price (Kelley Blue Book / J.D. Power)
      const carPriceByYear = {
        1980: 7200, 1985: 11450, 1990: 15400, 1995: 19500, 2000: 24800,
        2005: 28400, 2010: 29200, 2015: 33500, 2018: 37200, 2019: 38700,
        2020: 40100, 2021: 43200, 2022: 48000, 2023: 48800, 2024: 48500, 2025: 49000
      };
      
      // Annual center-based infant childcare cost (Care.com / Child Care Aware)
      const daycareCostByYear = {
        1990: 4200, 1995: 5800, 2000: 7400, 2005: 9200, 2010: 11700,
        2015: 13500, 2018: 15600, 2019: 16300, 2020: 16800, 2021: 17500,
        2022: 18500, 2023: 19200, 2024: 20200, 2025: 21000
      };
      
      // Interpolation helper for years between data points
      const interpolate = (data, year) => {
        const years = Object.keys(data).map(Number).sort((a, b) => a - b);
        if (year <= years[0]) return data[years[0]];
        if (year >= years[years.length - 1]) return data[years[years.length - 1]];
        let lower = years[0], upper = years[years.length - 1];
        for (let i = 0; i < years.length - 1; i++) {
          if (year >= years[i] && year <= years[i + 1]) {
            lower = years[i];
            upper = years[i + 1];
            break;
          }
        }
        const ratio = (year - lower) / (upper - lower);
        return Math.round(data[lower] + ratio * (data[upper] - data[lower]));
      };
      
      const careerStartYear = workStartYear;
      const startCPI = interpolate(cpiByYear, careerStartYear);
      const nowCPI = interpolate(cpiByYear, currentYear);
      const inflationMultiplier = nowCPI / startCPI;
      
      // What $1 from start year buys today
      const dollarThenWorthNow = (1 / inflationMultiplier).toFixed(2);
      const thousandThenWorthNow = Math.round(1000 / inflationMultiplier);
      
      // Cost comparisons
      const homeStart = interpolate(homePriceByYear, careerStartYear);
      const homeNow = interpolate(homePriceByYear, currentYear);
      const homeIncrease = ((homeNow - homeStart) / homeStart * 100).toFixed(0);
      
      const carStart = interpolate(carPriceByYear, careerStartYear);
      const carNow = interpolate(carPriceByYear, currentYear);
      const carIncrease = ((carNow - carStart) / carStart * 100).toFixed(0);
      
      const daycareStart = interpolate(daycareCostByYear, Math.max(1990, careerStartYear));
      const daycareNow = interpolate(daycareCostByYear, currentYear);
      const daycareIncrease = ((daycareNow - daycareStart) / daycareStart * 100).toFixed(0);
      
      // =========================================
      // SATURN JOURNEY CALCULATION
      // =========================================
      // Cassini took 7 years to reach Saturn (1997-2004)
      // Round trip: 7 years out + 6 months orbiting + 7 years back = ~14.5 years
      const saturnOneWayYears = 7;
      const saturnOrbitYears = 0.5;
      const saturnRoundTripYears = 14.5;
      
      const saturnTripsComplete = Math.floor(yearsWorked / saturnRoundTripYears);
      const saturnCurrentTripYears = yearsWorked % saturnRoundTripYears;
      
      // Where on the journey? (0-7 = outbound, 7-7.5 = orbiting Saturn, 7.5-14.5 = return)
      let saturnJourneyPhase = '';
      let saturnJourneyPercent = 0;
      let saturnYearsIntoPhase = 0;
      if (saturnCurrentTripYears <= saturnOneWayYears) {
        saturnJourneyPhase = 'outbound';
        saturnJourneyPercent = Math.round((saturnCurrentTripYears / saturnOneWayYears) * 100);
        saturnYearsIntoPhase = saturnCurrentTripYears;
      } else if (saturnCurrentTripYears <= saturnOneWayYears + saturnOrbitYears) {
        saturnJourneyPhase = 'orbiting Saturn';
        saturnJourneyPercent = 100;
        saturnYearsIntoPhase = saturnCurrentTripYears - saturnOneWayYears;
      } else {
        saturnJourneyPhase = 'returning to Earth';
        const returnProgress = saturnCurrentTripYears - saturnOneWayYears - saturnOrbitYears;
        saturnJourneyPercent = Math.round((returnProgress / saturnOneWayYears) * 100);
        saturnYearsIntoPhase = returnProgress;
      }
      
      // =========================================
      // HISTORICAL INCOME EQUIVALENTS (Percentile-Based)
      // =========================================
      // Map user's income percentile to equivalent social class in each era
      
      const currentIncome = latestData.income;
      
      // US Household Income Distribution 2024 (Census/BLS data)
      // Returns percentile (0-100) for given income
      const getIncomePercentile = (income) => {
        const brackets = [
          { income: 15000, percentile: 10 },
          { income: 30000, percentile: 20 },
          { income: 42000, percentile: 30 },
          { income: 55000, percentile: 40 },
          { income: 75000, percentile: 50 },
          { income: 95000, percentile: 60 },
          { income: 120000, percentile: 70 },
          { income: 155000, percentile: 80 },
          { income: 220000, percentile: 90 },
          { income: 300000, percentile: 95 },
          { income: 600000, percentile: 99 },
        ];
        if (income <= brackets[0].income) return brackets[0].percentile;
        if (income >= brackets[brackets.length - 1].income) return 99.5;
        for (let i = 0; i < brackets.length - 1; i++) {
          if (income >= brackets[i].income && income < brackets[i + 1].income) {
            const ratio = (income - brackets[i].income) / (brackets[i + 1].income - brackets[i].income);
            return brackets[i].percentile + ratio * (brackets[i + 1].percentile - brackets[i].percentile);
          }
        }
        return 50;
      };
      
      const incomePercentile = getIncomePercentile(currentIncome);
      
      // Ordinal suffix helper (1st, 2nd, 3rd, 4th, etc.)
      const getOrdinal = (n) => {
        const s = ['th', 'st', 'nd', 'rd'];
        const v = n % 100;
        return n + (s[(v - 20) % 10] || s[v] || s[0]);
      };
      const percentileFormatted = getOrdinal(Math.round(incomePercentile));
      
      // Ancient Rome (circa 100 AD) - map percentile to social class
      // Social structure: slaves (~35%), freedmen/laborers (~25%), artisans (~20%), 
      // merchants (~12%), equestrians (~5%), senators (~2%), elite (~1%)
      let romanClass = '';
      let romanDescription = '';
      if (incomePercentile < 25) {
        romanClass = 'day laborer';
        romanDescription = 'You would hire out for agricultural work or construction, sleeping in rented rooms, owning little beyond your tools.';
      } else if (incomePercentile < 45) {
        romanClass = 'legionary soldier';
        romanDescription = 'You would serve 25 years in the Roman army, earning steady pay, eventual citizenship, and a land grant at discharge.';
      } else if (incomePercentile < 65) {
        romanClass = 'freedman shopkeeper';
        romanDescription = 'You would own a small shop or tavern, perhaps having bought your freedom, building modest wealth through trade.';
      } else if (incomePercentile < 80) {
        romanClass = 'skilled artisan';
        romanDescription = 'You would run a workshop producing pottery, jewelry, or textiles, employing apprentices and living in a comfortable apartment.';
      } else if (incomePercentile < 90) {
        romanClass = 'prosperous merchant';
        romanDescription = 'You would trade goods across the Mediterranean, owning a townhouse with running water and perhaps a country villa.';
      } else if (incomePercentile < 96) {
        romanClass = 'equestrian';
        romanDescription = 'You would meet the 400,000 sestertii property requirement, hold government contracts, manage estates, and serve as a tax collector in the provinces.';
      } else if (incomePercentile < 99) {
        romanClass = 'senator';
        romanDescription = 'You would own multiple estates across Italy, maintain a household of 100 slaves, vote in the Senate, and govern a minor province.';
      } else {
        romanClass = 'consul or provincial governor';
        romanDescription = 'You would command legions, administer justice over millions, live in a marble palace, and shape the fate of the empire.';
      }
      
      // American Revolution (1776) - map percentile to social class
      // Social structure: indentured/enslaved (~25%), landless poor (~20%), small farmers (~30%),
      // yeoman farmers (~15%), craftsmen/merchants (~7%), wealthy (~3%)
      let revolutionClass = '';
      let revolutionDescription = '';
      if (incomePercentile < 20) {
        revolutionClass = 'landless laborer';
        revolutionDescription = 'You would work other men\'s farms for wages, move frequently seeking employment, and own nothing but the clothes on your back.';
      } else if (incomePercentile < 40) {
        revolutionClass = 'tenant farmer';
        revolutionDescription = 'You would rent land from a larger holder, growing crops and raising livestock, keeping what remained after paying your share.';
      } else if (incomePercentile < 60) {
        revolutionClass = 'yeoman farmer';
        revolutionDescription = 'You would own 50 to 100 acres free and clear, feed your family from your own land, and vote as an independent freeholder.';
      } else if (incomePercentile < 80) {
        revolutionClass = 'master craftsman';
        revolutionDescription = 'You would run a silversmith shop or printing press like Paul Revere, own your home and tools, and train apprentices in your trade.';
      } else if (incomePercentile < 92) {
        revolutionClass = 'successful merchant';
        revolutionDescription = 'You would trade with the Caribbean and Europe, own a brick townhouse in Boston or Philadelphia, and dine with the colonial elite.';
      } else if (incomePercentile < 98) {
        revolutionClass = 'gentleman planter';
        revolutionDescription = 'You would own 500 to 1,000 acres, hold local office, sit on the vestry, and debate independence in the taverns and assemblies.';
      } else {
        revolutionClass = 'founding father class';
        revolutionDescription = 'You would match the wealth of Jefferson or Adams, owning thousands of acres, financing the revolution, and signing documents that would outlast empires.';
      }
      
      return {
        yearsWorked, monthsWorked, weeksWorkedCalc, daysWorked,
        totalWorkHours, deskHours, meetingHours,
        grossEarnings, netEarnings,
        moveCount, totalMiles, locations: locationSequence,
        yearsRemaining, monthsRemaining, weeksRemaining, daysRemaining, hoursRemaining,
        retirementSavingsNeeded, targetIncome, currentThreshold,
        retireAge, currentIncome: latestData.income, currentLocation: latestData.location,
        // Inflation data
        careerStartYear, inflationMultiplier,
        dollarThenWorthNow, thousandThenWorthNow,
        homeStart, homeNow, homeIncrease,
        carStart, carNow, carIncrease,
        daycareStart, daycareNow, daycareIncrease,
        // Saturn journey
        saturnTripsComplete, saturnCurrentTripYears, saturnJourneyPhase, saturnJourneyPercent, saturnYearsIntoPhase,
        // Historical equivalents (percentile-based)
        incomePercentile, percentileFormatted, romanClass, romanDescription, revolutionClass, revolutionDescription
      };
    };
    
    const summaryData = calculateSummaryData();
    
    // Bold style for user-specific values (same size as body text)
    const boldValue = { fontWeight: '600', color: '#141413' };
    
    const legendItems = [
      { color: '#5C5A4D', label: 'Below Poverty' },
      { color: '#B53232', label: 'Above Poverty' },
      { color: '#C86A45', label: 'Above Median' },
      { color: '#eab308', label: 'Above Functional' },
      { color: '#347613', label: 'Above Safe' },
      { color: '#2E8AD8', label: 'Above Goal' },
      { color: '#E5E2DA', label: 'Future' },
    ];
    
    // Calculate current week index
    const currentWeekIndex = weeksData ? weeksData.weeksWorked - 1 : -1;
    
    return (
      <div style={{ width: '100%', padding: '32px 32px', backgroundColor: '#FAF9F5', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
        {/* CSS Animation for blinking current week */}
        <style>{`
          @keyframes currentWeekBlink {
            0%, 100% { background-color: #E5E2DA; }
            50% { background-color: white; }
          }
          .current-week-pill {
            animation: currentWeekBlink 2s ease-in-out infinite;
          }
        `}</style>
        
        <div style={{ maxWidth: `${containerWidth}px`, margin: '0 auto' }}>
          <PageHeader currentPage={currentPage} setCurrentPage={setCurrentPage} scaledFont={scaledFont} windowWidth={windowWidth} containerWidth={containerWidth} setContainerWidth={setContainerWidth} />
          
          {/* Your Career Timeline Section - Only show if timeline fields filled in Calculator */}
          {hasTimelineData && (
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', marginBottom: '16px', padding: '16px' }}>
            <h3 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: 0, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Your Career Timeline</h3>
            <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '12px 0 0', lineHeight: '1.6' }}>
              Your working life measured in weeks. Each pill represents one week and each row represents one year. The colors show how your income compared to key thresholds, adjusted for local cost of living.
            </p>
          </div>
          )}
          
          {/* Two Column Layout: Weeks Grid + Summary - ONLY show if Report filled AND timeline filled */}
          {hasReportData && hasTimelineData && (
          <div style={{ display: 'grid', gridTemplateColumns: windowWidth > 900 ? '1fr 1fr' : '1fr', gap: '16px', marginBottom: '16px' }}>
            {/* Life in Weeks - styled like Data page cards */}
            <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px' }}>
              <h3 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 22px 0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Your Working Life in Weeks</h3>
              
              {!weeksData ? (
                <div style={{ padding: '32px', textAlign: 'center', color: '#73726C' }}>
                  <p style={{ fontSize: scaledFont(14), margin: 0 }}>Fill in your birth date and work start date above to generate your visualization.</p>
                </div>
              ) : (
                <>
                  {/* Pill Grid - 52 pills per row (1 year) using CSS Grid */}
                  <div style={{ 
                    display: 'grid', 
                    gridTemplateColumns: 'repeat(52, 1fr)', 
                    gap: '3px',
                  }}>
                    {weeksData.weeks.map((w, i) => (
                      <div
                        key={i}
                        className={i === currentWeekIndex ? 'current-week-pill' : ''}
                        style={{
                          height: '8px',
                          backgroundColor: i === currentWeekIndex ? undefined : w.color,
                          borderRadius: '2px',
                        }}
                        title={`Week ${i + 1} (${w.year})${i === currentWeekIndex ? ' - Current Week' : ''}`}
                      />
                    ))}
                  </div>
                    
                    {/* Legend - 4 columns grid for alignment */}
                    <div style={{ 
                      display: 'grid', 
                      gridTemplateColumns: 'repeat(4, auto)', 
                      gap: '8px 14px',
                      marginTop: '16px',
                      justifyContent: 'start',
                    }}>
                      {legendItems.map(item => (
                        <div key={item.label} style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                          <div style={{ width: '10px', height: '10px', backgroundColor: item.color, borderRadius: '2px', flexShrink: 0 }} />
                          <span style={{ fontSize: scaledFont(10), color: '#5C5A4D' }}>{item.label}</span>
                        </div>
                      ))}
                    </div>
                  </>
                )}
            </div>
            
            {/* Summary Section - styled like Data page cards */}
            <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px' }}>
              <h3 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 16px 0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Summary</h3>
              
              {!weeksData ? (
                <div style={{ padding: '32px', textAlign: 'center', color: '#73726C' }}>
                  <p style={{ fontSize: scaledFont(14), margin: 0 }}>Complete your career timeline to see your summary.</p>
                </div>
              ) : (
                <>
                  {/* Stats Row - lead into summary */}
                  <div style={{ display: 'flex', gap: '24px', marginBottom: '16px', flexWrap: 'wrap' }}>
                    <div>
                      <span style={{ fontSize: scaledFont(16), fontWeight: '700', color: '#141413', fontFamily: 'monospace' }}>{weeksData.totalWeeks.toLocaleString()}</span>
                      <span style={{ fontSize: scaledFont(10), color: '#73726C', marginLeft: '6px', textTransform: 'uppercase' }}>Total Weeks</span>
                    </div>
                    <div>
                      <span style={{ fontSize: scaledFont(16), fontWeight: '700', color: '#141413', fontFamily: 'monospace' }}>{weeksData.weeksWorked.toLocaleString()}</span>
                      <span style={{ fontSize: scaledFont(10), color: '#73726C', marginLeft: '6px', textTransform: 'uppercase' }}>Worked</span>
                    </div>
                    <div>
                      <span style={{ fontSize: scaledFont(16), fontWeight: '700', color: '#141413', fontFamily: 'monospace' }}>{weeksData.weeksRemaining.toLocaleString()}</span>
                      <span style={{ fontSize: scaledFont(10), color: '#73726C', marginLeft: '6px', textTransform: 'uppercase' }}>Remaining</span>
                    </div>
                  </div>
                  
                  <div style={{ fontSize: scaledFont(12), color: '#3D3D3A', lineHeight: '1.6' }}>
                    {summaryData && (
                      <>
                        <p style={{ margin: '0 0 12px' }}>
                          You have been working for <span style={boldValue}>{summaryData.yearsWorked} years</span>, accumulating roughly <span style={boldValue}>{summaryData.totalWorkHours.toLocaleString()} hours</span> of professional experience. Gross career earnings total approximately <span style={boldValue}>${Math.round(summaryData.grossEarnings).toLocaleString()}</span>, with an estimated <span style={boldValue}>${Math.round(summaryData.netEarnings).toLocaleString()}</span> after federal and state taxes.
                        </p>
                        
                        <p style={{ margin: '0 0 12px' }}>
                          When you started working in <span style={boldValue}>{summaryData.careerStartYear}</span>, one dollar bought what <span style={boldValue}>${summaryData.dollarThenWorthNow}</span> buys today. Put differently, the <span style={boldValue}>$1,000</span> you earned then has the purchasing power of <span style={boldValue}>${summaryData.thousandThenWorthNow.toLocaleString()}</span> now. The median home sold for <span style={boldValue}>${summaryData.homeStart.toLocaleString()}</span> in {summaryData.careerStartYear} and sells for <span style={boldValue}>${summaryData.homeNow.toLocaleString()}</span> today, an increase of <span style={boldValue}>{summaryData.homeIncrease}%</span>. A new car averaged <span style={boldValue}>${summaryData.carStart.toLocaleString()}</span> then versus <span style={boldValue}>${summaryData.carNow.toLocaleString()}</span> now, up <span style={boldValue}>{summaryData.carIncrease}%</span>. Annual daycare ran <span style={boldValue}>${summaryData.daycareStart.toLocaleString()}</span> and now costs <span style={boldValue}>${summaryData.daycareNow.toLocaleString()}</span>, a <span style={boldValue}>{summaryData.daycareIncrease}%</span> increase.
                        </p>
                        
                        <p style={{ margin: '0 0 12px' }}>
                          {summaryData.yearsWorked >= 30 
                            ? <>An oak tree takes 30 years to reach full maturity. Your career has outlasted that timeline. A round trip to Saturn takes 14.5 years, the path Cassini flew. Your <span style={boldValue}>{summaryData.yearsWorked} years</span> would have carried you there and back <span style={boldValue}>{summaryData.saturnTripsComplete} {summaryData.saturnTripsComplete === 1 ? 'time' : 'times'}</span>, and you would currently be <span style={boldValue}>{summaryData.saturnJourneyPhase}</span> on trip {summaryData.saturnTripsComplete + 1}. Your income places you at the <span style={boldValue}>{summaryData.percentileFormatted} percentile</span> of American households. That same rank in ancient Rome would make you a <span style={boldValue}>{summaryData.romanClass}</span>. {summaryData.romanDescription} In 1776, you would be a <span style={boldValue}>{summaryData.revolutionClass}</span>. {summaryData.revolutionDescription}</>
                            : summaryData.yearsWorked >= 14.5
                            ? <>An oak tree takes 30 years to reach full maturity. At <span style={boldValue}>{summaryData.yearsWorked} years</span>, yours is still growing but beginning to produce acorns. A round trip to Saturn takes 14.5 years. You have completed <span style={boldValue}>{summaryData.saturnTripsComplete} full {summaryData.saturnTripsComplete === 1 ? 'trip' : 'trips'}</span> and are currently <span style={boldValue}>{summaryData.saturnJourneyPhase}</span>{summaryData.saturnJourneyPhase !== 'orbiting Saturn' && <>, roughly <span style={boldValue}>{summaryData.saturnJourneyPercent}%</span> of the way</>}. Your income places you at the <span style={boldValue}>{summaryData.percentileFormatted} percentile</span> of American households. That same rank in ancient Rome would make you a <span style={boldValue}>{summaryData.romanClass}</span>. {summaryData.romanDescription} In 1776, you would be a <span style={boldValue}>{summaryData.revolutionClass}</span>. {summaryData.revolutionDescription}</>
                            : summaryData.yearsWorked >= 7
                            ? <>An oak tree takes 30 years to reach full maturity. At <span style={boldValue}>{summaryData.yearsWorked} years</span>, you are in the sapling stage, trunk thickening, canopy years away. A round trip to Saturn takes 14.5 years. Your spacecraft {summaryData.saturnJourneyPhase === 'orbiting Saturn' ? <>has reached Saturn and is currently <span style={boldValue}>orbiting the rings</span></> : <>is <span style={boldValue}>{summaryData.saturnJourneyPhase}</span>, roughly <span style={boldValue}>{summaryData.saturnJourneyPercent}%</span> of the way</>}. Your income places you at the <span style={boldValue}>{summaryData.percentileFormatted} percentile</span> of American households. That same rank in ancient Rome would make you a <span style={boldValue}>{summaryData.romanClass}</span>. {summaryData.romanDescription} In 1776, you would be a <span style={boldValue}>{summaryData.revolutionClass}</span>. {summaryData.revolutionDescription}</>
                            : <>An oak tree takes 30 years to reach full maturity. At <span style={boldValue}>{summaryData.yearsWorked} years</span>, you are a seedling. A round trip to Saturn takes 14.5 years. Your spacecraft is <span style={boldValue}>{summaryData.saturnJourneyPhase}</span>, roughly <span style={boldValue}>{summaryData.saturnJourneyPercent}%</span> of the way to the ringed planet. Your income places you at the <span style={boldValue}>{summaryData.percentileFormatted} percentile</span> of American households. That same rank in ancient Rome would make you a <span style={boldValue}>{summaryData.romanClass}</span>. {summaryData.romanDescription} In 1776, you would be a <span style={boldValue}>{summaryData.revolutionClass}</span>. {summaryData.revolutionDescription}</>}
                        </p>
                        
                        <p style={{ margin: '0 0 12px' }}>
                          {summaryData.moveCount === 0 
                            ? <>Geographic stability carries both advantages and tradeoffs. Staying in one location means deeper professional networks, established community ties, and no relocation costs eating into earnings. It also means your income trajectory reflects a single labor market.</>
                            : <>Your career spans <span style={boldValue}>{summaryData.moveCount} relocations</span> covering <span style={boldValue}>{Math.round(summaryData.totalMiles).toLocaleString()} miles</span>. Each move carried transaction costs. Realtor fees average 5 to 6 percent of home value. Moving expenses add up. Rebuilding professional networks takes time. Your moves placed you in different regional labor markets, each with distinct cost structures, industry concentrations, and income distributions.</>}
                        </p>
                        
                        <p style={{ margin: '0 0 12px' }}>
                          {summaryData.yearsRemaining <= 0 
                            ? <>At your planned retirement age of <span style={boldValue}>{summaryData.retireAge}</span>, you have reached or passed the conventional career endpoint. What follows depends on whether accumulated assets generate sufficient passive income or whether continued work remains necessary.</>
                            : <>Your planned retirement at age <span style={boldValue}>{summaryData.retireAge}</span> sits <span style={boldValue}>{summaryData.yearsRemaining} years</span> ahead, representing <span style={boldValue}>{summaryData.hoursRemaining.toLocaleString()} working hours</span> spread across <span style={boldValue}>{summaryData.weeksRemaining.toLocaleString()} weeks</span>. You have already completed <span style={boldValue}>{Math.round(summaryData.yearsWorked / (summaryData.yearsWorked + summaryData.yearsRemaining) * 100)}%</span> of your total working life. The remaining <span style={boldValue}>{100 - Math.round(summaryData.yearsWorked / (summaryData.yearsWorked + summaryData.yearsRemaining) * 100)}%</span> will determine whether the first part was foundation or false start.</>}
                        </p>
                        
                        <p style={{ margin: '0 0 0' }}>
                          {summaryData.currentThreshold === 'above your goal' 
                            ? <>Your current income of <span style={boldValue}>${summaryData.currentIncome.toLocaleString()}</span> in {summaryData.currentLocation} exceeds your stated goal. For retirement planning, we target <span style={boldValue}>${Math.round(summaryData.targetIncome).toLocaleString()}</span>, the midpoint between your income and goal, assuming some lifestyle compression is acceptable. Applying the 4% safe withdrawal rate, this requires accumulated savings of <span style={boldValue}>${Math.round(summaryData.retirementSavingsNeeded).toLocaleString()}</span>.</>
                            : summaryData.currentThreshold === 'above safe'
                            ? <>Your current income of <span style={boldValue}>${summaryData.currentIncome.toLocaleString()}</span> in {summaryData.currentLocation} places you above the safe threshold. For retirement planning, we target <span style={boldValue}>${Math.round(summaryData.targetIncome).toLocaleString()}</span>, the midpoint between your income and the safe line, preserving most of your current lifestyle while acknowledging that peak earning years rarely extend into retirement. Applying the 4% safe withdrawal rate, this requires accumulated savings of <span style={boldValue}>${Math.round(summaryData.retirementSavingsNeeded).toLocaleString()}</span>.</>
                            : summaryData.currentThreshold === 'above functional'
                            ? <>Your current income of <span style={boldValue}>${summaryData.currentIncome.toLocaleString()}</span> in {summaryData.currentLocation} places you above the functional threshold. For retirement planning, we target <span style={boldValue}>${Math.round(summaryData.targetIncome).toLocaleString()}</span>, holding the functional line where a household can meet obligations without chronic financial stress. Applying the 4% safe withdrawal rate, this requires accumulated savings of <span style={boldValue}>${Math.round(summaryData.retirementSavingsNeeded).toLocaleString()}</span>.</>
                            : summaryData.currentThreshold === 'above median'
                            ? <>Your current income of <span style={boldValue}>${summaryData.currentIncome.toLocaleString()}</span> in {summaryData.currentLocation} places you above median but below the functional threshold. For retirement planning, we target <span style={boldValue}>${Math.round(summaryData.targetIncome).toLocaleString()}</span>, the local median household income, which represents the minimum floor for dignified retirement in your area. Applying the 4% safe withdrawal rate, this requires accumulated savings of <span style={boldValue}>${Math.round(summaryData.retirementSavingsNeeded).toLocaleString()}</span>.</>
                            : <>Your current income of <span style={boldValue}>${summaryData.currentIncome.toLocaleString()}</span> in {summaryData.currentLocation} falls below the local median. For retirement planning, we target <span style={boldValue}>${Math.round(summaryData.targetIncome).toLocaleString()}</span>, your current income, on the principle that retirement should not mean a further reduction in an already constrained lifestyle. Applying the 4% safe withdrawal rate, this requires accumulated savings of <span style={boldValue}>${Math.round(summaryData.retirementSavingsNeeded).toLocaleString()}</span>.</>}
                        </p>
                      </>
                    )}
                  </div>
                  </>
                )}
            </div>
          </div>
          )}
          
          {/* U.S. College Graduates Jobs Chart - Always visible */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '16px', flexWrap: 'wrap', gap: '12px' }}>
              <h3 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: 0, textTransform: 'uppercase', letterSpacing: '0.05em' }}>U.S. College Graduates Jobs</h3>
              
              {/* Gender Toggle */}
              <div style={{ display: 'flex', gap: '4px' }}>
                {[
                  { key: 'all', label: 'All' },
                  { key: 'men', label: 'Men' },
                  { key: 'women', label: 'Women' }
                ].map(({ key, label }) => (
                  <button
                    key={key}
                    onClick={() => setJobsGenderFilter(key)}
                    style={{
                      height: '28px',
                      padding: '0 12px',
                      fontSize: '12px',
                      fontWeight: '500',
                      border: 'none',
                      borderRadius: '4px',
                      backgroundColor: jobsGenderFilter === key ? '#5C5A4D' : 'white',
                      color: jobsGenderFilter === key ? 'white' : '#5C5A4D',
                      cursor: 'pointer',
                      transition: 'all 0.15s ease'
                    }}
                  >
                    {label}
                  </button>
                ))}
              </div>
            </div>
            
            {/* Legend - Row 1 */}
            <div style={{ display: 'flex', gap: '16px', marginBottom: '4px', flexWrap: 'wrap' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <div style={{ width: '16px', height: '3px', backgroundColor: '#5C5A4D', borderRadius: '1px' }} />
                <span style={{ fontSize: scaledFont(10), color: '#73726C' }}>Employed (M)</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <div style={{ width: '20px', position: 'relative', display: 'flex', alignItems: 'center' }}>
                  <div style={{ width: '100%', height: '2px', backgroundColor: '#C5C2BA', backgroundImage: 'repeating-linear-gradient(90deg, #C5C2BA 0px, #C5C2BA 6px, transparent 6px, transparent 10px)' }} />
                  <div style={{ position: 'absolute', left: '50%', transform: 'translateX(-50%)', width: '5px', height: '5px', borderRadius: '50%', backgroundColor: '#C5C2BA' }} />
                </div>
                <span style={{ fontSize: scaledFont(10), color: '#73726C' }}>Degree-Required Jobs (M)</span>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <div style={{ width: '16px', height: '2px', backgroundColor: '#eab308' }} />
                <span style={{ fontSize: scaledFont(10), color: '#73726C' }}>$100k+ Jobs %</span>
              </div>
              {jobsGenderFilter !== 'all' && (
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <div style={{ width: '16px', height: '2px', backgroundColor: '#16a34a' }} />
                  <span style={{ fontSize: scaledFont(10), color: '#73726C' }}>Labor Force Participation %</span>
                </div>
              )}
              <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                <div style={{ width: '16px', height: '2px', backgroundColor: '#C86A45' }} />
                <span style={{ fontSize: scaledFont(10), color: '#73726C' }}>Underemployment %</span>
              </div>
            </div>
            {/* Legend - Row 2: Growth lines (only when "All" selected) */}
            {jobsGenderFilter === 'all' && (
              <div style={{ display: 'flex', gap: '16px', marginBottom: '12px', flexWrap: 'wrap' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <div style={{ width: '16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: '#2E8AD8', opacity: 0.5 }} />
                    <div style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: '#2E8AD8', opacity: 0.5 }} />
                    <div style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: '#2E8AD8', opacity: 0.5 }} />
                  </div>
                  <span style={{ fontSize: scaledFont(10), color: '#73726C' }}>Men Growth</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <div style={{ width: '16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: '#B53232', opacity: 0.5 }} />
                    <div style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: '#B53232', opacity: 0.5 }} />
                    <div style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: '#B53232', opacity: 0.5 }} />
                  </div>
                  <span style={{ fontSize: scaledFont(10), color: '#73726C' }}>Women Growth</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <div style={{ width: '16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: '#A193D8', opacity: 0.5 }} />
                    <div style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: '#A193D8', opacity: 0.5 }} />
                    <div style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: '#A193D8', opacity: 0.5 }} />
                  </div>
                  <span style={{ fontSize: scaledFont(10), color: '#73726C' }}>Growing Divide</span>
                </div>
              </div>
            )}
            {/* Legend - Row 2: Portion change dots (only when Men or Women selected) */}
            {jobsGenderFilter === 'men' && (
              <div style={{ display: 'flex', gap: '16px', marginBottom: '12px', flexWrap: 'wrap' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <div style={{ width: '20px', position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ position: 'absolute', top: '50%', left: 0, right: 0, height: '1px', backgroundColor: '#2E8AD8', opacity: 0.5, backgroundImage: 'repeating-linear-gradient(90deg, #2E8AD8 0px, #2E8AD8 3px, transparent 3px, transparent 6px)' }} />
                    <div style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: '#2E8AD8', opacity: 0.5, position: 'relative', zIndex: 1 }} />
                    <div style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: '#2E8AD8', opacity: 0.5, position: 'relative', zIndex: 1 }} />
                    <div style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: '#2E8AD8', opacity: 0.5, position: 'relative', zIndex: 1 }} />
                  </div>
                  <span style={{ fontSize: scaledFont(10), color: '#73726C' }}>Share of Degree Jobs (Δ from Jan '15)</span>
                </div>
              </div>
            )}
            {jobsGenderFilter === 'women' && (
              <div style={{ display: 'flex', gap: '16px', marginBottom: '12px', flexWrap: 'wrap' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '6px' }}>
                  <div style={{ width: '20px', position: 'relative', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                    <div style={{ position: 'absolute', top: '50%', left: 0, right: 0, height: '1px', backgroundColor: '#B53232', opacity: 0.5, backgroundImage: 'repeating-linear-gradient(90deg, #B53232 0px, #B53232 3px, transparent 3px, transparent 6px)' }} />
                    <div style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: '#B53232', opacity: 0.5, position: 'relative', zIndex: 1 }} />
                    <div style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: '#B53232', opacity: 0.5, position: 'relative', zIndex: 1 }} />
                    <div style={{ width: '4px', height: '4px', borderRadius: '50%', backgroundColor: '#B53232', opacity: 0.5, position: 'relative', zIndex: 1 }} />
                  </div>
                  <span style={{ fontSize: scaledFont(10), color: '#73726C' }}>Share of Degree Jobs (Δ from Jan '15)</span>
                </div>
              </div>
            )}
            {jobsGenderFilter !== 'all' && jobsGenderFilter !== 'men' && jobsGenderFilter !== 'women' && <div style={{ marginBottom: '12px' }} />}
            
            {/* Chart */}
            {jobsLoading ? (
              <div style={{ height: 300, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <span style={{ fontSize: scaledFont(12), color: '#73726C' }}>Loading labor market data...</span>
              </div>
            ) : jobsError && !jobsData ? (
              <div style={{ height: 300, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <span style={{ fontSize: scaledFont(12), color: '#B53232' }}>{jobsError}</span>
              </div>
            ) : jobsData && jobsData.length > 0 ? (() => {
              // Event context for tooltips (2015+)
              const eventContext = {
                2015: { label: 'Expansion Continues', desc: 'Steady job growth, Fed ends QE' },
                2016: { label: 'Election Year', desc: 'Solid labor market, policy uncertainty' },
                2017: { label: 'Tax Reform', desc: 'Corporate tax cuts, deregulation push' },
                2018: { label: 'Tariff Shock', desc: 'Trade war escalation, manufacturing uncertainty' },
                2019: { label: 'Pre-COVID Peak', desc: 'Tight labor market, low unemployment' },
                2020: { label: 'COVID Pandemic', desc: 'Lockdowns, remote work shift, mass layoffs' },
                2021: { label: 'Stimulus Recovery', desc: 'Reopening surge, labor shortages, wage gains' },
                2022: { label: 'Fed Tightening', desc: 'Inflation peak, rate hikes, tech layoffs begin' },
                2023: { label: 'AI Disruption Begins', desc: 'ChatGPT impact, white-collar job concerns' },
                2024: { label: 'AI Adoption Period', desc: 'Continued automation pressure, hiring slowdown' },
              };
              
              // Custom tooltip component
              const JobsTooltip = ({ active, payload, label }) => {
                if (!active || !payload || !payload.length) return null;
                
                const dataPoint = payload[0]?.payload;
                if (!dataPoint) return null;
                
                const year = dataPoint.year;
                const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
                const monthName = months[dataPoint.month - 1];
                const event = eventContext[year];
                
                // Calculate QoQ jobs created (find previous quarter - 3 months prior)
                const currentIdx = jobsData.findIndex(d => d.year === year && d.month === dataPoint.month);
                const prevQtrData = currentIdx >= 3 ? jobsData[currentIdx - 3] : null;
                const currentJobs = dataPoint[`jobs_created_${jobsGenderFilter}`];
                const prevJobs = prevQtrData ? prevQtrData[`jobs_created_${jobsGenderFilter}`] : null;
                const qoqChange = prevJobs ? (currentJobs - prevJobs).toFixed(1) : null;
                const qoqPrefix = qoqChange && parseFloat(qoqChange) > 0 ? '+' : '';
                const qoqPercent = prevJobs ? (((currentJobs - prevJobs) / prevJobs) * 100).toFixed(1) : null;
                const qoqPercentPrefix = qoqPercent && parseFloat(qoqPercent) > 0 ? '+' : '';
                
                // Header label
                const headerLabel = jobsGenderFilter === 'all' ? 'All College Graduates' : jobsGenderFilter === 'men' ? 'Men' : 'Women';
                
                return (
                  <div style={{ backgroundColor: '#1f2937', padding: '12px', borderRadius: '4px', fontSize: '11px', color: '#ffffff', minWidth: '250px' }}>
                    <div style={{ fontWeight: '600', marginBottom: '8px', paddingBottom: '6px', borderBottom: '1px solid #73726C' }}>
                      {monthName} {year} · {headerLabel}
                    </div>
                    {/* All Govt Reported Jobs - dark purple */}
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                      <span style={{ color: '#d1d5db' }}>All Govt Reported Jobs</span>
                      <span style={{ color: '#6650A1', fontWeight: '500', filter: 'brightness(1.5)' }}>{dataPoint.total_jobs}M</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                      <span style={{ color: '#d1d5db' }}>Employed College Grads</span>
                      <span style={{ color: '#ffffff', fontWeight: '500' }}>{dataPoint[`employed_${jobsGenderFilter}`]}M</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                      <span style={{ color: '#d1d5db' }}>Degree-Required Jobs</span>
                      <span style={{ color: '#E8E6E1', fontWeight: '500' }}>{dataPoint[`jobs_created_${jobsGenderFilter}`]}M</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                      <span style={{ color: '#d1d5db' }}>$100k+ Jobs</span>
                      <span style={{ color: '#eab308', fontWeight: '500', filter: 'brightness(1.3)' }}>{dataPoint[`sixfig_pct_${jobsGenderFilter}`]}%, {dataPoint[`sixfig_${jobsGenderFilter}`]}M</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                      <span style={{ color: '#d1d5db' }}>Labor Force Participation</span>
                      <span style={{ color: '#16a34a', fontWeight: '500', filter: 'brightness(1.3)' }}>{dataPoint[`lfpr_${jobsGenderFilter}`]}%</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                      <span style={{ color: '#d1d5db' }}>Underemployment</span>
                      <span style={{ color: '#C86A45', fontWeight: '500', filter: 'brightness(1.3)' }}>{dataPoint[`underemployment_${jobsGenderFilter}`]}%</span>
                    </div>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                      <span style={{ color: '#d1d5db' }}>Unemployed</span>
                      <span style={{ color: '#B53232', fontWeight: '500', filter: 'brightness(1.3)' }}>{dataPoint[`unemployment_${jobsGenderFilter}`] || '—'}%</span>
                    </div>
                    {/* Jobs Created QoQ - white */}
                    <div style={{ borderTop: '1px solid #73726C', marginTop: '6px', paddingTop: '6px' }}>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                        <span style={{ color: '#9CA3AF' }}>Degree Jobs Created (QoQ)</span>
                        <span style={{ color: '#ffffff', fontWeight: '500' }}>
                          {qoqChange ? (() => {
                            const val = parseFloat(qoqChange);
                            const absVal = Math.abs(val);
                            const prefix = val > 0 ? '+' : val < 0 ? '-' : '';
                            // Show as ###k until 1.0M
                            if (absVal < 1.0) {
                              return `${prefix}${Math.round(absVal * 1000)}k`;
                            }
                            return `${prefix}${absVal.toFixed(1)}M`;
                          })() : '—'}
                        </span>
                      </div>
                      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                        <span style={{ color: '#9CA3AF' }}>Change % (QoQ)</span>
                        <span style={{ color: '#ffffff', fontWeight: '500' }}>
                          {qoqPercent ? `${qoqPercentPrefix}${qoqPercent}%` : '—'}
                        </span>
                      </div>
                    </div>
                    {/* Portion of Degree Jobs - show for Men or Women filter */}
                    {(jobsGenderFilter === 'men' || jobsGenderFilter === 'women') && dataPoint.portion_change_men !== undefined && (
                      <div style={{ borderTop: '1px solid #73726C', marginTop: '6px', paddingTop: '6px' }}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                          <span style={{ color: '#9CA3AF' }}>Share of Degree Jobs (Δ)</span>
                          <span style={{ color: jobsGenderFilter === 'men' ? '#7dd3fc' : '#fda4af', fontWeight: '500' }}>
                            {(() => {
                              const val = jobsGenderFilter === 'men' ? dataPoint.portion_change_men : dataPoint.portion_change_women;
                              const prefix = val > 0 ? '+' : '';
                              return `${prefix}${val.toFixed(2)}%`;
                            })()}
                          </span>
                        </div>
                      </div>
                    )}
                    {/* Battle of the Genders - only show when All selected and we have growth data */}
                    {jobsGenderFilter === 'all' && dataPoint.pct_change_men !== undefined && (
                      <div style={{ borderTop: '1px solid #73726C', marginTop: '6px', paddingTop: '6px' }}>
                        <div style={{ fontSize: '10px', color: '#9CA3AF', fontWeight: '600', marginBottom: '4px' }}>Battle of the Sexes (From Jan '15)</div>
                        {(() => {
                          const menGrowth = dataPoint.pct_change_men;
                          const womenGrowth = dataPoint.pct_change_women;
                          const menAhead = menGrowth > womenGrowth;
                          const winner = menAhead ? 'Men' : 'Women';
                          const loser = menAhead ? 'Women' : 'Men';
                          // Baby blue for men, pink for women (tooltip colors)
                          const menColor = '#7dd3fc';
                          const womenColor = '#fda4af';
                          const winnerColor = menAhead ? menColor : womenColor;
                          const loserColor = menAhead ? womenColor : menColor;
                          
                          // Calculate QoQ gap change
                          const currentIdx = jobsData.findIndex(d => d.year === dataPoint.year && d.month === dataPoint.month);
                          const prevQtrData = currentIdx >= 3 ? jobsData[currentIdx - 3] : null;
                          
                          let gapQoQ = null;
                          if (prevQtrData && prevQtrData.pct_change_men !== undefined) {
                            const currGap = menGrowth - womenGrowth;
                            const prevGap = prevQtrData.pct_change_men - prevQtrData.pct_change_women;
                            gapQoQ = (currGap - prevGap).toFixed(1);
                          }
                          const gapQoQVal = gapQoQ ? parseFloat(gapQoQ) : 0;
                          const gapQoQPrefix = gapQoQVal > 0 ? '+' : '';
                          
                          // Loser's cumulative disadvantage
                          const loserGrowth = menAhead ? womenGrowth : menGrowth;
                          const winnerGrowth = menAhead ? menGrowth : womenGrowth;
                          const cumulativeGap = Math.abs(winnerGrowth - loserGrowth).toFixed(1);
                          
                          return (
                            <>
                              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                                <span style={{ color: winnerColor }}>⬆ {winner}</span>
                                <span style={{ color: winnerColor, fontWeight: '500' }}>+{menAhead ? menGrowth : womenGrowth}%</span>
                              </div>
                              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                                <span style={{ color: loserColor }}>⬇ {loser}</span>
                                <span style={{ color: loserColor, fontWeight: '500' }}>+{menAhead ? womenGrowth : menGrowth}%</span>
                              </div>
                              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px', marginTop: '4px' }}>
                                <span style={{ color: '#6B7280', fontSize: '10px' }}>Gap (QoQ)</span>
                                <span style={{ color: '#6B7280', fontWeight: '500', fontSize: '10px' }}>
                                  {gapQoQ !== null ? (Math.abs(gapQoQVal) < 0.1 ? 'Negligible' : `${gapQoQPrefix}${gapQoQ} pts`) : '—'}
                                </span>
                              </div>
                              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                                <span style={{ color: womenColor, fontSize: '10px' }}>Women in degree jobs</span>
                                <span style={{ color: womenColor, fontWeight: '500', fontSize: '10px' }}>
                                  {dataPoint.jobs_created_women}M
                                </span>
                              </div>
                              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                                <span style={{ color: menColor, fontSize: '10px' }}>Men in degree jobs</span>
                                <span style={{ color: menColor, fontWeight: '500', fontSize: '10px' }}>
                                  {dataPoint.jobs_created_men}M
                                </span>
                              </div>
                              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                                <span style={{ color: '#6B7280', fontSize: '10px' }}>{loser} in decline</span>
                                <span style={{ color: '#6B7280', fontWeight: '500', fontSize: '10px' }}>
                                  {parseFloat(cumulativeGap) < 0.1 ? 'Negligible' : `-${cumulativeGap}%`}
                                </span>
                              </div>
                              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '2px' }}>
                                <span style={{ color: '#A193D8', fontSize: '10px' }}>Growing Divide</span>
                                <span style={{ color: '#A193D8', fontWeight: '500', fontSize: '10px' }}>
                                  {dataPoint.portion_gap !== undefined ? (dataPoint.portion_gap <= 0 ? 'Negligible' : `${dataPoint.portion_gap.toFixed(2)}%`) : '—'}
                                </span>
                              </div>
                            </>
                          );
                        })()}
                      </div>
                    )}
                    {event && (
                      <div style={{ borderTop: '1px solid #73726C', marginTop: '6px', paddingTop: '6px', fontSize: '10px', lineHeight: '1.5' }}>
                        <div style={{ color: '#9CA3AF', fontWeight: '500' }}>{event.label}</div>
                        <div style={{ color: '#6B7280' }}>{event.desc}</div>
                      </div>
                    )}
                  </div>
                );
              };
              
              return (
              <div style={{ height: 420 }}>
                <ResponsiveContainer>
                  <ComposedChart 
                    data={jobsData}
                    margin={{ top: 30, right: 10, left: 10, bottom: 20 }}
                  >
                    <CartesianGrid strokeDasharray="2 2" stroke="#EBE8E0" />
                    <XAxis
                      dataKey="date"
                      tick={{ fill: '#73726C', fontSize: 10 }}
                      tickLine={{ stroke: '#e5e7eb' }}
                      axisLine={{ stroke: '#e5e7eb' }}
                      tickFormatter={(date, index) => {
                        // Show year label on Q1 (index 0, 4, 8, 12... since we start at Q1 2015)
                        if (index % 4 === 0) {
                          const year = date.substring(0, 4);
                          return containerWidth < 600 ? `'${year.substring(2)}` : year;
                        }
                        return '';
                      }}
                      interval={0}
                    />
                    {/* Left Y-Axis: Jobs (millions) - ticks match 10% intervals on right axis */}
                    <YAxis
                      yAxisId="jobs"
                      width={40}
                      domain={[0, 60]}
                      ticks={[0, 6, 12, 18, 24, 30, 36, 42, 48, 54, 60]}
                      tick={{ fill: '#5C5A4D', fontSize: 10 }}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={(v) => `${v}M`}
                    />
                    {/* Right Y-Axis: Percentage - ticks every 10% */}
                    <YAxis
                      yAxisId="percent"
                      orientation="right"
                      width={40}
                      domain={[0, 100]}
                      ticks={[0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]}
                      tick={{ fill: '#73726C', fontSize: 10 }}
                      tickLine={false}
                      axisLine={false}
                      tickFormatter={(v) => `${v}%`}
                    />
                    <Tooltip content={<JobsTooltip />} offset={15} />
                    
                    {/* Event Markers */}
                    {[
                      { x: '2018-03', label: 'Tariff Shock', color: '#73726C' },
                      { x: '2020-03', label: 'COVID', color: '#B53232' },
                      { x: '2021-03', label: 'Stimulus Wave', color: '#16a34a' },
                      { x: '2022-06', label: 'Fed Tightening', color: '#ea580c' },
                      { x: '2023-06', label: 'AI Adoption', color: '#6650A1' },
                    ].map((event) => (
                      <ReferenceLine
                        key={event.x}
                        x={event.x}
                        yAxisId="percent"
                        stroke={event.color}
                        strokeDasharray="3 3"
                        strokeWidth={1}
                        label={{
                          value: event.label,
                          position: 'top',
                          fill: event.color,
                          fontSize: 8,
                          fontWeight: 500,
                          offset: 5
                        }}
                      />
                    ))}
                    
                    {/* LEFT AXIS LINES (Jobs - absolute numbers) */}
                    {/* Employed - Income color, thick with dots only at January */}
                    <Line
                      yAxisId="jobs"
                      type="monotone"
                      dataKey={`employed_${jobsGenderFilter}`}
                      stroke="#5C5A4D"
                      strokeWidth={3}
                      dot={(props) => {
                        const { cx, cy, payload } = props;
                        if (payload.quarter === 1) {
                          return <circle cx={cx} cy={cy} r={3} fill="white" stroke="#5C5A4D" strokeWidth={2} />;
                        }
                        return null;
                      }}
                      isAnimationActive={false}
                    />
                    {/* Degree-Required Jobs - Percentile color, dashed */}
                    <Line
                      yAxisId="jobs"
                      type="monotone"
                      dataKey={`jobs_created_${jobsGenderFilter}`}
                      stroke="#C5C2BA"
                      strokeWidth={2}
                      strokeDasharray="8 4"
                      dot={false}
                      isAnimationActive={false}
                    />
                    {/* Annual dots on Degree-Required Jobs line */}
                    <Customized
                      component={({ xAxisMap, yAxisMap }) => {
                        const xAxis = xAxisMap && Object.values(xAxisMap)[0];
                        const yAxis = yAxisMap && yAxisMap['jobs'];
                        if (!xAxis || !yAxis) return null;
                        
                        // Only show Q1 data points (annual)
                        const annualData = jobsData.filter(d => d.quarter === 1);
                        const dataKey = `jobs_created_${jobsGenderFilter}`;
                        
                        return (
                          <g>
                            {annualData.map((d, i) => {
                              if (d[dataKey] === undefined) return null;
                              const x = xAxis.scale(d.date);
                              const y = yAxis.scale(d[dataKey]);
                              if (isNaN(x) || isNaN(y)) return null;
                              return (
                                <circle key={i} cx={x} cy={y} r={3} fill="#C5C2BA" />
                              );
                            })}
                          </g>
                        );
                      }}
                    />
                    {/* $100k+ Jobs as % of Degree Jobs - Gold/amber color */}
                    <Line
                      yAxisId="percent"
                      type="monotone"
                      dataKey={`sixfig_pct_${jobsGenderFilter}`}
                      stroke="#eab308"
                      strokeWidth={2}
                      dot={false}
                      isAnimationActive={false}
                    />
                    
                    {/* RIGHT AXIS LINES (Percentages) */}
                    {/* Labor Force Participation - hide on All view */}
                    {jobsGenderFilter !== 'all' && (
                      <Line
                        yAxisId="percent"
                        type="monotone"
                        dataKey={`lfpr_${jobsGenderFilter}`}
                        stroke="#16a34a"
                        strokeWidth={1.5}
                        dot={false}
                        isAnimationActive={false}
                      />
                    )}
                    <Line
                      yAxisId="percent"
                      type="monotone"
                      dataKey={`underemployment_${jobsGenderFilter}`}
                      stroke="#C86A45"
                      strokeWidth={2}
                      dot={false}
                      isAnimationActive={false}
                    />
                    
                    {/* PORTION CHANGE DOTS - Show on Men or Women filter only */}
                    {(jobsGenderFilter === 'men' || jobsGenderFilter === 'women') && (
                      <Customized
                        component={({ xAxisMap, yAxisMap, offset }) => {
                          const xAxis = xAxisMap && Object.values(xAxisMap)[0];
                          if (!xAxis) return null;
                          
                          const dataKey = jobsGenderFilter === 'men' ? 'portion_change_men' : 'portion_change_women';
                          const dotColor = jobsGenderFilter === 'men' ? '#2E8AD8' : '#B53232';
                          
                          // Find min/max for scaling
                          let minPortion = 0, maxPortion = 0;
                          jobsData.forEach(d => {
                            if (d[dataKey] !== undefined) {
                              minPortion = Math.min(minPortion, d[dataKey]);
                              maxPortion = Math.max(maxPortion, d[dataKey]);
                            }
                          });
                          // Add padding and ensure zero is always visible
                          const range = Math.max(Math.abs(minPortion), Math.abs(maxPortion), 0.5);
                          const domainMin = -Math.ceil(range + 0.5);
                          const domainMax = Math.ceil(range + 0.5);
                          
                          // Create scale function
                          const chartHeight = 420 - 30 - 20; // height - top margin - bottom margin
                          const scaleY = (val) => {
                            const normalized = (val - domainMin) / (domainMax - domainMin);
                            return 30 + chartHeight * (1 - normalized);
                          };
                          
                          // Draw zero line
                          const zeroY = scaleY(0);
                          const xStart = xAxis.scale(jobsData[0]?.date) || 0;
                          const xEnd = xAxis.scale(jobsData[jobsData.length - 1]?.date) || 0;
                          
                          // Build path for dashed line
                          let path = '';
                          jobsData.forEach((d, i) => {
                            if (d[dataKey] === undefined) return;
                            const x = xAxis.scale(d.date);
                            if (isNaN(x)) return;
                            const y = scaleY(d[dataKey]);
                            if (path === '') {
                              path += `M ${x} ${y}`;
                            } else {
                              path += ` L ${x} ${y}`;
                            }
                          });
                          
                          return (
                            <g>
                              {/* Zero reference line */}
                              <line x1={xStart} y1={zeroY} x2={xEnd} y2={zeroY} stroke="#9CA3AF" strokeWidth={0.5} strokeDasharray="2 2" />
                              {/* Dashed line connecting dots */}
                              <path d={path} fill="none" stroke={dotColor} strokeWidth={1} strokeDasharray="4 3" strokeOpacity={0.5} />
                              {/* Portion change dots */}
                              {jobsData.map((d, i) => {
                                if (d[dataKey] === undefined) return null;
                                const x = xAxis.scale(d.date);
                                if (isNaN(x)) return null;
                                const y = scaleY(d[dataKey]);
                                return (
                                  <circle key={i} cx={x} cy={y} r={2.5} fill={dotColor} fillOpacity={0.5} />
                                );
                              })}
                            </g>
                          );
                        }}
                      />
                    )}
                    
                    {/* INDEXED GENDER LINES - Only show when "All" selected */}
                    {jobsGenderFilter === 'all' && (
                      <Customized
                        component={({ xAxisMap, yAxisMap, offset }) => {
                          const xAxis = xAxisMap && Object.values(xAxisMap)[0];
                          const yAxis = yAxisMap && yAxisMap['percent'];
                          if (!xAxis || !yAxis) return null;
                          
                          return (
                            <g>
                              {jobsData.map((d, i) => {
                                if (d.growth_men === undefined || d.growth_women === undefined) return null;
                                const x = xAxis.scale(d.date);
                                const yMen = yAxis.scale(d.growth_men);
                                const yWomen = yAxis.scale(d.growth_women);
                                if (isNaN(x) || isNaN(yMen) || isNaN(yWomen)) return null;
                                return (
                                  <g key={i}>
                                    {/* Men - Blue dot */}
                                    <circle cx={x} cy={yMen} r={2.5} fill="#2E8AD8" fillOpacity={0.5} />
                                    {/* Women - Red dot */}
                                    <circle cx={x} cy={yWomen} r={2.5} fill="#B53232" fillOpacity={0.5} />
                                  </g>
                                );
                              })}
                            </g>
                          );
                        }}
                      />
                    )}
                    
                    {/* GENDER GAP LINE - Only show when "All" selected */}
                    {jobsGenderFilter === 'all' && (
                      <Customized
                        component={({ xAxisMap, yAxisMap, offset }) => {
                          const xAxis = xAxisMap && Object.values(xAxisMap)[0];
                          const yAxis = yAxisMap && yAxisMap['percent'];
                          if (!xAxis || !yAxis) return null;
                          
                          const purpleColor = '#6650A1';
                          
                          // Find max gap for dynamic scaling
                          let maxGap = 0;
                          jobsData.forEach(d => {
                            if (d.portion_gap !== undefined && d.portion_gap > 0) {
                              maxGap = Math.max(maxGap, d.portion_gap);
                            }
                          });
                          if (maxGap === 0) maxGap = 1; // Prevent division by zero
                          
                          // Scale function: max gap = 100, 0 or below = 0
                          const scaleGap = (val) => {
                            if (val <= 0) return 0;
                            return (val / maxGap) * 100;
                          };
                          
                          // Build path for dashed line
                          let gapPath = '';
                          jobsData.forEach((d, i) => {
                            if (d.portion_gap === undefined) return;
                            const x = xAxis.scale(d.date);
                            if (isNaN(x)) return;
                            const scaledVal = scaleGap(d.portion_gap);
                            const y = yAxis.scale(scaledVal);
                            if (isNaN(y)) return;
                            if (gapPath === '') {
                              gapPath += `M ${x} ${y}`;
                            } else {
                              gapPath += ` L ${x} ${y}`;
                            }
                          });
                          
                          return (
                            <g>
                              {/* Dashed line connecting dots */}
                              <path d={gapPath} fill="none" stroke={purpleColor} strokeWidth={1} strokeDasharray="4 3" strokeOpacity={0.5} />
                              {/* Gap dots */}
                              {jobsData.map((d, i) => {
                                if (d.portion_gap === undefined) return null;
                                const x = xAxis.scale(d.date);
                                if (isNaN(x)) return null;
                                const scaledVal = scaleGap(d.portion_gap);
                                const y = yAxis.scale(scaledVal);
                                if (isNaN(y)) return null;
                                return (
                                  <circle key={i} cx={x} cy={y} r={2.5} fill={purpleColor} fillOpacity={0.5} />
                                );
                              })}
                            </g>
                          );
                        }}
                      />
                    )}
                  </ComposedChart>
                </ResponsiveContainer>
              </div>
              );
            })() : (
              <div style={{ height: 300, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                <span style={{ fontSize: scaledFont(12), color: '#73726C' }}>No data available</span>
              </div>
            )}
            
            {/* Description with Sources */}
            <div style={{ marginTop: '12px' }}>
              <p style={{ fontSize: scaledFont(11), color: '#73726C', margin: '0 0 8px', lineHeight: '1.5' }}>
                Labor market for Americans 25+ with a bachelor's degree or higher. Left axis shows absolute counts: total employed college grads, full-time positions requiring a degree, and jobs paying $100k or more. Right axis shows labor force participation and underemployment (grads working jobs that don't require degrees). {jobsGenderFilter === 'all' && 'The faded dots show men (blue) and women (red) employment growth indexed to 50 from Jan 2015 baseline. The purple dots track the growing divide between men and women in degree-required jobs. '}{jobsGenderFilter === 'men' && 'The faded blue dots show men\'s change in share of degree-required jobs from Jan 2015 baseline. '}{jobsGenderFilter === 'women' && 'The faded red dots show women\'s change in share of degree-required jobs from Jan 2015 baseline. '}The gap between employed and degree-required jobs reveals credential inflation.
              </p>
              <p style={{ fontSize: scaledFont(9), color: '#73726C', margin: 0, lineHeight: '1.4' }}>
                Sources: Bureau of Labor Statistics Current Population Survey and Occupational Employment & Wage Statistics (OEWS), Federal Reserve Economic Data (FRED), NY Fed Labor Market Survey. Employment figures represent civilian noninstitutional population. $100k+ threshold is nominal (not inflation-adjusted). Underemployment defined as college graduates in non-college occupations per NY Fed methodology.
              </p>
            </div>
          </div>
          
          {/* Dating Market Map - State 1: No user data yet, show top 15 with total singles */}
          <DatingMarketMap 
            currentLocation={'St. Louis, MO'}
            currentMatchPool={0}
            scaledFont={scaledFont}
            cbsaData={cbsaDataLoaded}
            userProfile={null}
            partnerPrefs={null}
            hasUserData={false}
            relocationMetros={null}
          />
          
          {/* Dating Economy Sections - Only show if user has filled out calculator */}
          {hasReportData && (() => {
            // For demo/testing, use demo data; later switch to formData
            const currentYearData = data[data.length - 1];
            const isSingle = currentYearData?.relationship === 'Single';
            const isMarried = currentYearData?.relationship === 'Married';
            const currentLocation = currentYearData?.location || 'Your Location';
            
            // Get relocation metros from formData (array of {cbsaCode, cbsaLabel})
            const relocationMetros = formData.relocationMetros || [];
            const hasRelocation = relocationMetros.length > 0;
            const relocationLabels = relocationMetros.map(m => m.cbsaLabel).sort();
            
            return (
              <>
              <div style={{ display: 'grid', gridTemplateColumns: windowWidth > 900 ? '1fr 1fr' : '1fr', gap: '16px', marginTop: '16px' }}>
                
                {/* SINGLES: Left - Matches Dot Grid */}
                {isSingle && (() => {
                  // Get metro name from current location
                  const metroName = currentYearData?.location ? 
                    (currentYearData.location.includes('Edwardsville') ? 'St. Louis' :
                     currentYearData.location.includes('Los Angeles') ? 'Los Angeles' :
                     currentYearData.location.includes('Sacramento') ? 'Sacramento' :
                     currentYearData.location.split(',')[0]) : 'your metro';
                  const targetGender = currentYearData?.targetGenderLabel || 'women';
                  
                  // Format match pool for display
                  const formatPool = (n) => {
                    if (n >= 1000000) return `${(n/1000000).toFixed(1)}M`;
                    if (n >= 1000) return `${Math.round(n/1000).toLocaleString()}k`;
                    return n.toLocaleString();
                  };
                  
                  // Calculate data based on location toggle
                  let displayPool = 0;
                  let displayMatches = 0;
                  let displayLocationName = metroName;
                  let nationalRealisticPool = 0; // For National percentage calculation
                  let relocationRealisticPool = 0; // For Relocation percentage calculation
                  
                  // Get tier-specific data from currentYearData
                  const getTierData = (yearData, tier) => {
                    if (!yearData) return { pool: 0, matches: 0 };
                    switch (tier) {
                      case 'Realistic':
                        return { pool: yearData.realisticPool || yearData.localSinglePool || 0, matches: yearData.realisticMatches || yearData.matchPool || 0 };
                      case 'Preferred':
                        return { pool: yearData.preferredPool || 0, matches: yearData.preferredMatches || 0 };
                      case 'Ideal':
                        return { pool: yearData.idealPool || 0, matches: yearData.idealMatches || 0 };
                      default:
                        return { pool: yearData.localSinglePool || 0, matches: yearData.matchPool || 0 };
                    }
                  };
                  
                  if (datingMatchLocation === 'Current') {
                    const tierData = getTierData(currentYearData, datingMatchTier);
                    displayPool = tierData.pool;
                    displayMatches = tierData.matches;
                    displayLocationName = metroName;
                  } else if (datingMatchLocation === 'Relocate' && hasRelocation) {
                    // Calculate population-weighted averages across relocation metros
                    let totalPool = 0;
                    let totalMatches = 0;
                    let totalRealisticPool = 0;
                    
                    // Get totals (sum of all pools/matches across metros)
                    relocationMetros.forEach(metro => {
                      const cbsa = cbsaDataLoaded?.[metro.cbsaCode];
                      if (!cbsa) return;
                      
                      const user = {
                        gender: formData.gender || 'man',
                        age: currentYearData?.age || 35,
                        income: currentYearData?.income || 100000,
                        education: currentYearData?.education || 'bachelors',
                        ethnicity: formData.ethnicity || 'white',
                        orientation: formData.orientation || 'straight',
                        hasKids: currentYearData?.children === 'Yes',
                        relationshipStatus: 'single'
                      };
                      
                      const threeTier = calculateThreeTierMatches(user, cbsa, formData.partnerPrefs || {}, formData.userProfile || {});
                      
                      // Always sum realistic pool for percentage calculation
                      totalRealisticPool += threeTier.realisticPool || 0;
                      
                      // Sum tier-specific data
                      switch (datingMatchTier) {
                        case 'Realistic':
                          totalPool += threeTier.realisticPool || 0;
                          totalMatches += threeTier.realisticMatches || 0;
                          break;
                        case 'Preferred':
                          totalPool += threeTier.preferredPool || 0;
                          totalMatches += threeTier.preferredMatches || 0;
                          break;
                        case 'Ideal':
                          totalPool += threeTier.idealPool || 0;
                          totalMatches += threeTier.idealMatches || 0;
                          break;
                      }
                    });
                    
                    displayPool = totalPool;
                    displayMatches = totalMatches;
                    relocationRealisticPool = totalRealisticPool;
                    displayLocationName = `${relocationMetros.length} relocation metro${relocationMetros.length > 1 ? 's' : ''}`;
                  } else if (datingMatchLocation === 'National') {
                    // National: Create synthetic national CBSA with national averages (all weights = 50)
                    const US_ADULT_POPULATION = 260000000; // ~260M adults 18-64
                    
                    // Build national CBSA with all weights at 50 (national average)
                    const nationalCbsa = {
                      cbsa_population: US_ADULT_POPULATION,
                      rpp: 100,
                      // Gender - use national percentages
                      gender_woman_cbsa: 50, // 50 = national average
                      gender_man_cbsa: 50,
                      female_cbsa: 51, // National: 51% women
                      male_cbsa: 49,   // National: 49% men
                      // Singles - national average
                      single_18_65_cbsa: 50,
                      relationship_single_cbsa: 38, // National: ~38% single
                      // Age brackets - national averages
                      age_18_19_cbsa: 50, age_20_24_cbsa: 50, age_25_29_cbsa: 50,
                      age_30_34_cbsa: 50, age_35_39_cbsa: 50, age_40_44_cbsa: 50,
                      age_45_49_cbsa: 50, age_50_54_cbsa: 50, age_55_59_cbsa: 50,
                      age_60_64_cbsa: 50,
                      // Income brackets - national averages
                      income_0_cbsa: 50, income_25k_cbsa: 50, income_50k_cbsa: 50,
                      income_75k_cbsa: 50, income_100k_cbsa: 50, income_150k_cbsa: 50,
                      income_200k_cbsa: 50,
                      // Education - national averages
                      bachelors_cbsa: 33, // National: ~33% bachelor's+
                      graduate_cbsa: 13,  // National: ~13% graduate
                      // Ethnicity - national averages
                      pct_white_cbsa: 58, // National: ~58% white
                      pct_black_cbsa: 12,
                      pct_asian_cbsa: 6,
                      pct_hispanic_cbsa: 19,
                      // Height brackets for men - national distribution
                      height_5_4_cbsa: 50, height_5_6_cbsa: 50, height_5_8_cbsa: 50,
                      height_5_10_cbsa: 50, height_6_0_cbsa: 50, height_6_2_cbsa: 50,
                      // BMI - national averages
                      bmi_underweight_cbsa: 50, bmi_normal_cbsa: 50,
                      bmi_overweight_cbsa: 50, bmi_obese_cbsa: 50,
                      // Fitness - national averages
                      fitness_never_cbsa: 50, fitness_1_day_cbsa: 50,
                      fitness_2_3_days_cbsa: 50, fitness_4_6_days_cbsa: 50,
                      fitness_daily_cbsa: 50,
                      // Political - national averages
                      political_liberal_cbsa: 50, political_moderate_cbsa: 50,
                      political_conservative_cbsa: 50, political_apolitical_cbsa: 50,
                      // Kids/Smoking - national averages
                      has_kids_yes_cbsa: 50, has_kids_no_cbsa: 50,
                      smoking_yes_cbsa: 50, smoking_no_cbsa: 50,
                      // Income distribution - use national median
                      income_cbsa: 75000
                    };
                    
                    const user = {
                      gender: formData.gender || 'man',
                      age: currentYearData?.age || 35,
                      income: currentYearData?.income || 100000,
                      education: currentYearData?.education || 'bachelors',
                      ethnicity: formData.ethnicity || 'white',
                      orientation: formData.orientation || 'straight',
                      hasKids: currentYearData?.children === 'Yes',
                      relationshipStatus: 'single'
                    };
                    
                    const nationalTierData = calculateThreeTierMatches(user, nationalCbsa, formData.partnerPrefs || {}, formData.userProfile || {});
                    
                    // Store national realistic pool for percentage calculation
                    nationalRealisticPool = nationalTierData.realisticPool || 0;
                    
                    switch (datingMatchTier) {
                      case 'Realistic':
                        displayPool = nationalTierData.realisticPool || 0;
                        displayMatches = nationalTierData.realisticMatches || 0;
                        break;
                      case 'Preferred':
                        displayPool = nationalTierData.preferredPool || 0;
                        displayMatches = nationalTierData.preferredMatches || 0;
                        break;
                      case 'Ideal':
                        displayPool = nationalTierData.idealPool || 0;
                        displayMatches = nationalTierData.idealMatches || 0;
                        break;
                    }
                    displayLocationName = 'the United States';
                  }
                  
                  // Use base local single pool for percentage (not tier-specific pool)
                  const baseSinglePool = currentYearData?.localSinglePool || currentYearData?.realisticPool || displayPool;
                  let basePoolForPercent = baseSinglePool;
                  if (datingMatchLocation === 'Relocate' && hasRelocation) {
                    basePoolForPercent = relocationRealisticPool;
                  } else if (datingMatchLocation === 'National') {
                    basePoolForPercent = nationalRealisticPool;
                  }
                  
                  const matchPercent = basePoolForPercent > 0 ? (displayMatches / basePoolForPercent) * 100 : 0;
                  
                  // Format percentage - show enough decimals to get a non-zero display
                  const formatPercent = (pct) => {
                    if (pct >= 1) return Math.round(pct);
                    if (pct >= 0.1) return pct.toFixed(1);
                    if (pct >= 0.01) return pct.toFixed(2);
                    if (pct >= 0.001) return pct.toFixed(3);
                    if (pct >= 0.0001) return pct.toFixed(4);
                    if (pct === 0) return '0';
                    return pct.toFixed(5);
                  };
                  const matchPercentDisplay = formatPercent(matchPercent);
                  const tierLabel = datingMatchTier.toLowerCase();
                  
                  return (
                    <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px' }}>
                      <h3 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: 0, textTransform: 'uppercase', letterSpacing: '0.05em' }}>Dating Matches</h3>
                      
                      {/* Centering wrapper */}
                      <div style={{ display: 'flex', justifyContent: 'center', marginTop: '26px' }}>
                        <div>
                          {/* Top Toggle: Location - aligned with grid left edge */}
                          <div style={{ display: 'flex', gap: '4px', marginBottom: '12px', marginLeft: '40px' }}>
                            {['Current', ...(hasRelocation ? ['Relocate'] : []), 'National'].map((option) => (
                              <button 
                                key={option}
                                onClick={() => setDatingMatchLocation(option)}
                                style={{ 
                                  height: '28px',
                                  padding: '0 12px', 
                                  fontSize: '12px', 
                                  border: 'none', 
                                  borderRadius: '4px', 
                                  backgroundColor: datingMatchLocation === option ? '#5C5A4D' : 'white',
                                  color: datingMatchLocation === option ? 'white' : '#5C5A4D',
                                  cursor: 'pointer',
                                  fontWeight: '500'
                                }}
                              >
                                {option}
                              </button>
                            ))}
                          </div>
                          
                          {/* Grid row with left toggles */}
                          <div style={{ display: 'flex', alignItems: 'flex-start' }}>
                            {/* Left Toggle: Match Type - VERTICAL */}
                            <div style={{ display: 'flex', flexDirection: 'column', gap: '4px', marginRight: '12px' }}>
                              {['Realistic', 'Preferred', 'Ideal'].map((type) => (
                                <button
                                  key={type}
                                  onClick={() => setDatingMatchTier(type)}
                                  style={{
                                    width: '28px',
                                    padding: '12px 0',
                                    fontSize: '12px',
                                    border: 'none',
                                    borderRadius: '4px',
                                    backgroundColor: datingMatchTier === type ? '#5C5A4D' : 'white',
                                    color: datingMatchTier === type ? 'white' : '#5C5A4D',
                                    cursor: 'pointer',
                                    fontWeight: '500',
                                    writingMode: 'vertical-rl',
                                    textOrientation: 'mixed',
                                    transform: 'rotate(180deg)',
                                  }}
                                >
                                  {type}
                                </button>
                              ))}
                            </div>
                            
                            {/* Grid + Summary */}
                            <div>
                              {/* Dot Grid: 10x10 = 100% */}
                              <div style={{ 
                                display: 'grid', 
                                gridTemplateColumns: 'repeat(10, 32px)', 
                                gap: '6px',
                              }}>
                                {Array.from({ length: 100 }, (_, i) => {
                                  const isFilled = i < Math.floor(matchPercent);
                                  const isPartial = i === Math.floor(matchPercent);
                                  const partialFill = matchPercent % 1;
                                  
                                  return (
                                    <div
                                      key={i}
                                      style={{
                                        width: '32px',
                                        height: '32px',
                                        borderRadius: '4px',
                                        backgroundColor: isFilled ? '#E5E2DA' : '#FAF9F5',
                                        position: 'relative',
                                        overflow: 'hidden'
                                      }}
                                    >
                                      {isPartial && partialFill > 0 && (
                                        <div style={{
                                          position: 'absolute',
                                          bottom: 0,
                                          left: 0,
                                          right: 0,
                                          height: `${partialFill * 100}%`,
                                          backgroundColor: '#E5E2DA'
                                        }} />
                                      )}
                                    </div>
                                  );
                                })}
                              </div>
                              
                              {/* Summary Text - under grid only */}
                              <div style={{ fontSize: '13px', color: '#3D3D3A', lineHeight: '1.6', marginTop: '16px' }}>
                                <span style={{ fontWeight: '600', color: '#5C5A4D' }}>{matchPercentDisplay}%</span> of single {targetGender} in {displayLocationName} are {tierLabel} matches.
                                <br />
                                <span style={{ color: '#73726C' }}>That's approximately <span style={{ fontWeight: '600' }}>{formatPool(displayMatches)}</span> potential partners.</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })()}
                
                {/* SINGLES: Right - Relocation Dating Costs */}
                {isSingle && (() => {
                  // Build sorted list: current first, then relocation metros alphabetically
                  const allMetros = hasRelocation ? [currentLocation, ...relocationLabels] : [currentLocation];
                  
                  // Determine gender for cost specifics (demo: man seeking women)
                  const isMale = currentYearData?.targetGenderLabel === 'women';
                  
                  // Build cost data dynamically from CBSA RPP values
                  const baseDateCost = 85; // Base cost for dating
                  const costData = {};
                  
                  // Current location cost
                  costData[currentLocation] = { perDate: baseDateCost, datesPerWeek: 1.5 };
                  
                  // Relocation metros - calculate cost based on RPP
                  relocationMetros.forEach(metro => {
                    const cbsa = cbsaDataLoaded?.[metro.cbsaCode];
                    const rpp = cbsa?.rpp || 100;
                    costData[metro.cbsaLabel] = { 
                      perDate: Math.round(baseDateCost * (rpp / 100)), 
                      datesPerWeek: 1.5 
                    };
                  });
                  
                  const maxCost = Math.max(...allMetros.map(m => costData[m]?.perDate || 90));
                  
                  // National median costs (gender-specific where applicable)
                  const dateBreakdown = [
                    { item: 'Personal Grooming', cost: isMale ? '$30' : '$60' },
                    { item: 'Apparel & Services', cost: '$30' },
                    { item: 'Dining Out', cost: '$112' },
                    { item: 'Drinks/Alcohol', cost: '$75' },
                    { item: 'Entertainment', cost: '$75' },
                    { item: 'Transportation', cost: '$22' },
                    { item: 'Parking/Valet', cost: '$17' },
                    { item: 'Childcare', cost: '$23' },
                    { item: 'Dating App', cost: '$65' },
                  ];
                  
                  return (
                    <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px' }}>
                      <h3 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 16px 0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Dating In Different Metro Areas</h3>
                      
                      {/* Cost Bars - relative width */}
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                        {allMetros.map((metro, idx) => {
                          const data = costData[metro] || { perDate: 90, datesPerWeek: 1.5 };
                          const barWidth = (data.perDate / maxCost) * 100;
                          const annualCost = Math.round(data.perDate * data.datesPerWeek * 52);
                          
                          return (
                            <div key={metro}>
                              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                                <span style={{ fontSize: scaledFont(11), color: '#3D3D3A', fontWeight: idx === 0 ? '600' : '400' }}>
                                  {metro}{idx === 0 ? ' (current)' : ''}
                                </span>
                                <span style={{ fontSize: scaledFont(11), fontWeight: '600', color: '#141413' }}>${data.perDate}/date</span>
                              </div>
                              <div style={{ height: '8px', backgroundColor: '#FAF9F5', borderRadius: '4px', overflow: 'hidden' }}>
                                <div style={{ 
                                  height: '100%', 
                                  width: `${barWidth}%`, 
                                  backgroundColor: '#E5E2DA',
                                  borderRadius: '4px'
                                }} />
                              </div>
                              <div style={{ fontSize: scaledFont(9), color: '#73726C', marginTop: '2px' }}>
                                ${annualCost.toLocaleString()} per year
                              </div>
                            </div>
                          );
                        })}
                      </div>
                      
                      {/* Itemized Costs */}
                      <div style={{ marginTop: '16px', paddingTop: '16px', paddingBottom: '8px', borderTop: '1px solid #e5e7eb' }}>
                        <div style={{ fontSize: scaledFont(11), color: '#3D3D3A', fontWeight: '600', marginBottom: '8px', padding: '0 16px' }}>Typical Date Breakdown</div>
                        <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', padding: '0 16px' }}>
                          {dateBreakdown.map((line) => (
                            <div key={line.item} style={{ display: 'flex', justifyContent: 'space-between', fontSize: scaledFont(11) }}>
                              <span style={{ color: '#3D3D3A' }}>{line.item}</span>
                              <span style={{ color: '#141413', fontWeight: '600' }}>{line.cost}</span>
                            </div>
                          ))}
                          {/* Total */}
                          <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: scaledFont(11), marginTop: '8px', paddingTop: '8px', borderTop: '1px solid #e5e7eb' }}>
                            <span style={{ color: '#141413', fontWeight: '600' }}>Total</span>
                            <span style={{ color: '#141413', fontWeight: '600' }}>${isMale ? '449' : '479'}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })()}
                
                {/* MARRIED: Left - Budget by Relocation */}
                {isMarried && (
                  <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px' }}>
                    <h3 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 16px 0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Family Budget by Location</h3>
                    
                    {/* Budget Bars */}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                      {(hasRelocation ? [currentLocation, ...relocationLabels] : [currentLocation]).map((metro, idx) => {
                        // Calculate thresholds from CBSA data
                        const income = currentYearData?.income || 100000;
                        
                        // Find CBSA for this metro
                        let cbsa = null;
                        if (metro !== currentLocation) {
                          const relocationMetro = relocationMetros.find(m => m.cbsaLabel === metro);
                          if (relocationMetro) {
                            cbsa = cbsaDataLoaded?.[relocationMetro.cbsaCode];
                          }
                        }
                        
                        const rpp = cbsa?.rpp || 100;
                        const baseCol = 137822;
                        const safe = Math.round(baseCol * 1.35 * (rpp / 100));
                        const functional = Math.round(baseCol * (rpp / 100));
                        const median = Math.round(80610 * (rpp / 100));
                        const t = { safe, functional, median };
                        
                        // Determine bar color based on which threshold income exceeds
                        let barColor, thresholdLabel;
                        if (income >= t.safe) { barColor = '#347613'; thresholdLabel = 'Family of 4'; }
                        else if (income >= t.functional) { barColor = '#eab308'; thresholdLabel = 'Functional'; }
                        else if (income >= t.median) { barColor = '#C86A45'; thresholdLabel = 'Median HH'; }
                        else { barColor = '#B53232'; thresholdLabel = 'Below Median'; }
                        
                        const coverage = Math.round((income / t.safe) * 100);
                        
                        return (
                          <div key={metro}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                              <span style={{ fontSize: scaledFont(11), color: '#3D3D3A', fontWeight: idx === 0 ? '600' : '400' }}>
                                {metro}{idx === 0 ? ' (current)' : ''}
                              </span>
                              <span style={{ fontSize: scaledFont(11), fontWeight: '600', color: barColor }}>{coverage}%</span>
                            </div>
                            <div style={{ height: '8px', backgroundColor: '#FAF9F5', borderRadius: '4px', overflow: 'hidden' }}>
                              <div style={{ 
                                height: '100%', 
                                width: `${Math.min(100, coverage)}%`, 
                                backgroundColor: barColor,
                                borderRadius: '4px'
                              }} />
                            </div>
                            <div style={{ fontSize: scaledFont(9), color: '#73726C', marginTop: '2px' }}>
                              ${income.toLocaleString()} income / ${t.safe.toLocaleString()} family of 4 cost
                            </div>
                          </div>
                        );
                      })}
                    </div>
                    
                    {/* Budget Breakdown - placeholder */}
                    <div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '1px solid #e5e7eb' }}>
                      <div style={{ fontSize: scaledFont(11), color: '#3D3D3A', fontWeight: '600', marginBottom: '8px', padding: '0 16px' }}>Budget Breakdown</div>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', padding: '0 16px' }}>
                        <div style={{ fontSize: scaledFont(10), color: '#73726C', fontStyle: 'italic' }}>
                          Budget breakdown items coming soon...
                        </div>
                      </div>
                    </div>
                  </div>
                )}
                
                {/* MARRIED: Right - Financial Recommendations */}
                {isMarried && (
                  <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px' }}>
                    <h3 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 16px 0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Financial Recommendations</h3>
                    
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                      {/* Recommendation Cards - placeholder for AI-generated content */}
                      <div style={{ padding: '12px', backgroundColor: '#FAF9F5', borderRadius: '4px', borderLeft: '3px solid #5C5A4D' }}>
                        <div style={{ fontSize: scaledFont(11), fontWeight: '600', color: '#141413', marginBottom: '4px' }}>Maximize Tax-Advantaged Savings</div>
                        <div style={{ fontSize: scaledFont(10), color: '#73726C', lineHeight: '1.5' }}>
                          At your income level, you should prioritize maxing out 401(k) contributions ($23,000/year) before taxable investments.
                        </div>
                      </div>
                      
                      <div style={{ padding: '12px', backgroundColor: '#FAF9F5', borderRadius: '4px', borderLeft: '3px solid #5C5A4D' }}>
                        <div style={{ fontSize: scaledFont(11), fontWeight: '600', color: '#141413', marginBottom: '4px' }}>Emergency Fund Status</div>
                        <div style={{ fontSize: scaledFont(10), color: '#73726C', lineHeight: '1.5' }}>
                          Target 6 months of expenses (approximately ${Math.round((currentYearData?.colFamily4 || 100000) / 2).toLocaleString()}) in liquid savings before aggressive investing.
                        </div>
                      </div>
                      
                      <div style={{ padding: '12px', backgroundColor: '#FAF9F5', borderRadius: '4px', borderLeft: '3px solid #5C5A4D' }}>
                        <div style={{ fontSize: scaledFont(11), fontWeight: '600', color: '#141413', marginBottom: '4px' }}>Geographic Arbitrage</div>
                        <div style={{ fontSize: scaledFont(10), color: '#73726C', lineHeight: '1.5' }}>
                          {hasRelocation 
                            ? 'Your relocation targets could significantly impact your effective income. Consider the full cost-of-living picture.'
                            : 'Consider whether remote work options could let you relocate to a lower cost-of-living area while maintaining income.'}
                        </div>
                      </div>
                    </div>
                    
                    <div style={{ marginTop: '16px', padding: '10px', backgroundColor: '#E5E2DA', borderRadius: '4px', textAlign: 'center' }}>
                      <div style={{ fontSize: scaledFont(10), color: '#73726C', fontStyle: 'italic' }}>
                        Personalized recommendations will be generated based on your complete profile.
                      </div>
                    </div>
                  </div>
                )}
                
              </div>
              
              {/* Second row for singles - show married sections */}
              {isSingle && (
                <div style={{ display: 'grid', gridTemplateColumns: windowWidth > 900 ? '1fr 1fr' : '1fr', gap: '16px', marginTop: '16px' }}>
                  {/* Family Budget by Location */}
                  <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px' }}>
                    <h3 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 16px 0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Family Budget by Location</h3>
                    
                    {/* Budget Bars */}
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                      {(hasRelocation ? [currentLocation, ...relocationLabels] : [currentLocation]).map((metro, idx) => {
                        // Calculate thresholds from CBSA data
                        const income = currentYearData?.income || 100000;
                        
                        // Find CBSA for this metro
                        let cbsa = null;
                        if (metro !== currentLocation) {
                          const relocationMetro = relocationMetros.find(m => m.cbsaLabel === metro);
                          if (relocationMetro) {
                            cbsa = cbsaDataLoaded?.[relocationMetro.cbsaCode];
                          }
                        }
                        
                        const rpp = cbsa?.rpp || 100;
                        const baseCol = 137822;
                        const safe = Math.round(baseCol * 1.35 * (rpp / 100));
                        const functional = Math.round(baseCol * (rpp / 100));
                        const median = Math.round(80610 * (rpp / 100));
                        const t = { safe, functional, median };
                        
                        // Determine bar color based on which threshold income exceeds
                        let barColor, thresholdLabel;
                        if (income >= t.safe) { barColor = '#347613'; thresholdLabel = 'Family of 4'; }
                        else if (income >= t.functional) { barColor = '#eab308'; thresholdLabel = 'Functional'; }
                        else if (income >= t.median) { barColor = '#C86A45'; thresholdLabel = 'Median HH'; }
                        else { barColor = '#B53232'; thresholdLabel = 'Below Median'; }
                        
                        const coverage = Math.round((income / t.safe) * 100);
                        
                        return (
                          <div key={metro}>
                            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4px' }}>
                              <span style={{ fontSize: scaledFont(11), color: '#3D3D3A', fontWeight: idx === 0 ? '600' : '400' }}>
                                {metro}{idx === 0 ? ' (current)' : ''}
                              </span>
                              <span style={{ fontSize: scaledFont(11), fontWeight: '600', color: barColor }}>{coverage}%</span>
                            </div>
                            <div style={{ height: '8px', backgroundColor: '#FAF9F5', borderRadius: '4px', overflow: 'hidden' }}>
                              <div style={{ 
                                height: '100%', 
                                width: `${Math.min(100, coverage)}%`, 
                                backgroundColor: barColor,
                                borderRadius: '4px'
                              }} />
                            </div>
                            <div style={{ fontSize: scaledFont(9), color: '#73726C', marginTop: '2px' }}>
                              ${income.toLocaleString()} income / ${t.safe.toLocaleString()} family of 4 cost
                            </div>
                          </div>
                        );
                      })}
                    </div>
                    
                    {/* Budget Breakdown - placeholder */}
                    <div style={{ marginTop: '16px', paddingTop: '16px', borderTop: '1px solid #e5e7eb' }}>
                      <div style={{ fontSize: scaledFont(11), color: '#3D3D3A', fontWeight: '600', marginBottom: '8px', padding: '0 16px' }}>Budget Breakdown</div>
                      <div style={{ display: 'flex', flexDirection: 'column', gap: '6px', padding: '0 16px' }}>
                        <div style={{ fontSize: scaledFont(10), color: '#73726C', fontStyle: 'italic' }}>
                          Budget breakdown items coming soon...
                        </div>
                      </div>
                    </div>
                  </div>
                  
                  {/* Financial Recommendations */}
                  <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px' }}>
                    <h3 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 16px 0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Financial Recommendations</h3>
                    
                    <div style={{ display: 'flex', flexDirection: 'column', gap: '12px' }}>
                      {/* Recommendation Cards - placeholder for AI-generated content */}
                      <div style={{ padding: '12px', backgroundColor: '#FAF9F5', borderRadius: '4px', borderLeft: '3px solid #5C5A4D' }}>
                        <div style={{ fontSize: scaledFont(11), fontWeight: '600', color: '#141413', marginBottom: '4px' }}>Maximize Tax-Advantaged Savings</div>
                        <div style={{ fontSize: scaledFont(10), color: '#73726C', lineHeight: '1.5' }}>
                          At your income level, you should prioritize maxing out 401(k) contributions ($23,000/year) before taxable investments.
                        </div>
                      </div>
                      
                      <div style={{ padding: '12px', backgroundColor: '#FAF9F5', borderRadius: '4px', borderLeft: '3px solid #5C5A4D' }}>
                        <div style={{ fontSize: scaledFont(11), fontWeight: '600', color: '#141413', marginBottom: '4px' }}>Emergency Fund Status</div>
                        <div style={{ fontSize: scaledFont(10), color: '#73726C', lineHeight: '1.5' }}>
                          Target 6 months of expenses (approximately ${Math.round((currentYearData?.colFamily4 || 100000) / 2).toLocaleString()}) in liquid savings before aggressive investing.
                        </div>
                      </div>
                      
                      <div style={{ padding: '12px', backgroundColor: '#FAF9F5', borderRadius: '4px', borderLeft: '3px solid #5C5A4D' }}>
                        <div style={{ fontSize: scaledFont(11), fontWeight: '600', color: '#141413', marginBottom: '4px' }}>Geographic Arbitrage</div>
                        <div style={{ fontSize: scaledFont(10), color: '#73726C', lineHeight: '1.5' }}>
                          {hasRelocation 
                            ? 'Your relocation targets could significantly impact your effective income. Consider the full cost-of-living picture.'
                            : 'Consider whether remote work options could let you relocate to a lower cost-of-living area while maintaining income.'}
                        </div>
                      </div>
                    </div>
                    
                    <div style={{ marginTop: '16px', padding: '10px', backgroundColor: '#E5E2DA', borderRadius: '4px', textAlign: 'center' }}>
                      <div style={{ fontSize: scaledFont(10), color: '#73726C', fontStyle: 'italic' }}>
                        Personalized recommendations will be generated based on your complete profile.
                      </div>
                    </div>
                  </div>
                </div>
              )}
              </>
            );
          })()}
          
          {/* Footer */}
          <div style={{ textAlign: 'center', padding: '16px 0', borderTop: '1px solid #e5e7eb', marginTop: '16px' }}>
            <p style={{ fontSize: scaledFont(10), color: '#9A9891', margin: 0 }}>
              Visualize uses demo data. Complete the Calculator to see your personal income trajectory.
            </p>
          </div>
        </div>
      </div>
    );
  }


  // Data Page
  if (currentPage === 'data') {
    // Use user's real data if available, otherwise use demo data
    const filledYears = formData.incomeYears.filter(y => y.year && y.income && y.location);
    const hasUserData = filledYears.length >= 3;
    
    // Build simplified user data for sidebar display
    const userData = hasUserData ? filledYears.map((row) => {
      const yearNum = parseInt(row.year);
      const income = parseInt(row.income);
      const rpp = 100; // Use national average for simplicity in sidebar
      const cpi = CPI_BY_YEAR_CALC[yearNum] || CPI_BY_YEAR_CALC[2025];
      const currentCPI = CPI_BY_YEAR_CALC[2025];
      const medianHH = MEDIAN_INCOME_BY_YEAR_CALC[yearNum] || MEDIAN_INCOME_BY_YEAR_CALC[2025];
      const povertyLine = POVERTY_LINE_BY_YEAR_CALC[yearNum] || POVERTY_LINE_BY_YEAR_CALC[2025];
      const colFamily4 = Math.round(medianHH * (rpp / 100));
      const greenLine = Math.round(colFamily4 * 1.35);
      const safe = Math.round(colFamily4 * 1.8);
      const purchasePower = Math.round(income * (currentCPI / cpi) * (100 / rpp));
      const goal = parseInt(row.goal) || 150000;
      
      // Simple percentile estimate based on national distribution
      let percentile = 50;
      if (income <= 15000) percentile = 10;
      else if (income <= 30000) percentile = 25;
      else if (income <= 50000) percentile = 40;
      else if (income <= 75000) percentile = 55;
      else if (income <= 100000) percentile = 70;
      else if (income <= 150000) percentile = 82;
      else if (income <= 200000) percentile = 88;
      else if (income <= 300000) percentile = 94;
      else if (income <= 500000) percentile = 98;
      else percentile = 99;
      
      return {
        year: yearNum,
        location: row.location,
        income,
        purchasePower,
        goal,
        greenLine,
        safe,
        medianHH,
        povertyLine,
        percentile,
      };
    }).sort((a, b) => a.year - b.year) : null;
    
    const displayData = userData || data;
    const lastYear = displayData[displayData.length - 1];
    const firstYear = displayData[0];
    
    // Calculate years below functional
    const yearsBelowFunctional = (() => {
      let count = 0;
      for (let year = firstYear.year; year <= lastYear.year; year++) {
        const yearData = displayData.find(d => d.year === year);
        if (yearData && yearData.income < yearData.greenLine) count++;
        else if (!yearData) {
          const before = displayData.filter(d => d.year < year).pop();
          const after = displayData.find(d => d.year > year);
          if (before && after) {
            const ratio = (year - before.year) / (after.year - before.year);
            const interpolatedIncome = before.income + (after.income - before.income) * ratio;
            const interpolatedGreen = before.greenLine + (after.greenLine - before.greenLine) * ratio;
            if (interpolatedIncome < interpolatedGreen) count++;
          }
        }
      }
      return count;
    })();

    const isWideScreen = windowWidth > 1024;
    const columnCount = isWideScreen ? 2 : 1;

    // Sidebar component for reuse
    const DataSidebar = ({ sticky = false }) => {
      const isCollapsible = !isWideScreen;
      const showContent = isWideScreen || dataSidebarExpanded;
      
      // If no user data, show prompt to fill out calculator
      if (!hasUserData) {
        return (
          <div style={sticky ? { position: 'sticky', top: '32px', alignSelf: 'start' } : { marginBottom: '16px' }}>
            <div style={{ 
              backgroundColor: 'white', 
              borderRadius: '4px', 
              border: '1px solid #e5e7eb', 
              padding: '16px',
            }}>
              <h3 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Your Data</h3>
              <p style={{ fontSize: scaledFont(12), color: '#73726C', margin: '0 0 12px', lineHeight: '1.5' }}>
                Complete the calculator to see your personalized income analysis here.
              </p>
              <button 
                onClick={() => setCurrentPage('calculator')}
                style={{ 
                  width: '100%',
                  padding: '10px 16px', 
                  backgroundColor: '#C96442', 
                  color: 'white', 
                  border: 'none', 
                  borderRadius: '4px', 
                  fontSize: scaledFont(11), 
                  fontWeight: '600',
                  cursor: 'pointer',
                  textTransform: 'uppercase',
                  letterSpacing: '0.05em'
                }}
              >
                Start Calculator
              </button>
            </div>
          </div>
        );
      }
      
      return (
        <div style={sticky ? { position: 'sticky', top: '32px', alignSelf: 'start' } : { marginBottom: '16px' }}>
          <div style={{ 
            backgroundColor: 'white', 
            borderRadius: '4px', 
            border: '1px solid #e5e7eb', 
            padding: '16px',
          }}>
            {/* Header with toggle for mobile */}
            <div 
              onClick={isCollapsible ? () => setDataSidebarExpanded(!dataSidebarExpanded) : undefined}
              style={{ 
                display: 'flex', 
                justifyContent: 'space-between', 
                alignItems: 'center',
                cursor: isCollapsible ? 'pointer' : 'default',
                marginBottom: showContent ? '16px' : '0',
              }}
            >
              <h3 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Your Data</h3>
              {isCollapsible && (
                <span style={{ fontSize: '12px', color: '#73726C', transform: dataSidebarExpanded ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}>▼</span>
              )}
            </div>
            
            {showContent && (
              <div style={{
                display: isWideScreen ? 'block' : 'grid',
                gridTemplateColumns: isWideScreen ? undefined : 'repeat(auto-fit, minmax(180px, 1fr))',
                gap: isWideScreen ? undefined : '12px',
              }}>
                {/* Current Income */}
                <div style={{ marginBottom: isWideScreen ? '16px' : '0', paddingBottom: isWideScreen ? '12px' : '0', borderBottom: isWideScreen ? '1px solid #e5e7eb' : 'none' }}>
                  <div style={{ fontSize: scaledFont(10), color: '#73726C', marginBottom: '2px', fontWeight: '400' }}>Current Income</div>
                  <div style={{ fontSize: scaledFont(16), fontWeight: '700', color: '#141413', fontFamily: 'monospace' }}>{formatCurrency(lastYear.income)}</div>
                  <div style={{ fontSize: scaledFont(10), color: '#73726C', fontWeight: '400' }}>{lastYear.year} · {lastYear.location}</div>
                </div>

                {/* Safe Threshold */}
                <div style={{ marginBottom: isWideScreen ? '14px' : '0', paddingBottom: isWideScreen ? '10px' : '0', borderBottom: isWideScreen ? '1px solid #f3f4f6' : 'none' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '2px' }}>
                    <span style={{ fontSize: scaledFont(11), color: '#347613', fontWeight: '600' }}>Safe</span>
                    <span style={{ fontSize: scaledFont(11), fontWeight: '700', color: '#141413', fontFamily: 'monospace' }}>{formatCurrency(lastYear.safe)}</span>
                  </div>
                  <div style={{ fontSize: scaledFont(10), color: '#73726C', fontWeight: '400' }}>
                    {lastYear.income >= lastYear.safe ? `${Math.round((lastYear.income / lastYear.safe) * 100)}% of threshold` : `${Math.round((lastYear.income / lastYear.safe) * 100)}% toward threshold`}
                  </div>
                </div>

                {/* Functional Survival */}
                <div style={{ marginBottom: isWideScreen ? '14px' : '0', paddingBottom: isWideScreen ? '10px' : '0', borderBottom: isWideScreen ? '1px solid #f3f4f6' : 'none' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '2px' }}>
                    <span style={{ fontSize: scaledFont(11), color: '#eab308', fontWeight: '600' }}>Functional</span>
                    <span style={{ fontSize: scaledFont(11), fontWeight: '700', color: '#141413', fontFamily: 'monospace' }}>{formatCurrency(lastYear.greenLine)}</span>
                  </div>
                  <div style={{ fontSize: scaledFont(10), color: '#73726C', fontWeight: '400' }}>
                    {yearsBelowFunctional} years below threshold
                  </div>
                </div>

                {/* Median Household */}
                <div style={{ marginBottom: isWideScreen ? '14px' : '0', paddingBottom: isWideScreen ? '10px' : '0', borderBottom: isWideScreen ? '1px solid #f3f4f6' : 'none' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '2px' }}>
                    <span style={{ fontSize: scaledFont(11), color: '#C86A45', fontWeight: '600' }}>Median</span>
                    <span style={{ fontSize: scaledFont(11), fontWeight: '700', color: '#141413', fontFamily: 'monospace' }}>{formatCurrency(lastYear.medianHH)}</span>
                  </div>
                  <div style={{ fontSize: scaledFont(10), color: '#73726C', fontWeight: '400' }}>
                    You earn {Math.round((lastYear.income / lastYear.medianHH) * 10) / 10}x median
                  </div>
                </div>

                {/* Poverty Line */}
                <div style={{ marginBottom: isWideScreen ? '14px' : '0', paddingBottom: isWideScreen ? '10px' : '0', borderBottom: isWideScreen ? '1px solid #f3f4f6' : 'none' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '2px' }}>
                    <span style={{ fontSize: scaledFont(11), color: '#B53232', fontWeight: '600' }}>Poverty</span>
                    <span style={{ fontSize: scaledFont(11), fontWeight: '700', color: '#141413', fontFamily: 'monospace' }}>{formatCurrency(lastYear.povertyLine)}</span>
                  </div>
                  <div style={{ fontSize: scaledFont(10), color: '#73726C', fontWeight: '400' }}>
                    {Math.round((lastYear.income / lastYear.povertyLine) * 10) / 10}x poverty line
                  </div>
                </div>

                {/* Percentile */}
                <div style={{ marginBottom: isWideScreen ? '14px' : '0', paddingBottom: isWideScreen ? '10px' : '0', borderBottom: isWideScreen ? '1px solid #f3f4f6' : 'none' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline', marginBottom: '2px' }}>
                    <span style={{ fontSize: scaledFont(11), color: '#73726C', fontWeight: '600' }}>Percentile</span>
                    <span style={{ fontSize: scaledFont(11), fontWeight: '700', color: '#141413', fontFamily: 'monospace' }}>{lastYear.percentile === 99 ? 'Top 1%' : `${lastYear.percentile}th`}</span>
                  </div>
                  <div style={{ fontSize: scaledFont(10), color: '#73726C', fontWeight: '400' }}>
                    National income rank
                  </div>
                </div>

                {/* View Report Button */}
                <div style={{ marginTop: isWideScreen ? '8px' : '0' }}>
                  <button 
                    onClick={() => setCurrentPage('report')}
                    style={{ 
                      width: '100%',
                      padding: '10px 16px', 
                      backgroundColor: '#C96442', 
                      color: 'white', 
                      border: 'none', 
                      borderRadius: '4px', 
                      fontSize: scaledFont(11), 
                      fontWeight: '600',
                      cursor: 'pointer',
                      textTransform: 'uppercase',
                      letterSpacing: '0.05em'
                    }}
                  >
                    View Full Report
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      );
    };

    return (
      <div style={{ width: '100%', padding: '32px 32px', backgroundColor: '#FAF9F5', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
        <div style={{ maxWidth: `${containerWidth}px`, margin: '0 auto' }}>
          
          {/* Header */}
          <PageHeader 
            currentPage={currentPage} 
            setCurrentPage={setCurrentPage} 
            scaledFont={scaledFont} 
            windowWidth={windowWidth} 
            containerWidth={containerWidth} 
            setContainerWidth={setContainerWidth} 
          />

          {/* Mobile sidebar - shows above content on small screens */}
          {!isWideScreen && <DataSidebar sticky={false} />}

          {/* Main grid with sidebar */}
          <div style={{ display: 'grid', gridTemplateColumns: isWideScreen ? '1fr 220px' : '1fr', gap: '20px' }}>
            
            {/* Left column - Content sections */}
            <div>

          {/* Why Four Thresholds - Collapsible */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <div 
              onClick={() => setWhyThresholdsExpanded(!whyThresholdsExpanded)}
              style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', cursor: 'pointer' }}
            >
              <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Why Four Thresholds</h2>
              <span style={{ fontSize: '12px', color: '#73726C', transform: whyThresholdsExpanded ? 'rotate(180deg)' : 'rotate(0deg)', transition: 'transform 0.2s' }}>▼</span>
            </div>
            
            {whyThresholdsExpanded && (
            <div style={{ columnCount: columnCount, columnGap: '24px', marginTop: '12px' }}>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Americans deserve income benchmarks that reflect how they actually experience money. The federal poverty line was built in 1963 on a grocery budget formula from an era when food consumed a third of household spending. Today food sits at roughly seven percent of the budget, while housing, healthcare, and childcare dominate. Yet the government still relies on a metric drafted when a Kennedy was in the White House.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Most people never learn how that line was created. I hadn't either. I assumed it was a neutral fact, a number produced by experts that marked the floor of economic life. Then I came across the sentence that explains the entire problem. The poverty line is still calculated as three times the cost of a minimum food diet in 1963, adjusted only for inflation. That was a reasonable method for that year because food truly was a massive share of spending and other data was harder to collect. Orshansky, the economist who built it, never claimed it measured adequacy. She was trying to mark the point where families were clearly in crisis.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                That crisis point bears no resemblance to what families face now. If you keep her logic but update the math to match today's spending proportions, the multiplier is no longer three. It is closer to sixteen. The crisis threshold for a family of four would not be about thirty thousand dollars. It would land near one hundred forty thousand. Not comfort. Not security. The modern version of too little. That single fact explains why the middle class feels poorer each year while official statistics insist the country is doing fine. We are measuring the economy with a yardstick built for a world that no longer exists.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                True, a family earning forty thousand clears the official poverty bar but cannot secure a basic two bedroom apartment in most major metros. Precision has drifted away from reality, and public policy has followed it off course. Better measurements exist.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Michael Green's Functional Survival threshold takes the question the government has avoided. What income allows a household to absorb a shock without sliding into debt. His answer is straightforward. Multiply the local cost of living by 1.35. That thirty five percent buffer is the difference between a repair bill being an inconvenience or a crisis. Brookings researchers arrive in the same neighborhood through a different model focused on raising children without constant financial strain. The results are not political statements. They are simple math that challenges a familiar narrative.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Relate Markets builds on this work with four thresholds that describe four different realities. The poverty line shows where public assistance begins and how far the official floor has drifted from lived experience. Functional Survival shows where stability starts, the point where a two thousand dollar car repair does not rearrange a month. Median household income shows the midpoint of the country, the reference most people use when they ask if they are doing alright. And the Safe threshold marks where a family can finally plan, save, and live without constant financial triage.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Nobody sets a life goal at one and a half times the poverty line. People want room to breathe and the freedom to think beyond the next bill. These benchmarks map that climb.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Context shapes every one of them. Earning one hundred fifty thousand in San Francisco has little resemblance to earning the same amount in Memphis. The same salary feels different at twenty eight than it does at forty five. A number untouched by geography, age, and time gives a distorted account of anyone's footing. You need the full map. The floor, the middle, and the point where real security begins.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The poverty line, median income, and our functional survival and safe thresholds create that landscape. Your position on that landscape is the meaningful story.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Relate Markets also provides two additional scores. The Relate Score and Match Score reflect another part of modern economic life. Relationships now operate with their own market signals. Dating platforms rank users with systems modeled on chess ratings. Those rankings determine visibility, which in turn is shaped by income driven signals like neighborhood, education, and the environments shown in photos. At the same time, financial strain is one of the strongest predictors of divorce, and women initiate most divorces. The research on preference patterns is consistent. Women tend to seek partners whose economic footing matches or exceeds their own.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                This is not a moral argument. It is a description of how incentives form and how systems behave. Relate Markets gives users a view into that terrain so they can understand the forces shaping their choices. Dating platforms already calculate versions of these scores in the background. Now the individual can see the economic and social structure that influences their options.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Understanding your position and your income arc does not solve every constraint, but it replaces guesswork with information. In an economy where perception and reality often drift apart, that alone is progress.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 16px', lineHeight: '1.6' }}>
                Money does not solve everything. But everything around us sorts us by what we have and what we do not. You might as well know where you stand.
              </p>
            </div>
            )}
          </div>

          {/* Safe As A Family Of Four */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#347613', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Safe As A Family Of Four</h2>
            
            <div style={{ columnCount: columnCount, columnGap: '24px' }}>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The Safe threshold answers a question that most financial calculators ignore: what does it actually cost to raise a family without the constant hum of money anxiety? Not surviving. Not getting by. Actually thriving, where a broken appliance or a kid's soccer registration does not require mental accounting against next month's bills.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The USDA tracked child-rearing costs and landed on $233,610 per child in 2015 dollars, birth through age 17. Adjust for inflation and you reach roughly $310,700 per child in 2025. Two kids means $621,400 total, or about $36,550 per year in direct expenses before you count housing, food, or anything the parents need for themselves.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Financial planners suggest child costs should consume no more than 15% of household income. Run that backward: $36,550 at 15% requires household income around $244,000. Regional adjustments push the 2025 national figure to approximately $248,000.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The implementation multiplies the base family-of-four cost of living by 1.80. In a metro where baseline costs sit at $138,000, the Safe threshold becomes $248,400. This multiplier captures child expenses plus the buffer that separates "making it work" from genuine security. It includes room for savings, for the occasional family vacation, for saying yes to opportunities without first checking the account balance.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Regional Price Parity keeps the threshold honest. San Francisco families need more nominal dollars than St. Louis families to reach the same quality of life. The Safe line adjusts accordingly.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Crossing this line does not mean rich. It means your kids can do the activities. It means the car repair is annoying, not destabilizing. The green line on your chart marks this territory. Years above it are years of genuine family financial health, where money serves life rather than constraining it.
              </p>
              <div style={{ fontSize: scaledFont(10), color: '#73726C', marginTop: '16px', paddingTop: '12px', borderTop: '1px solid #e5e7eb' }}>
                <strong>Sources:</strong> USDA Center for Nutrition Policy and Promotion, "Expenditures on Children by Families" (2015 report, inflation-adjusted). Brookings Institution analysis of child-rearing costs. Bureau of Labor Statistics Consumer Expenditure Survey. Bureau of Economic Analysis Regional Price Parities.
              </div>
            </div>
          </div>

          {/* Functional Survival */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#eab308', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Functional Survival</h2>
            
            <div style={{ columnCount: columnCount, columnGap: '24px' }}>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                This threshold marks where survival becomes stability. Not comfort, not thriving, just the floor where a $2,000 emergency does not send everything sliding.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Michael Green developed the methodology in his "Yes I Give A Fig" analysis after observing that existing measures failed families. The poverty line captures starvation risk. Cost of living figures capture breakeven. Neither accounts for the buffer that real life demands. His research pointed to a multiplier of 1.35 applied to baseline costs.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Below this line, families operate in permanent crisis mode. Every purchase runs through a mental filter. There is no slack for the inevitable surprises. A child's broken glasses triggers anxiety. A parking ticket becomes a budget crisis. The cumulative weight of this vigilance compounds into exhaustion that outsiders rarely see.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The 35% buffer exists because cars break, kids get sick, furnaces die in February. Emergencies do not check your calendar. At the Functional level, these events stay manageable. Small savings accumulate. Insurance deductibles become payable. Short disruptions remain short.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                For 2025, the national threshold lands around $186,000 for a family of four. Regional adjustments shift this based on local costs. The yellow line on your chart tracks this across your trajectory.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The "Years Below Functional" stat card counts how many years you spent in the danger zone, interpolating between your data points to catch every year. For those who climbed out, this number quantifies the weight carried. For those still below, it names the ongoing strain that financial conversations often skip.
              </p>
              <div style={{ fontSize: scaledFont(10), color: '#73726C', marginTop: '16px', paddingTop: '12px', borderTop: '1px solid #e5e7eb' }}>
                <strong>Sources:</strong> Michael Green, "Yes I Give A Fig" (Functional Threshold methodology). Bureau of Labor Statistics Consumer Expenditure Survey. Bureau of Economic Analysis Regional Price Parities. Census Bureau income distribution data.
              </div>
            </div>
          </div>

          {/* Median Household */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#C86A45', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Median Household</h2>
            
            <div style={{ columnCount: columnCount, columnGap: '24px' }}>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Half of American households earn more than this figure. Half earn less. For 2025, the median sits at approximately $80,610, sourced from Census Bureau Historical Income Tables.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The median matters because it resists distortion. When billionaires skew averages upward, the median stays planted in reality. It tells you what an actual household in the actual middle brings home. Above the orange line means you earn more than most American families. Below means you earn less.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Track it across time and you see American economic history compressed into a line. In 1998, median household income was $38,885. By 2025 it reached $80,610. Looks like progress until you adjust for inflation and housing costs. Real gains have been modest. Many households ran faster just to stay even as costs climbed around them.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The orange line tracks this across your trajectory. When your income crosses above it, you have moved into the upper half of earners. The distance between your line and the median shows how far you sit from the middle. Often this relative position matters more than the raw number.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                One catch: median household income is national. It ignores regional cost differences. Earning the median in Mississippi buys far more than earning the median in Manhattan. Relate Markets handles this separately through Regional Price Parity adjustments. The median gives national context. RPP gives local context. Together they complete the picture.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Many people carry a vague sense of being "middle class" without knowing where the middle actually sits. Seeing your income relative to this line can clarify things, sometimes reassuringly, sometimes not. Either way, concrete data beats vague feelings.
              </p>
              <div style={{ fontSize: scaledFont(10), color: '#73726C', marginTop: '16px', paddingTop: '12px', borderTop: '1px solid #e5e7eb' }}>
                <strong>Sources:</strong> U.S. Census Bureau Historical Income Tables (Table H-8). Current Population Survey Annual Social and Economic Supplement. Federal Reserve Survey of Consumer Finances.
              </div>
            </div>
          </div>

          {/* Poverty Line */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#B53232', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Poverty Line</h2>
            
            <div style={{ columnCount: columnCount, columnGap: '24px' }}>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                In 1963, economist Mollie Orshansky created the federal poverty measure using a formula: minimum food diet cost times three. Back then, food consumed roughly a third of household budgets. The math made sense. The figure has been inflation-adjusted annually ever since, but the underlying methodology remains frozen in the Kennedy administration.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                For a family of four in 2025, poverty means earning below approximately $32,150. This single number gates access to Medicaid, SNAP, housing assistance, and dozens of other programs. Millions of policy decisions flow from it.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Nearly everyone who studies poverty agrees the threshold is broken. Food now represents 5 to 7 percent of typical household spending, not 33 percent. Housing, healthcare, childcare, and transportation devour modern budgets while food costs have stayed relatively flat. A formula calibrated to 1963 spending patterns produces a number disconnected from how families actually live.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The red line marks this threshold on your chart. It sits at the bottom of the visualization, the floor below which the federal government officially acknowledges hardship. But look at the gap between this line and Functional Survival. A family earning $40,000 technically escapes poverty yet cannot cover basic expenses in most metros. The official definition and lived reality barely overlap.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Geography compounds the problem. The poverty line ignores regional costs entirely. Official poverty costs the same in San Francisco as in rural Mississippi, despite housing differing by factors of three or four.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Relate Markets includes the poverty line for historical context and to complete the spectrum of thresholds. But Functional Survival and Safe better reflect what families actually need. The poverty line tells you where government programs begin. The other thresholds tell you where stability begins.
              </p>
              <div style={{ fontSize: scaledFont(10), color: '#73726C', marginTop: '16px', paddingTop: '12px', borderTop: '1px solid #e5e7eb' }}>
                <strong>Sources:</strong> Department of Health and Human Services Poverty Guidelines (annual). Census Bureau Historical Poverty Tables. Mollie Orshansky, "Counting the Poor: Another Look at the Poverty Profile" (1965). National Academy of Sciences poverty measurement recommendations.
              </div>
            </div>
          </div>

          {/* Relate Score */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#6650A1', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Relate Score</h2>
            
            <div style={{ columnCount: columnCount, columnGap: '24px' }}>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Can they understand your journey? Not tolerate it, not benefit from it, but actually comprehend what you went through to get here. The scarcity years. The climb. The specific weight of decisions made when money was tight. The Relate Score attempts to quantify this.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Five factors feed the score, weighted differently by gender. Income percentile carries the heaviest weight for men (45%) and lighter weight for women (25%), reflecting research on how income shapes dating outcomes asymmetrically. Education, age relative to preference windows, local demographic match, and parental status round out the inputs.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Location adjustment matters. Earning $200,000 in San Francisco positions you differently than $200,000 in St. Louis. The algorithm compresses scores in competitive metros and expands them in thinner markets. Your Relate Score reflects your actual dating pool, not some national abstraction.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The scale runs 0 to 10. Above 7 means high-relatability partners exist in meaningful numbers locally. Between 4 and 7 suggests you will need to filter intentionally. Below 4 means most available partners will struggle to viscerally understand your financial path.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Hypergamy cuts into relatability in specific ways. Women tend to partner with men of equal or higher status, which narrows the pool for high-earning women. But the relatability problem goes deeper. A man who always earned well may not grasp the anxiety of climbing from nothing. A man who started where you did but stayed there may not grasp the psychological distance you traveled. High-earning men face the inverse: hypergamy expands their numerical pool but can reduce experiential overlap when partners come from different economic origins.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The score cannot capture emotional intelligence or willingness to learn. Someone with low experiential overlap but high empathy might exceed predictions. Someone with a matching trajectory but poor attunement might disappoint. The Relate Score identifies probability of baseline comprehension, not connection quality.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                On the chart, the purple line tracks your Relate Score across time. It shows how your positioning evolved as income, location, and circumstances shifted. Scores during married years reflect hypothetical market position, useful for understanding what divorce or widowhood changed.
              </p>
              <div style={{ fontSize: scaledFont(10), color: '#73726C', marginTop: '16px', paddingTop: '12px', borderTop: '1px solid #e5e7eb' }}>
                <strong>Sources:</strong> Buss (1989), cross-cultural mate preferences. Hitsch, Hortacsu, Ariely (2010), online dating behavioral analysis. Bruch and Newman (2018), dating app desirability patterns. Bertrand, Kamenica, Pan (2015), gender identity and relative income within households. Census Bureau demographic distributions by CBSA.
              </div>
            </div>
          </div>

          {/* Match Score */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#A193D8', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Match Score</h2>
            
            <div style={{ columnCount: columnCount, columnGap: '24px' }}>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                How many people meet your criteria? Of those, how many would consider you? Of that overlap, how many are realistically accessible? The Match Score collapses this supply-demand problem into a single percentage.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Dating platforms run on Elo-derived systems. Every user carries a hidden desirability rating. A right-swipe from a high-rated profile boosts your rating. Rejection from one drops it. Over time, users converge into tiers and mostly see profiles within their tier. Cross-tier matching is rare regardless of what you want.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The Match Score multiplies probabilities. Start with the base rate of partners meeting your criteria in the population. Multiply by the odds they exist in your tier. Multiply by mutual interest given tier overlap. Multiply by conversion from match to relationship. Each step shrinks the number, often dramatically.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                A sigmoid function converts your composite score to probability. Score 50 yields 50%. Score 30 drops to roughly 12%. Score 70 climbs to about 88%. The curve flattens at the extremes because neither perfection nor rock-bottom are truly reachable.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Hypergamy reshapes these probabilities by gender. Women tend to prefer partners earning at least as much as they do. For men, higher income expands the pool of interested women. For women, higher income shrinks the pool of men meeting the equal-or-higher bar. A woman earning $300,000 fishes in a much smaller pond than a man at the same income. The algorithm applies different weights and pool calculations accordingly.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Above 30% means favorable conditions. Patience and volume should produce results. Between 10% and 30% means challenging but viable, requiring strategic adjustments. Below 10% suggests your criteria may be statistically incompatible with local supply.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The match pool figure shows raw counts. A 30% score in a metro with 150,000 singles means roughly 45,000 potential matches exist. Even small percentages produce large numbers in major metros. High percentages can mean thin pools in smaller markets.
              </p>
              <div style={{ fontSize: scaledFont(10), color: '#73726C', marginTop: '16px', paddingTop: '12px', borderTop: '1px solid #e5e7eb' }}>
                <strong>Sources:</strong> Bruch and Newman (2018), quantitative analysis of dating markets. Hitsch, Hortacsu, Ariely (2010), mate preferences in online dating. Feliciano, Robnett, Komaie (2009), racial preferences in dating. Bertrand, Kamenica, Pan (2015), gender identity and relative income within households. Census Bureau American Community Survey single population by CBSA.
              </div>
            </div>
          </div>

          {/* Relate's Three Pools */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#5C5A4D', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Relate's Three Pools</h2>
            
            <div style={{ columnCount: columnCount, columnGap: '24px' }}>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Dating markets operate on cascading filters. Each preference you hold reduces the available pool. Our three-tiered module separates these filters into meaningful stages, showing how your pool shrinks from realistic to preferred to ideal.
              </p>
              
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '16px 0 6px', lineHeight: '1.6', fontWeight: '600' }}>
                Tier 1: Realistic Pool
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Start with the metro population. Remove those over 65 (23%) and homeless (0.5%). Apply the gender filter with local weight adjustments. Factor in orientation: straight users see 91% of the opposite gender pool, gay/lesbian users see 4% of same gender, bisexual users see the combined straight and bisexual populations.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Next, remove felons using stratified rates by gender, ethnicity, and education. Men carry higher rates than women. People of color carry higher rates than white populations. Those without degrees carry higher rates than graduates. The intersections compound: a man of color without a degree faces a 29% removal rate; a white woman with a bachelor's faces 0.5%.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Drug use follows similar stratification. Then apply relationship status with local weighting. Finally, filter by your stated age range and minimum income preferences. The result is your Realistic Pool: everyone who passes basic demographic and legal filters.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                A sigmoid function converts your competitive position (age and income relative to local distributions) into Realistic Matches: the subset of the Realistic Pool statistically likely to match with you.
              </p>
              
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '16px 0 6px', lineHeight: '1.6', fontWeight: '600' }}>
                Tier 2: Preferred Pool
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Starting from Realistic Matches, apply your stated preferences. Ethnicity filters using local demographic weights. Education filters cumulatively: selecting "bachelor's" includes both bachelor's and graduate degree holders. Political views, parental status, and smoking preferences each remove non-matching segments.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Another sigmoid function evaluates how your own attributes (ethnicity, education, politics, parental status, smoking) align with your stated preferences. Someone demanding traits they lack themselves faces steeper probability reductions. The output is Preferred Matches.
              </p>
              
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '16px 0 6px', lineHeight: '1.6', fontWeight: '600' }}>
                Tier 3: Ideal Pool
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The final tier applies physical preferences. For women seeking men, minimum height filters using local height distribution brackets. Body type preferences remove non-matching segments. Fitness frequency applies conditionally: only when your body type selections are limited to average and/or overweight, since selecting lean/fit already implies fitness, and selecting obese makes fitness filtering moot.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The final sigmoid evaluates your own physical attributes against your stated preferences. A man demanding partners over 6'0" while standing 5'6" faces probability penalties. Someone requiring lean/fit bodies while carrying obesity faces similar reductions.
              </p>
              
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '16px 0 6px', lineHeight: '1.6', fontWeight: '600' }}>
                Why Three Tiers Matter
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The cascade reveals where your preferences cost you the most. Someone with 50,000 Realistic Matches might discover that ethnicity and education preferences cut the Preferred Pool to 8,000. Physical preferences might shrink Ideal Matches to 400. Seeing each stage separately lets you identify which filters carry the highest cost.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                Relocation decisions become clearer when viewed through all three tiers. A metro might triple your Realistic Pool while barely moving the Ideal needle if local demographics don't match your preferences. Another metro might offer modest Realistic gains but double your Preferred Matches because its population skews toward your stated criteria.
              </p>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
                The percentages shown represent matches as a share of the Realistic Pool, not the tier-specific pool. This keeps the baseline consistent. When the Visualize page shows "0.4% of single women are Ideal Matches," that 0.4% is measured against all single women passing basic filters, not against the already-reduced Preferred Pool. This prevents inflated percentages that would obscure how selective your full criteria stack has become.
              </p>
              <div style={{ fontSize: scaledFont(10), color: '#73726C', marginTop: '16px', paddingTop: '12px', borderTop: '1px solid #e5e7eb' }}>
                <strong>Methodology:</strong> Pool calculations use Census Bureau American Community Survey demographic distributions by CBSA. Felon rates derived from Bureau of Justice Statistics publications stratified by gender, race, and education. Drug use rates from SAMHSA National Survey on Drug Use and Health. Sigmoid functions calibrated to dating market research from Bruch and Newman (2018). Local weights normalize CBSA-specific distributions against national averages.
              </div>
            </div>
          </div>

            </div>
            
            {/* Right column - Sticky sidebar (desktop only) */}
            {isWideScreen && <DataSidebar sticky={true} />}

          </div>
        </div>
      </div>
    );
  }

  // Glossary Page
  if (currentPage === 'glossary') {
    return (
      <div style={{ width: '100%', padding: '32px 32px', backgroundColor: '#FAF9F5', minHeight: '100vh', fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif' }}>
        <div style={{ maxWidth: `${containerWidth}px`, margin: '0 auto' }}>
          
          {/* Header */}
          <PageHeader 
            currentPage={currentPage} 
            setCurrentPage={setCurrentPage} 
            scaledFont={scaledFont} 
            windowWidth={windowWidth} 
            containerWidth={containerWidth} 
            setContainerWidth={setContainerWidth} 
          />

          {/* Summary */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Summary</h2>
            
            <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
              Relate Markets exists because a single income number tells you almost nothing. Earning $150,000 means something very different in a coastal metro than in the Midwest, in 2008 than in 2024, at age 28 than at age 45. Most financial tools ignore this. They show you where you stand today without any sense of the ground you've covered or the terrain you crossed to get there.
            </p>
            
            <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
              This tool reconstructs your full income trajectory and adjusts every data point for inflation, regional cost of living, and national income distribution. Each year gets translated into comparable terms so you can see real progress rather than nominal changes. A raise that merely kept pace with inflation looks different from one that actually moved you up the ladder. A move from a cheap metro to an expensive one might erase years of apparent gains. These dynamics only become visible when you track income across time and place simultaneously.
            </p>
            
            <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: '0 0 12px', lineHeight: '1.6' }}>
              The calculations draw from federal data sources including the Consumer Price Index, Bureau of Economic Analysis Regional Price Parities, Census Bureau income tables, and Current Population Survey microdata. Cost of living thresholds come from the Bureau of Labor Statistics Consumer Expenditure Survey, adjusted to each metro. The functional threshold methodology adapts research on what families actually need to achieve financial stability rather than just survival.
            </p>
            
            <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.6' }}>
              What makes this different from a standard income chart is the layering of context. You see your trajectory against the national median, against what a family needs to cover basic costs, against the threshold where financial shocks stop being crises. You see how your past self compares to your present self in equivalent dollars. The result is less a financial report and more a map of the economic landscape you've navigated, with markers showing where you were fragile, where you stabilized, and where you finally pulled ahead.
            </p>
          </div>

          {/* Income Metrics */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Income Metrics</h2>
            
            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#5C5A4D', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Income</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                Your gross annual income for each year. Everything else in Relate Markets derives from this number. Dark olive line on the chart.
              </p>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#1B6CB5', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>{data.length > 0 ? `$${Math.round(data[data.length-1].income/1000)}k` : '$700k'} Equivalent (Equiv)</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                What your current income would have purchased in each historical year, adjusted for both inflation and where you lived. If you earn {data.length > 0 ? `$${Math.round(data[data.length-1].income/1000)}k` : '$700k'} today, this line shows how far that money would have stretched in 2005 dollars or 2015 dollars. It answers the question of what you would have been back then, except calculated properly, with regional cost of living baked in. Blue line.
              </p>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#2E8AD8', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Initial Goal</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                What you thought you needed to "feel rich" at each point in your career. Most people's number creeps upward as income grows. The goalpost moves. Tracking this reveals whether you've actually arrived somewhere or just kept chasing. Light blue dashed line.
              </p>
            </div>
          </div>

          {/* Threshold Lines */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Threshold Lines</h2>
            
            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#347613', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Safe As A Family Of Four</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                Where a family of four can actually thrive rather than just survive. Kids can do the activities. Parents can save for retirement. A busted transmission is annoying, not catastrophic. We calculate this as cost of living × 1.80, which accounts for child-rearing expenses plus enough buffer that you're not constantly triaging bills. Green dashed line.
              </p>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#eab308', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Functional Survival</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                The line between "one bad month could ruin us" and "we can absorb a shock." Based on Michael Green's research: local cost of living × 1.35. That 35% buffer is what it takes to handle a job loss, a medical bill, or a major car repair without spiraling into debt. Below this line, you're one emergency away from crisis. Above it, emergencies become inconveniences. Yellow dashed line.
              </p>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#C86A45', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Median Household Income</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                Half of American households earn more than this, half earn less. About $80,610 in 2025. It's the number most people instinctively use when asking themselves whether they're doing okay. The middle of the pack, the benchmark for normal. Orange dashed line.
              </p>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#B53232', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Poverty Line</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                The federal threshold, based on a 1963 formula that tripled a minimum food budget. About $32,150 for a family of four in 2025. Widely criticized as absurdly outdated. Food consumed a third of household budgets when Kennedy was president, now it's barely 7%. Yet it remains the official floor for assistance programs and policy debates. Red dashed line.
              </p>
            </div>
          </div>

          {/* Chart Zones */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Chart Zones</h2>
            
            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#347613', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Aspiration Zone</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                The green shaded area between the Safe (Family Of Four) threshold and your Initial Goal. This is the level up zone, the territory between survival and aspiration. Early on, you're fighting to reach the Safe line just to keep your head above water. Once you clear it, your sights shift upward to the goal you set for yourself. The shading makes that progression visible: survival first, then ambition.
              </p>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#eab308', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Functional Zone</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                The yellow shaded area between your income and the Functional Survival line. When you're inside this zone, you've escaped financial fragility. You can absorb shocks without spiraling. The first year you enter it is worth noticing. The deeper you are into this zone, the more breathing room you have.
              </p>
            </div>
          </div>

          {/* Goal Achievement */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Goal Achievement</h2>
            
            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#9A9891', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>% Achieved</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                Your income as a percentage of your goal for that year. At 100% you've hit your target. At 150% you're earning half again what you thought you'd need. At 350% you're living in a world your younger self couldn't have imagined. Gray dashed line.
              </p>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#5C5A4D', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Purchase Power</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                Your past income translated into today's dollars. That $45k you made in 2008? This shows what it would actually buy now, accounting for inflation and where you lived at the time. It's the honest comparison. What your old life would cost if you tried to live it today. Dark olive dashed line.
              </p>
            </div>
          </div>

          {/* Percentile Metrics */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Percentile Metrics</h2>
            
            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: '#141413', backgroundColor: '#C5C2BA', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Income Percentile (Pctl)</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                Where you rank nationally. The 75th percentile means you out-earn 75% of American households. What most people don't realize is how compressed the top is. The jump from 90th to 95th percentile is often larger than the jump from 50th to 75th. On the chart, up is better: the line climbs toward "1%" at the top as you advance through the distribution. The percentile data comes from Census Bureau microdata via IPUMS, recalculated annually. Light gray line.
              </p>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#141413', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Regional Price Parity (RPP)</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                How expensive your metro is compared to the national average of 100. Washington DC at 108.6 means everything costs 8.6% more than typical. Boise at 93.4 means 6.6% cheaper. This is why the same salary buys completely different lives in different cities, and why we adjust for it throughout the analysis.
              </p>
            </div>
          </div>

          {/* Relationship Scores */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Relationship Scores</h2>
            
            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#6650A1', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Relate Score (0-10)</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                A composite score for your local dating market, weighing income percentile, education, age, and demographics. Location-adjusted because $150k plays very differently in Manhattan than in Memphis. Dating apps already run similar calculations behind the scenes to decide who sees your profile. We're just showing you the math. Purple dashed line.
              </p>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: '#141413', backgroundColor: '#A193D8', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Match Score (%)</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                The percentage of local singles who meet your preferences AND whose preferences you meet. Mutual compatibility. A 30% score with 155k singles in your metro means roughly 47k realistic matches. The number sounds big until you realize how fast selectivity compounds. Each filter you add cuts the pool dramatically. Light purple dashed line.
              </p>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#141413', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Marriage Premium</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                Married men statistically out-earn single men. Whether marriage causes success or successful men marry more is debated, but the correlation is real. For women the picture is more complicated and varies by career stage. We factor these dynamics into the relationship calculations.
              </p>
            </div>
          </div>

          {/* Analysis Cards */}
          <div style={{ backgroundColor: 'white', borderRadius: '4px', border: '1px solid #e5e7eb', padding: '16px', marginBottom: '16px' }}>
            <h2 style={{ fontSize: scaledFont(13), fontWeight: '700', color: '#141413', margin: '0 0 12px', textTransform: 'uppercase', letterSpacing: '0.05em' }}>Analysis Sections</h2>
            
            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#141413', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Key Findings</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                Five bullets summarizing your trajectory's major themes. The executive summary.
              </p>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#141413', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Context by Year</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                Year-by-year narrative of your trajectory. Each entry combines the quantitative (income change, percentile shift, cost of living comparison) with the qualitative (what was happening in your life, what the economy was doing, why you made the moves you made). The goal isn't just to show the numbers but to explain what each year actually meant. A 15% raise during the 2008 crash lands differently than the same raise in a boom year. A lateral move to a cheaper city might look flat on paper but represent massive purchasing power gains. This section surfaces those dynamics.
              </p>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#141413', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Rarity Analysis</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                What makes your path statistically unusual. Maybe it's intergenerational mobility. Moving from the 38th percentile to the 99th happens in fewer than 2% of cases. Maybe it's recovery from divorce, or late-career acceleration, or geographic arbitrage that worked. Whatever sets your trajectory apart from the typical outcome, this section names it.
              </p>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#141413', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Inflation Impact</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                Did your raises actually outrun inflation, or did rising costs quietly eat your gains? A 3% annual raise sounds fine until you realize inflation ran 4%. This section breaks down which years you genuinely advanced in purchasing power versus which years you were just running to stay in place. It also accounts for regional cost shifts. If you moved from Boise to San Francisco, your 40% raise might have been a real-terms pay cut.
              </p>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#141413', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>Scarcity Mindset</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                How early financial constraint may have shaped your relationship with money. If you spent years below the Functional Survival line, especially formative years in your twenties, those years left marks. You might still feel the urge to stockpile, to catastrophize small expenses, to treat every purchase as a moral failing. Your bank account says you're safe; your nervous system never got the memo. Research on scarcity psychology shows these patterns persist long after the material conditions change. This section looks at what your specific trajectory suggests about the money scripts you might be running.
              </p>
            </div>

            <div style={{ marginBottom: '14px' }}>
              <span style={{ display: 'inline-block', fontSize: scaledFont(11), fontWeight: '600', color: 'white', backgroundColor: '#141413', padding: '2px 8px', borderRadius: '4px', marginBottom: '4px' }}>What You're Creating</span>
              <p style={{ fontSize: scaledFont(12), color: '#3D3D3A', margin: 0, lineHeight: '1.5' }}>
                Your kids start where you are now, not where you started. That gap is the legacy.
              </p>
            </div>
          </div>
        </div>
      </div>
    );
  }
}